import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import zlib from 'node:zlib';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const publicDir = path.resolve(__dirname, '../public');

// Compute CRC32 for PNG chunks
const CRC_TABLE = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  }
  CRC_TABLE[n] = c;
}

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

function makeChunk(type, data) {
  const typeBuf = Buffer.from(type, 'ascii');
  const lenBuf = Buffer.alloc(4);
  lenBuf.writeUInt32BE(data.length, 0);

  const body = Buffer.concat([typeBuf, data]);
  const crcVal = crc32(body);
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crcVal, 0);

  return Buffer.concat([lenBuf, body, crcBuf]);
}

function createPngBuffer(width, height) {
  const signature = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

  // IHDR chunk
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8; // bit depth
  ihdrData[9] = 6; // color type RGBA
  ihdrData[10] = 0; // compression
  ihdrData[11] = 0; // filter
  ihdrData[12] = 0; // interlace
  const ihdrChunk = makeChunk('IHDR', ihdrData);

  // Raw pixel generation: Deep navy tile (#090D16), glowing indigo arc, gold badge
  const rowBytes = width * 4;
  const rawData = Buffer.alloc((1 + rowBytes) * height);
  const cx = width / 2;
  const cy = height / 2;
  const radius = width * 0.46;

  for (let y = 0; y < height; y++) {
    const rowOffset = y * (1 + rowBytes);
    rawData[rowOffset] = 0; // Filter byte 0 (None)

    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * 4;
      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Default outer border / tile background
      let r = 11, g = 17, b = 32, a = 255; // #0B1120

      // Rounded rect container
      const cornerR = width * 0.22;
      const inCornerX = x < cornerR ? cornerR - x : x > width - cornerR ? x - (width - cornerR) : 0;
      const inCornerY = y < cornerR ? cornerR - y : y > height - cornerR ? y - (height - cornerR) : 0;
      const cornerDist = Math.sqrt(inCornerX * inCornerX + inCornerY * inCornerY);
      if (cornerDist > cornerR) {
        a = 0; // Transparent outside rounded squircle
      } else {
        // Glowing circular arc for "Q"
        const ringR = width * 0.3;
        const ringDist = Math.abs(dist - ringR);
        if (ringDist < width * 0.035 && (x > width * 0.22 || y > height * 0.4)) {
          r = 99; g = 102; b = 241; // Indigo #6366F1
        }
        // Inner ledger box
        if (x >= width * 0.32 && x <= width * 0.65 && y >= height * 0.32 && y <= height * 0.62) {
          r = 15; g = 23; b = 42; // #0F172A
          if (Math.abs(y - height * 0.4) < 3 || Math.abs(y - height * 0.48) < 3) {
            r = 100; g = 116; b = 139; // Ledger line
          } else if (Math.abs(y - height * 0.55) < 3 && x < width * 0.55) {
            r = 16; g = 185; b = 129; // Emerald line #10B981
          }
        }
        // Gold "CA" badge in top-right
        if (x >= width * 0.64 && x <= width * 0.88 && y >= height * 0.14 && y <= height * 0.25) {
          r = 245; g = 158; b = 11; // Gold #F59E0B
        }
        // Q Tail
        if (x > width * 0.65 && y > height * 0.65 && Math.abs(dx - dy) < width * 0.05 && dist < width * 0.44) {
          r = 79; g = 70; b = 229; // Indigo #4F46E5
        }
      }

      rawData[pxOffset] = r;
      rawData[pxOffset + 1] = g;
      rawData[pxOffset + 2] = b;
      rawData[pxOffset + 3] = a;
    }
  }

  const deflated = zlib.deflateSync(rawData, { level: 9 });
  const idatChunk = makeChunk('IDAT', deflated);
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function run() {
  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }

  const icon512 = createPngBuffer(512, 512);
  const icon192 = createPngBuffer(192, 192);
  const iconApple = createPngBuffer(180, 180);

  fs.writeFileSync(path.join(publicDir, 'icon-512.png'), icon512);
  fs.writeFileSync(path.join(publicDir, 'icon-192.png'), icon192);
  fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), iconApple);

  console.log('✅ Generated Questify CA brand icons in /public:');
  console.log('   - icon-512.png (512x512)');
  console.log('   - icon-192.png (192x192)');
  console.log('   - apple-touch-icon.png (180x180)');
}

run();
