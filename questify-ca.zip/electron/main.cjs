const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');

let mainWindow = null;

function getStorageFilePath() {
  const userDataDir = app.getPath('userData');
  if (!fs.existsSync(userDataDir)) {
    fs.mkdirSync(userDataDir, { recursive: true });
  }
  return path.join(userDataDir, 'questify-ca-storage.json');
}

function createWindow() {
  mainWindow = new BrowserWindow({
    title: 'Questify CA',
    icon: path.join(__dirname, '../public/icon-512.png'),
    width: 1280,
    height: 820,
    minWidth: 420,
    minHeight: 640,
    autoHideMenuBar: true,
    backgroundColor: '#090D16',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false,
    },
  });

  if (process.env.ELECTRON_DEV_URL) {
    mainWindow.loadURL(process.env.ELECTRON_DEV_URL);
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// IPC Handlers for Native %APPDATA% Hard-Disk Storage Bridge
ipcMain.handle('questify:is-electron', () => true);

ipcMain.handle('questify:read-save', async () => {
  try {
    const filePath = getStorageFilePath();
    if (fs.existsSync(filePath)) {
      const content = fs.readFileSync(filePath, 'utf-8');
      return JSON.parse(content);
    }
  } catch (err) {
    console.error('Failed to read native storage:', err);
  }
  return null;
});

ipcMain.handle('questify:write-save', async (_event, data) => {
  try {
    const filePath = getStorageFilePath();
    const tempPath = `${filePath}.tmp`;
    const serialized = typeof data === 'string' ? data : JSON.stringify(data, null, 2);
    fs.writeFileSync(tempPath, serialized, 'utf-8');
    fs.renameSync(tempPath, filePath);
    return true;
  } catch (err) {
    console.error('Failed to write native storage:', err);
    return false;
  }
});

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
