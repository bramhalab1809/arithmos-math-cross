const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('questifyElectron', {
  isElectron: true,
  readSaveFile: () => ipcRenderer.invoke('questify:read-save'),
  writeSaveFile: (data) => ipcRenderer.invoke('questify:write-save', data),
  getPlatform: () => process.platform,
});
