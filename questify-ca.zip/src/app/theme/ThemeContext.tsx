import React, { createContext, useContext, useEffect, useState } from 'react';

export type ThemeMode = 'system' | 'light' | 'dark';
export type ResolvedTheme = 'light' | 'dark';
export type FontSizeScale = 'compact' | 'normal' | 'large' | 'xlarge';
export type AccentTheme = 'sky' | 'emerald' | 'amber' | 'violet' | 'rose';

interface ThemeContextValue {
  activeTheme: ThemeMode;
  resolvedTheme: ResolvedTheme;
  fontSize: FontSizeScale;
  accentTheme: AccentTheme;
  setTheme: (theme: ThemeMode) => void;
  setFontSize: (size: FontSizeScale) => void;
  setAccentTheme: (accent: AccentTheme) => void;
}

const THEME_STORAGE_KEY = 'ca_foundation_theme_v1';
const FONT_SIZE_STORAGE_KEY = 'questify_font_size';
const ACCENT_STORAGE_KEY = 'questify_accent_theme';

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

function getSystemPreference(): ResolvedTheme {
  if (typeof window === 'undefined' || !window.matchMedia) return 'dark';
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

function readStoredTheme(): ThemeMode {
  try {
    const raw = localStorage.getItem(THEME_STORAGE_KEY);
    if (raw === 'light' || raw === 'dark' || raw === 'system') return raw;
  } catch { /* Fallback */ }
  return 'system';
}

function readStoredFontSize(): FontSizeScale {
  try {
    const raw = localStorage.getItem(FONT_SIZE_STORAGE_KEY);
    if (raw === 'compact' || raw === 'normal' || raw === 'large' || raw === 'xlarge') return raw;
  } catch { /* Fallback */ }
  return 'normal';
}

function readStoredAccent(): AccentTheme {
  try {
    const raw = localStorage.getItem(ACCENT_STORAGE_KEY);
    if (raw === 'sky' || raw === 'emerald' || raw === 'amber' || raw === 'violet' || raw === 'rose') return raw;
  } catch { /* Fallback */ }
  return 'sky';
}

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTheme, setActiveTheme] = useState<ThemeMode>(() => readStoredTheme());
  const [systemTheme, setSystemTheme] = useState<ResolvedTheme>(() => getSystemPreference());
  const [fontSize, setFontSizeState] = useState<FontSizeScale>(() => readStoredFontSize());
  const [accentTheme, setAccentThemeState] = useState<AccentTheme>(() => readStoredAccent());

  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = (event: MediaQueryListEvent) => {
      setSystemTheme(event.matches ? 'dark' : 'light');
    };
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, []);

  const resolvedTheme: ResolvedTheme = activeTheme === 'system' ? systemTheme : activeTheme;

  useEffect(() => {
    const root = document.documentElement;
    if (resolvedTheme === 'dark') root.classList.add('dark');
    else root.classList.remove('dark');
    root.setAttribute('data-font-size', fontSize);
    root.setAttribute('data-accent', accentTheme);
  }, [resolvedTheme, fontSize, accentTheme]);

  const setTheme = (nextTheme: ThemeMode) => {
    setActiveTheme(nextTheme);
    try { localStorage.setItem(THEME_STORAGE_KEY, nextTheme); } catch { /* Ignore */ }
  };

  const setFontSize = (nextSize: FontSizeScale) => {
    setFontSizeState(nextSize);
    try { localStorage.setItem(FONT_SIZE_STORAGE_KEY, nextSize); } catch { /* Ignore */ }
  };

  const setAccentTheme = (nextAccent: AccentTheme) => {
    setAccentThemeState(nextAccent);
    try { localStorage.setItem(ACCENT_STORAGE_KEY, nextAccent); } catch { /* Ignore */ }
  };

  return (
    <ThemeContext.Provider
      value={{ activeTheme, resolvedTheme, fontSize, accentTheme, setTheme, setFontSize, setAccentTheme }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export function useTheme(): ThemeContextValue {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within a ThemeProvider');
  return ctx;
}
