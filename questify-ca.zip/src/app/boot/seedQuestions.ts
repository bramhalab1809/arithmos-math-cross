import { QuestionBankJSON } from '../../features/explorer/engine/vfsTypes';

export const LAW_CASE_STUDY_MOCK_BANK: QuestionBankJSON = {
  type: 'subjective',
  title: 'CA Foundation Business Law - Case Study Mock',
  subject: 'Business Laws',
  chapter: 'Indian Contract Act, 1872 & Companies Act, 2013',
  examSession: 'Descriptive Practice',
  questions: [
    {
      id: 'Q1',
      topic: 'Companies Act, 2013 - Corporate Veil',
      marks: 5,
      caseStudy:
        'Mr. Rajeev held 99% of the equity share capital in Zenith Merchandising Pvt. Ltd. To evade personal income-tax obligations, he formed three wholly-owned shell companies that had no independent business assets and existed solely to receive dividend income and loan it back to Mr. Rajeev as a simulated capital receipt.',
      question:
        'Referring to the provisions of the Companies Act, 2013 and decided judicial precedents, examine whether the separate legal personality of the three companies can be disregarded by the Revenue Authorities.',
      modelAnswer:
        '1. Statutory Principle (Separate Legal Entity): Under Section 9 of the Companies Act, 2013 and the rule in Salomon v. Salomon & Co. Ltd., a company is a distinct legal person separate from its members.\n2. Exception (Lifting of Corporate Veil for Evasion of Tax): Where the corporate facade is used solely as a cloak or sham for tax evasion or to circumvent statutory obligations (re: Sir Dinshaw Maneckjee Petit), the Court is entitled to pierce the corporate veil.\n3. Conclusion: Since the three companies had no commercial business and were formed exclusively as conduits to evade tax, the Revenue Authorities can lift the corporate veil and club the income in the hands of Mr. Rajeev.',
    },
    {
      id: 'Q2',
      topic: 'Indian Contract Act, 1872 - Consideration & Exceptions',
      marks: 5,
      caseStudy:
        'Mr. Arjun, out of natural love and affection, promised in writing to pay Rs. 2,50,000 to his younger brother Karan to set up a professional consultancy office. The agreement was duly registered under the law for the time being in force for registration of documents. Later, Arjun refused to pay, contending there was no consideration from Karan.',
      question:
        'State with reasons under the Indian Contract Act, 1872 whether Karan can legally enforce the promise made by Mr. Arjun.',
      modelAnswer:
        '1. Legal Provision (Section 25(1) of the Indian Contract Act, 1872): While the general rule is "ex nudo pacto non oritur actio" (an agreement without consideration is void), Section 25(1) creates an express statutory exception.\n2. Conditions for Validity: An agreement made without consideration is valid and enforceable if it is: (a) expressed in writing, (b) registered under the law for registration of documents, (c) made on account of natural love and affection, and (d) between parties standing in a near relation to each other.\n3. Conclusion: All four statutory conditions under Section 25(1) are satisfied between brothers Arjun and Karan. Therefore, Karan can validly enforce the registered promise for Rs. 2,50,000.',
    },
    {
      id: 'Q3',
      topic: 'Companies Act, 2013 - Doctrine of Indoor Management',
      marks: 5,
      caseStudy:
        'The Articles of Association of Apex Infrastructure Ltd. empowered the Board of Directors to borrow up to Rs. 50 Lakhs on bond only after passing an ordinary resolution in a general meeting. The directors borrowed Rs. 35 Lakhs from Sunrise Bank on a company bond without passing any resolution in the general meeting.',
      question:
        'Examine under the Doctrine of Indoor Management whether Apex Infrastructure Ltd. is bound to repay the loan of Rs. 35 Lakhs to Sunrise Bank.',
      modelAnswer:
        '1. Legal Principle (Doctrine of Indoor Management / Turquand Rule): As established in Royal British Bank v. Turquand, outsiders dealing with a company in good faith are required to inspect the Memorandum and Articles (Constructive Notice), but are entitled to assume that internal corporate proceedings (such as passing an ordinary resolution) have been regularly conducted.\n2. Application to Facts: The Articles authorized borrowing upon passing a resolution. Sunrise Bank had no duty to inquire into the internal regularity of the general meeting.\n3. Conclusion: Apex Infrastructure Ltd. is legally bound by the bond and must repay the loan of Rs. 35 Lakhs to Sunrise Bank.',
    },
  ],
};

export const SEP_2024_CH10_PYQ_BANK: QuestionBankJSON = {
  type: 'objective',
  title: 'CA Foundation Sep 2024 PYQ - Indian Economy',
  subject: 'Business Economics',
  chapter: 'Chapter 10 - Indian Economy',
  examSession: 'September 2024',
  questions: [
    {
      id: 'Q91',
      question: 'Which of the following group of activities is included in the tertiary sector of the Indian Economy?',
      options: ['Agriculture, forestry, fishery, and mining', 'Manufacturing, electricity, gas, water supply, and construction', 'Transportation, storage, real estate, public administration, and education', 'Mining, quarrying, construction, and dairy farming'],
      correctAnswer: 2,
      hint: 'Concept: Primary = natural resource extraction; Secondary = industrial manufacturing & utilities; Tertiary = intangible services & trade.',
      explanation: 'The tertiary (service) sector encompasses trade, transportation, storage, communication, real estate, banking, public administration, defense, and education.',
      topic: 'Sectoral Composition of Indian Economy',
      marks: 1,
    },
    {
      id: 'Q92',
      question: 'Which of the following is the defining feature of the Green Revolution introduced in Indian agriculture?',
      options: ['Expansion of rain-fed traditional farming across arid zones', 'Complete replacement of commercial crops with subsistence pulses', 'Abolition of institutional agricultural credit and cooperative banking', 'Adoption of High Yielding Variety (HYV) seeds and scientific cultivation methods'],
      correctAnswer: 3,
      hint: 'Concept: The 1960s agricultural breakthrough driven by Norman Borlaug & M.S. Swaminathan relied on miracle seed technology and irrigation.',
      explanation: 'The Green Revolution centered on the use of High Yielding Variety (HYV) seeds alongside assured irrigation, chemical fertilizers, and scientific farm practices.',
      topic: 'Green Revolution & Agricultural Reforms',
      marks: 1,
    },
    {
      id: 'Q93',
      question: 'On which date was the historic New Industrial Policy announced by the Government of India during the 1991 economic reforms?',
      options: ['1st July 1991', '24th July 1991', '15th August 1991', '1st April 1992'],
      correctAnswer: 1,
      hint: 'Concept: The LPG (Liberalisation, Privatisation, Globalisation) Industrial Policy was tabled in Parliament on the same day as the landmark July 1991 Union Budget.',
      explanation: 'The New Industrial Policy (NIP) was tabled in Parliament on 24th July 1991, dismantling the License Raj and opening key sectors to private and foreign investment.',
      topic: 'New Economic Policy 1991',
      marks: 1,
    },
    {
      id: 'Q94',
      question: 'NITI Aayog was established by the Government of India, replacing the 65-year-old Planning Commission, on:',
      options: ['15th August 2014', '2nd October 2014', '1st January 2015', '1st April 2015'],
      correctAnswer: 2,
      hint: 'Concept: Announced on Independence Day 2014, NITI Aayog formally commenced operations on New Year Day of the following year.',
      explanation: 'NITI (National Institution for Transforming India) Aayog came into existence on 1st January 2015 to foster cooperative federalism and act as a policy think-tank.',
      topic: 'NITI Aayog',
      marks: 1,
    },
    {
      id: 'Q95',
      question: 'What is the primary objective of the Paramparagat Krishi Vikas Yojana (PKVY) launched by the Government of India?',
      options: ['Subsidizing imported diesel tractors for large landholders', 'Establishing exclusive export zones for genetically modified cotton', 'Financing inter-state river linking canal infrastructure', 'Promoting cluster-based organic farming and improving soil health'],
      correctAnswer: 3,
      hint: 'Concept: "Paramparagat Krishi" refers to traditional chemical-free farming organized in farmer clusters with PGS certification.',
      explanation: 'Paramparagat Krishi Vikas Yojana (PKVY) promotes commercial organic production through certified cluster farming and chemical-free soil health management.',
      topic: 'Sustainable Agriculture Initiatives',
      marks: 1,
    },
    {
      id: 'Q96',
      question: 'The "Udyami Bharat" programme of the Government of India is specifically aimed at the empowerment and growth of:',
      options: ['Micro, Small and Medium Enterprises (MSMEs)', 'Public Sector Maharatna Oil Refineries', 'Foreign Institutional Investors (FIIs)', 'Large-scale Defence Ordnance Factories'],
      correctAnswer: 0,
      hint: 'Concept: "Udyami" means entrepreneur (as in Udyam Registration portal for small business enterprises).',
      explanation: 'Udyami Bharat reflects the government commitment to work towards the empowerment of Micro, Small and Medium Enterprises (MSMEs) through credit and technology schemes.',
      topic: 'Industrial & MSME Development',
      marks: 1,
    },
    {
      id: 'Q97',
      question: 'The bi-annual "India Development Update" (IDU) report, which assesses the Indian economy and its prospects, is published by:',
      options: ['Reserve Bank of India (RBI)', 'World Economic Forum (WEF)', 'The World Bank', 'Asian Development Bank (ADB)'],
      correctAnswer: 2,
      hint: 'Concept: Identify the Bretton Woods multilateral development bank headquartered in Washington, D.C. focused on development reports.',
      explanation: 'The India Development Update (IDU) is the World Bank flagship half-yearly report analyzing India macroeconomic performance and structural growth trends.',
      topic: 'Economic Reports & International Institutions',
      marks: 1,
    },
    {
      id: 'Q98',
      question: 'In the context of India industrial and FDI policy framework, what does the acronym DPIIT stand for?',
      options: ['Directorate of Public Investment and International Trade', 'Department of Portfolio Investment and Industrial Taxation', 'Directorate for Promotion of Infrastructure and Information Technology', 'Department for Promotion of Industry and Internal Trade'],
      correctAnswer: 3,
      hint: 'Concept: Formerly DIPP, this Department under the Ministry of Commerce & Industry was renamed in 2019 to include domestic (Internal) trade.',
      explanation: 'DPIIT stands for the Department for Promotion of Industry and Internal Trade, operating under the Ministry of Commerce and Industry.',
      topic: 'Industrial Policy & FDI Institutional Framework',
      marks: 1,
    },
    {
      id: 'Q99',
      question: 'NITI Aayog "Methanol Economy" programme aims at all of the following objectives EXCEPT:',
      options: ['Reducing India oil import bill through fuel blending', 'Reducing greenhouse gas (GHG) emissions', 'Converting high-ash Indian coal and agricultural residue into methanol', 'Eliminating all generic non-hazardous industrial solid waste from urban municipalities'],
      correctAnswer: 3,
      hint: 'Concept: Methanol (CH3OH) is an alternative clean transportation/cooking fuel blended to substitute crude oil imports and cut carbon emissions.',
      explanation: 'The Methanol Economy program focuses on reducing oil imports, cutting GHG emissions, and converting coal/MSW/stranded gas into methanol fuel—not generic industrial solid waste disposal.',
      topic: 'NITI Aayog Initiatives',
      marks: 1,
    },
    {
      id: 'Q100',
      question: 'Which platform was launched by NITI Aayog to democratize and facilitate user-friendly access to foundational Indian government datasets?',
      options: ['Unified Logistics Interface Platform (ULIP)', 'National Data and Analytics Platform (NDAP)', 'Open Network for Digital Commerce (ONDC)', 'Government e-Marketplace (GeM)'],
      correctAnswer: 1,
      hint: 'Concept: Look for the platform acronym explicitly containing "Data and Analytics".',
      explanation: 'The National Data and Analytics Platform (NDAP) was launched by NITI Aayog to standardize and democratize access to published Indian government datasets.',
      topic: 'Digital Public Infrastructure & Data Governance',
      marks: 1,
    },
  ],
};

export const SEED_LAW_TXT_FILES: { id: string; name: string; content: string }[] = [
  {
    id: 'fil_law_txt_companies',
    name: 'Companies_Act_2013_Sections.txt',
    content: [
      'Section 2(20) Company: Under Section 2(20) of the Companies Act, 2013, "company" means a company incorporated under this Act or under any previous company law.',
      'Section 2(45) Government Company: Under Section 2(45), a Government Company is one in which not less than 51% of paid-up share capital is held by the Central Government, State Government(s), or partly by both.',
      'Section 2(68) Private Company: Restricts right to transfer shares, limits members to 200 (excluding employees), and prohibits public invitation to subscribe for securities.',
      'Section 2(85) Small Company: Paid-up capital not exceeding Rs. 4 Crore and turnover not exceeding Rs. 40 Crore (excluding holding/subsidiary/Sec 8 companies).',
      'Section 2(87) Subsidiary Company: A company in which the holding company controls the composition of the Board of Directors or exercises/controls more than one-half of the total voting power.',
      'Section 8 Charitable Company: Licensed to promote commerce, art, science, sports, education, research, or charity; applies profits strictly to objects and prohibits dividend payment.',
      'Salomon v. Salomon & Co. Ltd. (Corporate Veil): An incorporated company is a distinct legal entity separate from its subscribers; the corporate veil is lifted only for fraud, tax evasion, or enemy character.',
      'Royal British Bank v. Turquand (Indoor Management): Outsiders dealing with a company in good faith may presume internal corporate proceedings have been regularly conducted.',
    ].join('\n\n'),
  },
  {
    id: 'fil_law_txt_contract',
    name: 'Indian_Contract_Act_1872_Key_CaseLaws.txt',
    content: [
      'Section 2(h) & Section 10 (Valid Contract): An agreement enforceable by law requires free consent of competent parties, lawful consideration, and a lawful object (Balfour v. Balfour: social agreements lack legal intention).',
      'Section 2(a) & Section 4 (Offer & Acceptance): General offers are accepted by performance of conditions (Carlill v. Carbolic Smoke Ball Co.). Acceptance must be communicated to the offeror (Felthouse v. Bindley).',
      'Section 2(d) & Section 25 (Consideration): Consideration may move from the promisee or any other person (Chinnayya v. Ramayya). An agreement without consideration is void unless in writing & registered out of natural love and affection (Sec 25(1)).',
      'Sections 14-19 (Free Consent): Consent is free when not caused by coercion (Sec 15), undue influence (Sec 16), fraud (Sec 17), misrepresentation (Sec 18), or mistake (Sec 20-22).',
      'Sections 26-30 (Void Agreements): Agreements in restraint of marriage (Sec 26), restraint of trade (Sec 27), restraint of legal proceedings (Sec 28), or by way of wager (Sec 30) are void.',
      'Sections 31-36 (Contingent Contracts): A contract to do or not to do something if some collateral uncertain event happens or does not happen.',
      'Sections 68-72 (Quasi-Contracts): Statutory obligations based on unjust enrichment: necessaries supplied to incapable persons (Sec 68), payment by interested person (Sec 69), non-gratuitous act (Sec 70), finder of goods (Sec 71).',
    ].join('\n\n'),
  },
  {
    id: 'fil_law_txt_soga',
    name: 'Sale_of_Goods_Act_1930_Provisions.txt',
    content: [
      'Section 12 (Condition vs Warranty): A Condition is a stipulation essential to the main purpose of the contract (breach gives right to repudiate); a Warranty is collateral to the main purpose (breach gives right to claim damages only).',
      'Section 16 (Doctrine of Caveat Emptor): "Let the buyer beware" — the seller is not bound to disclose defects in goods unless the buyer makes known the specific purpose and relies on the seller skill and judgment.',
      'Sections 18-26 (Transfer of Property & Risk): Property in specific deliverable goods passes when the contract is made (Sec 20). Risk prima facie passes with property (Sec 26). Nemo dat quod non habet (Sec 27).',
      'Sections 45-54 (Unpaid Seller Rights): An unpaid seller has a right of Lien (Sec 47), Stoppage in transit when buyer becomes insolvent (Sec 50), and Right of Resale (Sec 54) against the goods.',
    ].join('\n\n'),
  },
  {
    id: 'fil_law_txt_partnership',
    name: 'Indian_Partnership_Act_1932_Sections.txt',
    content: [
      'Section 4 & Section 6 (True Test of Partnership): Partnership is the relation between persons who have agreed to share profits of a business carried on by all or any of them acting for all. Mutual agency (Cox v. Hickman) is the conclusive test.',
      'Section 19 & Section 22 (Implied Authority of Partner): The act of a partner done to carry on, in the usual way, business of the kind carried on by the firm binds the firm.',
      'Section 30 (Minor Admitted to Benefits of Partnership): A minor cannot become a partner, but with the consent of all partners may be admitted to the benefits of an existing partnership; his share is liable, not he personally.',
      'Sections 39-44 (Dissolution of Firm): Dissolution of partnership between all partners of a firm is called dissolution of the firm (by agreement Sec 40, compulsory Sec 41, on contingencies Sec 42, by notice Sec 43, or by Court Sec 44).',
    ].join('\n\n'),
  },
];
