import { QuestionBankJSON } from '../../features/explorer/engine/vfsTypes';

export const ACCOUNTING_CH7_FINAL_ACCOUNTS_BANK: QuestionBankJSON = {
  type: 'subjective',
  title: 'Accounting Chapter 7 - Final Accounts of Sole Proprietors',
  subject: 'Accounting',
  chapter: 'Chapter 7 - Final Accounts',
  examSession: 'ICAI Study Material Practical Problems',
  questions: [
    {
      id: 'Q1',
      topic: 'Trading & P&L A/c and Balance Sheet (Mr. Ganguli)',
      marks: 20,
      table: {
        title: 'Trial Balance of Mr. Ganguli as on 31st March, 2022',
        headers: ['Particulars', 'Debit (₹)', 'Credit (₹)'],
        rows: [
          ['Stock on 1.4.2021 (Opening)', '2,34,000', '-'],
          ['Purchases & Sales', '12,15,500', '14,48,000'],
          ['Returns (Inward & Outward)', '43,000', '29,000'],
          ['Productive Carriage Inwards', '93,000', '-'],
          ['Rent & Taxes', '28,500', '-'],
          ['Salaries', '46,500', '-'],
          ['Sundry Debtors & Creditors', '1,20,000', '74,000'],
          ['Loan from Dena Bank Ltd. (at 12%)', '-', '1,00,000'],
          ['Interest Paid', '4,500', '-'],
          ['Interest Received', '-', '7,250'],
          ['Cash with Traders Bank Ltd.', '40,000', '-'],
          ['Discounts (Allowed & Received)', '37,700', '14,950'],
          ['Investments at 5%', '25,000', '-'],
          ['Furniture as on 1.4.2021', '9,000', '-'],
          ['General & Travelling Expenses', '31,250', '-'],
          ['Audit Fees & Insurance', '6,500', '-'],
          ['Postage & Printing Stationery', '21,350', '-'],
          ['Cash in Hand', '1,900', '-'],
          ['Deposits at 10% (1.4.2021)', '1,50,000', '-'],
          ['Drawings & Ganguli Capital', '50,000', '5,40,500'],
        ],
        totals: ['Total', '21,04,700', '22,13,700'],
      },
      caseStudy:
        'Additional Adjustments as on 31st March, 2022:\n1. Value of Closing Stock on 31st March, 2022 was ₹3,93,000.\n2. Purchase of Furniture on 1st October, 2021 for ₹10,000 was wrongly debited to Purchases Account.\n3. Provide Depreciation @ 10% p.a. on Furniture (including addition).\n4. Provide for full year interest on Loan from Dena Bank Ltd. @ 12% p.a. and accrued interest on Deposits @ 10% p.a.\n5. Provide 5% for Doubtful Debts on Sundry Debtors.',
      question:
        'Prepare the Trading and Profit & Loss Account of Mr. Ganguli for the year ended 31st March, 2022 and the Balance Sheet as on that date after incorporating all adjustments.',
      modelAnswer:
        'Trading Account for the year ended 31st March, 2022:\n| Particulars (Dr.) | Amount (₹) | Particulars (Cr.) | Amount (₹) |\n| --- | --- | --- | --- |\n| To Opening Stock | 2,34,000 | By Sales (14,48,000 - 43,000) | 14,05,000 |\n| To Purchases (12,15,500 - 29,000 - 10,000) | 11,76,500 | By Closing Stock | 3,93,000 |\n| To Productive Carriage Inwards | 93,000 | - | - |\n| To Gross Profit c/d | 2,79,500 | - | - |\n| Total | 17,98,000 | Total | 17,98,000 |\n\nProfit & Loss Account for the year ended 31st March, 2022:\n| Particulars (Dr.) | Amount (₹) | Particulars (Cr.) | Amount (₹) |\n| --- | --- | --- | --- |\n| To Salaries & Rent (46,500 + 28,500) | 75,000 | By Gross Profit b/d | 2,79,500 |\n| To Interest on Dena Bank Loan (4,500 + 7,500) | 12,000 | By Discount Received | 14,950 |\n| To Discount Allowed | 37,700 | By Interest on Deposits & Inv. | 16,250 |\n| To General, Audit & Postage Exp. | 59,100 | - | - |\n| To Depreciation on Furniture (900 + 500) | 1,400 | - | - |\n| To Provision for Doubtful Debts (5%) | 6,000 | - | - |\n| To Net Profit (Transferred to Capital) | 70,500 | - | - |\n| Total | 3,10,700 | Total | 3,10,700 |\n\nBalance Sheet of Mr. Ganguli as on 31st March, 2022:\n| Liabilities | Amount (₹) | Assets | Amount (₹) |\n| --- | --- | --- | --- |\n| Capital (5,40,500 + 70,500 - 50,000) | 5,61,000 | Furniture (9,000 + 10,000 - 1,400) | 17,600 |\n| 12% Loan from Dena Bank (+ O/s Int 7,500) | 1,07,500 | Investments (5%) & Deposits (10%) | 1,84,000 |\n| Sundry Creditors | 74,000 | Closing Stock | 3,93,000 |\n| - | - | Debtors (1,20,000 - 6,000 Prov.) | 1,14,000 |\n| - | - | Cash at Bank & in Hand | 41,900 |\n| Total | 7,28,000 | Total | 7,28,000 |',
    },
    {
      id: 'Q2',
      topic: 'Provision for Doubtful Debts & Discount on Debtors',
      marks: 10,
      table: {
        title: 'Extract of Trial Balance as on 31st March, 2024',
        headers: ['Particulars', 'Debit (₹)', 'Credit (₹)'],
        rows: [
          ['Sundry Debtors (before further bad debts)', '4,12,000', '-'],
          ['Bad Debts written off during the year', '18,500', '-'],
          ['Provision for Doubtful Debts (1.4.2023)', '-', '28,000'],
        ],
      },
      caseStudy:
        'Adjustments:\n1. Write off further Bad Debts of ₹12,000.\n2. Maintain Provision for Doubtful Debts @ 5% on Sundry Debtors.\n3. Create a Provision for Discount on Debtors @ 2% on Good Debtors.',
      question:
        'Prepare the Provision for Doubtful Debts Account and show the extracts of the Profit & Loss Account and Balance Sheet as on 31st March, 2024.',
      modelAnswer:
        'Summary of Working & Financial Extracts:\n| Particulars | Calculation | Amount (₹) |\n| --- | --- | --- |\n| Collectible Debtors | 4,12,000 - 12,000 (Further Bad Debts) | 4,00,000 |\n| Less: Closing Provision for Doubtful Debts (5%) | 5% of ₹4,00,000 | 20,000 |\n| Good Debtors eligible for Discount | 4,00,000 - 20,000 | 3,80,000 |\n| Less: Provision for Discount on Debtors (2%) | 2% of ₹3,80,000 | 7,600 |\n| Total Net Debtors in Balance Sheet | 3,80,000 - 7,600 | 3,72,400 |\n\nNet Debit to P&L A/c for Bad & Doubtful Debts = (₹18,500 + ₹12,000 + ₹20,000) - ₹28,000 (Old Provision) = ₹22,500.',
    },
    {
      id: 'Q3',
      topic: 'Manufacturing Account & Cost of Goods Manufactured',
      marks: 10,
      table: {
        title: 'Manufacturing Cost Records of Mr. Vimal (Year ended 31.3.2024)',
        headers: ['Particulars', 'Opening (₹)', 'Closing / Annual (₹)'],
        rows: [
          ['Raw Materials Stock', '80,000', '95,000'],
          ['Work-in-Progress (WIP)', '35,000', '48,000'],
          ['Purchases of Raw Material', '-', '6,40,000'],
          ['Direct Manufacturing Wages', '-', '1,65,000'],
          ['Factory Power, Fuel & Plant Depreciation', '-', '80,000'],
          ['Sale of Factory Scrap', '-', '12,000'],
        ],
      },
      question:
        'Prepare the Manufacturing Account of Mr. Vimal for the year ended 31st March, 2024 showing Raw Material Consumed, Prime Cost, and Cost of Goods Manufactured.',
      modelAnswer:
        'Manufacturing Account of Mr. Vimal for the year ended 31st March, 2024:\n| Particulars (Dr.) | Amount (₹) | Particulars (Cr.) | Amount (₹) |\n| --- | --- | --- | --- |\n| To Opening Work-in-Progress | 35,000 | By Closing Work-in-Progress | 48,000 |\n| To Raw Material Consumed (80k + 6,40k - 95k) | 6,25,000 | By Sale of Factory Scrap | 12,000 |\n| To Direct Manufacturing Wages | 1,65,000 | By Cost of Goods Manufactured (t/f to Trading A/c) | 8,45,000 |\n| To Factory Overheads (Power 42k + Depr 38k) | 80,000 | - | - |\n| Total | 9,05,000 | Total | 9,05,000 |',
    },
  ],
};

export const QA_CH4_MATH_OF_FINANCE_BANK: QuestionBankJSON = {
  type: 'objective',
  title: 'Quantitative Aptitude Chapter 4 - Mathematics of Finance',
  subject: 'Quantitative Aptitude',
  chapter: 'Chapter 4 - Mathematics of Finance',
  examSession: 'ICAI Exercise 4(A) & 4(B)',
  questions: [
    { id: 'Q1', question: 'Sania deposited Rs. 50,000 in a bank for two years with the interest rate of 5.5% p.a. What will be the final value of investment under Simple Interest?', options: ['Rs. 55,000', 'Rs. 55,500', 'Rs. 56,000', 'Rs. 54,500'], correctAnswer: 1, hint: 'Formula: SI = (P × R × T) / 100 and Final Amount A = P + SI', explanation: 'SI = (50,000 × 5.5 × 2)/100 = Rs. 5,500. Final Amount A = 50,000 + 5,500 = Rs. 55,500.', topic: 'Simple Interest - Exercise 4(A)', marks: 1 },
    { id: 'Q2', question: 'In what time will Rs. 85,000 amount to Rs. 1,57,675 at 4.5% per annum simple interest?', options: ['17 years', '18 years', '19 years', '20.5 years'], correctAnswer: 2, hint: 'Formula: SI = A − P and Time T = (SI × 100) / (P × R)', explanation: 'SI = 1,57,675 - 85,000 = Rs. 72,675. Time T = (72,675 × 100) / (85,000 × 4.5) = 19 years.', topic: 'Simple Interest - Exercise 4(A)', marks: 1 },
    { id: 'Q3', question: 'A sum of money doubles itself in 10 years at simple interest. The number of years it would triple itself at the same rate is:', options: ['15 years', '20 years', '25 years', '30 years'], correctAnswer: 1, hint: 'Formula: For doubling, SI = P; for tripling, SI = 2P (twice the interest takes twice the time at constant rate R).', explanation: 'For doubling, SI = P in 10 years => Rate R = 10% p.a. For tripling, SI = 2P => T = (2P × 100)/(P × 10) = 20 years.', topic: 'Simple Interest Rate & Time', marks: 1 },
    { id: 'Q4', question: 'If P = Rs. 1,000, R = 5% p.a., and n = 4; what is the Amount and Compound Interest compounded annually?', options: ['Rs. 1,215.50, Rs. 215.50', 'Rs. 1,125.00, Rs. 125.00', 'Rs. 1,200.00, Rs. 200.00', 'Rs. 1,225.50, Rs. 225.50'], correctAnswer: 0, hint: 'Formula: A = P(1 + i)^n and CI = A − P, where i = R / 100.', explanation: 'A = 1000 × (1.05)^4 = Rs. 1,215.50; CI = Rs. 215.50.', topic: 'Compound Interest - Exercise 4(B)', marks: 1 },
    { id: 'Q5', question: 'The difference between Simple Interest and Compound Interest on a certain sum of money invested for 3 years at 6% p.a. is Rs. 110.16. The principal is:', options: ['Rs. 3,000', 'Rs. 3,700', 'Rs. 12,000', 'Rs. 10,000'], correctAnswer: 3, hint: 'Formula (3-Year Difference): CI − SI = P × i² × (3 + i), where i = 0.06.', explanation: 'For 3 years, CI - SI = P × i^2 × (3 + i) = 0.011016 P = 110.16 => P = Rs. 10,000.', topic: 'CI vs SI Difference', marks: 1 },
    { id: 'Q6', question: 'What is the effective rate of interest equivalent to a nominal rate of 10% per annum compounded half-yearly?', options: ['10.15%', '10.25%', '10.38%', '10.50%'], correctAnswer: 1, hint: 'Formula: Effective Rate E = (1 + i/m)^m − 1, with m = 2 for half-yearly compounding.', explanation: 'Effective Rate E = (1 + 0.05)^2 - 1 = 1.1025 - 1 = 10.25%.', topic: 'Effective Rate of Interest', marks: 1 },
    { id: 'Q7', question: 'A machine depreciates at 10% of its value at the beginning of a year. The cost and scrap value realized at the end of 10 years were Rs. 20,000 and Rs. 6,973 respectively. Number of years n is:', options: ['9 years', '10 years', '11 years', '12 years'], correctAnswer: 1, hint: 'Formula (Reducing Balance Depreciation): Scrap Value S = P × (1 − i)^n', explanation: 'S = 20,000 × (0.9)^10 = Rs. 6,973.56, hence n = 10 years.', topic: 'Depreciation & Compound Decay', marks: 1 },
    { id: 'Q8', question: 'Find the Future Value of an ordinary annuity of Rs. 500 made annually for 7 years at interest rate of 14% compounded annually [Given (1.14)^7 = 2.5023]:', options: ['Rs. 5,365.35', 'Rs. 5,150.25', 'Rs. 5,650.00', 'Rs. 4,985.50'], correctAnswer: 0, hint: 'Formula: FV of Ordinary Annuity = C × [(1 + i)^n − 1] / i', explanation: 'FV = 500 × [(2.5023 - 1) / 0.14] = Rs. 5,365.35.', topic: 'Future Value of Annuity', marks: 1 },
    { id: 'Q9', question: 'What is the Present Value of Rs. 10,000 to be required after 5 years if the interest rate be 9% per annum [Given (1.09)^-5 = 0.6499]?', options: ['Rs. 6,199.00', 'Rs. 6,499.00', 'Rs. 6,899.00', 'Rs. 7,050.00'], correctAnswer: 1, hint: 'Formula: PV = A × (1 + i)^(-n)', explanation: 'PV = 10,000 × 0.6499 = Rs. 6,499.00.', topic: 'Present Value', marks: 1 },
    { id: 'Q10', question: 'Rs. 200 is invested at the end of each month in an account paying interest 6% per year compounded monthly. What is the future value of this annuity after 10th payment [Given (1.005)^10 = 1.0511]?', options: ['Rs. 2,022', 'Rs. 2,044', 'Rs. 2,066', 'Rs. 2,088'], correctAnswer: 1, hint: 'Formula: FV = C × [(1 + i)^n − 1] / i, using monthly rate i = 0.06 / 12 = 0.005.', explanation: 'FV = 200 × [(1.0511 - 1) / 0.005] = Rs. 2,044.', topic: 'Monthly Annuity', marks: 1 },
  ],
};

export const PROMPT_EXTRACT_OBJECTIVE_TXT = `========================================================================
AI PROMPT: EXTRACT OBJECTIVE MCQs FROM ICAI CHAPTER PDF INTO JSON
========================================================================
Instructions:
1. Attach your ICAI CA Foundation Chapter PDF (Economics or Quantitative Aptitude) in ChatGPT, Claude, Gemini, or Google AI Studio.
2. Paste the prompt below and save the generated output as a .json file.
3. Drag & drop the .json file into this Virtual File Explorer!

--- COPY FROM BELOW THIS LINE ---

Act as an expert ICAI CA Foundation examiner. Extract all Multiple Choice Questions (MCQs) and their official Answer Keys from the attached chapter PDF into a single valid JSON object.

Use this exact JSON structure:
{
  "type": "objective",
  "title": "<Subject & Chapter Title>",
  "subject": "<Economics | Quantitative Aptitude>",
  "chapter": "<Chapter Number & Name>",
  "questions": [
    {
      "id": "Q1",
      "question": "<Complete question statement with all figures>",
      "options": [
        "<Option A>",
        "<Option B>",
        "<Option C>",
        "<Option D>"
      ],
      "correctAnswer": 0,
      "explanation": "<Step-by-step formula, calculation, or conceptual explanation>",
      "topic": "<Sub-topic name>",
      "marks": 1
    }
  ]
}

Rules:
- "correctAnswer" can be 0-indexed (0=A, 1=B, 2=C, 3=D) or letter ("A", "B", "C", "D").
- Output pure valid JSON only so I can save it directly as a .json file.`;

export const PROMPT_EXTRACT_SUBJECTIVE_TXT = `========================================================================
AI PROMPT: EXTRACT SUBJECTIVE CASE STUDIES & ACCOUNTING TABLES INTO JSON
========================================================================
Instructions:
1. Attach your ICAI CA Foundation Chapter PDF (Accounting or Business Law) in ChatGPT, Claude, Gemini, or Google AI Studio.
2. Paste the prompt below and save the generated output as a .json file.
3. Drag & drop the .json file into this Virtual File Explorer!

--- COPY FROM BELOW THIS LINE ---

Act as an expert ICAI CA Foundation examiner. Extract all Descriptive Questions, Legal Case Studies, and Practical Accounting Problems (including Trial Balances, Ledgers, and Adjustments) along with their official ICAI Model Solutions from the attached PDF into a single valid JSON object.

Use this exact JSON structure:
{
  "type": "subjective",
  "title": "<Subject & Chapter Title>",
  "subject": "<Accounting | Business Law>",
  "chapter": "<Chapter Number & Name>",
  "questions": [
    {
      "id": "Q1",
      "topic": "<Concept / Accounting Standard / Section Number>",
      "marks": 10,
      "table": {
        "title": "<Optional Table Title, e.g., Trial Balance as on 31st March>",
        "headers": ["Particulars", "Debit (₹)", "Credit (₹)"],
        "rows": [
          ["Opening Stock", "2,34,000", "-"],
          ["Sales", "-", "14,48,000"]
        ],
        "totals": ["Total", "21,04,700", "22,13,700"]
      },
      "caseStudy": "<Case Scenario narrative or numbered Adjustments below the table>",
      "question": "<Exact Question Requirement asked in the exam>",
      "modelAnswer": "<Complete ICAI Model Solution. Use Markdown tables (| Particulars | Amount (₹) |) for Trading A/c, P&L A/c, Balance Sheet, or Working Notes>"
    }
  ]
}

Rules:
- If a question has no table (e.g. pure Business Law case study), omit the "table" field and put the scenario in "caseStudy".
- Output pure valid JSON only so I can save it directly as a .json file.`;
