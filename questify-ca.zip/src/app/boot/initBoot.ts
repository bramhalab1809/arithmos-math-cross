import { ACCOUNTING_TRUE_FALSE_BANK } from '../../data/seedTrueFalseQA';
import { ROOT_FOLDER_ID, countQuestionsInContent } from '../../features/explorer/engine/vfsEngine';
import { VFSFileNode, VFSFolderNode, VFSState } from '../../features/explorer/engine/vfsTypes';
import { SEED_ACC_FORMAT_TXT_FILES } from '../../features/playground/accounts/accountDefinitions';
import {
  ACCOUNTING_CH7_FINAL_ACCOUNTS_BANK,
  PROMPT_EXTRACT_OBJECTIVE_TXT,
  PROMPT_EXTRACT_SUBJECTIVE_TXT,
  QA_CH4_MATH_OF_FINANCE_BANK,
} from './seedAccountsQA';
import { LAW_CASE_STUDY_MOCK_BANK, SEED_LAW_TXT_FILES, SEP_2024_CH10_PYQ_BANK } from './seedQuestions';

export const VFS_STORAGE_KEY = 'ca_foundation_vfs_v1';

function makeFolder(
  id: string,
  name: string,
  parentId: string | null,
  childrenIds: string[],
  createdAt: number,
  metadata?: VFSFolderNode['metadata']
): VFSFolderNode {
  return { id, type: 'folder', name, parentId, childrenIds, createdAt, ...(metadata ? { metadata } : {}) };
}

function makeFile(
  id: string,
  name: string,
  parentId: string,
  fileType: 'json' | 'txt',
  content: string,
  createdAt: number
): VFSFileNode {
  return { id, type: 'file', name, parentId, fileType, content, createdAt, updatedAt: createdAt };
}

export function buildSeedVFSState(): VFSState {
  const now = Date.now();
  const accFormatTxtNodes = SEED_ACC_FORMAT_TXT_FILES.map((item, idx) =>
    makeFile(item.id, item.name, 'fld_acc_std_formats', 'txt', item.content, now - 37400 + idx * 50)
  );
  const stdFormatsFolder = makeFolder(
    'fld_acc_std_formats',
    'Standard Account Formats',
    'fld_accounting',
    accFormatTxtNodes.map((f) => f.id),
    now - 37500,
    { isSystemLinked: true, subjectRestriction: 'Accounting' }
  );

  const accountingFolder = makeFolder('fld_accounting', 'Accounting', null, ['fld_acc_std_formats', 'fil_acc_true_false', 'fil_acc_ch7_final'], now - 40000);
  const accTrueFalseFile = makeFile('fil_acc_true_false', 'Chapter 1 & 7 - True False with Reasons (Q1a).json', 'fld_accounting', 'json', JSON.stringify(ACCOUNTING_TRUE_FALSE_BANK, null, 2), now - 39000);
  const accCh7File = makeFile('fil_acc_ch7_final', 'Chapter 7 - Final Accounts of Sole Proprietors.json', 'fld_accounting', 'json', JSON.stringify(ACCOUNTING_CH7_FINAL_ACCOUNTS_BANK, null, 2), now - 38000);

  const lawTxtNodes = SEED_LAW_TXT_FILES.map((item, idx) =>
    makeFile(item.id, item.name, 'fld_law_precedents', 'txt', item.content, now - 24800 + idx * 100)
  );
  const lawPrecedentsFolder = makeFolder(
    'fld_law_precedents',
    'Legal Precedents & Sections',
    'fld_business_law',
    lawTxtNodes.map((f) => f.id),
    now - 26000,
    { isSystemLinked: true, subjectRestriction: 'Business Law' }
  );
  const lawFolder = makeFolder('fld_business_law', 'Business Law', null, ['fld_law_precedents', 'fil_law_case_study_mock'], now - 30000);
  const lawMockFile = makeFile('fil_law_case_study_mock', 'Law_Case_Study_Mock.json', 'fld_business_law', 'json', JSON.stringify(LAW_CASE_STUDY_MOCK_BANK, null, 2), now - 25000);

  const economicsFolder = makeFolder('fld_economics', 'Economics', null, ['fld_eco_ch10'], now - 20000);
  const ecoCh10Folder = makeFolder('fld_eco_ch10', 'Chapter 10 - Indian Economy', 'fld_economics', ['fil_sep_2024_pyq'], now - 15000);
  const sep2024File = makeFile('fil_sep_2024_pyq', 'Sep_2024_PYQ.json', 'fld_eco_ch10', 'json', JSON.stringify(SEP_2024_CH10_PYQ_BANK, null, 2), now - 10000);

  const quantFolder = makeFolder('fld_quant_aptitude', 'Quantitative Aptitude', null, ['fil_qa_ch4_finance'], now - 5000);
  const qaCh4File = makeFile(
    'fil_qa_ch4_finance',
    'Chapter 4 - Mathematics of Finance.json',
    'fld_quant_aptitude',
    'json',
    JSON.stringify(QA_CH4_MATH_OF_FINANCE_BANK, null, 2),
    now - 4000
  );

  const promptsFolder = makeFolder('fld_ai_prompts', 'AI Prompts & Templates', null, ['fil_prompt_obj_txt', 'fil_prompt_subj_txt'], now - 2000);
  const promptObjFile = makeFile('fil_prompt_obj_txt', '01-Prompt-Extract-Objective-MCQs.txt', 'fld_ai_prompts', 'txt', PROMPT_EXTRACT_OBJECTIVE_TXT, now - 1500);
  const promptSubjFile = makeFile('fil_prompt_subj_txt', '02-Prompt-Extract-Subjective-Questions.txt', 'fld_ai_prompts', 'txt', PROMPT_EXTRACT_SUBJECTIVE_TXT, now - 1000);

  const accTxtNodesRecord = Object.fromEntries(accFormatTxtNodes.map((f) => [f.id, f]));
  const lawTxtNodesRecord = Object.fromEntries(lawTxtNodes.map((f) => [f.id, f]));

  return {
    nodes: {
      [accountingFolder.id]: accountingFolder,
      [stdFormatsFolder.id]: stdFormatsFolder,
      ...accTxtNodesRecord,
      [accTrueFalseFile.id]: accTrueFalseFile,
      [accCh7File.id]: accCh7File,
      [lawFolder.id]: lawFolder,
      [lawPrecedentsFolder.id]: lawPrecedentsFolder,
      ...lawTxtNodesRecord,
      [lawMockFile.id]: lawMockFile,
      [economicsFolder.id]: economicsFolder,
      [ecoCh10Folder.id]: ecoCh10Folder,
      [sep2024File.id]: sep2024File,
      [quantFolder.id]: quantFolder,
      [qaCh4File.id]: qaCh4File,
      [promptsFolder.id]: promptsFolder,
      [promptObjFile.id]: promptObjFile,
      [promptSubjFile.id]: promptSubjFile,
    },
    rootFolderIds: [accountingFolder.id, lawFolder.id, economicsFolder.id, quantFolder.id, promptsFolder.id],
    currentFolderId: ROOT_FOLDER_ID,
    pinnedFolderIds: ['fld_eco_ch10', 'fld_accounting', 'fld_ai_prompts'],
  };
}

function isValidVFSState(candidate: unknown): candidate is VFSState {
  if (!candidate || typeof candidate !== 'object') return false;
  const obj = candidate as Record<string, unknown>;
  return typeof obj.nodes === 'object' && obj.nodes !== null && Array.isArray(obj.rootFolderIds) && typeof obj.currentFolderId === 'string';
}

export function loadOrSeedVFS(): VFSState {
  try {
    const raw = localStorage.getItem(VFS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (isValidVFSState(parsed)) {
        const freshSeed = buildSeedVFSState();
        let mutated = false;

        for (const nodeId of Object.keys(parsed.nodes)) {
          if (nodeId.startsWith('fil_tmpl_') || nodeId.startsWith('fil_fmt_')) {
            delete parsed.nodes[nodeId];
            mutated = true;
          }
        }
        const stdFld = parsed.nodes['fld_acc_std_formats'] as VFSFolderNode | undefined;
        if (stdFld && stdFld.type === 'folder') {
          stdFld.childrenIds = stdFld.childrenIds.filter(
            (cid) => !cid.startsWith('fil_tmpl_') && !cid.startsWith('fil_fmt_') && Boolean(parsed.nodes[cid])
          );
          if (!stdFld.metadata?.isSystemLinked) {
            stdFld.metadata = { isSystemLinked: true, subjectRestriction: 'Accounting' };
            mutated = true;
          }
        }

        for (const [id, node] of Object.entries(freshSeed.nodes)) {
          if (!parsed.nodes[id]) {
            parsed.nodes[id] = node;
            mutated = true;
            if (node.parentId === null && !parsed.rootFolderIds.includes(id)) parsed.rootFolderIds.push(id);
            else if (node.parentId && parsed.nodes[node.parentId]?.type === 'folder') {
              const parent = parsed.nodes[node.parentId] as VFSFolderNode;
              if (!parent.childrenIds.includes(id)) parent.childrenIds.push(id);
            }
          }
        }
        const lawFld = parsed.nodes['fld_law_precedents'] as VFSFolderNode | undefined;
        if (lawFld && lawFld.type === 'folder' && !lawFld.metadata?.isSystemLinked) {
          lawFld.metadata = { isSystemLinked: true, subjectRestriction: 'Business Law' };
          mutated = true;
        }
        if (mutated) saveVFS(parsed);
        return parsed;
      }
    }
  } catch { /* Fallback to fresh seed */ }
  const seeded = buildSeedVFSState();
  saveVFS(seeded);
  return seeded;
}

export function saveVFS(state: VFSState): void {
  try { localStorage.setItem(VFS_STORAGE_KEY, JSON.stringify(state)); } catch { /* Ignore */ }
  if (typeof window !== 'undefined' && window.questifyElectron?.writeSaveFile) {
    window.questifyElectron.writeSaveFile(state).catch(() => {});
  }
}

export async function syncFromNativeDisk(): Promise<VFSState | null> {
  if (typeof window !== 'undefined' && window.questifyElectron?.readSaveFile) {
    try {
      const diskData = await window.questifyElectron.readSaveFile();
      if (isValidVFSState(diskData)) {
        try { localStorage.setItem(VFS_STORAGE_KEY, JSON.stringify(diskData)); } catch { /* Ignore */ }
        return diskData;
      }
    } catch { /* Ignore */ }
  }
  return null;
}

export function resetVFS(): VFSState {
  const seeded = buildSeedVFSState();
  saveVFS(seeded);
  return seeded;
}

export function getVFSStorageSummary(state: VFSState): { totalFolders: number; totalFiles: number; storageBytes: number } {
  let totalFolders = 0;
  let totalFiles = 0;
  for (const node of Object.values(state.nodes)) {
    if (node.type === 'folder') totalFolders += 1;
    else totalFiles += 1;
  }
  const raw = JSON.stringify(state);
  return { totalFolders, totalFiles, storageBytes: new Blob([raw]).size };
}
