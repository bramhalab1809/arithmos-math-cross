import React, { useEffect, useMemo, useState } from 'react';
import { ExplorerToolbar } from '../features/explorer/components/ExplorerToolbar';
import { FileGridPane } from '../features/explorer/components/FileGridPane';
import { FolderTreePane } from '../features/explorer/components/FolderTreePane';
import { ROOT_FOLDER_ID, addFile, addFolder, calculatePath, deleteNode, pasteClipboard, renameNode, searchVFS } from '../features/explorer/engine/vfsEngine';
import { addTxtFile, buildDefaultFileTemplate, importJsonFilesToVFS, normalizeQuestionBank, readUploadedJsonFiles, updateFileContent } from '../features/explorer/engine/vfsImport';
import { QuestionBankJSON, VFSClipboard, VFSFileNode, VFSFolderNode, VFSNode, VFSState } from '../features/explorer/engine/vfsTypes';
import { FileActionModal } from '../features/explorer/modals/FileActionModal';
import { NodeDialogModal, NodeDialogMode } from '../features/explorer/modals/NodeDialogModal';
import { PromptViewerModal } from '../features/explorer/modals/PromptViewerModal';
import { SettingsModal } from '../features/settings/SettingsModal';
import { AnalyticsDashboardScreen } from '../screens/analytics/AnalyticsDashboardScreen';
import { JsonEditorScreen } from '../screens/editor/JsonEditorScreen';
import { McqPlaygroundScreen } from '../screens/playground/mcq/McqPlaygroundScreen';
import { SubjectivePlaygroundScreen } from '../screens/playground/subjective/SubjectivePlaygroundScreen';
import { ToastPill } from '../ui/feedback/ToastPill';
import { loadOrSeedVFS, resetVFS, saveVFS, syncFromNativeDisk } from './boot/initBoot';

type ActiveScreen = 'explorer' | 'editor' | 'playground' | 'analytics';

export const AppShell: React.FC = () => {
  const [vfsState, setVfsState] = useState<VFSState>(() => loadOrSeedVFS());
  const [activeScreen, setActiveScreen] = useState<ActiveScreen>('explorer');
  const [activeFileId, setActiveFileId] = useState<string | null>(null);
  const [sessionMode, setSessionMode] = useState<'resume' | 'fresh'>('resume');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [clipboard, setClipboard] = useState<VFSClipboard>(null);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(false);
  const [modalFile, setModalFile] = useState<VFSFileNode | null>(null);
  const [promptFile, setPromptFile] = useState<VFSFileNode | null>(null);
  const [nodeDialog, setNodeDialog] = useState<NodeDialogMode>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const notify = (message: string, type: 'success' | 'error' | 'info' = 'info') => setToast({ message, type });
  const commitVFS = (next: VFSState) => { setVfsState(next); saveVFS(next); };
  const handleSelectFolder = (folderId: string) => { commitVFS({ ...vfsState, currentFolderId: folderId }); setSearchQuery(''); };

  useEffect(() => {
    syncFromNativeDisk().then((diskState) => {
      if (diskState) setVfsState(diskState);
    });
    const onVfsUpdated = () => setVfsState(loadOrSeedVFS());
    window.addEventListener('vfs-updated', onVfsUpdated);
    return () => window.removeEventListener('vfs-updated', onVfsUpdated);
  }, []);

  const breadcrumbs = useMemo(() => calculatePath(vfsState, vfsState.currentFolderId), [vfsState]);
  const displayedNodes = useMemo((): VFSNode[] => {
    if (searchQuery.trim()) return searchVFS(vfsState, searchQuery);
    if (vfsState.currentFolderId === ROOT_FOLDER_ID) return vfsState.rootFolderIds.map((id) => vfsState.nodes[id]).filter(Boolean);
    const folder = vfsState.nodes[vfsState.currentFolderId] as VFSFolderNode | undefined;
    if (!folder || folder.type !== 'folder') return [];
    return folder.childrenIds.map((id) => vfsState.nodes[id]).filter(Boolean);
  }, [vfsState, searchQuery]);

  const activeFileNode = useMemo(() => {
    if (!activeFileId) return null;
    const node = vfsState.nodes[activeFileId];
    return node && node.type === 'file' ? node : null;
  }, [activeFileId, vfsState.nodes]);

  const activeParsedBank: QuestionBankJSON | null = useMemo(() => {
    if (!activeFileNode || activeFileNode.fileType === 'txt') return null;
    try { return normalizeQuestionBank(JSON.parse(activeFileNode.content), activeFileNode.name.replace(/\.json$/i, '')); }
    catch { return null; }
  }, [activeFileNode]);

  const handleOpenFileModal = (file: VFSFileNode) => {
    if (file.fileType === 'txt' || file.name.toLowerCase().endsWith('.txt')) setPromptFile(file);
    else setModalFile(file);
  };

  const handleLaunchBank = (file: VFSFileNode, mode: 'resume' | 'fresh' = 'resume') => {
    setModalFile(null); setActiveFileId(file.id); setSessionMode(mode); setActiveScreen('playground');
  };

  const handleImportFiles = async (fileList: FileList | File[]) => {
    const payloads = await readUploadedJsonFiles(fileList);
    if (payloads.length === 0) { notify('No valid files selected.', 'error'); return; }
    const { nextState, importedFiles, failedFiles } = importJsonFilesToVFS(vfsState, payloads, vfsState.currentFolderId);
    commitVFS(nextState);
    if (importedFiles.length > 0) notify(`Uploaded ${importedFiles.length} file(s).`, 'success');
    else if (failedFiles.length > 0) notify(`Failed to upload: ${failedFiles.join(', ')}`, 'error');
  };

  if (activeScreen === 'analytics') {
    return (
      <>
        <AnalyticsDashboardScreen vfsState={vfsState} onBackToExplorer={() => setActiveScreen('explorer')} onLaunchBank={handleLaunchBank} />
        <ToastPill message={toast?.message || null} type={toast?.type} onDismiss={() => setToast(null)} />
      </>
    );
  }

  if (activeScreen === 'editor') {
    return (
      <>
        <JsonEditorScreen
          file={activeFileNode}
          onBackToExplorer={() => setActiveScreen('explorer')}
          onSaveContent={(fileId, content) => { commitVFS(updateFileContent(vfsState, fileId, content)); notify('Saved JSON Question Bank.', 'success'); }}
          onLaunchPlayground={() => { setSessionMode('resume'); setActiveScreen('playground'); }}
          onNotify={notify}
        />
        <ToastPill message={toast?.message || null} type={toast?.type} onDismiss={() => setToast(null)} />
      </>
    );
  }

  if (activeScreen === 'playground' && activeFileNode && activeParsedBank) {
    const isSubj = activeParsedBank.type === 'subjective' || activeParsedBank.type === 'accounts';
    return isSubj ? (
      <SubjectivePlaygroundScreen bank={activeParsedBank} fileId={activeFileNode.id} fileName={activeFileNode.name} sessionMode={sessionMode} onBackToExplorer={() => setActiveScreen('explorer')} />
    ) : (
      <McqPlaygroundScreen bank={activeParsedBank} fileId={activeFileNode.id} fileName={activeFileNode.name} sessionMode={sessionMode} onBackToExplorer={() => setActiveScreen('explorer')} />
    );
  }

  const targetFolderId = vfsState.currentFolderId === ROOT_FOLDER_ID ? vfsState.rootFolderIds[0] || 'fld_accounting' : vfsState.currentFolderId;

  return (
    <div className="h-[100dvh] w-full flex bg-[var(--bg-app)] text-[var(--text-primary)] overflow-hidden">
      <FolderTreePane vfsState={vfsState} isCollapsed={isSidebarCollapsed} onToggleCollapse={() => setIsSidebarCollapsed((c) => !c)} onSelectFolder={handleSelectFolder} onOpenFileModal={handleOpenFileModal} onOpenSettings={() => setIsSettingsOpen(true)} onOpenAnalytics={() => setActiveScreen('analytics')} />

      <div className="flex-1 flex flex-col min-w-0 min-h-0 overflow-hidden">
        <ExplorerToolbar
          breadcrumbs={breadcrumbs}
          searchQuery={searchQuery}
          clipboard={clipboard}
          canGoBack={vfsState.currentFolderId !== ROOT_FOLDER_ID}
          onGoBack={() => { const cur = vfsState.nodes[vfsState.currentFolderId]; handleSelectFolder(cur?.parentId || ROOT_FOLDER_ID); }}
          onNavigateBreadcrumb={handleSelectFolder}
          onSearchChange={setSearchQuery}
          onRequestNewFolder={() => setNodeDialog({ type: 'new-folder' })}
          onRequestNewFile={() => setNodeDialog({ type: 'new-file' })}
          onRequestNewTxtFile={() => setNodeDialog({ type: 'new-txt' })}
          onUploadFiles={(files) => handleImportFiles(files)}
          onPaste={() => {
            if (!clipboard) return;
            const res = pasteClipboard(vfsState, clipboard, targetFolderId);
            commitVFS(res.state); setClipboard(res.clipboard); notify('Pasted item(s).', 'success');
          }}
        />

        <FileGridPane
          vfsState={vfsState}
          displayedNodes={displayedNodes}
          searchQuery={searchQuery}
          clipboard={clipboard}
          onOpenFolder={handleSelectFolder}
          onOpenFileModal={handleOpenFileModal}
          onCutNode={(id) => setClipboard({ action: 'cut', nodeIds: [id] })}
          onCopyNode={(id) => setClipboard({ action: 'copy', nodeIds: [id] })}
          onRequestRename={(node) => setNodeDialog({ type: 'rename', target: node })}
          onDeleteNode={(id) => { commitVFS(deleteNode(vfsState, id)); notify('Deleted item.', 'info'); }}
          onTogglePinFolder={(id) => {
            const curPins = vfsState.pinnedFolderIds || [];
            const nextPins = curPins.includes(id) ? curPins.filter((p) => p !== id) : [...curPins, id];
            commitVFS({ ...vfsState, pinnedFolderIds: nextPins });
          }}
          onRequestNewFolder={() => setNodeDialog({ type: 'new-folder' })}
          onRequestNewFile={() => setNodeDialog({ type: 'new-file' })}
          onRequestNewTxtFile={() => setNodeDialog({ type: 'new-txt' })}
          onDropFiles={(files) => handleImportFiles(files)}
          onClearClipboard={() => setClipboard(null)}
        />
      </div>

      <FileActionModal file={modalFile} onClose={() => setModalFile(null)} onOpenInEditor={(f) => { setModalFile(null); setActiveFileId(f.id); setActiveScreen('editor'); }} onStartPlayground={handleLaunchBank} onOpenAnalytics={() => { setModalFile(null); setActiveScreen('analytics'); }} />
      <PromptViewerModal file={promptFile} onClose={() => setPromptFile(null)} onSaveContent={(fileId, content) => { commitVFS(updateFileContent(vfsState, fileId, content)); setPromptFile((prev) => (prev && prev.id === fileId ? { ...prev, content } : prev)); }} onNotify={notify} />
      <NodeDialogModal dialog={nodeDialog} onClose={() => setNodeDialog(null)} onCreateFolder={(name) => commitVFS(addFolder(vfsState, vfsState.currentFolderId, name))} onCreateFile={(name) => commitVFS(addFile(vfsState, targetFolderId, name, buildDefaultFileTemplate(name)))} onCreateTxtFile={(name) => commitVFS(addTxtFile(vfsState, targetFolderId, name))} onRenameNode={(id, newName) => commitVFS(renameNode(vfsState, id, newName))} />
      <SettingsModal isOpen={isSettingsOpen} vfsState={vfsState} onClose={() => setIsSettingsOpen(false)} onResetVFS={() => { commitVFS(resetVFS()); notify('Restored default ICAI seed files.', 'success'); }} />
      <ToastPill message={toast?.message || null} type={toast?.type} onDismiss={() => setToast(null)} />
    </div>
  );
};
