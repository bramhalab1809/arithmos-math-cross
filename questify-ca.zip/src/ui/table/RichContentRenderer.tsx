import React from 'react';
import { TableData } from '../../features/explorer/engine/vfsTypes';
import { Table } from '../icons';

export interface RichContentRendererProps {
  text?: string;
  content?: string;
  table?: TableData;
  tables?: TableData[];
  className?: string;
}

/**
 * Parses inline markdown: <u>underline</u>, **bold** to <strong>, *italic* to <em>, and ### headings
 */
export function renderFormattedInline(text: string): React.ReactNode {
  if (!text) return null;
  if (text.trim().startsWith('### ')) {
    return <span className="font-bold text-indigo-700 dark:text-indigo-300 underline underline-offset-4">{renderFormattedInline(text.trim().slice(4))}</span>;
  }
  const tokens = text.split(/(<u>[\s\S]*?<\/u>|\*\*[^*]+\*\*|\*[^*]+\*)/gi);

  return tokens.map((token, idx) => {
    if (token.toLowerCase().startsWith('<u>') && token.toLowerCase().endsWith('</u>') && token.length > 7) {
      return (
        <u key={idx} className="underline decoration-2 underline-offset-4 text-slate-900 dark:text-slate-100">
          {renderFormattedInline(token.slice(3, -4))}
        </u>
      );
    }
    if (token.startsWith('**') && token.endsWith('**') && token.length > 4) {
      return (
        <strong key={idx} className="font-semibold text-slate-900 dark:text-slate-100">
          {token.slice(2, -2)}
        </strong>
      );
    }
    if (token.startsWith('*') && token.endsWith('*') && token.length > 2) {
      return (
        <em key={idx} className="italic text-slate-700 dark:text-slate-300">
          {token.slice(1, -1)}
        </em>
      );
    }
    return token;
  });
}

function isNumericOrCurrencyHeader(header: string, colIdx: number): boolean {
  if (colIdx === 0) return false;
  const h = header.toLowerCase();
  return h.includes('debit') || h.includes('credit') || h.includes('rs') || h.includes('₹') || h.includes('amount') || colIdx > 0;
}

function renderSingleTable(tbl: TableData, key: string | number) {
  return (
    <div key={key} className="rounded-xl border border-slate-200 dark:border-slate-700 bg-[var(--bg-surface)] overflow-hidden shadow-2xs my-2.5">
      {tbl.title && (
        <div className="px-3.5 py-2.5 bg-slate-100/90 dark:bg-slate-800/90 border-b border-slate-200 dark:border-slate-700 flex items-center gap-2">
          <Table size={14} className="text-sky-600 dark:text-cyan-400 shrink-0" />
          <span className="text-xs font-bold text-slate-900 dark:text-slate-100 tracking-tight">
            {renderFormattedInline(tbl.title)}
          </span>
        </div>
      )}
      <div className="overflow-x-auto">
        <table className="w-full border-collapse text-xs">
          <thead>
            <tr className="bg-slate-100 dark:bg-slate-800/80 text-slate-800 dark:text-slate-200 font-bold text-xs uppercase tracking-wider border-b border-slate-200 dark:border-slate-700">
              {tbl.headers.map((hdr, cIdx) => {
                const isRight = isNumericOrCurrencyHeader(hdr, cIdx);
                return (
                  <th
                    key={cIdx}
                    className={`px-3.5 py-2.5 ${isRight ? 'text-right font-mono-tabular whitespace-nowrap' : 'text-left'} ${
                      cIdx > 0 ? 'border-l border-slate-200 dark:border-slate-700' : ''
                    }`}
                  >
                    {renderFormattedInline(hdr)}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200/70 dark:divide-slate-800">
            {tbl.rows.map((row, rIdx) => {
              const isRowTotal = row[0] && /total|profit|balance c\/d/i.test(row[0]);
              return (
                <tr
                  key={rIdx}
                  className={`${
                    isRowTotal
                      ? 'bg-slate-100/70 dark:bg-slate-800/60 font-semibold'
                      : 'even:bg-[var(--bg-app)] odd:bg-[var(--bg-surface)] hover:bg-sky-500/5'
                  } transition-colors`}
                >
                  {row.map((cell, cIdx) => {
                    const isRight = isNumericOrCurrencyHeader(tbl.headers[cIdx] || '', cIdx);
                    return (
                      <td
                        key={cIdx}
                        className={`px-3.5 py-2 text-slate-800 dark:text-slate-200 ${
                          isRight ? 'text-right font-mono-tabular whitespace-nowrap' : 'text-left font-medium'
                        } ${cIdx > 0 ? 'border-l border-slate-200/70 dark:border-slate-800' : ''}`}
                      >
                        {renderFormattedInline(cell)}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
          {tbl.totals && tbl.totals.length > 0 && (
            <tfoot>
              <tr className="font-bold font-mono-tabular bg-slate-200/60 dark:bg-slate-800 border-t-2 border-slate-400 dark:border-slate-600 border-b-4 border-double text-slate-900 dark:text-slate-100">
                {tbl.totals.map((tot, cIdx) => {
                  const isRight = isNumericOrCurrencyHeader(tbl.headers[cIdx] || '', cIdx);
                  return (
                    <td
                      key={cIdx}
                      className={`px-3.5 py-2.5 ${isRight ? 'text-right whitespace-nowrap' : 'text-left'} ${
                        cIdx > 0 ? 'border-l border-slate-200 dark:border-slate-700' : ''
                      }`}
                    >
                      {renderFormattedInline(tot)}
                    </td>
                  );
                })}
              </tr>
            </tfoot>
          )}
        </table>
      </div>
    </div>
  );
}

type Segment = { type: 'text'; content: string } | { type: 'table'; data: TableData };

function parseMarkdownSegments(rawText: string): Segment[] {
  const lines = rawText.split('\n');
  const segments: Segment[] = [];
  let textBuffer: string[] = [];
  let tableBuffer: string[] = [];
  let pendingTitle: string | undefined;

  const flushText = () => {
    const joined = textBuffer.join('\n').trim();
    if (joined) segments.push({ type: 'text', content: joined });
    textBuffer = [];
  };

  const flushTable = () => {
    if (tableBuffer.length < 2) {
      textBuffer.push(...tableBuffer);
      tableBuffer = [];
      pendingTitle = undefined;
      return;
    }
    const parsedRows = tableBuffer
      .filter((line) => !/^\s*\|[\s\-:|]+\|\s*$/.test(line))
      .map((line) => line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((cell) => cell.trim()));

    if (parsedRows.length >= 2) {
      const headers = parsedRows[0];
      const bodyRows = parsedRows.slice(1);
      const lastRow = bodyRows[bodyRows.length - 1];
      const isTotalRow = lastRow && /^total/i.test(lastRow[0].replace(/\*/g, ''));
      const rows = isTotalRow ? bodyRows.slice(0, -1) : bodyRows;
      const totals = isTotalRow ? lastRow : undefined;
      segments.push({ type: 'table', data: { title: pendingTitle, headers, rows, totals } });
    }
    tableBuffer = [];
    pendingTitle = undefined;
  };

  for (const line of lines) {
    const trimmed = line.trim();
    const isPipe = trimmed.startsWith('|') && trimmed.endsWith('|');
    if (isPipe) {
      if (tableBuffer.length === 0 && textBuffer.length > 0) {
        const lastTextLine = textBuffer[textBuffer.length - 1].trim();
        if (lastTextLine && lastTextLine.endsWith(':') && lastTextLine.length < 95) {
          pendingTitle = lastTextLine.replace(/:$/, '');
          textBuffer.pop();
        }
        flushText();
      }
      tableBuffer.push(trimmed);
    } else {
      if (tableBuffer.length > 0) flushTable();
      textBuffer.push(line);
    }
  }
  if (tableBuffer.length > 0) flushTable();
  flushText();
  return segments;
}

export const RichContentRenderer: React.FC<RichContentRendererProps> = ({ text, content, table, tables, className = '' }) => {
  const rawString = text ?? content ?? '';
  const allTables: TableData[] = [...(table ? [table] : []), ...(tables || [])];
  const segments = rawString ? parseMarkdownSegments(rawString) : [];

  return (
    <div className={`rich-content-body space-y-2.5 ${className}`}>
      {allTables.map((tbl, idx) => renderSingleTable(tbl, `prop_tbl_${idx}`))}
      {segments.map((seg, idx) =>
        seg.type === 'table' ? (
          renderSingleTable(seg.data, `md_tbl_${idx}`)
        ) : (
          <div key={`txt_${idx}`} className="space-y-1.5">
            {seg.content.split('\n').map((line, lIdx) =>
              line.trim() ? (
                <p key={lIdx} className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed">
                  {renderFormattedInline(line)}
                </p>
              ) : null
            )}
          </div>
        )
      )}
    </div>
  );
};
