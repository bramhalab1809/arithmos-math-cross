import React, { useEffect } from 'react';
import { AlertCircle, CheckCircle2, Sparkles, X } from '../../ui/icons';

interface ToastPillProps {
  message: string | null;
  type?: 'success' | 'error' | 'info';
  onDismiss: () => void;
}

export const ToastPill: React.FC<ToastPillProps> = ({
  message,
  type = 'info',
  onDismiss,
}) => {
  useEffect(() => {
    if (!message) return;
    const timer = window.setTimeout(() => {
      onDismiss();
    }, 3500);
    return () => window.clearTimeout(timer);
  }, [message, onDismiss]);

  if (!message) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-5 left-1/2 -translate-x-1/2 rounded-full bg-slate-900/95 dark:bg-slate-100/95 text-white dark:text-slate-900 px-4 py-2 text-xs font-medium shadow-xl backdrop-blur-md border border-white/10 dark:border-slate-900/10 z-50 flex items-center gap-2 transition-all"
    >
      {type === 'success' && (
        <CheckCircle2 size={15} className="text-emerald-400 dark:text-emerald-600 shrink-0" />
      )}
      {type === 'error' && (
        <AlertCircle size={15} className="text-rose-400 dark:text-rose-600 shrink-0" />
      )}
      {type === 'info' && (
        <Sparkles size={15} className="text-sky-400 dark:text-sky-600 shrink-0" />
      )}
      <span className="truncate max-w-[75vw] sm:max-w-md">{message}</span>
      <button
        type="button"
        onClick={onDismiss}
        className="p-0.5 rounded-full opacity-70 hover:opacity-100 transition-opacity shrink-0"
        aria-label="Dismiss notification"
      >
        <X size={13} />
      </button>
    </div>
  );
};
