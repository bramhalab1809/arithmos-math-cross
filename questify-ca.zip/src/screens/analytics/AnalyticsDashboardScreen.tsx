import React, { useMemo, useState } from 'react';
import { VFSFileNode, VFSState } from '../../features/explorer/engine/vfsTypes';
import { Icon } from '../../ui/icons';
import { computeGlobalAnalytics } from '../../features/analytics/engine/analyticsEngine';
import { CanonicalSubject, QuestionSourceTag } from '../../features/playground/shared/sessionStore';

interface AnalyticsDashboardScreenProps {
  vfsState: VFSState;
  onBackToExplorer: () => void;
  onLaunchBank: (file: VFSFileNode, mode: 'resume' | 'fresh') => void;
}

const SUBJECT_FILTERS: ('All' | CanonicalSubject)[] = ['All', 'Accounting', 'Business Law', 'Business Economics', 'Quantitative Aptitude'];
const SOURCE_FILTERS: ('All' | QuestionSourceTag)[] = ['All', 'PYQ', 'RTP', 'MTP', 'ICAI Study Material', 'Other Faculties'];

export const AnalyticsDashboardScreen: React.FC<AnalyticsDashboardScreenProps> = ({
  vfsState, onBackToExplorer, onLaunchBank,
}) => {
  const [subjectFilter, setSubjectFilter] = useState<'All' | CanonicalSubject>('All');
  const [sourceFilter, setSourceFilter] = useState<'All' | QuestionSourceTag>('All');
  const report = useMemo(() => computeGlobalAnalytics(vfsState), [vfsState]);

  const filteredBanks = useMemo(
    () => report.bankRows.filter((r) => (subjectFilter === 'All' || r.subject === subjectFilter) && (sourceFilter === 'All' || r.sourceTag === sourceFilter)),
    [report.bankRows, subjectFilter, sourceFilter]
  );

  const fmtTime = (sec: number) => {
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    return h > 0 ? `${h}h ${m}m` : `${m}m ${sec % 60}s`;
  };

  const kpis = [
    { label: 'Questions Solved', val: `${report.totalQuestionsSolved} / ${report.totalQuestionsAvailable}`, sub: `${report.completedBanks} Completed • ${report.inProgressBanks} In Progress`, icon: 'check-circle-2' as const, color: 'text-emerald-500' },
    { label: 'Overall Accuracy', val: `${report.overallAccuracyPercent}%`, sub: `${report.totalCorrect} Correct / Evaluated`, icon: 'award' as const, color: 'text-indigo-500' },
    { label: 'Total Study Time', val: fmtTime(report.totalStudySeconds), sub: `Avg ${report.avgSecondsPerQuestion}s / question`, icon: 'clock' as const, color: 'text-amber-500' },
    { label: 'Exam Readiness Score', val: `${report.examReadinessScore}%`, sub: 'Weighted Accuracy & Coverage', icon: 'trending-up' as const, color: 'text-emerald-500' },
  ];

  return (
    <div className="h-[100dvh] w-full flex flex-col bg-[var(--bg-app)] text-[var(--text-primary)] overflow-hidden">
      <header className="h-14 px-4 lg:px-6 border-b border-[var(--border-subtle)] bg-[var(--bg-surface)] flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          <button type="button" onClick={onBackToExplorer} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[var(--bg-app)] border border-[var(--border-subtle)] hover:border-sky-500 text-xs font-medium shrink-0">
            <Icon name="arrow-left" size={14} /><span>Explorer</span>
          </button>
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-sky-500/12 text-sky-500 flex items-center justify-center shrink-0">
              <Icon name="bar-chart-2" size={17} />
            </div>
            <div className="min-w-0">
              <h1 className="text-sm font-bold truncate">CA Foundation Performance &amp; Source Analytics</h1>
              <p className="text-[11px] text-[var(--text-muted)] truncate hidden sm:block">Real-Time PYQ, RTP, MTP &amp; ICAI Study Material Mastery Tracker</p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {SUBJECT_FILTERS.map((subj) => (
            <button key={subj} type="button" onClick={() => setSubjectFilter(subj)} className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap ${subjectFilter === subj ? 'bg-sky-500 text-white shadow-xs' : 'bg-[var(--bg-app)] text-[var(--text-muted)] border border-[var(--border-subtle)]'}`}>
              {subj}
            </button>
          ))}
        </div>
      </header>

      <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-5 max-w-7xl w-full mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {kpis.map((k) => (
            <div key={k.label} className="rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] p-4">
              <div className="flex items-center justify-between text-xs text-[var(--text-muted)] font-semibold">
                <span>{k.label}</span><Icon name={k.icon} size={16} className={k.color} />
              </div>
              <div className={`mt-2 text-2xl font-bold font-mono-tabular ${k.color}`}>{k.val}</div>
              <p className="mt-1.5 text-[11px] text-[var(--text-muted)]">{k.sub}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div className="rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] p-5 space-y-3.5">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold">Source-Wise Practice Distribution</h2>
                <p className="text-xs text-[var(--text-muted)]">Completion &amp; accuracy across PYQ, RTP, MTP &amp; ICAI Material</p>
              </div>
              <Icon name="layers" size={16} className="text-sky-500" />
            </div>
            <div className="space-y-3">
              {report.sourceBreakdown.map((src) => (
                <div key={src.sourceTag} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold">{src.sourceTag} <span className="text-[11px] font-normal text-[var(--text-muted)]">({src.totalBanks} banks)</span></span>
                    <span className="font-mono-tabular text-[11px] text-[var(--text-muted)]">Solved {src.attemptedQuestions}/{src.totalQuestions} &bull; <strong className="text-emerald-500">{src.accuracyPercent}% Acc</strong></span>
                  </div>
                  <div className="h-2.5 w-full rounded-full bg-[var(--bg-app)] overflow-hidden">
                    <div className="h-full bg-indigo-500 transition-all" style={{ width: `${src.completionPercent}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] p-5 space-y-3.5">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold">Subject-Wise Mastery &amp; Accuracy</h2>
                <p className="text-xs text-[var(--text-muted)]">CA Foundation Papers 1 to 4 performance breakdown</p>
              </div>
              <Icon name="activity" size={16} className="text-emerald-500" />
            </div>
            <div className="space-y-3">
              {report.subjectBreakdown.map((sub) => (
                <div key={sub.subject} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold">{sub.paperLabel}</span>
                    <span className="font-mono-tabular text-[11px] text-[var(--text-muted)]">{sub.attemptedQuestions}/{sub.totalQuestions} Qs &bull; <strong className="text-indigo-500">{sub.accuracyPercent}% Acc</strong> &bull; {fmtTime(sub.elapsedSeconds)}</span>
                  </div>
                  <div className="h-2.5 w-full rounded-full bg-[var(--bg-app)] overflow-hidden">
                    <div className="h-full bg-emerald-500 transition-all" style={{ width: `${sub.masteryPercent}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] overflow-hidden">
          <div className="px-5 py-3.5 border-b border-[var(--border-subtle)] flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-sm font-bold">Question Bank Performance &amp; Quick-Launch ({filteredBanks.length})</h2>
              <p className="text-xs text-[var(--text-muted)]">Resume any in-progress session directly or start a fresh attempt</p>
            </div>
            <div className="flex items-center gap-1.5 flex-wrap">
              {SOURCE_FILTERS.map((src) => (
                <button key={src} type="button" onClick={() => setSourceFilter(src)} className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold ${sourceFilter === src ? 'bg-indigo-600 text-white' : 'bg-[var(--bg-app)] text-[var(--text-muted)]'}`}>
                  {src}
                </button>
              ))}
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-[var(--border-subtle)] bg-[var(--bg-app)] text-[11px] font-bold uppercase text-[var(--text-muted)]">
                  <th className="py-2.5 px-4">Question Bank</th>
                  <th className="py-2.5 px-3">Subject</th>
                  <th className="py-2.5 px-3">Source</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Progress</th>
                  <th className="py-2.5 px-3">Accuracy</th>
                  <th className="py-2.5 px-3">Time</th>
                  <th className="py-2.5 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--border-subtle)]">
                {filteredBanks.map((row) => (
                  <tr key={row.fileId} className="hover:bg-[var(--bg-app)]/50">
                    <td className="py-2.5 px-4 font-semibold max-w-[240px] truncate">{row.title}</td>
                    <td className="py-2.5 px-3 text-[var(--text-muted)]">{row.subject}</td>
                    <td className="py-2.5 px-3"><span className="px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-500 font-mono-tabular text-[10px] font-semibold">{row.sourceTag}</span></td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${row.status === 'completed' ? 'bg-emerald-500/15 text-emerald-500' : row.status === 'in-progress' ? 'bg-amber-500/15 text-amber-500' : 'bg-[var(--bg-app)] text-[var(--text-muted)]'}`}>
                        {row.status === 'completed' ? 'Completed' : row.status === 'in-progress' ? 'In Progress' : 'Not Started'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-mono-tabular">{row.attemptedCount}/{row.totalQuestions}</td>
                    <td className="py-2.5 px-3 font-mono-tabular font-bold text-emerald-500">{row.accuracyPercent}%</td>
                    <td className="py-2.5 px-3 font-mono-tabular text-[var(--text-muted)]">{fmtTime(row.elapsedSeconds)}</td>
                    <td className="py-2.5 px-4 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        {row.status !== 'not-started' && (
                          <button type="button" onClick={() => onLaunchBank(row.fileNode, 'resume')} className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-semibold">Resume</button>
                        )}
                        <button type="button" onClick={() => onLaunchBank(row.fileNode, 'fresh')} className="px-2.5 py-1 rounded-lg bg-[var(--bg-app)] border border-[var(--border-subtle)] hover:border-sky-500 text-[11px] font-semibold">
                          {row.status === 'not-started' ? 'Start' : 'Start Fresh'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
