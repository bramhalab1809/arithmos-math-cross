import React, { useEffect, useMemo, useState } from 'react';
import { QuestionBankJSON } from '../../../features/explorer/engine/vfsTypes';
import { CasioMJ12DCalculator } from '../../../features/playground/accounts/CasioMJ12DCalculator';
import { ExportModal } from '../../../features/playground/export/ExportModal';
import { hasSavedLawContent } from '../../../features/playground/law/LawAnswerWriter';
import { QuestionPalette } from '../../../features/playground/mcq/QuestionPalette';
import { TimerPill } from '../../../features/playground/mcq/TimerPill';
import { buildInitialSessionFromBank, getBankSession, saveBankSession } from '../../../features/playground/shared/sessionStore';
import { AnswerImageGallery } from '../../../features/playground/subjective/AnswerImageGallery';
import { DigitalAnswerWriter, hasSavedBlocksContent, loadSavedDigitalAnswer } from '../../../features/playground/subjective/DigitalAnswerWriter';
import { ModelAnswerModal } from '../../../features/playground/subjective/ModelAnswerModal';
import { PeekDisplayMode, QuestionPeekSheet, getUnifiedQuestionStatement } from '../../../features/playground/subjective/QuestionPeekSheet';
import { SubjectiveHeader } from '../../../features/playground/subjective/SubjectiveHeader';
import { loadBankAnswerImages, saveBankAnswerImages } from '../../../services/storage/imageStore';
import { ArrowLeft, ArrowRight, Camera, ChevronLeft, ChevronRight, Edit3, Lock, Unlock } from '../../../ui/icons';
import { ExitConfirmModal } from '../../../ui/modals/ExitConfirmModal';
import { RichContentRenderer } from '../../../ui/table/RichContentRenderer';

interface SubjectivePlaygroundScreenProps {
  bank: QuestionBankJSON;
  fileId: string;
  fileName: string;
  sessionMode?: 'resume' | 'fresh';
  onBackToExplorer: () => void;
}

export const SubjectivePlaygroundScreen: React.FC<SubjectivePlaygroundScreenProps> = ({
  bank, fileId, fileName, sessionMode = 'resume', onBackToExplorer,
}) => {
  const questions = useMemo(() => bank.questions || [], [bank.questions]);
  const totalCount = questions.length;
  const isLawSubject = useMemo(() => {
    const hay = `${bank.subject || ''} ${bank.title || ''} ${fileName}`.toLowerCase();
    return hay.includes('law') || hay.includes('companies') || hay.includes('contract');
  }, [bank.subject, bank.title, fileName]);

  const initialRecord = useMemo(() => {
    const existing = getBankSession(fileId);
    if (sessionMode === 'resume' && existing && existing.status !== 'not-started') return existing;
    return buildInitialSessionFromBank(fileId, fileName, bank);
  }, [bank, fileId, fileName, sessionMode]);

  const [currentIndex, setCurrentIndex] = useState<number>(() => Math.min(initialRecord.currentIndex || 0, Math.max(0, totalCount - 1)));
  const [solveMode, setSolveMode] = useState<'digital' | 'upload'>('upload');
  const [isSheetLocked, setIsSheetLocked] = useState<boolean>(false);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(() => initialRecord.status === 'completed');
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(() => initialRecord.elapsedSeconds || 0);
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(() => (typeof window !== 'undefined' ? window.innerWidth >= 1024 : true));
  const [isCalculatorOpen, setIsCalculatorOpen] = useState<boolean>(false);
  const [isQuestionPeekOpen, setIsQuestionPeekOpen] = useState<boolean>(false);
  const [peekDisplayMode, setPeekDisplayMode] = useState<PeekDisplayMode>(() => (typeof window !== 'undefined' && window.innerWidth >= 1024 ? 'split' : 'floating'));
  const [isModelAnswerOpen, setIsModelAnswerOpen] = useState<boolean>(false);
  const [isExportOpen, setIsExportOpen] = useState<boolean>(false);
  const [isExitModalOpen, setIsExitModalOpen] = useState<boolean>(false);
  const [imageMap, setImageMap] = useState<Record<string, string[]>>({});
  const [digitalAnsweredMap, setDigitalAnsweredMap] = useState<Record<string, boolean>>({});
  const [visitedIndices, setVisitedIndices] = useState<Set<number>>(() => new Set(initialRecord.visitedIndices?.length ? initialRecord.visitedIndices : [0]));

  useEffect(() => {
    let mounted = true;
    loadBankAnswerImages(fileId).then((loaded) => { if (mounted) setImageMap(loaded || {}); });
    const statusMap: Record<string, boolean> = {};
    questions.forEach((q, idx) => {
      const qId = q.id || `q_${idx}`;
      statusMap[qId] = isLawSubject ? hasSavedLawContent(fileId, qId) : hasSavedBlocksContent(loadSavedDigitalAnswer(fileId, qId).blocks);
    });
    setDigitalAnsweredMap(statusMap);
    return () => { mounted = false; };
  }, [fileId, isLawSubject, questions]);

  useEffect(() => {
    if (isPaused || isSubmitted) return;
    const id = window.setInterval(() => setElapsedSeconds((s) => s + 1), 1000);
    return () => window.clearInterval(id);
  }, [isPaused, isSubmitted]);

  const selectedAnswers = useMemo(() => {
    const map: Record<number, number> = {};
    questions.forEach((q, idx) => {
      const qId = q.id || `q_${idx}`;
      if (digitalAnsweredMap[qId] || (imageMap[qId] && imageMap[qId].length > 0)) map[idx] = 0;
    });
    return map;
  }, [digitalAnsweredMap, imageMap, questions]);

  const solvedCount = Object.keys(selectedAnswers).length;

  useEffect(() => {
    const status = isSubmitted ? 'completed' : solvedCount > 0 || elapsedSeconds > 3 ? 'in-progress' : 'not-started';
    const pct = totalCount > 0 ? Math.round((solvedCount / totalCount) * 100) : 0;
    saveBankSession({
      ...initialRecord, status, currentIndex, selectedAnswers, visitedIndices: Array.from(visitedIndices),
      elapsedSeconds, attemptedCount: solvedCount, correctCount: solvedCount, accuracyPercent: pct,
      totalQuestions: totalCount, updatedAt: new Date().toISOString(),
    });
  }, [currentIndex, elapsedSeconds, initialRecord, isSubmitted, selectedAnswers, solvedCount, totalCount, visitedIndices]);

  useEffect(() => {
    const onBeforeUnload = (e: BeforeUnloadEvent) => { if (!isSubmitted && solvedCount > 0) { e.preventDefault(); e.returnValue = ''; } };
    const onKeyDown = (e: KeyboardEvent) => { if (e.altKey && e.key === 'ArrowLeft') { e.preventDefault(); setIsExitModalOpen(true); } };
    window.addEventListener('beforeunload', onBeforeUnload);
    window.addEventListener('keydown', onKeyDown);
    return () => { window.removeEventListener('beforeunload', onBeforeUnload); window.removeEventListener('keydown', onKeyDown); };
  }, [isSubmitted, solvedCount]);

  const currentQuestion = questions[currentIndex];
  if (!currentQuestion) return null;
  const currentQId = currentQuestion.id || `q_${currentIndex}`;
  const currentPhotos = imageMap[currentQId] || [];
  const marks = currentQuestion.marks || 5;

  const updateQuestionPhotos = (nextPhotos: string[]) => {
    const nextMap = { ...imageMap, [currentQId]: nextPhotos };
    setImageMap(nextMap);
    saveBankAnswerImages(fileId, nextMap);
  };

  return (
    <div className="h-[100dvh] w-full flex flex-col bg-slate-50 dark:bg-slate-950 overflow-hidden">
      <SubjectiveHeader title={bank.title || fileName.replace(/\.json$/i, '')} elapsedSeconds={elapsedSeconds} isPaused={isPaused} isSubmitted={isSubmitted} isCalculatorOpen={isCalculatorOpen} onBackToExplorer={() => setIsExitModalOpen(true)} onTogglePause={() => setIsPaused((p) => !p)} onToggleCalculator={() => setIsCalculatorOpen((v) => !v)} onOpenExport={() => setIsExportOpen(true)} onOpenModelAnswer={() => setIsModelAnswerOpen(true)} onToggleSubmitted={() => setIsSubmitted((s) => !s)} />

      <div className="relative flex-1 min-h-0 flex gap-3 sm:gap-4 p-3 sm:p-4 overflow-hidden">
        {isSidebarOpen && (
          <div className="fixed inset-0 z-30 bg-slate-950/45 backdrop-blur-xs lg:hidden" onClick={() => setIsSidebarOpen(false)} />
        )}

        <aside className={`${isSidebarOpen ? 'fixed inset-y-0 left-0 z-40 w-72 sm:w-80 lg:static lg:w-72 flex' : 'hidden'} shrink-0 flex-col gap-3 p-3.5 sm:p-4 bg-[var(--bg-surface)] lg:rounded-2xl border-r lg:border border-[var(--border-subtle)] shadow-xl lg:shadow-xs overflow-y-auto`}>
          <div className="flex items-center justify-between shrink-0">
            <span className="text-xs font-bold uppercase tracking-wider text-[var(--text-muted)]">Questions ({totalCount})</span>
            <button type="button" onClick={() => setIsSidebarOpen(false)} className="p-1.5 rounded-lg border border-[var(--border-subtle)] text-[var(--text-secondary)] hover:bg-[var(--bg-app)]" title="Collapse Palette">
              <ChevronLeft size={14} />
            </button>
          </div>
          <TimerPill elapsedSeconds={elapsedSeconds} isPaused={isPaused} isSubmitted={isSubmitted} onTogglePause={() => setIsPaused((p) => !p)} />
          <QuestionPalette questions={questions} currentIndex={currentIndex} selectedAnswers={selectedAnswers} visitedIndices={visitedIndices} isSubmitted={false} onSelectQuestion={(idx) => { setCurrentIndex(idx); setVisitedIndices((prev) => (prev.has(idx) ? prev : new Set(prev).add(idx))); if (window.innerWidth < 1024) setIsSidebarOpen(false); }} />
        </aside>

        <main className="flex-1 min-h-0 flex flex-col rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
          <div className="px-4 py-2.5 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 shrink-0">
            <div className="flex items-center gap-2 min-w-0">
              {!isSidebarOpen && (
                <button type="button" onClick={() => setIsSidebarOpen(true)} className="flex items-center gap-1 px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-mono-tabular font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800">
                  <span>Q1 - Q{totalCount}</span><ChevronRight size={13} />
                </button>
              )}
              <span className="text-xs sm:text-sm font-bold font-mono-tabular text-slate-900 dark:text-slate-100">Q{currentIndex + 1}.</span>
              <span className="text-xs text-slate-500 dark:text-slate-400 truncate">{currentQuestion.topic || bank.chapter || 'Subjective Problem'}</span>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <div className="flex items-center p-0.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <button type="button" onClick={() => setSolveMode('digital')} className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors ${solveMode === 'digital' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-2xs' : 'text-slate-600 dark:text-slate-400'}`}>
                  <Edit3 size={12} /><span>Digital</span>
                </button>
                <button type="button" onClick={() => setSolveMode('upload')} className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors ${solveMode === 'upload' ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-2xs' : 'text-slate-600 dark:text-slate-400'}`}>
                  <Camera size={12} /><span>Photos ({currentPhotos.length})</span>
                </button>
              </div>
              {solveMode === 'digital' && (
                <button type="button" onClick={() => setIsSheetLocked((v) => !v)} className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200">
                  {isSheetLocked ? <Lock size={12} /> : <Unlock size={12} />}<span className="hidden sm:inline">{isSheetLocked ? 'Locked' : 'Edit Sheet'}</span>
                </button>
              )}
              <span className="px-2.5 py-1 rounded-lg bg-amber-500/12 border border-amber-500/30 text-amber-700 dark:text-amber-300 text-xs font-mono-tabular font-semibold">{marks} Marks</span>
            </div>
          </div>

          <div className="flex-1 min-h-0 flex flex-col p-3 sm:p-4 overflow-hidden">
            {solveMode === 'digital' ? (
              <div className="flex-1 min-h-0 flex flex-col lg:flex-row gap-4 overflow-hidden">
                <QuestionPeekSheet isOpen={isQuestionPeekOpen} question={currentQuestion} questionNumber={currentIndex + 1} displayMode={peekDisplayMode} onChangeDisplayMode={setPeekDisplayMode} onClose={() => setIsQuestionPeekOpen(false)} />
                <div className={`flex-1 min-h-0 flex flex-col ${isQuestionPeekOpen && peekDisplayMode === 'split' ? 'w-full lg:w-1/2 h-full' : 'w-full h-full'}`}>
                  <DigitalAnswerWriter bankId={fileId} questionId={currentQId} isLawSubject={isLawSubject} isSubmitted={isSubmitted || isSheetLocked} isQuestionPeekOpen={isQuestionPeekOpen} onToggleQuestionPeek={() => setIsQuestionPeekOpen((v) => !v)} onAnswerStatusChange={(hasContent) => setDigitalAnsweredMap((prev) => (prev[currentQId] === hasContent ? prev : { ...prev, [currentQId]: hasContent }))} />
                </div>
              </div>
            ) : (
              <div className="flex-1 min-h-0 overflow-y-auto space-y-4 pr-0.5">
                <div className="p-4 sm:p-5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-3 shadow-2xs">
                  <RichContentRenderer text={getUnifiedQuestionStatement(currentQuestion)} table={currentQuestion.table} tables={currentQuestion.tables} />
                </div>
                <AnswerImageGallery images={currentPhotos} isSubmitted={isSubmitted} onAddImages={(added) => updateQuestionPhotos([...currentPhotos, ...added])} onRemoveImage={(idx) => updateQuestionPhotos(currentPhotos.filter((_, i) => i !== idx))} />
              </div>
            )}
          </div>

          <footer className="px-4 py-2.5 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 bg-slate-50/60 dark:bg-slate-900 shrink-0">
            <button type="button" disabled={currentIndex === 0} onClick={() => setCurrentIndex((i) => Math.max(0, i - 1))} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 disabled:opacity-40">
              <ArrowLeft size={13} /><span>Previous</span>
            </button>
            <span className="text-xs font-mono-tabular text-slate-500">{solvedCount} / {totalCount} Solved</span>
            <button type="button" disabled={currentIndex >= totalCount - 1} onClick={() => setCurrentIndex((i) => Math.min(totalCount - 1, i + 1))} className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white disabled:opacity-40">
              <span>Next</span><ArrowRight size={13} />
            </button>
          </footer>
        </main>
      </div>

      <ModelAnswerModal isOpen={isModelAnswerOpen} questionNumber={currentIndex + 1} questionTopic={currentQuestion.topic || bank.chapter} marks={marks} modelAnswerText={currentQuestion.modelAnswer || currentQuestion.explanation || 'Model solution not provided.'} onClose={() => setIsModelAnswerOpen(false)} />
      <ExportModal isOpen={isExportOpen} exportContext={{ bankId: fileId, bankTitle: bank.title || fileName, subject: bank.subject || 'CA Foundation', questionNumber: currentIndex + 1, question: currentQuestion, isLawSubject }} onClose={() => setIsExportOpen(false)} />
      <CasioMJ12DCalculator isOpen={isCalculatorOpen} onClose={() => setIsCalculatorOpen(false)} />
      <ExitConfirmModal isOpen={isExitModalOpen} progressSummary={`Progress saved: ${solvedCount} of ${totalCount} subjective questions drafted or uploaded.`} onCancel={() => setIsExitModalOpen(false)} onConfirmExit={onBackToExplorer} />
    </div>
  );
};
