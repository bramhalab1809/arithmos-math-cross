import React, { useEffect, useMemo, useState } from 'react';
import { QuestionBankJSON, isTrueFalseBank, isTrueFalseQuestion } from '../../../features/explorer/engine/vfsTypes';
import { CasioMJ12DCalculator } from '../../../features/playground/accounts/CasioMJ12DCalculator';
import { QuestionCard } from '../../../features/playground/mcq/QuestionCard';
import { QuestionPalette } from '../../../features/playground/mcq/QuestionPalette';
import { ScoreModal } from '../../../features/playground/mcq/ScoreModal';
import { TimerPill, formatDurationMMSS } from '../../../features/playground/mcq/TimerPill';
import { TrueFalseCard } from '../../../features/playground/mcq/TrueFalseCard';
import { buildInitialSessionFromBank, getBankSession, saveBankSession } from '../../../features/playground/shared/sessionStore';
import { ArrowLeft, ArrowRight, CheckCircle2, ChevronLeft, ChevronRight, FileJson, HelpCircle, Icon, Pause, Play, Timer } from '../../../ui/icons';
import { ExitConfirmModal } from '../../../ui/modals/ExitConfirmModal';

interface McqPlaygroundScreenProps {
  bank: QuestionBankJSON;
  fileId: string;
  fileName: string;
  sessionMode?: 'resume' | 'fresh';
  onBackToExplorer: () => void;
}

export const McqPlaygroundScreen: React.FC<McqPlaygroundScreenProps> = ({
  bank, fileId, fileName, sessionMode = 'resume', onBackToExplorer,
}) => {
  const questions = bank.questions || [];
  const totalCount = questions.length;
  const isTFBank = isTrueFalseBank(bank);

  const initialRecord = useMemo(() => {
    const existing = getBankSession(fileId);
    if (sessionMode === 'resume' && existing && existing.status !== 'not-started') return existing;
    return buildInitialSessionFromBank(fileId, fileName, bank);
  }, [bank, fileId, fileName, sessionMode]);

  const [currentIndex, setCurrentIndex] = useState<number>(() => Math.min(initialRecord.currentIndex || 0, Math.max(0, totalCount - 1)));
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>(() => initialRecord.selectedAnswers || {});
  const [reasonNotes, setReasonNotes] = useState<Record<number, string>>(() => initialRecord.reasonNotes || {});
  const [visitedIndices, setVisitedIndices] = useState<Set<number>>(() => new Set(initialRecord.visitedIndices?.length ? initialRecord.visitedIndices : [0]));
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(() => initialRecord.elapsedSeconds || 0);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(() => initialRecord.status === 'completed');
  const [isScoreModalOpen, setIsScoreModalOpen] = useState<boolean>(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(() => (typeof window !== 'undefined' ? window.innerWidth >= 1024 : true));
  const [isCalculatorOpen, setIsCalculatorOpen] = useState<boolean>(false);
  const [showHint, setShowHint] = useState<boolean>(false);
  const [isExitModalOpen, setIsExitModalOpen] = useState<boolean>(false);

  const currentQuestion = questions[currentIndex];
  const answeredCount = Object.keys(selectedAnswers).length;
  const correctCount = questions.reduce((acc, q, idx) => {
    const ans = selectedAnswers[idx];
    return ans !== undefined && ans === Number(q.correctAnswer ?? 0) ? acc + 1 : acc;
  }, 0);

  useEffect(() => {
    if (isPaused || isSubmitted) return;
    const id = window.setInterval(() => setElapsedSeconds((s) => s + 1), 1000);
    return () => window.clearInterval(id);
  }, [isPaused, isSubmitted]);

  useEffect(() => {
    setShowHint(false);
    setVisitedIndices((prev) => (prev.has(currentIndex) ? prev : new Set(prev).add(currentIndex)));
  }, [currentIndex]);

  useEffect(() => {
    const accuracy = totalCount > 0 ? Math.round((correctCount / totalCount) * 100) : 0;
    const status = isSubmitted ? 'completed' : answeredCount > 0 || elapsedSeconds > 3 ? 'in-progress' : 'not-started';
    saveBankSession({
      ...initialRecord, status, currentIndex, selectedAnswers, reasonNotes,
      visitedIndices: Array.from(visitedIndices), elapsedSeconds, attemptedCount: answeredCount,
      correctCount, accuracyPercent: accuracy, totalQuestions: totalCount, updatedAt: new Date().toISOString(),
    });
  }, [answeredCount, correctCount, currentIndex, elapsedSeconds, initialRecord, isSubmitted, reasonNotes, selectedAnswers, totalCount, visitedIndices]);

  useEffect(() => {
    const onBeforeUnload = (e: BeforeUnloadEvent) => {
      if (!isSubmitted && answeredCount > 0) { e.preventDefault(); e.returnValue = ''; }
    };
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && e.key === 'ArrowLeft') { e.preventDefault(); setIsExitModalOpen(true); }
    };
    window.addEventListener('beforeunload', onBeforeUnload);
    window.addEventListener('keydown', onKeyDown);
    return () => { window.removeEventListener('beforeunload', onBeforeUnload); window.removeEventListener('keydown', onKeyDown); };
  }, [answeredCount, isSubmitted]);

  const handleRetake = () => {
    setSelectedAnswers({}); setReasonNotes({}); setVisitedIndices(new Set([0]));
    setCurrentIndex(0); setElapsedSeconds(0); setIsSubmitted(false); setIsScoreModalOpen(false);
  };

  if (!currentQuestion) return null;
  const isCurrentTF = isTFBank || isTrueFalseQuestion(currentQuestion, bank.type);
  const marks = currentQuestion.marks || (isCurrentTF ? 2 : 1);

  return (
    <div className="h-[100dvh] w-full flex flex-col bg-slate-50 dark:bg-slate-950 overflow-hidden">
      <header className="h-14 shrink-0 px-3 sm:px-6 flex items-center justify-between gap-2 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 z-20">
        <div className="flex items-center gap-2.5 min-w-0">
          <button type="button" onClick={() => setIsExitModalOpen(true)} className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-slate-400 text-slate-800 dark:text-slate-200 shrink-0">
            <ArrowLeft size={14} /><span className="hidden sm:inline">Explorer</span>
          </button>
          <FileJson size={16} className="text-emerald-500 shrink-0" />
          <h1 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-slate-100 truncate">
            {bank.title || fileName.replace(/\.json$/i, '')}
          </h1>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button type="button" onClick={() => setIsPaused((p) => !p)} className="flex lg:hidden items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-mono-tabular font-bold bg-sky-500/12 text-sky-600 dark:text-cyan-300 border border-sky-500/30">
            <Timer size={13} /><span>{formatDurationMMSS(elapsedSeconds)}</span>{!isSubmitted && (isPaused ? <Play size={11} /> : <Pause size={11} />)}
          </button>
          <button type="button" onClick={() => setIsCalculatorOpen((v) => !v)} className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors ${isCalculatorOpen ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-400 text-indigo-700 dark:text-indigo-300' : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200'}`}>
            <Icon name="calculator" size={14} /><span className="hidden sm:inline">Calculator</span>
          </button>
          <button type="button" onClick={() => { setIsSubmitted(true); setIsScoreModalOpen(true); }} className="flex items-center gap-1.5 px-3 sm:px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white transition-colors">
            <CheckCircle2 size={14} /><span>{isSubmitted ? 'Scorecard' : 'Submit'}</span>
          </button>
        </div>
      </header>

      <div className="relative flex-1 min-h-0 flex gap-3 sm:gap-4 p-3 sm:p-4 overflow-hidden">
        {isSidebarOpen && (
          <div className="fixed inset-0 z-30 bg-slate-950/45 backdrop-blur-xs lg:hidden" onClick={() => setIsSidebarOpen(false)} />
        )}

        <aside className={`${isSidebarOpen ? 'fixed inset-y-0 left-0 z-40 w-72 sm:w-80 lg:static lg:w-72 flex' : 'hidden'} shrink-0 flex-col gap-3 p-3.5 sm:p-4 bg-[var(--bg-surface)] lg:rounded-2xl border-r lg:border border-[var(--border-subtle)] shadow-xl lg:shadow-xs overflow-y-auto`}>
          <div className="flex items-center justify-between shrink-0">
            <span className="text-xs font-bold uppercase tracking-wider text-[var(--text-muted)]">Questions ({totalCount})</span>
            <button type="button" onClick={() => setIsSidebarOpen(false)} className="p-1.5 rounded-lg border border-[var(--border-subtle)] text-[var(--text-secondary)] hover:bg-[var(--bg-app)]" title="Collapse Palette">
              <ChevronLeft size={14} />
            </button>
          </div>
          <TimerPill elapsedSeconds={elapsedSeconds} isPaused={isPaused} isSubmitted={isSubmitted} onTogglePause={() => setIsPaused((p) => !p)} />
          <QuestionPalette questions={questions} currentIndex={currentIndex} selectedAnswers={selectedAnswers} visitedIndices={visitedIndices} isSubmitted={isSubmitted} onSelectQuestion={(idx) => { setCurrentIndex(idx); if (window.innerWidth < 1024) setIsSidebarOpen(false); }} />
        </aside>

        <main className="flex-1 min-h-0 flex flex-col rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
          <div className="px-4 py-2.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 shrink-0">
            <div className="flex items-center gap-2 min-w-0">
              {!isSidebarOpen && (
                <button type="button" onClick={() => setIsSidebarOpen(true)} className="flex items-center gap-1 px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-mono-tabular font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800">
                  <span>Q1 - Q{totalCount}</span><ChevronRight size={13} />
                </button>
              )}
              <span className="text-xs sm:text-sm font-bold font-mono-tabular text-slate-900 dark:text-slate-100">Q{currentIndex + 1}.</span>
              {currentQuestion.topic && <span className="text-xs text-slate-500 dark:text-slate-400 truncate">{currentQuestion.topic}</span>}
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button type="button" onClick={() => setShowHint((v) => !v)} className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold border transition-colors ${showHint ? 'bg-amber-500/15 border-amber-500 text-amber-700 dark:text-amber-300' : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:border-amber-400'}`} title="Toggle Formula or Statutory Principle Hint">
                <HelpCircle size={13} className="text-amber-500" /><span>Hint</span>
              </button>
              <span className="px-2.5 py-0.5 rounded-lg bg-amber-500/12 border border-amber-500/30 text-amber-700 dark:text-amber-300 text-xs font-mono-tabular font-semibold">
                {marks} {marks === 1 ? 'Mark' : 'Marks'}
              </span>
            </div>
          </div>

          <div className="flex-1 min-h-0 overflow-y-auto p-4 sm:p-6">
            {isCurrentTF ? (
              <TrueFalseCard question={currentQuestion} selectedOption={selectedAnswers[currentIndex]} userReason={reasonNotes[currentIndex] || ''} isSubmitted={isSubmitted} showHint={showHint} onSelectOption={(idx) => setSelectedAnswers((prev) => ({ ...prev, [currentIndex]: idx }))} onChangeReason={(txt) => setReasonNotes((prev) => ({ ...prev, [currentIndex]: txt }))} />
            ) : (
              <QuestionCard question={currentQuestion} questionNumber={currentIndex + 1} totalQuestions={totalCount} selectedOption={selectedAnswers[currentIndex]} isSubmitted={isSubmitted} showHint={showHint} onSelectOption={(idx) => setSelectedAnswers((prev) => ({ ...prev, [currentIndex]: idx }))} />
            )}
          </div>

          <footer className="px-4 py-2.5 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 bg-slate-50/60 dark:bg-slate-900 shrink-0">
            <button type="button" disabled={currentIndex === 0} onClick={() => setCurrentIndex((i) => Math.max(0, i - 1))} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 disabled:opacity-40">
              <ArrowLeft size={13} /><span>Previous</span>
            </button>
            <span className="text-xs font-mono-tabular text-slate-500">{answeredCount} / {totalCount} Answered</span>
            <button type="button" disabled={currentIndex >= totalCount - 1} onClick={() => setCurrentIndex((i) => Math.min(totalCount - 1, i + 1))} className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white disabled:opacity-40">
              <span>Next</span><ArrowRight size={13} />
            </button>
          </footer>
        </main>
      </div>

      <CasioMJ12DCalculator isOpen={isCalculatorOpen} onClose={() => setIsCalculatorOpen(false)} />
      <ScoreModal isOpen={isScoreModalOpen} correctCount={correctCount} totalQuestions={totalCount} answeredCount={answeredCount} elapsedSeconds={elapsedSeconds} onReviewAnswers={() => setIsScoreModalOpen(false)} onRetakeTest={handleRetake} onBackToExplorer={onBackToExplorer} />
      <ExitConfirmModal isOpen={isExitModalOpen} progressSummary={`Progress saved: ${answeredCount} of ${totalCount} questions attempted (${bank.title || fileName}).`} onCancel={() => setIsExitModalOpen(false)} onConfirmExit={onBackToExplorer} />
    </div>
  );
};
