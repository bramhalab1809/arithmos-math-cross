import React, { useEffect, useMemo, useState } from 'react';
import { RawCodeEditor } from '../../features/editor/components/RawCodeEditor';
import { VisualFormEditor } from '../../features/editor/components/VisualFormEditor';
import { validateQuestionBankJson } from '../../features/editor/engine/schemaValidator';
import { QuestionBankJSON, VFSFileNode } from '../../features/explorer/engine/vfsTypes';
import { ArrowLeft, Code, FileJson, ListCheck, Play, Save, Undo2 } from '../../ui/icons';

interface JsonEditorScreenProps {
  file: VFSFileNode | null;
  onBackToExplorer: () => void;
  onSaveContent: (fileId: string, updatedContent: string) => void;
  onLaunchPlayground: () => void;
  onNotify: (message: string, type: 'success' | 'error') => void;
}

export const JsonEditorScreen: React.FC<JsonEditorScreenProps> = ({
  file,
  onBackToExplorer,
  onSaveContent,
  onLaunchPlayground,
  onNotify,
}) => {
  const [editorMode, setEditorMode] = useState<'visual' | 'raw'>('visual');
  const [rawText, setRawText] = useState<string>(() => file?.content || '');

  useEffect(() => {
    setRawText(file?.content || '');
  }, [file?.id]);

  const isDirty = Boolean(file && rawText !== file.content);
  const validation = useMemo(() => validateQuestionBankJson(rawText), [rawText]);

  const handleSave = (): boolean => {
    if (!file) return false;
    if (!validation.isValid || !validation.parsed) {
      onNotify(validation.error || 'Fix JSON errors before saving.', 'error');
      setEditorMode('raw');
      return false;
    }
    const formatted = JSON.stringify(validation.parsed, null, 2);
    setRawText(formatted);
    onSaveContent(file.id, formatted);
    return true;
  };

  const handleDiscard = () => {
    if (!file) return;
    setRawText(file.content);
    onNotify('Reverted unsaved changes.', 'success');
  };

  const handleLaunchPlayground = () => {
    if (isDirty) {
      if (!handleSave()) return;
    } else if (!validation.isValid) {
      onNotify(validation.error || 'Fix JSON errors before launching Playground.', 'error');
      return;
    }
    onLaunchPlayground();
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        handleSave();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [rawText, validation, file]);

  const handleVisualBankChange = (updatedBank: QuestionBankJSON) => {
    setRawText(JSON.stringify(updatedBank, null, 2));
  };

  if (!file) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 bg-[var(--bg-app)]">
        <p className="text-sm text-[var(--text-secondary)] mb-4">No file selected for editing.</p>
        <button
          type="button"
          onClick={onBackToExplorer}
          className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold bg-sky-500 text-white"
        >
          <ArrowLeft size={15} />
          <span>Back to Explorer</span>
        </button>
      </div>
    );
  }

  return (
    <div className="h-[100dvh] w-full flex flex-col min-w-0 bg-[var(--bg-app)] overflow-hidden">
      <header className="h-14 shrink-0 px-3 sm:px-6 flex items-center justify-between gap-2 border-b border-[var(--border-subtle)] bg-[var(--bg-surface)]">
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          <button
            type="button"
            onClick={onBackToExplorer}
            title="Back to Explorer"
            aria-label="Back to Explorer"
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-semibold bg-[var(--bg-app)] border border-[var(--border-subtle)] hover:border-[var(--border-strong)] text-[var(--text-primary)] transition-colors shrink-0"
          >
            <ArrowLeft size={15} />
            <span className="hidden md:inline">Explorer</span>
          </button>

          <div className="flex items-center gap-2 min-w-0">
            <FileJson size={16} className="text-sky-500 shrink-0" />
            <span className="text-xs sm:text-sm font-bold font-mono-tabular text-[var(--text-primary)] truncate">
              {file.name}
            </span>
            {isDirty && (
              <span className="text-[11px] font-medium text-amber-600 dark:text-amber-400 shrink-0">
                (Modified)
              </span>
            )}
          </div>
        </div>

        {/* Center Mode Switcher */}
        <div className="flex items-center p-1 rounded-xl bg-[var(--bg-app)] border border-[var(--border-subtle)] shrink-0">
          <button
            type="button"
            title="Visual Form Editor"
            aria-label="Visual Form Editor"
            onClick={() => {
              if (!validation.isValid) {
                onNotify('Fix raw JSON syntax error before switching to Visual mode.', 'error');
                return;
              }
              setEditorMode('visual');
            }}
            className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
              editorMode === 'visual'
                ? 'bg-[var(--bg-surface)] text-sky-600 dark:text-cyan-400 shadow-xs'
                : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }`}
          >
            <ListCheck size={14} />
            <span className="hidden md:inline">Visual</span>
          </button>
          <button
            type="button"
            title="Raw JSON Code"
            aria-label="Raw JSON Code"
            onClick={() => setEditorMode('raw')}
            className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
              editorMode === 'raw'
                ? 'bg-[var(--bg-surface)] text-sky-600 dark:text-cyan-400 shadow-xs'
                : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }`}
          >
            <Code size={14} />
            <span className="hidden md:inline">Code</span>
          </button>
        </div>

        {/* Right Action Buttons */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <button
            type="button"
            disabled={!isDirty}
            onClick={handleDiscard}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-[var(--bg-app)] border border-[var(--border-subtle)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] disabled:opacity-40 disabled:pointer-events-none transition-colors"
            title="Discard unsaved changes"
            aria-label="Discard"
          >
            <Undo2 size={14} />
            <span className="hidden md:inline">Discard</span>
          </button>

          <button
            type="button"
            onClick={handleSave}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-semibold bg-sky-500 hover:bg-sky-600 text-white transition-colors"
            title="Save Changes (Ctrl+S)"
            aria-label="Save"
          >
            <Save size={14} />
            <span className="hidden md:inline">Save</span>
          </button>

          <button
            type="button"
            onClick={handleLaunchPlayground}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition-colors"
            title="Save & Launch Playground"
            aria-label="Play"
          >
            <Play size={14} />
            <span className="hidden md:inline">Play</span>
          </button>
        </div>
      </header>

      {editorMode === 'visual' && validation.parsed ? (
        <VisualFormEditor bank={validation.parsed} onChangeBank={handleVisualBankChange} />
      ) : (
        <RawCodeEditor rawText={rawText} validation={validation} onChangeRawText={setRawText} />
      )}
    </div>
  );
};
