export interface QuestifyElectronBridge {
  isElectron: boolean;
  readSaveFile: () => Promise<unknown>;
  writeSaveFile: (data: unknown) => Promise<boolean>;
  getPlatform: () => string;
}

declare global {
  interface Window {
    questifyElectron?: QuestifyElectronBridge;
  }
}
