import { AppShell } from './app/AppShell';
import { ThemeProvider } from './app/theme/ThemeContext';

export default function App() {
  return (
    <ThemeProvider>
      <AppShell />
    </ThemeProvider>
  );
}
