import React, { useState } from 'react';
import {
  BarChart2,
  FolderOpen,
  PanelLeft,
  PanelLeftClose,
  Settings,
} from '../../../ui/icons';
import { ROOT_FOLDER_ID } from '../engine/vfsEngine';
import { VFSFileNode, VFSFolderNode, VFSState } from '../engine/vfsTypes';
import { FolderTreeItem } from './FolderTreeItem';

interface FolderTreePaneProps {
  vfsState: VFSState;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  onSelectFolder: (folderId: string) => void;
  onOpenFileModal: (file: VFSFileNode) => void;
  onOpenSettings: () => void;
  onOpenAnalytics?: () => void;
}

export const FolderTreePane: React.FC<FolderTreePaneProps> = ({
  vfsState,
  isCollapsed,
  onToggleCollapse,
  onSelectFolder,
  onOpenFileModal,
  onOpenSettings,
  onOpenAnalytics,
}) => {
  const [expandedIds, setExpandedIds] = useState<Set<string>>(
    new Set(['fld_accounting', 'fld_business_law', 'fld_economics', 'fld_eco_ch10'])
  );

  const handleToggleExpand = (folderId: string) => {
    setExpandedIds((prev) => {
      const next = new Set(prev);
      if (next.has(folderId)) next.delete(folderId);
      else next.add(folderId);
      return next;
    });
  };

  const rootFolders = vfsState.rootFolderIds
    .map((id) => vfsState.nodes[id])
    .filter((n): n is VFSFolderNode => Boolean(n && n.type === 'folder'));

  if (isCollapsed) {
    return (
      <aside className="w-12 h-full border-r border-[var(--border-subtle)] bg-[var(--bg-surface)] flex flex-col items-center py-3 justify-between shrink-0 select-none">
        <div className="flex flex-col items-center gap-3">
          <img src="./icon.svg" alt="Questify CA" className="w-6 h-6 rounded-md object-contain" />
          <button
            type="button"
            onClick={onToggleCollapse}
            className="p-2 rounded-xl text-[var(--text-muted)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-app)] transition-colors"
            title="Expand Explorer Sidebar"
          >
            <PanelLeft size={18} />
          </button>

          <button
            type="button"
            onClick={() => onSelectFolder(ROOT_FOLDER_ID)}
            className={`p-2 rounded-xl transition-colors ${
              vfsState.currentFolderId === ROOT_FOLDER_ID
                ? 'bg-sky-500/15 text-sky-600 dark:text-cyan-400'
                : 'text-[var(--text-muted)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-app)]'
            }`}
            title="CA Foundation Root"
          >
            <FolderOpen size={18} />
          </button>
        </div>

        <div className="flex flex-col items-center gap-2">
          {onOpenAnalytics && (
            <button
              type="button"
              onClick={onOpenAnalytics}
              className="p-2 rounded-xl text-[var(--text-muted)] hover:text-sky-500 hover:bg-[var(--bg-app)] transition-colors"
              title="Performance Analytics"
            >
              <BarChart2 size={18} />
            </button>
          )}
          <button
            type="button"
            onClick={onOpenSettings}
            className="p-2 rounded-xl text-[var(--text-muted)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-app)] transition-colors"
            title="Settings"
          >
            <Settings size={18} />
          </button>
        </div>
      </aside>
    );
  }

  return (
    <aside className="w-64 h-full border-r border-[var(--border-subtle)] bg-[var(--bg-surface)] flex flex-col justify-between shrink-0 select-none">
      <div className="flex items-center justify-between px-3.5 h-14 border-b border-[var(--border-subtle)] shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <img src="./icon.svg" alt="Questify CA" className="w-7 h-7 rounded-lg shrink-0 object-contain shadow-xs" />
          <div className="min-w-0 flex flex-col">
            <span className="text-xs font-bold tracking-tight text-[var(--text-primary)] truncate">Questify CA</span>
            <span className="text-[10px] text-[var(--text-muted)] truncate font-mono">VFS Explorer</span>
          </div>
        </div>

        <div className="flex items-center gap-1">
          {onOpenAnalytics && (
            <button
              type="button"
              onClick={onOpenAnalytics}
              className="p-1.5 rounded-lg text-[var(--text-muted)] hover:text-sky-500 hover:bg-[var(--bg-app)] transition-colors"
              title="Open Performance Analytics Dashboard"
            >
              <BarChart2 size={15} />
            </button>
          )}
          <button
            type="button"
            onClick={onOpenSettings}
            className="p-1.5 rounded-lg text-[var(--text-muted)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-app)] transition-colors"
            title="Open Settings"
          >
            <Settings size={15} />
          </button>
          <button
            type="button"
            onClick={onToggleCollapse}
            className="p-1.5 rounded-lg text-[var(--text-muted)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-app)] transition-colors"
            title="Collapse Sidebar"
          >
            <PanelLeftClose size={15} />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-2 space-y-1">
        <div
          onClick={() => onSelectFolder(ROOT_FOLDER_ID)}
          className={`flex items-center justify-between px-3 py-2 rounded-xl cursor-pointer text-xs font-medium transition-all ${
            vfsState.currentFolderId === ROOT_FOLDER_ID
              ? 'bg-sky-500/12 text-sky-600 dark:text-cyan-400 font-semibold'
              : 'text-[var(--text-primary)] hover:bg-[var(--bg-app)]'
          }`}
        >
          <div className="flex items-center gap-2">
            <FolderOpen size={15} className="text-sky-500" />
            <span>CA Foundation Root</span>
          </div>
          <span className="text-[10px] font-mono-tabular text-[var(--text-muted)]">
            {rootFolders.length}
          </span>
        </div>

        <div className="pt-1 space-y-0.5">
          {rootFolders.map((folder) => (
            <FolderTreeItem
              key={folder.id}
              folder={folder}
              vfsState={vfsState}
              expandedIds={expandedIds}
              onSelectFolder={onSelectFolder}
              onToggleExpand={handleToggleExpand}
              onOpenFileModal={onOpenFileModal}
            />
          ))}
        </div>
      </div>
    </aside>
  );
};
