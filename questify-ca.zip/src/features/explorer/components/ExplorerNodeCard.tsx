import React, { useState } from 'react';
import {
  CheckCircle2,
  Clock,
  FileJson,
  FileText,
  Folder,
  MoreVertical,
  Pin,
} from '../../../ui/icons';
import { countQuestionsInContent } from '../engine/vfsEngine';
import { VFSClipboard, VFSFileNode, VFSNode } from '../engine/vfsTypes';
import { NodeActionMenu } from './NodeActionMenu';
import { getBankSession } from '../../playground/shared/sessionStore';

interface ExplorerNodeCardProps {
  node: VFSNode;
  clipboard: VFSClipboard;
  isPinned: boolean;
  onOpenFolder: (folderId: string) => void;
  onOpenFileModal: (file: VFSFileNode) => void;
  onCutNode: (nodeId: string) => void;
  onCopyNode: (nodeId: string) => void;
  onRequestRename: (node: VFSNode) => void;
  onDeleteNode: (nodeId: string) => void;
  onTogglePinFolder: (folderId: string) => void;
}

export const ExplorerNodeCard: React.FC<ExplorerNodeCardProps> = ({
  node,
  clipboard,
  isPinned,
  onOpenFolder,
  onOpenFileModal,
  onCutNode,
  onCopyNode,
  onRequestRename,
  onDeleteNode,
  onTogglePinFolder,
}) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const isFolder = node.type === 'folder';
  const isCut = Boolean(clipboard?.action === 'cut' && clipboard.nodeIds.includes(node.id));

  const session = !isFolder && node.fileType === 'json' ? getBankSession(node.id) : null;
  const sessionStatus = session?.status || 'not-started';

  let cardSurfaceClasses =
    'bg-[var(--bg-surface)] border-[var(--border-subtle)] hover:border-sky-500/60';
  if (sessionStatus === 'completed') {
    cardSurfaceClasses =
      'bg-emerald-500/[0.05] border-emerald-500/45 hover:border-emerald-500';
  } else if (sessionStatus === 'in-progress') {
    cardSurfaceClasses =
      'bg-amber-500/[0.05] border-amber-500/45 hover:border-amber-500';
  }

  const questionCount =
    !isFolder && node.fileType === 'json' ? countQuestionsInContent(node.content) : 0;

  return (
    <div
      onClick={() => {
        if (isFolder) onOpenFolder(node.id);
        else onOpenFileModal(node);
      }}
      onContextMenu={(e) => {
        e.preventDefault();
        setMenuOpen(true);
      }}
      className={`group relative rounded-2xl border p-4 cursor-pointer transition-all duration-150 hover:shadow-md flex flex-col justify-between min-h-[124px] select-none ${cardSurfaceClasses} ${
        isCut ? 'opacity-50 border-dashed' : ''
      }`}
    >
      <div className="flex items-start justify-between gap-2">
        <div
          className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 ${
            isFolder
              ? 'bg-amber-500/10 text-amber-500 border-amber-500/20'
              : node.fileType === 'json'
              ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
              : 'bg-sky-500/10 text-sky-500 border-sky-500/20'
          }`}
        >
          {isFolder ? (
            <Folder size={20} />
          ) : node.fileType === 'json' ? (
            <FileJson size={20} />
          ) : (
            <FileText size={20} />
          )}
        </div>

        <div className="flex items-center gap-1 relative">
          {sessionStatus === 'completed' && session && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 text-[10px] font-bold">
              <CheckCircle2 size={11} />
              Completed &bull; {session.accuracyPercent}%
            </span>
          )}
          {sessionStatus === 'in-progress' && session && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30 text-[10px] font-bold">
              <Clock size={11} />
              Resume &bull; {session.attemptedCount}/{session.totalQuestions}
            </span>
          )}

          {isFolder && isPinned && (
            <span className="p-1 text-amber-500" title="Pinned Folder">
              <Pin size={13} className="fill-amber-500" />
            </span>
          )}

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setMenuOpen((p) => !p);
            }}
            className="p-1.5 rounded-lg text-[var(--text-muted)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-app)] transition-colors"
            title="Actions"
          >
            <MoreVertical size={15} />
          </button>

          <NodeActionMenu
            isOpen={menuOpen}
            isFolder={isFolder}
            isPinned={isPinned}
            onClose={() => setMenuOpen(false)}
            onTogglePin={() => onTogglePinFolder(node.id)}
            onCut={() => onCutNode(node.id)}
            onCopy={() => onCopyNode(node.id)}
            onRename={() => onRequestRename(node)}
            onDelete={() => onDeleteNode(node.id)}
          />
        </div>
      </div>

      <div className="mt-3">
        <h3 className="text-sm font-semibold text-[var(--text-primary)] truncate group-hover:text-sky-600 dark:group-hover:text-cyan-400 transition-colors">
          {node.name.replace(/\.(json|txt)$/i, '')}
        </h3>
        <div className="flex items-center justify-between mt-1 text-[11px] text-[var(--text-muted)] font-mono-tabular">
          <span>
            {isFolder
              ? 'Directory'
              : node.fileType === 'json'
              ? 'JSON Bank'
              : 'TXT Note'}
          </span>
          <span>
            {isFolder
              ? `${node.childrenIds.length} items`
              : node.fileType === 'json'
              ? `${questionCount} questions`
              : '.txt'}
          </span>
        </div>
      </div>
    </div>
  );
};
