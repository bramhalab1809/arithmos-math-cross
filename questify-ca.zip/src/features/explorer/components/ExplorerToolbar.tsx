import React, { useRef, useState } from 'react';
import {
  ArrowLeft,
  ChevronDown,
  ChevronRight,
  ClipboardPaste,
  FileJson,
  FileText,
  FileUp,
  FolderPlus,
  Plus,
  Search,
  X,
} from '../../../ui/icons';
import { ROOT_FOLDER_ID } from '../engine/vfsEngine';
import { BreadcrumbItem, VFSClipboard } from '../engine/vfsTypes';

interface ExplorerToolbarProps {
  breadcrumbs: BreadcrumbItem[];
  searchQuery: string;
  clipboard: VFSClipboard;
  canGoBack: boolean;
  onGoBack: () => void;
  onNavigateBreadcrumb: (folderId: string) => void;
  onSearchChange: (q: string) => void;
  onRequestNewFolder: () => void;
  onRequestNewFile: () => void;
  onRequestNewTxtFile: () => void;
  onUploadFiles: (files: FileList) => void;
  onPaste: () => void;
}

export const ExplorerToolbar: React.FC<ExplorerToolbarProps> = ({
  breadcrumbs,
  searchQuery,
  clipboard,
  canGoBack,
  onGoBack,
  onNavigateBreadcrumb,
  onSearchChange,
  onRequestNewFolder,
  onRequestNewFile,
  onRequestNewTxtFile,
  onUploadFiles,
  onPaste,
}) => {
  const [showCreateMenu, setShowCreateMenu] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const folderCrumbs = breadcrumbs.filter((c) => c.id !== ROOT_FOLDER_ID);

  return (
    <header className="h-14 px-4 border-b border-[var(--border-subtle)] bg-[var(--bg-surface)] flex items-center justify-between gap-3 shrink-0">
      <div className="flex items-center gap-2 min-w-0 flex-1">
        <button
          type="button"
          onClick={onGoBack}
          disabled={!canGoBack}
          className="p-2 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-app)] text-[var(--text-primary)] disabled:opacity-35 hover:border-sky-500 transition-colors shrink-0"
          title="Back to parent folder"
        >
          <ArrowLeft size={15} />
        </button>

        <nav className="flex items-center gap-1 text-xs font-medium overflow-x-auto no-scrollbar py-1">
          <button
            type="button"
            onClick={() => onNavigateBreadcrumb(ROOT_FOLDER_ID)}
            className={`px-2 py-1 rounded-lg transition-colors shrink-0 ${
              folderCrumbs.length === 0
                ? 'bg-sky-500/12 text-sky-600 dark:text-cyan-400 font-semibold'
                : 'text-[var(--text-muted)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-app)]'
            }`}
          >
            Home
          </button>

          {folderCrumbs.map((crumb, idx) => {
            const isLast = idx === folderCrumbs.length - 1;
            return (
              <React.Fragment key={crumb.id}>
                <ChevronRight size={13} className="text-[var(--text-muted)] shrink-0" />
                <button
                  type="button"
                  onClick={() => onNavigateBreadcrumb(crumb.id)}
                  className={`px-2 py-1 rounded-lg truncate max-w-[160px] transition-colors ${
                    isLast
                      ? 'bg-sky-500/12 text-sky-600 dark:text-cyan-400 font-semibold'
                      : 'text-[var(--text-muted)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-app)]'
                  }`}
                >
                  {crumb.name}
                </button>
              </React.Fragment>
            );
          })}
        </nav>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <div className="relative w-40 sm:w-56">
          <Search
            size={14}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]"
          />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search..."
            className="w-full pl-8 pr-7 py-1.5 rounded-xl bg-[var(--bg-app)] border border-[var(--border-subtle)] text-xs text-[var(--text-primary)] placeholder:text-[var(--text-muted)] focus:outline-none focus:border-sky-500"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => onSearchChange('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-[var(--text-muted)] hover:text-[var(--text-primary)]"
            >
              <X size={13} />
            </button>
          )}
        </div>

        {clipboard && clipboard.nodeIds.length > 0 && (
          <button
            type="button"
            onClick={onPaste}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/15 border border-amber-500/40 text-amber-600 dark:text-amber-400 text-xs font-semibold"
            title="Paste Here"
          >
            <ClipboardPaste size={14} />
            <span className="hidden sm:inline">Paste ({clipboard.nodeIds.length})</span>
          </button>
        )}

        <div className="relative">
          <button
            type="button"
            onClick={() => setShowCreateMenu((prev) => !prev)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-medium hover:bg-indigo-500 shadow-xs"
            title="Create New"
          >
            <Plus size={14} />
            <ChevronDown size={12} />
          </button>

          {showCreateMenu && (
            <>
              <div className="fixed inset-0 z-30" onClick={() => setShowCreateMenu(false)} />
              <div className="absolute right-0 mt-2 w-48 rounded-xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xl py-1.5 z-40 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setShowCreateMenu(false);
                    onRequestNewFolder();
                  }}
                  className="w-full px-3 py-2 flex items-center gap-2.5 text-left text-[var(--text-primary)] hover:bg-[var(--bg-app)]"
                >
                  <FolderPlus size={15} className="text-amber-500" />
                  <span>New Folder</span>
                </button>
                <div className="my-1 border-t border-[var(--border-subtle)]" />
                <button
                  type="button"
                  onClick={() => {
                    setShowCreateMenu(false);
                    onRequestNewFile();
                  }}
                  className="w-full px-3 py-2 flex items-center gap-2.5 text-left text-[var(--text-primary)] hover:bg-[var(--bg-app)]"
                >
                  <FileJson size={15} className="text-emerald-500" />
                  <span>New Question Bank (.json)</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowCreateMenu(false);
                    onRequestNewTxtFile();
                  }}
                  className="w-full px-3 py-2 flex items-center gap-2.5 text-left text-[var(--text-primary)] hover:bg-[var(--bg-app)]"
                >
                  <FileText size={15} className="text-sky-500" />
                  <span>New Prompt / Note (.txt)</span>
                </button>
              </div>
            </>
          )}
        </div>

        <input
          ref={fileInputRef}
          type="file"
          multiple
          onChange={(e) => {
            if (e.target.files && e.target.files.length > 0) {
              onUploadFiles(e.target.files);
              e.target.value = '';
            }
          }}
          className="hidden"
        />
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="flex items-center gap-1.5 px-2.5 sm:px-3.5 py-1.5 rounded-xl bg-[var(--bg-app)] border border-[var(--border-subtle)] hover:border-sky-500 text-xs font-semibold text-[var(--text-primary)] transition-colors shrink-0"
          title="Upload files"
        >
          <FileUp size={15} className="text-sky-500 shrink-0" />
          <span>Upload</span>
        </button>
      </div>
    </header>
  );
};
