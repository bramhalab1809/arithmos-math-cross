import React, { useEffect, useRef } from 'react';
import { Copy, Edit, Pin, Scissors, Trash2 } from '../../../ui/icons';

interface NodeActionMenuProps {
  isOpen: boolean;
  isFolder: boolean;
  isPinned: boolean;
  onClose: () => void;
  onTogglePin: () => void;
  onCut: () => void;
  onCopy: () => void;
  onRename: () => void;
  onDelete: () => void;
}

export const NodeActionMenu: React.FC<NodeActionMenuProps> = ({
  isOpen,
  isFolder,
  isPinned,
  onClose,
  onTogglePin,
  onCut,
  onCopy,
  onRename,
  onDelete,
}) => {
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isOpen) return;

    const handlePointerDown = (e: MouseEvent | TouchEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        onClose();
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };

    document.addEventListener('mousedown', handlePointerDown);
    document.addEventListener('touchstart', handlePointerDown);
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('mousedown', handlePointerDown);
      document.removeEventListener('touchstart', handlePointerDown);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const runAction = (fn: () => void) => {
    fn();
    onClose();
  };

  return (
    <div
      ref={menuRef}
      onClick={(e) => e.stopPropagation()}
      className="absolute right-0 top-full mt-1.5 w-44 rounded-xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xl backdrop-blur-md p-1.5 z-40 animate-in fade-in zoom-in-95 duration-150 origin-top-right"
      role="menu"
    >
      {isFolder && (
        <button
          type="button"
          onClick={() => runAction(onTogglePin)}
          className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-xs font-medium text-[var(--text-primary)] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-left"
          role="menuitem"
        >
          <Pin size={14} className={isPinned ? 'fill-amber-500 text-amber-500' : 'text-[var(--text-muted)]'} />
          <span>{isPinned ? 'Unpin' : 'Pin to Shortcuts'}</span>
        </button>
      )}
      <button
        type="button"
        onClick={() => runAction(onCut)}
        className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-xs font-medium text-[var(--text-primary)] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-left"
        role="menuitem"
      >
        <Scissors size={14} className="text-[var(--text-muted)]" />
        <span>Cut</span>
      </button>
      <button
        type="button"
        onClick={() => runAction(onCopy)}
        className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-xs font-medium text-[var(--text-primary)] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-left"
        role="menuitem"
      >
        <Copy size={14} className="text-[var(--text-muted)]" />
        <span>Copy</span>
      </button>
      <button
        type="button"
        onClick={() => runAction(onRename)}
        className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-xs font-medium text-[var(--text-primary)] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-left"
        role="menuitem"
      >
        <Edit size={14} className="text-[var(--text-muted)]" />
        <span>Rename</span>
      </button>
      <div className="my-1 border-t border-[var(--border-subtle)]" />
      <button
        type="button"
        onClick={() => runAction(onDelete)}
        className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-xs font-medium text-rose-500 hover:bg-rose-500/10 transition-colors text-left"
        role="menuitem"
      >
        <Trash2 size={14} className="text-rose-500" />
        <span>Delete</span>
      </button>
    </div>
  );
};
