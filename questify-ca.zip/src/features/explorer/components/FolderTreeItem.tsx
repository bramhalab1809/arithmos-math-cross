import React from 'react';
import {
  ChevronDown,
  ChevronRight,
  FileJson,
  FileText,
  Folder,
  FolderOpen,
  Pin,
} from '../../../ui/icons';
import { VFSFileNode, VFSFolderNode, VFSState } from '../engine/vfsTypes';
import { getBankSession } from '../../playground/shared/sessionStore';

interface FolderTreeItemProps {
  folder: VFSFolderNode;
  vfsState: VFSState;
  expandedIds: Set<string>;
  depth?: number;
  onSelectFolder: (folderId: string) => void;
  onToggleExpand: (folderId: string) => void;
  onOpenFileModal: (file: VFSFileNode) => void;
}

export const FolderTreeItem: React.FC<FolderTreeItemProps> = ({
  folder,
  vfsState,
  expandedIds,
  depth = 0,
  onSelectFolder,
  onToggleExpand,
  onOpenFileModal,
}) => {
  const isExpanded = expandedIds.has(folder.id);
  const isSelected = vfsState.currentFolderId === folder.id;
  const isPinned = (vfsState.pinnedFolderIds || []).includes(folder.id);

  const childFolders: VFSFolderNode[] = [];
  const childFiles: VFSFileNode[] = [];

  for (const cid of folder.childrenIds) {
    const child = vfsState.nodes[cid];
    if (!child) continue;
    if (child.type === 'folder') childFolders.push(child);
    else childFiles.push(child);
  }

  const totalChildrenCount = childFolders.length + childFiles.length;
  const hasChildren = totalChildrenCount > 0;

  return (
    <div>
      <div
        onClick={() => {
          onSelectFolder(folder.id);
          if (hasChildren && !isExpanded) onToggleExpand(folder.id);
        }}
        style={{ paddingLeft: `${depth * 14 + 10}px` }}
        className={`group flex items-center justify-between pr-2.5 py-1.5 rounded-xl cursor-pointer text-xs font-medium transition-all select-none ${
          isSelected
            ? 'bg-sky-500/12 text-sky-600 dark:text-cyan-400 font-semibold'
            : 'text-[var(--text-primary)] hover:bg-[var(--bg-app)]'
        }`}
      >
        <div className="flex items-center gap-2 min-w-0 flex-1">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleExpand(folder.id);
            }}
            className={`w-4 h-4 flex items-center justify-center rounded text-[var(--text-muted)] hover:text-[var(--text-primary)] ${
              !hasChildren ? 'opacity-25' : ''
            }`}
          >
            {isExpanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
          </button>

          <span className="shrink-0 text-amber-500 flex items-center">
            {isExpanded ? <FolderOpen size={15} /> : <Folder size={15} />}
          </span>

          <span className="truncate">{folder.name}</span>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          {isPinned && <Pin size={11} className="text-amber-500 fill-amber-500 shrink-0" />}
          <span className="text-[10px] font-mono-tabular text-[var(--text-muted)] px-1.5 py-0.5 rounded bg-[var(--bg-app)]">
            {totalChildrenCount}
          </span>
        </div>
      </div>

      {isExpanded && hasChildren && (
        <div className="mt-0.5 space-y-0.5">
          {childFolders.map((child) => (
            <FolderTreeItem
              key={child.id}
              folder={child}
              vfsState={vfsState}
              expandedIds={expandedIds}
              depth={depth + 1}
              onSelectFolder={onSelectFolder}
              onToggleExpand={onToggleExpand}
              onOpenFileModal={onOpenFileModal}
            />
          ))}

          {childFiles.map((file) => {
            const session = file.fileType === 'json' ? getBankSession(file.id) : null;
            return (
              <div
                key={file.id}
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectFolder(folder.id);
                  onOpenFileModal(file);
                }}
                style={{ paddingLeft: `${(depth + 1) * 14 + 28}px` }}
                className="group flex items-center justify-between pr-2.5 py-1 rounded-xl cursor-pointer text-[11px] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-app)] transition-all select-none"
              >
                <div className="flex items-center gap-2 min-w-0">
                  {file.fileType === 'json' ? (
                    <FileJson size={13} className="shrink-0 text-emerald-500" />
                  ) : (
                    <FileText size={13} className="shrink-0 text-sky-500" />
                  )}
                  <span className="truncate">{file.name}</span>
                </div>
                {session && session.status !== 'not-started' && (
                  <span
                    className={`w-2 h-2 rounded-full shrink-0 ${
                      session.status === 'completed' ? 'bg-emerald-500' : 'bg-amber-500'
                    }`}
                    title={
                      session.status === 'completed'
                        ? `Completed (${session.accuracyPercent}%)`
                        : `In Progress (${session.attemptedCount}/${session.totalQuestions})`
                    }
                  />
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
