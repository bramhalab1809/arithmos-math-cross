import React, { useState } from 'react';
import { FileJson, FileText, FileUp, FolderOpen, FolderPlus, X } from '../../../ui/icons';
import { ROOT_FOLDER_ID } from '../engine/vfsEngine';
import {
  VFSClipboard,
  VFSFileNode,
  VFSFolderNode,
  VFSNode,
  VFSState,
} from '../engine/vfsTypes';
import { ExplorerNodeCard } from './ExplorerNodeCard';

interface FileGridPaneProps {
  vfsState: VFSState;
  displayedNodes: VFSNode[];
  searchQuery: string;
  clipboard: VFSClipboard;
  onOpenFolder: (folderId: string) => void;
  onOpenFileModal: (file: VFSFileNode) => void;
  onCutNode: (nodeId: string) => void;
  onCopyNode: (nodeId: string) => void;
  onRequestRename: (node: VFSNode) => void;
  onDeleteNode: (nodeId: string) => void;
  onTogglePinFolder: (folderId: string) => void;
  onRequestNewFolder: () => void;
  onRequestNewFile: () => void;
  onRequestNewTxtFile?: () => void;
  onDropFiles: (files: File[]) => void;
  onClearClipboard: () => void;
}

export const FileGridPane: React.FC<FileGridPaneProps> = ({
  vfsState,
  displayedNodes,
  searchQuery,
  clipboard,
  onOpenFolder,
  onOpenFileModal,
  onCutNode,
  onCopyNode,
  onRequestRename,
  onDeleteNode,
  onTogglePinFolder,
  onRequestNewFolder,
  onRequestNewFile,
  onRequestNewTxtFile,
  onDropFiles,
  onClearClipboard,
}) => {
  const [isDragActive, setIsDragActive] = useState(false);

  const isRoot = vfsState.currentFolderId === ROOT_FOLDER_ID;
  const currentFolder = !isRoot
    ? (vfsState.nodes[vfsState.currentFolderId] as VFSFolderNode | undefined)
    : undefined;

  const folders = displayedNodes.filter((n) => n.type === 'folder');
  const files = displayedNodes.filter((n) => n.type === 'file');
  const sortedNodes = [...folders, ...files];
  const pinnedSet = new Set(vfsState.pinnedFolderIds || []);

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isDragActive) setIsDragActive(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (
      e.relatedTarget instanceof Node &&
      e.currentTarget.contains(e.relatedTarget)
    ) {
      return;
    }
    setIsDragActive(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onDropFiles(Array.from(e.dataTransfer.files));
    }
  };

  return (
    <div
      onDragEnter={handleDragOver}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className="relative flex-1 flex flex-col min-h-0 bg-[var(--bg-app)]"
    >
      {isDragActive && (
        <div className="absolute inset-0 z-30 m-3 rounded-2xl border-2 border-dashed border-sky-500 bg-sky-500/12 dark:bg-sky-500/20 backdrop-blur-xs flex flex-col items-center justify-center pointer-events-none text-center p-6 transition-all">
          <FileUp size={44} className="text-sky-500 animate-bounce mb-3" />
          <h3 className="text-base font-bold text-[var(--text-primary)]">
            Drop Files Here to Upload
          </h3>
          <p className="text-xs text-[var(--text-secondary)] mt-1">
            Files will be imported into the current folder automatically
          </p>
        </div>
      )}

      {/* Context Subheader */}
      <div className="px-4 sm:px-6 pt-5 pb-3 flex items-center justify-between gap-4">
        <div>
          <h1 className="text-base sm:text-lg font-bold tracking-tight text-[var(--text-primary)]">
            {searchQuery.trim()
              ? `Search Results for "${searchQuery}"`
              : isRoot
              ? 'CA Foundation Subjects'
              : currentFolder?.name || 'Directory'}
          </h1>
          <div className="flex items-center gap-2 text-xs text-[var(--text-muted)] mt-0.5 font-mono-tabular">
            <span>{folders.length} Folders</span>
            <span aria-hidden="true">·</span>
            <span>{files.length} Files</span>
          </div>
        </div>

        {clipboard && clipboard.nodeIds.length > 0 && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-xs text-[var(--text-secondary)]">
            <span className="font-mono-tabular">
              Clipboard: {clipboard.nodeIds.length} ({clipboard.action})
            </span>
            <button
              type="button"
              onClick={onClearClipboard}
              className="p-0.5 text-[var(--text-muted)] hover:text-[var(--text-primary)]"
              title="Clear clipboard"
            >
              <X size={13} />
            </button>
          </div>
        )}
      </div>

      {/* Main Grid Area */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-6 pb-8">
        {sortedNodes.length === 0 ? (
          <div className="h-72 rounded-2xl border border-dashed border-[var(--border-strong)] flex flex-col items-center justify-center p-6 text-center">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center mb-3">
              <FolderOpen size={24} />
            </div>
            <h2 className="text-sm font-semibold text-[var(--text-primary)]">
              {searchQuery.trim() ? 'No matching items found' : 'This folder is empty'}
            </h2>
            <p className="text-xs text-[var(--text-muted)] max-w-xs mt-1 mb-4">
              {searchQuery.trim()
                ? 'Try a different keyword or clear the search filter.'
                : 'Drag and drop .json files here, create nested folders, or add a JSON bank / TXT note.'}
            </p>
            {!searchQuery.trim() && (
              <div className="flex flex-wrap items-center justify-center gap-2">
                <button
                  type="button"
                  onClick={onRequestNewFolder}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium bg-[var(--bg-surface)] border border-[var(--border-subtle)] hover:border-amber-500/50 text-[var(--text-primary)] transition-colors"
                >
                  <FolderPlus size={15} className="text-amber-500" />
                  <span>New Folder</span>
                </button>
                {!isRoot && (
                  <>
                    <button
                      type="button"
                      onClick={onRequestNewFile}
                      className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium bg-sky-500 hover:bg-sky-600 text-white transition-colors"
                    >
                      <FileJson size={15} />
                      <span>New JSON Bank</span>
                    </button>
                    {onRequestNewTxtFile && (
                      <button
                        type="button"
                        onClick={onRequestNewTxtFile}
                        className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium bg-[var(--bg-surface)] border border-[var(--border-subtle)] hover:border-sky-500/50 text-[var(--text-primary)] transition-colors"
                      >
                        <FileText size={15} className="text-sky-500" />
                        <span>New TXT</span>
                      </button>
                    )}
                  </>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {sortedNodes.map((node) => (
              <ExplorerNodeCard
                key={node.id}
                node={node}
                clipboard={clipboard}
                isPinned={pinnedSet.has(node.id)}
                onOpenFolder={onOpenFolder}
                onOpenFileModal={onOpenFileModal}
                onCutNode={onCutNode}
                onCopyNode={onCopyNode}
                onRequestRename={onRequestRename}
                onDeleteNode={onDeleteNode}
                onTogglePinFolder={onTogglePinFolder}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
