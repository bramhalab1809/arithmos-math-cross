import React, { useEffect, useState } from 'react';
import { Check, Copy, Download, Edit3, FileText, Save, Sparkles, X } from '../../../ui/icons';
import { VFSFileNode } from '../engine/vfsTypes';

interface PromptViewerModalProps {
  file: VFSFileNode | null;
  onClose: () => void;
  onSaveContent?: (fileId: string, updatedContent: string) => void;
  onNotify: (msg: string, type: 'success' | 'error') => void;
}

export const PromptViewerModal: React.FC<PromptViewerModalProps> = ({
  file,
  onClose,
  onSaveContent,
  onNotify,
}) => {
  const [copied, setCopied] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [draftText, setDraftText] = useState('');

  useEffect(() => {
    setCopied(false);
    setIsEditing(false);
    setDraftText(file?.content || '');
  }, [file?.id, file?.content]);

  useEffect(() => {
    if (!file) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [file, onClose]);

  if (!file) return null;

  const handleCopyPrompt = async () => {
    try {
      await navigator.clipboard.writeText(draftText);
      setCopied(true);
      onNotify('TXT content copied to clipboard!', 'success');
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      onNotify('Failed to copy to clipboard.', 'error');
    }
  };

  const handleSaveTxt = () => {
    if (!onSaveContent) return;
    onSaveContent(file.id, draftText);
    setIsEditing(false);
    onNotify('TXT file saved!', 'success');
  };

  const handleDownloadTxt = () => {
    const blob = new Blob([draftText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = file.name.toLowerCase().endsWith('.txt') ? file.name : `${file.name}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    onNotify(`Downloaded ${link.download}`, 'success');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/65 backdrop-blur-xs animate-in fade-in duration-150"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="w-full max-w-2xl max-h-[88dvh] flex flex-col rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-4 sm:px-6 py-3.5 flex items-center justify-between gap-2 border-b border-[var(--border-subtle)] shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-amber-500/12 text-amber-500 flex items-center justify-center shrink-0">
              <FileText size={18} className="text-amber-500" />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm font-bold text-[var(--text-primary)] truncate font-mono-tabular">
                {file.name}
              </h2>
              <div className="text-xs text-[var(--text-muted)] mt-0.5 truncate">
                TXT Note &amp; Prompt Template · Edit, Copy &amp; Download
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {onSaveContent && (
              isEditing ? (
                <button
                  type="button"
                  onClick={handleSaveTxt}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition-colors"
                  title="Save TXT File"
                >
                  <Save size={14} />
                  <span>Save</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setIsEditing(true)}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-[var(--bg-app)] border border-[var(--border-subtle)] text-[var(--text-primary)] hover:border-sky-500 transition-colors"
                  title="Edit TXT File"
                >
                  <Edit3 size={14} />
                  <span className="hidden sm:inline">Edit</span>
                </button>
              )
            )}

            <button
              type="button"
              onClick={handleDownloadTxt}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-[var(--bg-app)] border border-[var(--border-subtle)] text-[var(--text-primary)] hover:border-sky-500 transition-colors"
              title="Download .txt file"
            >
              <Download size={14} />
              <span className="hidden sm:inline">Download</span>
            </button>

            <button
              type="button"
              onClick={handleCopyPrompt}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all shadow-2xs ${
                copied
                  ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/40'
                  : 'bg-sky-500 hover:bg-sky-600 text-white'
              }`}
              title="Copy to Clipboard"
            >
              {copied ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
              <span>{copied ? 'Copied!' : 'Copy'}</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl text-[var(--text-muted)] hover:text-[var(--text-primary)] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="Close Viewer"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        <div className="p-4 sm:p-6 space-y-3.5 overflow-y-auto min-h-0 flex-1 flex flex-col">
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-2.5 text-xs text-[var(--text-secondary)] leading-relaxed shrink-0">
            <Sparkles size={15} className="text-amber-500 shrink-0 mt-0.5" />
            <div>
              <strong className="text-[var(--text-primary)]">TXT Workspace:</strong> Use this file to store AI extraction prompts, custom accounting format templates, or ICAI revision notes.
            </div>
          </div>

          {isEditing ? (
            <textarea
              value={draftText}
              onChange={(e) => setDraftText(e.target.value)}
              rows={14}
              className="flex-1 w-full p-4 text-xs font-mono-tabular bg-[var(--bg-app)] border border-sky-500 rounded-xl leading-relaxed text-[var(--text-primary)] focus:outline-none resize-y"
              placeholder="Write your TXT note or template here..."
            />
          ) : (
            <pre className="p-4 text-xs font-mono-tabular bg-[var(--bg-app)] border border-[var(--border-subtle)] rounded-xl overflow-x-auto whitespace-pre-wrap leading-relaxed text-[var(--text-primary)] select-all">
              {draftText}
            </pre>
          )}
        </div>
      </div>
    </div>
  );
};
