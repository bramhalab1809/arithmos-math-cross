import React from 'react';
import { BarChart2, Code, FileJson, Play, PlayCircle, RefreshCw, X } from '../../../ui/icons';
import { VFSFileNode } from '../engine/vfsTypes';
import {
  getBankSession,
  detectQuestionSourceTag,
  detectCanonicalSubject,
} from '../../playground/shared/sessionStore';

interface FileActionModalProps {
  file: VFSFileNode | null;
  onClose: () => void;
  onOpenInEditor: (file: VFSFileNode) => void;
  onStartPlayground: (file: VFSFileNode, mode?: 'resume' | 'fresh') => void;
  onOpenAnalytics?: () => void;
}

export const FileActionModal: React.FC<FileActionModalProps> = ({
  file,
  onClose,
  onOpenInEditor,
  onStartPlayground,
  onOpenAnalytics,
}) => {
  if (!file) return null;

  let questionCount = 0;
  let subject = 'CA Foundation';
  let bankType = 'mcq';
  let title = file.name.replace(/\.json$/i, '');

  try {
    const parsed = JSON.parse(file.content);
    if (Array.isArray(parsed.questions)) questionCount = parsed.questions.length;
    if (parsed.subject) subject = parsed.subject;
    if (parsed.type) bankType = parsed.type;
    if (parsed.title) title = parsed.title;
  } catch {
    questionCount = 0;
  }

  const session = getBankSession(file.id);
  const status = session?.status || 'not-started';
  const hasSavedProgress = status === 'in-progress' || status === 'completed';
  const sourceTag = session?.sourceTag || detectQuestionSourceTag(file.name, title);
  const canonicalSubject = session?.subject || detectCanonicalSubject(subject, file.name, title);

  const formatDuration = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const rem = sec % 60;
    return `${mins}m ${String(rem).padStart(2, '0')}s`;
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-[var(--border-subtle)]">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 flex items-center justify-center shrink-0">
              <FileJson size={18} />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm font-semibold text-[var(--text-primary)] truncate">{title}</h3>
              <p className="text-[11px] text-[var(--text-muted)] font-mono-tabular truncate">
                {canonicalSubject} &bull; {sourceTag} &bull; {questionCount} Questions
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-[var(--text-muted)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-app)]"
          >
            <X size={16} />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div className="rounded-xl bg-[var(--bg-app)] border border-[var(--border-subtle)] p-3.5 grid grid-cols-4 gap-2 text-center">
            <div>
              <div className="text-[10px] uppercase font-bold tracking-wider text-[var(--text-muted)]">Status</div>
              <div
                className={`mt-1 text-xs font-bold ${
                  status === 'completed'
                    ? 'text-emerald-500'
                    : status === 'in-progress'
                    ? 'text-amber-500'
                    : 'text-[var(--text-primary)]'
                }`}
              >
                {status === 'completed' ? 'Completed' : status === 'in-progress' ? 'In Progress' : 'Not Started'}
              </div>
            </div>
            <div>
              <div className="text-[10px] uppercase font-bold tracking-wider text-[var(--text-muted)]">Attempted</div>
              <div className="mt-1 text-xs font-bold font-mono-tabular text-[var(--text-primary)]">
                {session ? `${session.attemptedCount}/${session.totalQuestions}` : `0/${questionCount}`}
              </div>
            </div>
            <div>
              <div className="text-[10px] uppercase font-bold tracking-wider text-[var(--text-muted)]">Accuracy</div>
              <div className="mt-1 text-xs font-bold font-mono-tabular text-emerald-500">
                {session ? `${session.accuracyPercent}%` : '0%'}
              </div>
            </div>
            <div>
              <div className="text-[10px] uppercase font-bold tracking-wider text-[var(--text-muted)]">Time Spent</div>
              <div className="mt-1 text-xs font-bold font-mono-tabular text-[var(--text-primary)]">
                {session ? formatDuration(session.elapsedSeconds) : '0m 00s'}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-2.5">
            {hasSavedProgress && session && (
              <button
                type="button"
                onClick={() => {
                  onStartPlayground(file, 'resume');
                  onClose();
                }}
                className="flex items-center gap-3.5 p-3.5 rounded-xl border border-emerald-500/40 bg-emerald-500/10 hover:bg-emerald-500/15 transition-all text-left group"
              >
                <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <PlayCircle size={18} />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-semibold text-[var(--text-primary)] flex items-center justify-between">
                    <span>Resume Session (Q{session.currentIndex + 1})</span>
                    <span className="text-[10px] font-mono-tabular px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-500 font-bold">
                      Saved
                    </span>
                  </div>
                  <p className="text-xs text-[var(--text-muted)] mt-0.5">
                    Continue with your saved answers &amp; timer ({formatDuration(session.elapsedSeconds)})
                  </p>
                </div>
              </button>
            )}

            <button
              type="button"
              onClick={() => {
                onStartPlayground(file, 'fresh');
                onClose();
              }}
              className="flex items-center gap-3.5 p-3.5 rounded-xl border border-sky-500/40 bg-sky-500/5 hover:bg-sky-500/10 transition-all text-left group"
            >
              <div className="w-10 h-10 rounded-xl bg-sky-500 text-white flex items-center justify-center shrink-0 shadow-xs">
                {hasSavedProgress ? <RefreshCw size={18} /> : <Play size={18} />}
              </div>
              <div>
                <div className="text-sm font-semibold text-[var(--text-primary)] group-hover:text-sky-500">
                  {hasSavedProgress ? 'Start Fresh / New Attempt' : 'Start Practice Session'}
                </div>
                <p className="text-xs text-[var(--text-muted)] mt-0.5">
                  {hasSavedProgress
                    ? 'Reset previous answers and start a clean practice timer from Q1'
                    : `Launch interactive ${
                        bankType === 'subjective' ? 'Subjective Answer' : 'MCQ / True-False'
                      } Playground`}
                </p>
              </div>
            </button>

            <div className="grid grid-cols-2 gap-2.5 pt-1">
              {onOpenAnalytics && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenAnalytics();
                  }}
                  className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-app)] hover:border-sky-500 text-xs font-semibold text-[var(--text-primary)] transition-all"
                >
                  <BarChart2 size={14} className="text-sky-500" />
                  <span>Open in Global Analytics</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => {
                  onOpenInEditor(file);
                  onClose();
                }}
                className={`flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-app)] hover:border-sky-500 text-xs font-semibold text-[var(--text-primary)] transition-all ${
                  !onOpenAnalytics ? 'col-span-2' : ''
                }`}
              >
                <Code size={14} className="text-[var(--text-muted)]" />
                <span>Edit JSON</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
