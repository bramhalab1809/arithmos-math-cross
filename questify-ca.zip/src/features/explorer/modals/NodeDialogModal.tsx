import React, { useEffect, useState } from 'react';
import { Check, Edit, FileJson, FileText, FolderPlus, X } from '../../../ui/icons';
import { VFSNode } from '../engine/vfsTypes';

export type NodeDialogMode =
  | { type: 'new-folder' }
  | { type: 'new-file' }
  | { type: 'new-txt' }
  | { type: 'rename'; target: VFSNode }
  | null;

interface NodeDialogModalProps {
  dialog: NodeDialogMode;
  onClose: () => void;
  onCreateFolder: (name: string) => void;
  onCreateFile: (name: string) => void;
  onCreateTxtFile?: (name: string) => void;
  onRenameNode: (nodeId: string, newName: string) => void;
}

export const NodeDialogModal: React.FC<NodeDialogModalProps> = ({
  dialog,
  onClose,
  onCreateFolder,
  onCreateFile,
  onCreateTxtFile,
  onRenameNode,
}) => {
  const [nameInput, setNameInput] = useState('');

  useEffect(() => {
    if (!dialog) {
      setNameInput('');
      return;
    }
    if (dialog.type === 'new-folder') {
      setNameInput('Chapter 1 - New Topic');
    } else if (dialog.type === 'new-file') {
      setNameInput('Practice_Set_1.json');
    } else if (dialog.type === 'new-txt') {
      setNameInput('Chapter_Notes_Template.txt');
    } else if (dialog.type === 'rename') {
      setNameInput(dialog.target.name);
    }
  }, [dialog]);

  if (!dialog) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = nameInput.trim();
    if (!cleaned) return;
    if (dialog.type === 'new-folder') {
      onCreateFolder(cleaned);
    } else if (dialog.type === 'new-file') {
      onCreateFile(cleaned.toLowerCase().endsWith('.json') ? cleaned : `${cleaned}.json`);
    } else if (dialog.type === 'new-txt') {
      const txtName = cleaned.toLowerCase().endsWith('.txt') ? cleaned : `${cleaned}.txt`;
      onCreateTxtFile?.(txtName);
    } else if (dialog.type === 'rename') {
      onRenameNode(dialog.target.id, cleaned);
    }
    onClose();
  };

  const title =
    dialog.type === 'new-folder'
      ? 'Create New Folder'
      : dialog.type === 'new-file'
      ? 'Create New JSON Question Bank'
      : dialog.type === 'new-txt'
      ? 'Create New TXT Note / Template'
      : `Rename ${dialog.target.type === 'folder' ? 'Folder' : 'File'}`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs"
      onClick={onClose}
    >
      <form
        onSubmit={handleSubmit}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xl overflow-hidden"
      >
        <div className="px-5 py-4 flex items-center justify-between border-b border-[var(--border-subtle)]">
          <div className="flex items-center gap-2.5">
            {dialog.type === 'new-folder' && <FolderPlus size={18} className="text-amber-500" />}
            {dialog.type === 'new-file' && <FileJson size={18} className="text-emerald-500 dark:text-cyan-400" />}
            {dialog.type === 'new-txt' && <FileText size={18} className="text-sky-500" />}
            {dialog.type === 'rename' && <Edit size={18} className="text-sky-500" />}
            <h2 className="text-sm font-bold text-[var(--text-primary)]">{title}</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-[var(--text-muted)] hover:text-[var(--text-primary)]"
          >
            <X size={16} />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-medium text-[var(--text-secondary)] mb-1.5">
              {dialog.type === 'new-file'
                ? 'File Name (.json)'
                : dialog.type === 'new-txt'
                ? 'File Name (.txt)'
                : 'Name'}
            </label>
            <input
              type="text"
              autoFocus
              value={nameInput}
              onChange={(e) => setNameInput(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg bg-[var(--bg-app)] border border-[var(--border-strong)] text-[var(--text-primary)] focus:outline-none focus:border-sky-500"
              placeholder="Enter name..."
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 rounded-lg text-xs font-medium text-[var(--text-secondary)] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-sky-500 hover:bg-sky-600 text-white transition-colors"
            >
              <Check size={14} />
              <span>Save</span>
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
