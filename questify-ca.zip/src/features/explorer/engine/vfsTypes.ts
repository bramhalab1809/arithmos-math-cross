export type VFSNodeType = 'folder' | 'file';

export interface VFSFolderNode {
  id: string;
  type: 'folder';
  name: string;
  parentId: string | null;
  childrenIds: string[];
  createdAt: number;
  metadata?: {
    isSystemLinked?: boolean;
    subjectRestriction?: string;
  };
}

export interface VFSFileNode {
  id: string;
  type: 'file';
  name: string;
  parentId: string;
  fileType: 'json' | 'txt';
  content: string;
  createdAt: number;
  updatedAt: number;
}

export type VFSNode = VFSFolderNode | VFSFileNode;

export interface VFSState {
  nodes: Record<string, VFSNode>;
  rootFolderIds: string[];
  currentFolderId: string;
  pinnedFolderIds?: string[];
}

export type VFSClipboard = {
  action: 'cut' | 'copy';
  nodeIds: string[];
} | null;

export interface BreadcrumbItem {
  id: string;
  name: string;
}

export interface TableData {
  title?: string;
  headers: string[];
  rows: string[][];
  totals?: string[];
}

export type BankType = 'objective' | 'mcq' | 'true-false' | 'subjective' | 'accounts';

export interface QuestionItem {
  id: string;
  question: string;
  statement?: string;
  requirement?: string;
  options?: string[];
  correctAnswer?: number | string;
  explanation?: string;
  reason?: string;
  modelAnswer?: string;
  caseStudy?: string;
  topic?: string;
  hint?: string;
  marks?: number;
  table?: TableData;
  tables?: TableData[];
}

export interface QuestionBankJSON {
  type?: BankType;
  title: string;
  subject: string;
  chapter: string;
  examSession?: string;
  questions: QuestionItem[];
}

export function isTrueFalseQuestion(q?: QuestionItem, bankType?: string): boolean {
  if (bankType === 'true-false') return true;
  if (!q?.options || q.options.length !== 2) return false;
  const normalized = q.options.map((o) => String(o).trim().toLowerCase());
  return normalized.includes('true') && normalized.includes('false');
}

export function isTrueFalseBank(bank?: QuestionBankJSON | null): boolean {
  if (!bank) return false;
  if (bank.type === 'true-false') return true;
  return bank.questions.length > 0 && bank.questions.every((q) => isTrueFalseQuestion(q, bank.type));
}
