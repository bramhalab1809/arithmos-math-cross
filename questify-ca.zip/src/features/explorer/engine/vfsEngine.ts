import {
  ROOT_FOLDER_ID,
  calculatePath,
  collectSubtreeIds,
  countQuestionsInContent,
  createUid,
  isDescendant,
  searchVFS,
} from './vfsQuery';
import {
  VFSClipboard,
  VFSFileNode,
  VFSFolderNode,
  VFSNode,
  VFSState,
} from './vfsTypes';

export { ROOT_FOLDER_ID, calculatePath, countQuestionsInContent, isDescendant, searchVFS };

export function addFolder(state: VFSState, parentId: string | null, name: string): VFSState {
  const trimmed = name.trim();
  if (!trimmed) return state;

  const id = createUid('fld');
  const targetParentId = parentId === ROOT_FOLDER_ID ? null : parentId;
  const newFolder: VFSFolderNode = {
    id,
    type: 'folder',
    name: trimmed,
    parentId: targetParentId,
    childrenIds: [],
    createdAt: Date.now(),
  };

  const nextNodes: Record<string, VFSNode> = { ...state.nodes, [id]: newFolder };
  const nextRootIds = [...state.rootFolderIds];

  if (targetParentId === null) {
    nextRootIds.push(id);
  } else {
    const parent = nextNodes[targetParentId];
    if (parent && parent.type === 'folder') {
      nextNodes[targetParentId] = { ...parent, childrenIds: [...parent.childrenIds, id] };
    }
  }
  return { ...state, nodes: nextNodes, rootFolderIds: nextRootIds };
}

export function addFile(state: VFSState, parentId: string, name: string, content: string): VFSState {
  const rawName = name.trim();
  if (!rawName) return state;
  const normalizedName = rawName.endsWith('.json') ? rawName : `${rawName}.json`;
  const id = createUid('fil');
  const now = Date.now();

  const newFile: VFSFileNode = {
    id,
    type: 'file',
    name: normalizedName,
    parentId,
    fileType: 'json',
    content,
    createdAt: now,
    updatedAt: now,
  };

  const nextNodes: Record<string, VFSNode> = { ...state.nodes, [id]: newFile };
  const parent = nextNodes[parentId];
  if (parent && parent.type === 'folder') {
    nextNodes[parentId] = { ...parent, childrenIds: [...parent.childrenIds, id] };
  }
  return { ...state, nodes: nextNodes };
}

export function deleteNode(state: VFSState, nodeId: string): VFSState {
  const target = state.nodes[nodeId];
  if (!target) return state;

  const idsToRemove = new Set(collectSubtreeIds(state, nodeId));
  const nextNodes: Record<string, VFSNode> = {};

  for (const [id, node] of Object.entries(state.nodes)) {
    if (idsToRemove.has(id)) continue;
    nextNodes[id] =
      node.type === 'folder'
        ? { ...node, childrenIds: node.childrenIds.filter((cid) => !idsToRemove.has(cid)) }
        : node;
  }

  return {
    ...state,
    nodes: nextNodes,
    rootFolderIds: state.rootFolderIds.filter((id) => !idsToRemove.has(id)),
    currentFolderId: idsToRemove.has(state.currentFolderId)
      ? target.parentId || ROOT_FOLDER_ID
      : state.currentFolderId,
    pinnedFolderIds: (state.pinnedFolderIds || []).filter((id) => !idsToRemove.has(id)),
  };
}

export function renameNode(state: VFSState, nodeId: string, newName: string): VFSState {
  const target = state.nodes[nodeId];
  const trimmed = newName.trim();
  if (!target || !trimmed) return state;
  const finalName = target.type === 'file' && !trimmed.endsWith('.json') ? `${trimmed}.json` : trimmed;
  return {
    ...state,
    nodes: {
      ...state.nodes,
      [nodeId]:
        target.type === 'file'
          ? { ...target, name: finalName, updatedAt: Date.now() }
          : { ...target, name: finalName },
    },
  };
}

export function moveNode(state: VFSState, nodeId: string, targetFolderId: string | null): VFSState {
  const node = state.nodes[nodeId];
  if (!node) return state;
  const destId = targetFolderId === ROOT_FOLDER_ID ? null : targetFolderId;
  if ((destId === null && node.type === 'file') || node.parentId === destId) return state;
  if (destId && isDescendant(state, destId, nodeId)) return state;

  const nextNodes: Record<string, VFSNode> = { ...state.nodes };
  let nextRootIds = [...state.rootFolderIds];

  if (node.parentId === null) {
    nextRootIds = nextRootIds.filter((id) => id !== nodeId);
  } else {
    const oldParent = nextNodes[node.parentId];
    if (oldParent && oldParent.type === 'folder') {
      nextNodes[node.parentId] = {
        ...oldParent,
        childrenIds: oldParent.childrenIds.filter((id) => id !== nodeId),
      };
    }
  }

  if (destId === null && node.type === 'folder') {
    nextRootIds.push(nodeId);
    nextNodes[nodeId] = { ...node, parentId: null };
  } else if (destId) {
    const newParent = nextNodes[destId];
    if (newParent && newParent.type === 'folder') {
      nextNodes[destId] = { ...newParent, childrenIds: [...newParent.childrenIds, nodeId] };
      nextNodes[nodeId] =
        node.type === 'folder'
          ? { ...node, parentId: destId }
          : { ...node, parentId: destId, updatedAt: Date.now() };
    }
  }
  return { ...state, nodes: nextNodes, rootFolderIds: nextRootIds };
}

export function copyNode(state: VFSState, nodeId: string, targetFolderId: string | null): VFSState {
  const source = state.nodes[nodeId];
  if (!source) return state;
  const destId = targetFolderId === ROOT_FOLDER_ID ? null : targetFolderId;
  if ((destId === null && source.type === 'file') || (destId && isDescendant(state, destId, nodeId))) {
    return state;
  }

  const copyName =
    source.parentId === destId
      ? source.type === 'file'
        ? source.name.replace(/\.json$/i, '_Copy.json')
        : `${source.name} (Copy)`
      : source.name;

  if (source.type === 'file' && destId) return addFile(state, destId, copyName, source.content);
  if (source.type === 'folder') {
    const nextState = addFolder(state, destId, copyName);
    const parentList =
      destId === null
        ? nextState.rootFolderIds
        : (nextState.nodes[destId] as VFSFolderNode).childrenIds;
    const createdFolderId = parentList[parentList.length - 1];
    return source.childrenIds.reduce((acc, cid) => copyNode(acc, cid, createdFolderId), nextState);
  }
  return state;
}

export function pasteClipboard(
  state: VFSState,
  clipboard: VFSClipboard,
  targetFolderId: string | null
): { state: VFSState; clipboard: VFSClipboard } {
  if (!clipboard || clipboard.nodeIds.length === 0) return { state, clipboard: null };
  const nextState = clipboard.nodeIds.reduce(
    (acc, id) => (clipboard.action === 'cut' ? moveNode(acc, id, targetFolderId) : copyNode(acc, id, targetFolderId)),
    state
  );
  return { state: nextState, clipboard: clipboard.action === 'cut' ? null : clipboard };
}

export const createFolder = addFolder;
export const createFile = addFile;
export const pasteNode = pasteClipboard;
export const cutNode = (nodeIds: string[]): VFSClipboard => ({ action: 'cut', nodeIds });
