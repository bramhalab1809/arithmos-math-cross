import { BreadcrumbItem, VFSNode, VFSState } from './vfsTypes';

export const ROOT_FOLDER_ID = 'root';

export function createUid(prefix: string): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}

export function isDescendant(
  state: VFSState,
  candidateId: string,
  potentialAncestorId: string
): boolean {
  let cursorId: string | null = candidateId;
  while (cursorId) {
    if (cursorId === potentialAncestorId) return true;
    const node: VFSNode | undefined = state.nodes[cursorId];
    cursorId = node ? node.parentId : null;
  }
  return false;
}

export function collectSubtreeIds(state: VFSState, rootId: string): string[] {
  const collected: string[] = [rootId];
  const node = state.nodes[rootId];
  if (node && node.type === 'folder') {
    for (const childId of node.childrenIds) {
      collected.push(...collectSubtreeIds(state, childId));
    }
  }
  return collected;
}

export function calculatePath(state: VFSState, folderId: string): BreadcrumbItem[] {
  const homeItem: BreadcrumbItem = { id: ROOT_FOLDER_ID, name: 'Home' };
  if (!folderId || folderId === ROOT_FOLDER_ID) return [homeItem];

  const trail: BreadcrumbItem[] = [];
  let cursorId: string | null = folderId;
  while (cursorId) {
    const node: VFSNode | undefined = state.nodes[cursorId];
    if (!node) break;
    trail.unshift({ id: node.id, name: node.name });
    cursorId = node.parentId;
  }
  return [homeItem, ...trail];
}

export function searchVFS(state: VFSState, query: string): VFSNode[] {
  const normalized = query.trim().toLowerCase();
  if (!normalized) return [];
  return Object.values(state.nodes).filter((node) =>
    node.name.toLowerCase().includes(normalized)
  );
}

export function countQuestionsInContent(content: string): number {
  try {
    const parsed = JSON.parse(content);
    if (Array.isArray(parsed)) return parsed.length;
    if (parsed && Array.isArray(parsed.questions)) return parsed.questions.length;
  } catch {
    // Ignore malformed JSON
  }
  return 0;
}
