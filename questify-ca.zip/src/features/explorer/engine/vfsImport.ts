import { ROOT_FOLDER_ID, addFile } from './vfsEngine';
import { createUid } from './vfsQuery';
import { BankType, QuestionBankJSON, QuestionItem, TableData, VFSFileNode, VFSFolderNode, VFSNode, VFSState, isTrueFalseQuestion } from './vfsTypes';

export function buildDefaultFileTemplate(name: string): string {
  return JSON.stringify(
    {
      type: 'objective', title: name.replace(/\.json$/i, ''), subject: 'CA Foundation', chapter: 'Custom Practice Bank',
      questions: [{ id: 'Q1', question: 'Sample CA Foundation MCQ question stem?', options: ['Option A', 'Option B', 'Option C', 'Option D'], correctAnswer: 0, explanation: 'Detailed conceptual explanation.', marks: 1 }],
    },
    null, 2
  );
}

export function buildDefaultTxtTemplate(name: string): string {
  const cleanTitle = name.replace(/\.txt$/i, '');
  return `# ${cleanTitle}\n\nWrite your custom ICAI notes, accounting format templates, legal provisions, or AI prompt instructions here.\n`;
}

export function addTxtFile(state: VFSState, parentId: string, name: string, content?: string): VFSState {
  const rawName = name.trim();
  if (!rawName) return state;
  const normalizedName = rawName.toLowerCase().endsWith('.txt') ? rawName : `${rawName}.txt`;
  const id = createUid('fil');
  const now = Date.now();
  const newFile: VFSFileNode = {
    id,
    type: 'file',
    name: normalizedName,
    parentId,
    fileType: 'txt',
    content: content ?? buildDefaultTxtTemplate(normalizedName),
    createdAt: now,
    updatedAt: now,
  };
  const nextNodes: Record<string, VFSNode> = { ...state.nodes, [id]: newFile };
  const parent = nextNodes[parentId];
  if (parent && parent.type === 'folder') {
    nextNodes[parentId] = { ...parent, childrenIds: [...parent.childrenIds, id] };
  }
  return { ...state, nodes: nextNodes };
}

export function updateFileContent(state: VFSState, fileId: string, newContent: string): VFSState {
  const target = state.nodes[fileId];
  if (!target || target.type !== 'file') return state;
  return { ...state, nodes: { ...state.nodes, [fileId]: { ...target, content: newContent, updatedAt: Date.now() } } };
}

export function normalizeQuestionItem(raw: Record<string, unknown>, index: number, bankType?: string): QuestionItem {
  const question = String(raw.question || raw.requirement || raw.statement || raw.text || raw.stem || raw.prompt || raw.title || `Question ${index + 1}`).trim();
  const rawOpts = raw.options || raw.choices;
  let options: string[] | undefined;
  if (Array.isArray(rawOpts) && rawOpts.length > 0) {
    options = rawOpts.map((opt) => {
      if (opt && typeof opt === 'object') {
        const o = opt as Record<string, unknown>;
        return String(o.text || o.title || o.label || o.value || '');
      }
      return String(opt ?? '');
    });
  } else if (bankType === 'true-false') {
    options = ['True', 'False'];
  }

  let correctAnswer: number | string = 0;
  const rawAns = raw.correctAnswer ?? raw.answer ?? raw.correctOption ?? raw.correct;
  if (typeof rawAns === 'number' && !Number.isNaN(rawAns)) {
    correctAnswer = options && rawAns >= 0 && rawAns < options.length ? rawAns : Math.max(0, rawAns - 1);
  } else if (typeof rawAns === 'string') {
    const clean = rawAns.trim();
    const upper = clean.toUpperCase();
    if (options && options.length === 2 && (upper === 'TRUE' || upper === 'FALSE')) {
      correctAnswer = upper === 'TRUE' ? 0 : 1;
    } else if (['A', 'B', 'C', 'D', 'E', 'F'].includes(upper)) {
      correctAnswer = upper.charCodeAt(0) - 65;
    } else if (/^\d+$/.test(clean)) {
      const n = Number(clean);
      correctAnswer = options && n >= 0 && n < options.length ? n : Math.max(0, n - 1);
    } else if (options) {
      const idx = options.findIndex((o) => o.trim().toLowerCase() === clean.toLowerCase());
      if (idx !== -1) correctAnswer = idx;
    }
  } else if (typeof rawAns === 'boolean') {
    correctAnswer = rawAns ? 0 : 1;
  }

  const isSubj = bankType === 'subjective' || bankType === 'accounts' || (!options && Boolean(raw.modelAnswer || raw.caseStudy || raw.table));
  const caseStudy = String(raw.caseStudy || (isSubj && raw.requirement ? raw.statement || '' : '') || raw.scenario || raw.context || '').trim();
  const modelAnswer = String(raw.modelAnswer || raw.reason || raw.explanation || raw.solution || '').trim();
  const table = raw.table && typeof raw.table === 'object' ? (raw.table as TableData) : undefined;
  const tables = Array.isArray(raw.tables) ? (raw.tables as TableData[]) : undefined;

  return {
    id: String(raw.id || `Q${index + 1}`),
    question,
    ...(options ? { options, correctAnswer } : {}),
    ...(modelAnswer ? { explanation: modelAnswer, reason: modelAnswer, modelAnswer } : {}),
    ...(caseStudy ? { caseStudy } : {}),
    ...(table ? { table } : {}),
    ...(tables ? { tables } : {}),
    topic: String(raw.topic || raw.concept || '').trim() || undefined,
    marks: Number(raw.marks) || (options ? (options.length === 2 ? 2 : 1) : 5),
  };
}

export function normalizeQuestionBank(rawParsed: unknown, fallbackTitle = 'CA Foundation Bank'): QuestionBankJSON {
  if (Array.isArray(rawParsed)) {
    const questions = rawParsed
      .filter((item): item is Record<string, unknown> => Boolean(item && typeof item === 'object'))
      .map((item, idx) => normalizeQuestionItem(item, idx));
    const isSubj = questions.some((q) => !q.options || q.options.length === 0);
    const isTF = !isSubj && questions.length > 0 && questions.every((q) => isTrueFalseQuestion(q));
    return { type: isSubj ? 'subjective' : isTF ? 'true-false' : 'objective', title: fallbackTitle, subject: 'CA Foundation', chapter: 'Practice Bank', questions };
  }
  if (rawParsed && typeof rawParsed === 'object') {
    const obj = rawParsed as Record<string, unknown>;
    const rawType = typeof obj.type === 'string' ? obj.type.toLowerCase() : '';
    const explicitType: BankType | undefined =
      rawType === 'subjective' || rawType === 'accounts' || rawType === 'true-false' || rawType === 'objective' || rawType === 'mcq'
        ? (rawType as BankType)
        : undefined;
    const rawList = Array.isArray(obj.questions) ? obj.questions : Array.isArray(obj.items) ? obj.items : Array.isArray(obj.data) ? obj.data : [];
    const questions = rawList
      .filter((item): item is Record<string, unknown> => Boolean(item && typeof item === 'object'))
      .map((item, idx) => normalizeQuestionItem(item, idx, explicitType));
    const inferredSubj = questions.some((q) => Boolean(q.caseStudy) || Boolean(q.table) || !q.options || q.options.length === 0);
    const inferredTF = !inferredSubj && questions.length > 0 && questions.every((q) => isTrueFalseQuestion(q, explicitType));
    return {
      type: explicitType || (inferredSubj ? 'subjective' : inferredTF ? 'true-false' : 'objective'),
      title: String(obj.title || obj.name || fallbackTitle),
      subject: String(obj.subject || 'CA Foundation'),
      chapter: String(obj.chapter || obj.topic || 'General'),
      ...(typeof obj.examSession === 'string' ? { examSession: obj.examSession } : {}),
      questions,
    };
  }
  return { type: 'objective', title: fallbackTitle, subject: 'CA Foundation', chapter: 'General', questions: [] };
}

export function parseAndValidateJsonFile(
  filename: string,
  rawContent: string
): { isValid: boolean; normalizedName: string; questionCount: number; detectedSubject?: string; normalizedJson?: string; error?: string } {
  const baseName = filename.trim() || 'Imported_Bank.json';
  const normalizedName = baseName.toLowerCase().endsWith('.json') ? baseName : `${baseName}.json`;
  try {
    const parsed = JSON.parse(rawContent);
    if (!parsed || typeof parsed !== 'object') return { isValid: false, normalizedName, questionCount: 0, error: 'Root must be an object or array.' };
    const bank = normalizeQuestionBank(parsed, normalizedName.replace(/\.json$/i, ''));
    return {
      isValid: true,
      normalizedName,
      questionCount: bank.questions.length,
      detectedSubject: `${bank.subject} ${bank.chapter} ${bank.title}`,
      normalizedJson: JSON.stringify(bank, null, 2),
    };
  } catch (err) {
    return { isValid: false, normalizedName, questionCount: 0, error: err instanceof Error ? err.message : 'Invalid JSON syntax.' };
  }
}

function resolveSmartFolderId(state: VFSState, targetFolderId: string, filename: string, detectedSubject?: string): string {
  if (targetFolderId !== ROOT_FOLDER_ID && state.nodes[targetFolderId]?.type === 'folder') return targetFolderId;
  const haystack = `${filename} ${detectedSubject || ''}`.toLowerCase();
  const findFolder = (ids: string[]) => ids.find((id) => state.nodes[id]?.type === 'folder');
  if (haystack.includes('prompt') || haystack.includes('template')) return findFolder(['fld_ai_prompts']) || 'fld_ai_prompts';
  if (haystack.includes('eco')) return findFolder(['fld_economics']) || 'fld_economics';
  if (haystack.includes('law')) return findFolder(['fld_business_law']) || 'fld_business_law';
  if (haystack.includes('acc')) return findFolder(['fld_accounting']) || 'fld_accounting';
  if (haystack.includes('quant') || haystack.includes('math') || haystack.includes('stat') || haystack.includes('finance')) {
    return findFolder(['fld_quant_aptitude']) || 'fld_quant_aptitude';
  }
  return findFolder(['fld_economics']) || state.rootFolderIds[0] || 'fld_economics';
}

function getUniqueFileName(state: VFSState, folderId: string, desiredName: string): string {
  const folder = state.nodes[folderId] as VFSFolderNode | undefined;
  if (!folder || folder.type !== 'folder') return desiredName;
  const existing = new Set(folder.childrenIds.map((cid) => state.nodes[cid]?.name.toLowerCase()).filter(Boolean));
  if (!existing.has(desiredName.toLowerCase())) return desiredName;
  const stem = desiredName.replace(/\.json$/i, '');
  let counter = 1;
  while (existing.has(`${stem} (${counter}).json`.toLowerCase())) counter += 1;
  return `${stem} (${counter}).json`;
}

export function importJsonFilesToVFS(state: VFSState, files: Array<{ name: string; content: string }>, targetFolderId: string) {
  let nextState = state;
  const importedFiles: string[] = [];
  const failedFiles: string[] = [];
  for (const file of files) {
    const validation = parseAndValidateJsonFile(file.name, file.content);
    const destFolderId = resolveSmartFolderId(nextState, targetFolderId, file.name, validation.detectedSubject);
    if (validation.isValid) {
      const uniqueName = getUniqueFileName(nextState, destFolderId, validation.normalizedName);
      nextState = addFile(nextState, destFolderId, uniqueName, validation.normalizedJson || file.content);
      importedFiles.push(uniqueName);
    } else if (file.content.trim().length > 0) {
      nextState = addTxtFile(nextState, destFolderId, file.name, file.content);
      importedFiles.push(file.name);
    } else {
      failedFiles.push(file.name);
    }
  }
  return { nextState, importedFiles, failedFiles };
}

export async function readUploadedJsonFiles(files: FileList | File[]): Promise<Array<{ name: string; content: string }>> {
  const allFiles = Array.from(files);
  const payloads = await Promise.all(
    allFiles.map((file) => new Promise<{ name: string; content: string }>((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve({ name: file.name, content: String(reader.result || '') });
      reader.onerror = () => resolve({ name: file.name, content: '' });
      reader.readAsText(file);
    }))
  );
  return payloads.filter((p) => p.content.trim().length > 0);
}
