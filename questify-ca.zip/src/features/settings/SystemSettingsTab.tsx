import React, { useState } from 'react';
import { usePWAInstall } from '../../app/pwa/usePWAInstall';
import { CheckCircle2, Download, HardDrive, Laptop, Monitor, Sparkles } from '../../ui/icons';

export const SystemSettingsTab: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIosTip, setShowIosTip] = useState(false);
  const isElectron = Boolean(typeof window !== 'undefined' && window.questifyElectron?.isElectron);

  const envTitle = isElectron
    ? 'Windows Native Desktop (.EXE)'
    : isInstalled
    ? 'Installed Offline PWA'
    : 'Web / Offline PWA Engine';

  const storageTitle = isElectron
    ? '%APPDATA% Native Disk Sync'
    : 'Browser LocalStorage + Cache API';

  const storageSub = isElectron
    ? 'Automated persistence to local disk (questify-ca-storage.json)'
    : 'Full offline cache via Service Worker & persistent Web Storage';

  return (
    <div className="space-y-4 text-xs">
      {/* Offline Desktop & App Status Card */}
      <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/60 space-y-3">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            <Monitor size={14} className="text-indigo-500" />
            <span>App Environment &amp; Packaging</span>
          </span>
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            100% Offline Ready
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <div className="p-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2 mb-1">
              <Laptop size={14} className="text-indigo-500" />
              <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">Runtime Target</span>
            </div>
            <div className="text-xs font-bold text-slate-900 dark:text-slate-100">{envTitle}</div>
            <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">Standalone cross-platform window</div>
          </div>

          <div className="p-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2 mb-1">
              <HardDrive size={14} className="text-emerald-500" />
              <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">Storage Backend</span>
            </div>
            <div className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">{storageTitle}</div>
            <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">{storageSub}</div>
          </div>
        </div>

        {/* Installation or Local App Action */}
        <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
          {isElectron ? (
            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20">
              <CheckCircle2 size={16} className="shrink-0 text-emerald-500" />
              <span className="text-xs font-medium">Running as native Windows .EXE with local file system access.</span>
            </div>
          ) : isInstalled ? (
            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20">
              <CheckCircle2 size={16} className="shrink-0 text-emerald-500" />
              <span className="text-xs font-medium">Questify CA is installed as a standalone offline desktop app.</span>
            </div>
          ) : isInstallable ? (
            <button
              type="button"
              onClick={install}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-colors cursor-pointer"
            >
              <Download size={15} />
              <span>Install Questify CA to Desktop</span>
            </button>
          ) : isIOS ? (
            <button
              type="button"
              onClick={() => setShowIosTip(true)}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <span>Install on iPhone / iPad (Safari)</span>
            </button>
          ) : (
            <div className="flex items-center justify-between p-2.5 rounded-lg bg-indigo-50/60 dark:bg-indigo-950/30 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-900/50">
              <div className="flex items-center gap-2">
                <Sparkles size={15} className="text-indigo-500" />
                <span className="text-[11px] font-medium">Cloud EXE &amp; PWA Offline Mode available.</span>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-100 dark:bg-indigo-900/60">Ready</span>
            </div>
          )}

          {showIosTip && (
            <div className="mt-2 p-3 rounded-lg bg-slate-100 dark:bg-slate-800 text-[11px] text-slate-600 dark:text-slate-300 space-y-1">
              <p><strong>iOS Installation:</strong> Tap the Share button in Safari, then tap <strong>&quot;Add to Home Screen&quot;</strong>.</p>
              <button type="button" onClick={() => setShowIosTip(false)} className="text-indigo-600 dark:text-indigo-400 font-semibold underline mt-1">Dismiss</button>
            </div>
          )}
        </div>
      </div>

      {/* Useful Keyboard Shortcuts */}
      <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/60 space-y-2">
        <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Desktop Shortcuts</div>
        <div className="grid grid-cols-2 gap-2 text-[11px]">
          <div className="flex items-center justify-between p-2 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <span className="text-slate-600 dark:text-slate-400">Search Files</span>
            <kbd className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-mono text-[10px] border border-slate-300 dark:border-slate-700">Ctrl + F</kbd>
          </div>
          <div className="flex items-center justify-between p-2 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <span className="text-slate-600 dark:text-slate-400">Toggle Theme</span>
            <kbd className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-mono text-[10px] border border-slate-300 dark:border-slate-700">Ctrl + T</kbd>
          </div>
        </div>
      </div>
    </div>
  );
};
