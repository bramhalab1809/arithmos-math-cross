import React, { useState } from 'react';
import { getVFSStorageSummary } from '../../app/boot/initBoot';
import { AccentTheme, FontSizeScale, ThemeMode, useTheme } from '../../app/theme/ThemeContext';
import {
  Check, Download, FileJson, FolderOpen, HardDrive, Laptop, Maximize2,
  Minimize2, Monitor, Moon, Palette, RotateCcw, Settings, Sliders, Sun, Type, X,
} from '../../ui/icons';
import { VFSState } from '../explorer/engine/vfsTypes';
import { SystemSettingsTab } from './SystemSettingsTab';

interface SettingsModalProps {
  isOpen: boolean;
  vfsState: VFSState;
  onClose: () => void;
  onResetVFS: () => void;
}
type SettingsTab = 'display' | 'typography' | 'storage' | 'system';

const THEME_OPTIONS: { id: ThemeMode; label: string; sub: string; IconComp: typeof Sun }[] = [
  { id: 'light', label: 'Light', sub: 'Day Sheet', IconComp: Sun },
  { id: 'dark', label: 'Dark', sub: 'Night Mode', IconComp: Moon },
  { id: 'system', label: 'Auto', sub: 'OS Sync', IconComp: Laptop },
];
const FONT_OPTIONS: { id: FontSizeScale; label: string; px: string; sampleCls: string }[] = [
  { id: 'compact', label: 'Compact', px: '14px', sampleCls: 'text-xs' },
  { id: 'normal', label: 'Normal', px: '16px', sampleCls: 'text-sm' },
  { id: 'large', label: 'Large', px: '18px', sampleCls: 'text-base' },
  { id: 'xlarge', label: 'X-Large', px: '20px', sampleCls: 'text-lg' },
];
const ACCENT_OPTIONS: { id: AccentTheme; label: string; hex: string }[] = [
  { id: 'sky', label: 'Sky', hex: '#0284c7' },
  { id: 'emerald', label: 'Emerald', hex: '#059669' },
  { id: 'amber', label: 'Amber', hex: '#d97706' },
  { id: 'violet', label: 'Violet', hex: '#7c3aed' },
  { id: 'rose', label: 'Rose', hex: '#e11d48' },
];
const TABS: { id: SettingsTab; label: string; IconComp: typeof Palette }[] = [
  { id: 'display', label: 'Theme', IconComp: Palette },
  { id: 'typography', label: 'Display', IconComp: Type },
  { id: 'storage', label: 'Storage', IconComp: HardDrive },
  { id: 'system', label: 'System', IconComp: Monitor },
];

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, vfsState, onClose, onResetVFS }) => {
  const { activeTheme, resolvedTheme, fontSize, accentTheme, setTheme, setFontSize, setAccentTheme } = useTheme();
  const [activeTab, setActiveTab] = useState<SettingsTab>('display');
  const [confirmingReset, setConfirmingReset] = useState(false);

  if (!isOpen) return null;
  const { totalFolders, totalFiles, storageBytes } = getVFSStorageSummary(vfsState);
  const formattedKB = (storageBytes / 1024).toFixed(1);

  const handleExportBackup = () => {
    const url = URL.createObjectURL(new Blob([JSON.stringify(vfsState, null, 2)], { type: 'application/json' }));
    const a = document.createElement('a');
    a.href = url; a.download = `questify-ca-backup-${new Date().toISOString().slice(0, 10)}.json`; a.click();
    URL.revokeObjectURL(url);
  };

  const applyDevicePreset = (preset: 'mobile' | 'laptop' | 'pc') => {
    if (preset === 'mobile') { setFontSize('large'); setAccentTheme('sky'); }
    else if (preset === 'laptop') { setFontSize('normal'); setAccentTheme('sky'); }
    else { setFontSize('compact'); setAccentTheme('emerald'); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150" onClick={onClose}>
      <div className="w-full sm:max-w-xl max-h-[90dvh] flex flex-col rounded-t-2xl sm:rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="px-4 sm:px-5 py-3.5 flex items-center justify-between border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/12 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 flex items-center justify-center shrink-0">
              <Settings size={18} />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-slate-100 truncate">Settings &amp; Workspace</h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">Theme, Display, Storage &amp; Desktop System</p>
            </div>
          </div>
          <button type="button" onClick={onClose} className="p-2 rounded-xl text-slate-500 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors shrink-0" aria-label="Close Settings">
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 min-h-0 flex flex-col md:flex-row overflow-hidden">
          <nav aria-label="Settings Categories" className="flex md:flex-col md:w-36 p-2 gap-1 border-b md:border-b-0 md:border-r border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-900/50 shrink-0">
            {TABS.map(({ id, label, IconComp }) => (
              <button key={id} type="button" onClick={() => setActiveTab(id)} className={`flex-1 md:flex-initial flex items-center justify-center md:justify-start gap-2 px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${activeTab === id ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200/70 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-100'}`}>
                <IconComp size={15} className="shrink-0" />
                <span>{label}</span>
              </button>
            ))}
          </nav>

          <div className="flex-1 p-4 sm:p-5 space-y-4 overflow-y-auto">
            {activeTab === 'display' && (
              <>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400"><Sun size={13} /><span>Theme</span></span>
                    <span className="text-[11px] font-mono-tabular text-indigo-600 dark:text-indigo-400 font-semibold capitalize">{resolvedTheme}</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {THEME_OPTIONS.map(({ id, label, sub, IconComp }) => (
                      <button key={id} type="button" onClick={() => setTheme(id)} className={`relative flex flex-col items-center justify-center gap-1.5 p-2.5 rounded-xl border text-center transition-all cursor-pointer ${activeTheme === id ? 'bg-indigo-50/80 dark:bg-indigo-950/40 border-indigo-500 text-indigo-700 dark:text-indigo-300 shadow-2xs' : 'bg-slate-50/70 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700/80 text-slate-700 dark:text-slate-200 hover:border-slate-400'}`}>
                        {activeTheme === id && <Check size={13} className="absolute top-2 right-2 text-indigo-600 dark:text-indigo-400" />}
                        <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${activeTheme === id ? 'bg-indigo-600 text-white' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'}`}><IconComp size={16} /></div>
                        <div className="w-full min-w-0"><div className="text-xs font-bold truncate">{label}</div><div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">{sub}</div></div>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400"><Palette size={13} /><span>Accent Color</span></span>
                    <span className="text-[11px] font-mono-tabular text-slate-500 capitalize">{accentTheme}</span>
                  </div>
                  <div className="grid grid-cols-5 gap-1.5">
                    {ACCENT_OPTIONS.map((swatch) => (
                      <button key={swatch.id} type="button" onClick={() => setAccentTheme(swatch.id)} className={`flex flex-col items-center justify-center gap-1 py-2 px-1 rounded-xl border transition-all cursor-pointer min-w-0 ${accentTheme === swatch.id ? 'bg-white dark:bg-slate-800 border-indigo-500 shadow-xs' : 'bg-slate-50/70 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700/80 hover:border-slate-400'}`}>
                        <span style={{ backgroundColor: swatch.hex }} className="w-6 h-6 rounded-full flex items-center justify-center text-white shadow-xs shrink-0">{accentTheme === swatch.id && <Check size={13} />}</span>
                        <span className="w-full text-center text-[10px] font-semibold text-slate-800 dark:text-slate-100 truncate">{swatch.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}

            {activeTab === 'typography' && (
              <>
                <div className="space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400"><Sliders size={13} /><span>Device Presets</span></div>
                  <div className="grid grid-cols-3 gap-2">
                    <button type="button" onClick={() => applyDevicePreset('mobile')} className="flex flex-col items-center gap-1 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 hover:border-indigo-400 text-center transition-colors cursor-pointer">
                      <Maximize2 size={15} className="text-indigo-500" />
                      <div className="w-full text-xs font-bold text-slate-800 dark:text-slate-100 truncate">Mobile</div>
                      <div className="text-[10px] font-mono text-slate-500">18px</div>
                    </button>
                    <button type="button" onClick={() => applyDevicePreset('laptop')} className="flex flex-col items-center gap-1 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 hover:border-indigo-400 text-center transition-colors cursor-pointer">
                      <Laptop size={15} className="text-indigo-500" />
                      <div className="w-full text-xs font-bold text-slate-800 dark:text-slate-100 truncate">Laptop</div>
                      <div className="text-[10px] font-mono text-slate-500">16px</div>
                    </button>
                    <button type="button" onClick={() => applyDevicePreset('pc')} className="flex flex-col items-center gap-1 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 hover:border-indigo-400 text-center transition-colors cursor-pointer">
                      <Minimize2 size={15} className="text-indigo-500" />
                      <div className="w-full text-xs font-bold text-slate-800 dark:text-slate-100 truncate">Desktop</div>
                      <div className="text-[10px] font-mono text-slate-500">14px</div>
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400"><Type size={13} /><span>Text Scale</span></span>
                  <div className="grid grid-cols-4 gap-1.5">
                    {FONT_OPTIONS.map((opt) => (
                      <button key={opt.id} type="button" onClick={() => setFontSize(opt.id)} className={`flex flex-col items-center justify-center gap-0.5 py-2 px-1.5 rounded-xl border transition-all cursor-pointer min-w-0 ${fontSize === opt.id ? 'bg-indigo-50/80 dark:bg-indigo-950/40 border-indigo-500 text-indigo-700 dark:text-indigo-300 shadow-2xs' : 'bg-slate-50 dark:bg-slate-800/70 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-slate-400'}`}>
                        <span className={`font-bold leading-none ${opt.sampleCls}`}>Aa</span>
                        <span className="w-full text-center text-[10px] font-bold truncate mt-1">{opt.label}</span>
                        <span className="text-[9px] font-mono text-slate-500 dark:text-slate-400">{opt.px}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}

            {activeTab === 'storage' && (
              <>
                <div className="grid grid-cols-3 gap-2 font-mono-tabular">
                  <div className="flex flex-col items-center p-2 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-center">
                    <FolderOpen size={16} className="text-amber-500 mb-0.5" />
                    <div className="text-sm font-bold text-slate-900 dark:text-slate-100">{totalFolders}</div>
                    <div className="text-[9px] uppercase text-slate-500">Folders</div>
                  </div>
                  <div className="flex flex-col items-center p-2 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-center">
                    <FileJson size={16} className="text-emerald-500 mb-0.5" />
                    <div className="text-sm font-bold text-slate-900 dark:text-slate-100">{totalFiles}</div>
                    <div className="text-[9px] uppercase text-slate-500">Files</div>
                  </div>
                  <div className="flex flex-col items-center p-2 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-center">
                    <HardDrive size={16} className="text-indigo-500 mb-0.5" />
                    <div className="text-sm font-bold text-indigo-600 dark:text-indigo-400">{formattedKB} KB</div>
                    <div className="text-[9px] uppercase text-slate-500">Used</div>
                  </div>
                </div>

                <button type="button" onClick={handleExportBackup} className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-colors cursor-pointer">
                  <Download size={14} /><span>Export Backup (.json)</span>
                </button>

                <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
                  {!confirmingReset ? (
                    <button type="button" onClick={() => setConfirmingReset(true)} className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-semibold text-rose-600 dark:text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/25 transition-colors cursor-pointer">
                      <RotateCcw size={14} /><span>Reset Default Files</span>
                    </button>
                  ) : (
                    <div className="p-2 rounded-xl bg-rose-500/12 border border-rose-500/40 flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold text-rose-700 dark:text-rose-300 truncate">Restore defaults?</span>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button type="button" onClick={() => setConfirmingReset(false)} className="px-2 py-0.5 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800">Cancel</button>
                        <button type="button" onClick={() => { onResetVFS(); setConfirmingReset(false); onClose(); }} className="flex items-center gap-1 px-2.5 py-0.5 rounded-lg text-xs font-semibold bg-rose-600 text-white hover:bg-rose-700"><Check size={12} /><span>Reset</span></button>
                      </div>
                    </div>
                  )}
                </div>
              </>
            )}

            {activeTab === 'system' && <SystemSettingsTab />}
          </div>
        </div>
      </div>
    </div>
  );
};
