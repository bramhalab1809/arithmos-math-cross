import { VFSFileNode, VFSState, isTrueFalseQuestion } from '../../explorer/engine/vfsTypes';
import {
  BankSessionRecord,
  BankSessionStatus,
  CanonicalSubject,
  QuestionSourceTag,
  getAllBankSessions,
  detectCanonicalSubject,
  detectQuestionSourceTag,
} from '../../playground/shared/sessionStore';

export interface BankAnalyticsRow {
  fileNode: VFSFileNode;
  fileId: string;
  title: string;
  subject: CanonicalSubject;
  sourceTag: QuestionSourceTag;
  bankType: 'mcq' | 'true-false' | 'subjective';
  status: BankSessionStatus;
  totalQuestions: number;
  attemptedCount: number;
  correctCount: number;
  accuracyPercent: number;
  elapsedSeconds: number;
  currentIndex: number;
  updatedAt: string | null;
}

export interface SourceBreakdownMetric {
  sourceTag: QuestionSourceTag;
  totalBanks: number;
  completedBanks: number;
  inProgressBanks: number;
  totalQuestions: number;
  attemptedQuestions: number;
  correctQuestions: number;
  accuracyPercent: number;
  completionPercent: number;
}

export interface SubjectBreakdownMetric {
  subject: CanonicalSubject;
  paperLabel: string;
  totalBanks: number;
  totalQuestions: number;
  attemptedQuestions: number;
  correctQuestions: number;
  accuracyPercent: number;
  masteryPercent: number;
  elapsedSeconds: number;
}

export interface GlobalAnalyticsReport {
  totalBanks: number;
  completedBanks: number;
  inProgressBanks: number;
  notStartedBanks: number;
  totalQuestionsAvailable: number;
  totalQuestionsSolved: number;
  totalCorrect: number;
  overallAccuracyPercent: number;
  totalStudySeconds: number;
  avgSecondsPerQuestion: number;
  examReadinessScore: number;
  sourceBreakdown: SourceBreakdownMetric[];
  subjectBreakdown: SubjectBreakdownMetric[];
  bankRows: BankAnalyticsRow[];
}

const ALL_SOURCES: QuestionSourceTag[] = [
  'PYQ',
  'RTP',
  'MTP',
  'ICAI Study Material',
  'Other Faculties',
];

const ALL_SUBJECTS: { subject: CanonicalSubject; paperLabel: string }[] = [
  { subject: 'Accounting', paperLabel: 'Paper 1: Accounting' },
  { subject: 'Business Law', paperLabel: 'Paper 2: Business Laws' },
  { subject: 'Quantitative Aptitude', paperLabel: 'Paper 3: Quantitative Aptitude' },
  { subject: 'Business Economics', paperLabel: 'Paper 4: Business Economics' },
];

export function computeGlobalAnalytics(vfsState: VFSState): GlobalAnalyticsReport {
  const sessions = getAllBankSessions();
  const jsonFiles = Object.values(vfsState.nodes).filter(
    (n): n is VFSFileNode => n.type === 'file' && n.fileType === 'json'
  );

  const bankRows: BankAnalyticsRow[] = [];

  for (const file of jsonFiles) {
    let parsedQuestions = 0;
    let parsedTitle = file.name.replace(/\.json$/i, '');
    let parsedSubject = '';
    let parsedChapter = '';
    let parsedType: 'mcq' | 'true-false' | 'subjective' = 'mcq';

    try {
      const data = JSON.parse(file.content);
      if (Array.isArray(data.questions)) {
        parsedQuestions = data.questions.length;
        const q0 = data.questions[0];
        const isTF = isTrueFalseQuestion(q0, data.type);
        const isSubj = data.type === 'subjective' || data.type === 'accounts';
        parsedType = isSubj ? 'subjective' : isTF ? 'true-false' : 'mcq';
      }
      if (data.title) parsedTitle = data.title;
      if (data.subject) parsedSubject = data.subject;
      if (data.chapter) parsedChapter = data.chapter;
    } catch {
      continue;
    }

    const saved: BankSessionRecord | undefined = sessions[file.id];
    const subject =
      saved?.subject || detectCanonicalSubject(parsedSubject, file.name, parsedTitle);
    const sourceTag =
      saved?.sourceTag || detectQuestionSourceTag(file.name, parsedTitle, parsedChapter);
    const totalQuestions = parsedQuestions || saved?.totalQuestions || 0;

    bankRows.push({
      fileNode: file,
      fileId: file.id,
      title: parsedTitle,
      subject,
      sourceTag,
      bankType: saved?.bankType || parsedType,
      status: saved?.status || 'not-started',
      totalQuestions,
      attemptedCount: saved?.attemptedCount || 0,
      correctCount: saved?.correctCount || 0,
      accuracyPercent: saved?.accuracyPercent || 0,
      elapsedSeconds: saved?.elapsedSeconds || 0,
      currentIndex: saved?.currentIndex || 0,
      updatedAt: saved?.updatedAt || null,
    });
  }

  const totalBanks = bankRows.length;
  const completedBanks = bankRows.filter((b) => b.status === 'completed').length;
  const inProgressBanks = bankRows.filter((b) => b.status === 'in-progress').length;
  const notStartedBanks = totalBanks - completedBanks - inProgressBanks;

  const totalQuestionsAvailable = bankRows.reduce((acc, b) => acc + b.totalQuestions, 0);
  const totalQuestionsSolved = bankRows.reduce((acc, b) => acc + b.attemptedCount, 0);
  const totalCorrect = bankRows.reduce((acc, b) => acc + b.correctCount, 0);
  const overallAccuracyPercent =
    totalQuestionsSolved > 0 ? Math.round((totalCorrect / totalQuestionsSolved) * 100) : 0;

  const totalStudySeconds = bankRows.reduce((acc, b) => acc + b.elapsedSeconds, 0);
  const avgSecondsPerQuestion =
    totalQuestionsSolved > 0 ? Math.round(totalStudySeconds / totalQuestionsSolved) : 0;

  const coverageRatio =
    totalQuestionsAvailable > 0 ? totalQuestionsSolved / totalQuestionsAvailable : 0;
  const examReadinessScore = Math.min(
    100,
    Math.round(overallAccuracyPercent * 0.65 + coverageRatio * 100 * 0.35)
  );

  const sourceBreakdown: SourceBreakdownMetric[] = ALL_SOURCES.map((sourceTag) => {
    const matching = bankRows.filter((b) => b.sourceTag === sourceTag);
    const totalQ = matching.reduce((s, b) => s + b.totalQuestions, 0);
    const attemptedQ = matching.reduce((s, b) => s + b.attemptedCount, 0);
    const correctQ = matching.reduce((s, b) => s + b.correctCount, 0);
    return {
      sourceTag,
      totalBanks: matching.length,
      completedBanks: matching.filter((b) => b.status === 'completed').length,
      inProgressBanks: matching.filter((b) => b.status === 'in-progress').length,
      totalQuestions: totalQ,
      attemptedQuestions: attemptedQ,
      correctQuestions: correctQ,
      accuracyPercent: attemptedQ > 0 ? Math.round((correctQ / attemptedQ) * 100) : 0,
      completionPercent: totalQ > 0 ? Math.round((attemptedQ / totalQ) * 100) : 0,
    };
  });

  const subjectBreakdown: SubjectBreakdownMetric[] = ALL_SUBJECTS.map(
    ({ subject, paperLabel }) => {
      const matching = bankRows.filter((b) => b.subject === subject);
      const totalQ = matching.reduce((s, b) => s + b.totalQuestions, 0);
      const attemptedQ = matching.reduce((s, b) => s + b.attemptedCount, 0);
      const correctQ = matching.reduce((s, b) => s + b.correctCount, 0);
      const accuracyPercent = attemptedQ > 0 ? Math.round((correctQ / attemptedQ) * 100) : 0;
      const coverage = totalQ > 0 ? Math.round((attemptedQ / totalQ) * 100) : 0;
      return {
        subject,
        paperLabel,
        totalBanks: matching.length,
        totalQuestions: totalQ,
        attemptedQuestions: attemptedQ,
        correctQuestions: correctQ,
        accuracyPercent,
        masteryPercent: Math.round(accuracyPercent * 0.6 + coverage * 0.4),
        elapsedSeconds: matching.reduce((s, b) => s + b.elapsedSeconds, 0),
      };
    }
  );

  return {
    totalBanks,
    completedBanks,
    inProgressBanks,
    notStartedBanks,
    totalQuestionsAvailable,
    totalQuestionsSolved,
    totalCorrect,
    overallAccuracyPercent,
    totalStudySeconds,
    avgSecondsPerQuestion,
    examReadinessScore,
    sourceBreakdown,
    subjectBreakdown,
    bankRows,
  };
}
