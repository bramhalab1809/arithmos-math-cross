import React, { useState } from 'react';
import { Copy, Eye, Icon, Plus, Table, Trash2 } from '../../../ui/icons';
import { RichContentRenderer } from '../../../ui/table/RichContentRenderer';
import { BankType, QuestionBankJSON, QuestionItem, isTrueFalseQuestion } from '../../explorer/engine/vfsTypes';
import { getUnifiedQuestionStatement } from '../../playground/subjective/QuestionPeekSheet';

export interface VisualFormEditorProps {
  bank: QuestionBankJSON;
  onChangeBank: (updatedBank: QuestionBankJSON) => void;
}

const INPUT_CLS = 'w-full text-xs sm:text-sm p-2.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-indigo-500 outline-none';
const LBL_CLS = 'text-xs font-semibold text-slate-600 dark:text-slate-400';
const TOGGLE_BTN_CLS = 'p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors shadow-xs shrink-0';

export const VisualFormEditor: React.FC<VisualFormEditorProps> = ({ bank, onChangeBank }) => {
  const questions = bank.questions || [];
  const [activeIndex, setActiveIndex] = useState<number>(0);
  const [showPreview, setShowPreview] = useState<boolean>(false);
  const [isPanelOpen, setIsPanelOpen] = useState<boolean>(true);

  const boundedIdx = Math.min(activeIndex, Math.max(0, questions.length - 1));
  const activeQ: QuestionItem = questions[boundedIdx] || { id: 'Q1', question: '' };

  const isSubjective = bank.type === 'subjective' || bank.type === 'accounts' || (!activeQ.options && Boolean(activeQ.modelAnswer || activeQ.caseStudy || activeQ.table));
  const isTrueFalse = !isSubjective && (bank.type === 'true-false' || isTrueFalseQuestion(activeQ, bank.type));
  const tfCorrectIsTrue = activeQ.correctAnswer === 0 || String(activeQ.correctAnswer).toLowerCase() === 'true';

  const updateActiveQ = (patch: Partial<QuestionItem>) => {
    onChangeBank({ ...bank, questions: questions.map((q, idx) => (idx === boundedIdx ? { ...q, ...patch } : q)) });
  };

  const handleBankTypeChange = (nextType: BankType) => {
    const updated = questions.map((q) => {
      if (nextType === 'subjective') {
        const { options: _o, correctAnswer: _c, ...rest } = q;
        const unified = getUnifiedQuestionStatement(q);
        return { ...rest, question: unified || q.question || '', caseStudy: '', requirement: '', modelAnswer: q.modelAnswer || q.explanation || '', marks: q.marks || 10 };
      }
      if (nextType === 'true-false') return { ...q, options: ['True', 'False'], correctAnswer: q.correctAnswer === 1 ? 1 : 0, reason: q.reason || q.explanation || '', marks: 2 };
      return { ...q, options: q.options?.length === 4 ? q.options : ['Option A', 'Option B', 'Option C', 'Option D'], correctAnswer: 0, marks: 1 };
    });
    onChangeBank({ ...bank, type: nextType, questions: updated });
  };

  const handleAddQuestion = () => {
    const n = questions.length + 1;
    const newQ: QuestionItem = isSubjective
      ? { id: `Q${n}`, question: 'Enter complete problem facts, adjustments, and requirements...', caseStudy: '', marks: 10, modelAnswer: 'Model answer solution.' }
      : isTrueFalse
      ? { id: `TF-${n}`, question: 'State with reasons whether True or False...', options: ['True', 'False'], correctAnswer: 0, marks: 2, reason: 'ICAI guideline reason.' }
      : { id: `Q${n}`, question: 'Question text here...', options: ['Option A', 'Option B', 'Option C', 'Option D'], correctAnswer: 0, marks: 1, explanation: '' };
    onChangeBank({ ...bank, questions: [...questions, newQ] });
    setActiveIndex(questions.length);
  };

  const handleDeleteQuestion = (idx: number) => {
    if (questions.length <= 1) return;
    onChangeBank({ ...bank, questions: questions.filter((_, i) => i !== idx) });
    setActiveIndex(Math.max(0, idx - 1));
  };

  const unifiedSubjectiveQuestion = getUnifiedQuestionStatement(activeQ);

  const handleInsertSampleTable = () => {
    const snippet = `\nTrial Balance as at 31st March:\n| Particulars | Debit (Rs.) | Credit (Rs.) |\n|---|---|---|\n| Machinery Account | 2,50,000 | - |\n| **Total** | **2,50,000** | **2,50,000** |`;
    updateActiveQ({ question: `${unifiedSubjectiveQuestion}${snippet}`.trim(), caseStudy: '', requirement: '' });
  };

  return (
    <div className="flex-1 min-h-0 flex flex-col md:flex-row h-full overflow-hidden bg-slate-50 dark:bg-slate-900">
      <aside className={isPanelOpen ? 'w-full md:w-72 lg:w-80 opacity-100 translate-x-0 transition-all duration-300 ease-in-out flex flex-col flex-shrink-0 border-b md:border-b-0 md:border-r border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-3 max-h-48 md:max-h-none' : 'w-0 h-0 md:h-auto opacity-0 -translate-x-full overflow-hidden pointer-events-none transition-all duration-300 ease-in-out border-none p-0'}>
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 dark:border-slate-700">
          <span className="text-xs font-semibold uppercase text-slate-500">Questions ({questions.length})</span>
          <div className="flex items-center gap-1">
            <button type="button" onClick={handleAddQuestion} className="p-1.5 rounded-lg text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/40" title="Add Question">
              <Plus size={16} />
            </button>
            <button type="button" onClick={() => setIsPanelOpen(false)} aria-label="Toggle Question Panel" title="Toggle Question Panel" className={TOGGLE_BTN_CLS}>
              <Icon name="chevron-left" size={16} />
            </button>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto space-y-1">
          {questions.map((q, idx) => (
            <div key={`${q.id}_${idx}`} onClick={() => setActiveIndex(idx)} className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium flex items-center justify-between cursor-pointer transition-colors ${boundedIdx === idx ? 'bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800' : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50'}`}>
              <span className="truncate">Q {idx + 1}. {(q.question || q.caseStudy || 'Untitled').replace(/\*\*/g, '').slice(0, 22)}...</span>
              {boundedIdx === idx && (
                <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                  <button type="button" onClick={() => { const next = [...questions]; next.splice(idx + 1, 0, { ...q, id: `Q${questions.length + 1}` }); onChangeBank({ ...bank, questions: next }); }} className="text-slate-400 hover:text-indigo-500"><Copy size={13} /></button>
                  {questions.length > 1 && <button type="button" onClick={() => handleDeleteQuestion(idx)} className="text-rose-500 hover:text-rose-700"><Trash2 size={14} /></button>}
                </div>
              )}
            </div>
          ))}
        </div>
      </aside>

      <div className="flex-1 min-h-0 flex flex-col h-full overflow-hidden">
        <div className="flex-1 overflow-y-auto w-full max-w-full p-4 sm:p-6 lg:p-8 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-800 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700">
            <div className="flex items-center gap-2.5 flex-1 min-w-[220px]">
              {!isPanelOpen ? (
                <button type="button" onClick={() => setIsPanelOpen(true)} aria-label="Toggle Question Panel" className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-100 text-indigo-600 dark:text-indigo-400 transition-colors shadow-xs shrink-0">
                  <span>Questions ({questions.length})</span><Icon name="chevron-right" size={15} />
                </button>
              ) : (
                <button type="button" onClick={() => setIsPanelOpen(false)} aria-label="Toggle Question Panel" className={TOGGLE_BTN_CLS}>
                  <Icon name="chevron-left" size={16} />
                </button>
              )}
              <input type="text" value={bank.title || ''} onChange={(e) => onChangeBank({ ...bank, title: e.target.value })} placeholder="Question Bank Title" className="font-semibold text-sm sm:text-base text-slate-900 dark:text-slate-100 bg-transparent outline-none flex-1" />
            </div>
            <select value={isSubjective ? 'subjective' : isTrueFalse ? 'true-false' : 'objective'} onChange={(e) => handleBankTypeChange(e.target.value as BankType)} className="px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 uppercase outline-none">
              <option value="objective">Objective MCQ</option>
              <option value="true-false">True / False</option>
              <option value="subjective">Subjective / Case</option>
            </select>
          </div>

          <div className="bg-white dark:bg-slate-800 p-4 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-4 shadow-2xs">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-slate-100 dark:border-slate-700">
              <div className="flex items-center gap-2.5 flex-1 min-w-[240px]">
                <input type="text" value={activeQ.topic || ''} onChange={(e) => updateActiveQ({ topic: e.target.value })} placeholder="Topic / AS / Section ref..." className="px-3 py-1.5 text-xs rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 outline-none flex-1 max-w-xs" />
                {isSubjective && (
                  <div className="flex items-center gap-1.5">
                    <span className={LBL_CLS}>Marks:</span>
                    <input type="number" value={activeQ.marks || 10} onChange={(e) => updateActiveQ({ marks: Number(e.target.value) })} className="w-20 px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 outline-none" />
                  </div>
                )}
              </div>
              <button type="button" onClick={() => setShowPreview((p) => !p)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-sky-500/12 text-sky-600 dark:text-cyan-400">
                <Eye size={13} /><span>{showPreview ? 'Hide Preview' : 'Markdown Preview'}</span>
              </button>
            </div>

            {isSubjective && (
              <>
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between gap-2">
                    <label className={LBL_CLS}>Question Statement (Q {boundedIdx + 1}. Facts, Adjustments &amp; Requirements)</label>
                    <button type="button" onClick={handleInsertSampleTable} className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100">
                      <Table size={12} /><span>+ Insert Pipe Table</span>
                    </button>
                  </div>
                  <textarea value={unifiedSubjectiveQuestion} onChange={(e) => updateActiveQ({ question: e.target.value, caseStudy: '', requirement: '' })} className="w-full min-h-[190px] font-mono text-sm leading-relaxed p-3.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-indigo-500 outline-none" />
                </div>
                <div className="space-y-1.5">
                  <label className={LBL_CLS}>ICAI Model Answer / Solution Guidelines (Supports Tables)</label>
                  <textarea value={activeQ.modelAnswer || activeQ.explanation || ''} onChange={(e) => updateActiveQ({ modelAnswer: e.target.value, explanation: e.target.value })} className="w-full min-h-[220px] font-mono text-sm leading-relaxed p-3.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-indigo-500 outline-none" />
                </div>
              </>
            )}

            {isTrueFalse && (
              <>
                <div className="space-y-1">
                  <label className={LBL_CLS}>Question / Statement</label>
                  <textarea rows={3} value={activeQ.question || ''} onChange={(e) => updateActiveQ({ question: e.target.value })} className={INPUT_CLS} />
                </div>
                <div className="space-y-1">
                  <label className={LBL_CLS}>Correct Answer</label>
                  <div className="flex gap-3">
                    {(['True', 'False'] as const).map((opt, idx) => (
                      <button key={opt} type="button" onClick={() => updateActiveQ({ options: ['True', 'False'], correctAnswer: idx })} className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg border ${(idx === 0 && tfCorrectIsTrue) || (idx === 1 && !tfCorrectIsTrue) ? 'bg-indigo-600 text-white border-indigo-600' : 'border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300'}`}>
                        [ {opt} ]
                      </button>
                    ))}
                  </div>
                </div>
                <div className="space-y-1">
                  <label className={LBL_CLS}>ICAI Official Reason (Compulsory for Full Marks)</label>
                  <textarea rows={4} value={activeQ.reason || activeQ.explanation || ''} onChange={(e) => updateActiveQ({ reason: e.target.value, explanation: e.target.value })} className={INPUT_CLS} />
                </div>
              </>
            )}

            {!isSubjective && !isTrueFalse && (
              <>
                <div className="space-y-1">
                  <label className={LBL_CLS}>Question / Statement</label>
                  <textarea rows={3} value={activeQ.question || ''} onChange={(e) => updateActiveQ({ question: e.target.value })} className={INPUT_CLS} />
                </div>
                <div className="space-y-2">
                  <label className={LBL_CLS}>Options (A to D)</label>
                  {['A', 'B', 'C', 'D'].map((label, i) => (
                    <div key={label} className="flex items-center gap-2">
                      <span className="w-6 text-xs font-bold text-slate-500">{label}.</span>
                      <input type="text" value={activeQ.options?.[i] || ''} onChange={(e) => { const opts = [...(activeQ.options || ['', '', '', ''])]; opts[i] = e.target.value; updateActiveQ({ options: opts }); }} className={INPUT_CLS} />
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className={LBL_CLS}>Correct Option</label>
                    <select value={typeof activeQ.correctAnswer === 'number' ? activeQ.correctAnswer : 0} onChange={(e) => updateActiveQ({ correctAnswer: Number(e.target.value) })} className={INPUT_CLS}>
                      {['A', 'B', 'C', 'D'].map((l, idx) => <option key={l} value={idx}>Option {l}</option>)}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className={LBL_CLS}>Explanation</label>
                    <input type="text" value={activeQ.explanation || ''} onChange={(e) => updateActiveQ({ explanation: e.target.value })} className={INPUT_CLS} />
                  </div>
                </div>
              </>
            )}

            {showPreview && (
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-sky-500/40 space-y-2">
                <span className="text-[11px] font-bold uppercase text-sky-600 dark:text-cyan-400">Live Preview</span>
                <RichContentRenderer text={[unifiedSubjectiveQuestion, activeQ.modelAnswer || activeQ.reason || activeQ.explanation].filter(Boolean).join('\n\n')} table={activeQ.table} tables={activeQ.tables} />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
