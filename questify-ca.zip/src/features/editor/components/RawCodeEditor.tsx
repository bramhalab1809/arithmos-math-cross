import React, { useState } from 'react';
import {
  AlertTriangle,
  Check,
  CheckCircle2,
  Code,
  Copy,
} from '../../../ui/icons';
import { ValidationResult, formatBeautifyJson } from '../engine/schemaValidator';

interface RawCodeEditorProps {
  rawText: string;
  validation: ValidationResult;
  onChangeRawText: (updated: string) => void;
}

export const RawCodeEditor: React.FC<RawCodeEditorProps> = ({
  rawText,
  validation,
  onChangeRawText,
}) => {
  const [copied, setCopied] = useState(false);

  const lineCount = rawText.split('\n').length;
  const charCount = rawText.length;

  const handleBeautify = () => {
    const { formatted, error } = formatBeautifyJson(rawText);
    if (!error) {
      onChangeRawText(formatted);
    }
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(rawText);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard fallback ignored
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const target = e.currentTarget;
      const start = target.selectionStart;
      const end = target.selectionEnd;
      const nextValue = `${rawText.substring(0, start)}  ${rawText.substring(end)}`;
      onChangeRawText(nextValue);
      requestAnimationFrame(() => {
        target.selectionStart = target.selectionEnd = start + 2;
      });
    }
  };

  return (
    <div className="flex-1 min-h-0 w-full max-w-6xl mx-auto p-3 sm:p-5 flex flex-col gap-3 overflow-hidden">
      <div className="flex-1 min-h-0 flex flex-col rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] overflow-hidden">
        {/* Editor Toolbar */}
        <div className="px-4 py-2.5 border-b border-[var(--border-subtle)] flex flex-wrap items-center justify-between gap-2 bg-[var(--bg-app)]/60 shrink-0">
          <div className="flex items-center gap-3 text-xs font-mono-tabular text-[var(--text-muted)]">
            <span>{lineCount} lines</span>
            <span aria-hidden="true">·</span>
            <span>{charCount} chars</span>
            <span aria-hidden="true">·</span>
            {validation.isValid ? (
              <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold">
                <CheckCircle2 size={13} />
                <span>Valid Schema ({validation.questionCount} Qs)</span>
              </span>
            ) : (
              <span className="flex items-center gap-1 text-rose-600 dark:text-rose-400 font-semibold">
                <AlertTriangle size={13} />
                <span>Syntax / Schema Error</span>
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleBeautify}
              disabled={!validation.isValid && Boolean(validation.errorLine)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[var(--bg-surface)] border border-[var(--border-subtle)] hover:border-sky-500/50 text-[var(--text-primary)] disabled:opacity-45 transition-colors"
              title="Format and indent JSON (2 spaces)"
            >
              <Code size={14} className="text-sky-500" />
              <span>Format / Beautify JSON</span>
            </button>

            <button
              type="button"
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[var(--bg-surface)] border border-[var(--border-subtle)] hover:border-[var(--border-strong)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors"
            >
              {copied ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
              <span>{copied ? 'Copied' : 'Copy Raw JSON'}</span>
            </button>
          </div>
        </div>

        {/* Monospace Code Textarea */}
        <textarea
          value={rawText}
          onChange={(e) => onChangeRawText(e.target.value)}
          onKeyDown={handleKeyDown}
          spellCheck={false}
          autoCapitalize="off"
          autoComplete="off"
          className="flex-1 min-h-0 w-full p-4 font-mono-tabular text-xs sm:text-sm leading-relaxed bg-[var(--bg-surface)] text-[var(--text-primary)] focus:outline-none resize-none overflow-y-auto"
          placeholder="Paste or edit raw CA Foundation JSON question bank..."
        />

        {/* Real-time Syntax & Schema Error Banner */}
        {!validation.isValid && validation.error && (
          <div className="px-4 py-3 border-t border-rose-500/30 bg-rose-500/10 flex items-start gap-2.5 text-xs text-rose-600 dark:text-rose-300 shrink-0">
            <AlertTriangle size={16} className="shrink-0 mt-0.5 text-rose-500" />
            <div className="font-mono-tabular">
              <span className="font-bold">Validation Error</span>
              {validation.errorLine ? ` (near line ${validation.errorLine})` : ''}:{' '}
              {validation.error}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
