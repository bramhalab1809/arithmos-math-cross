import { normalizeQuestionBank } from '../../explorer/engine/vfsImport';
import { QuestionBankJSON } from '../../explorer/engine/vfsTypes';

export interface ValidationResult {
  isValid: boolean;
  error: string | null;
  errorLine?: number;
  parsed: QuestionBankJSON | null;
  questionCount: number;
  warnings: string[];
}

function extractErrorLine(rawContent: string, message: string): number | undefined {
  const posMatch = message.match(/position\s+(\d+)/i);
  if (posMatch) {
    const pos = Number(posMatch[1]);
    if (!Number.isNaN(pos) && pos >= 0) return rawContent.slice(0, pos).split('\n').length;
  }
  const lineMatch = message.match(/line\s+(\d+)/i);
  return lineMatch ? Number(lineMatch[1]) : undefined;
}

export function validateQuestionBankJson(rawContent: string): ValidationResult {
  const fail = (error: string, errorLine?: number, warnings: string[] = []): ValidationResult => ({
    isValid: false,
    error,
    errorLine,
    parsed: null,
    questionCount: 0,
    warnings,
  });

  if (!rawContent.trim()) return fail('JSON content cannot be empty.');

  let rawParsed: unknown;
  try {
    rawParsed = JSON.parse(rawContent);
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Invalid JSON syntax.';
    return fail(msg, extractErrorLine(rawContent, msg));
  }

  if (!rawParsed || typeof rawParsed !== 'object') {
    return fail('Root JSON must be an object or array of questions.');
  }

  const warnings: string[] = [];
  if (Array.isArray(rawParsed)) {
    warnings.push('Top-level JSON is an array; normalized into QuestionBankJSON structure.');
  }

  const normalizedBank = normalizeQuestionBank(rawParsed, 'CA Foundation Practice Bank');
  if (normalizedBank.questions.length === 0) {
    return fail('No questions found. Ensure your JSON has a "questions" array with at least 1 item.');
  }

  return {
    isValid: true,
    error: null,
    parsed: normalizedBank,
    questionCount: normalizedBank.questions.length,
    warnings,
  };
}

export function formatBeautifyJson(rawContent: string): { formatted: string; error: string | null } {
  try {
    return { formatted: JSON.stringify(JSON.parse(rawContent), null, 2), error: null };
  } catch (err) {
    return { formatted: rawContent, error: err instanceof Error ? err.message : 'Cannot format invalid JSON.' };
  }
}
