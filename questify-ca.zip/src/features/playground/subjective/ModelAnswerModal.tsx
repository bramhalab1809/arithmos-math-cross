import React, { useEffect } from 'react';
import { Icon } from '../../../ui/icons';
import { RichContentRenderer } from '../../../ui/table/RichContentRenderer';

interface ModelAnswerModalProps {
  isOpen: boolean;
  questionNumber: number;
  questionTopic?: string;
  marks?: number;
  modelAnswerText: string;
  onClose: () => void;
}

export const ModelAnswerModal: React.FC<ModelAnswerModalProps> = ({
  isOpen,
  questionNumber,
  questionTopic,
  marks = 5,
  modelAnswerText,
  onClose,
}) => {
  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-slate-950/55 backdrop-blur-xs animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl h-[100dvh] bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <header className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-emerald-50/70 dark:bg-emerald-950/30 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
              <Icon name="lightbulb" size={18} />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate">
                ICAI Suggested Solution &amp; Marking Scheme
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                Q{questionNumber}. {questionTopic || 'Subjective Problem'} · {marks} {marks === 1 ? 'Mark' : 'Marks'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors shrink-0"
          >
            <Icon name="x" size={14} />
            <span>Close</span>
          </button>
        </header>

        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4">
          <div className="p-4 sm:p-5 rounded-xl bg-slate-50/80 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <RichContentRenderer text={modelAnswerText} />
          </div>
        </div>
      </div>
    </div>
  );
};
