import React, { useEffect, useMemo, useState } from 'react';
import { Icon } from '../../../ui/icons';
import {
  ACCOUNT_DEF_CATEGORIES,
  AccountDefinition,
  getAllAccountDefinitions,
} from '../accounts/accountDefinitions';
import { SubjectVfsManagerBar } from '../shared/SubjectVfsManagerBar';
import { getSubjectDescendantFolders } from '../shared/vfsSubjectScoped';

interface FormatsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onInsertDefinition: (def: AccountDefinition) => void;
}

export const FormatsDrawer: React.FC<FormatsDrawerProps> = ({
  isOpen,
  onClose,
  onInsertDefinition,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('ALL');
  const [selectedFolderId, setSelectedFolderId] = useState<string | 'ALL'>('ALL');
  const [vfsTick, setVfsTick] = useState(0);

  useEffect(() => {
    const onVfsUpdated = () => setVfsTick((t) => t + 1);
    window.addEventListener('vfs-updated', onVfsUpdated);
    return () => window.removeEventListener('vfs-updated', onVfsUpdated);
  }, []);

  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isOpen, onClose]);

  const folders = useMemo(() => {
    void vfsTick;
    return getSubjectDescendantFolders('fld_accounting');
  }, [vfsTick]);

  const definitions = useMemo(() => {
    void vfsTick;
    const allDefs = getAllAccountDefinitions(selectedFolderId);
    const q = searchQuery.trim().toLowerCase();
    return allDefs.filter((d) => {
      const catOk = activeCategory === 'ALL' || d.category === activeCategory;
      if (!catOk) return false;
      if (!q) return true;
      return (
        d.command.toLowerCase().includes(q) ||
        d.title.toLowerCase().includes(q) ||
        d.category.toLowerCase().includes(q) ||
        d.description.toLowerCase().includes(q) ||
        (d.fileName && d.fileName.toLowerCase().includes(q))
      );
    });
  }, [activeCategory, searchQuery, selectedFolderId, vfsTick]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-slate-950/55 backdrop-blur-xs animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl h-[100dvh] bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-4 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-800/70 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0">
              <Icon name="table" size={16} />
            </span>
            <div className="min-w-0">
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate">
                Accounting Formats (.txt Library)
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                Loaded from Standard Account Formats (.txt) &mdash; Inserts Interactive Cards
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800"
            aria-label="Close Formats Drawer"
          >
            <Icon name="x" size={16} />
          </button>
        </div>

        <div className="px-3.5 py-2 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900 shrink-0">
          <SubjectVfsManagerBar
            rootFolderId="fld_accounting"
            folders={folders}
            selectedFolderId={selectedFolderId}
            onSelectFolder={setSelectedFolderId}
            onRefresh={() => setVfsTick((t) => t + 1)}
          />
        </div>

        <div className="p-3 border-b border-slate-200 dark:border-slate-800 space-y-2.5 bg-white dark:bg-slate-900 shrink-0">
          <div className="relative">
            <Icon name="search" size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search format .txt file or command (e.g. /Trading, /BRS, /Revaluation)..."
              className="w-full pl-8 pr-3 py-1.5 rounded-lg text-xs border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 no-scrollbar">
            {['ALL', ...ACCOUNT_DEF_CATEGORIES].map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setActiveCategory(cat)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold whitespace-nowrap transition-colors ${
                  activeCategory === cat
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {cat === 'ALL' ? 'All Formats' : cat}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-3.5 space-y-2.5">
          {definitions.map((def) => (
            <div
              key={def.id}
              className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 hover:border-indigo-300 dark:hover:border-indigo-700 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div className="min-w-0 flex-1 space-y-1">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-xs font-mono font-bold text-indigo-600 dark:text-indigo-400">
                    {def.command}
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200/60 dark:border-indigo-800 font-semibold">
                    {def.category}
                  </span>
                  {def.fileName && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-200/70 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-mono">
                      {def.fileName}
                    </span>
                  )}
                </div>
                <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100">{def.title}</h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  {def.description}
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  onInsertDefinition(def);
                  onClose();
                }}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shrink-0 flex items-center justify-center gap-1.5 transition-colors"
              >
                <Icon name="plus" size={13} />
                <span>Insert Card</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
