import React, { useRef, useState } from 'react';
import { Camera, Image, Plus, X, ZoomIn } from '../../../ui/icons';
import { ImageZoomModal } from './ImageZoomModal';

interface AnswerImageGalleryProps {
  images: string[];
  isSubmitted: boolean;
  onAddImages: (newImages: string[]) => void;
  onRemoveImage: (index: number) => void;
}

const MAX_IMAGE_DIMENSION = 1600;

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read image'));
    reader.onload = () => {
      const rawDataUrl = typeof reader.result === 'string' ? reader.result : '';
      if (!rawDataUrl) return resolve('');

      const img = new window.Image();
      img.onerror = () => resolve(rawDataUrl);
      img.onload = () => {
        const { width, height } = img;
        if (width <= MAX_IMAGE_DIMENSION && height <= MAX_IMAGE_DIMENSION) {
          return resolve(rawDataUrl);
        }
        const scale = MAX_IMAGE_DIMENSION / Math.max(width, height);
        const targetW = Math.round(width * scale);
        const targetH = Math.round(height * scale);
        const canvas = document.createElement('canvas');
        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext('2d');
        if (!ctx) return resolve(rawDataUrl);
        ctx.drawImage(img, 0, 0, targetW, targetH);
        resolve(canvas.toDataURL('image/jpeg', 0.85));
      };
      img.src = rawDataUrl;
    };
    reader.readAsDataURL(file);
  });
}

export const AnswerImageGallery: React.FC<AnswerImageGalleryProps> = ({
  images,
  isSubmitted,
  onAddImages,
  onRemoveImage,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [zoomedIndex, setZoomedIndex] = useState<number | null>(null);

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    const files = Array.from(fileList).filter((f) => f.type.startsWith('image/'));
    if (files.length === 0) return;

    try {
      const results = await Promise.all(files.map(readFileAsDataUrl));
      const validUrls = results.filter(Boolean);
      if (validUrls.length > 0) onAddImages(validUrls);
    } catch {
      // Safe fallback
    } finally {
      e.target.value = '';
    }
  };

  return (
    <div className="p-4 sm:p-5 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-3">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        capture="environment"
        onChange={handleImageChange}
        className="hidden"
      />

      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-sky-500/12 text-sky-600 dark:text-cyan-400 flex items-center justify-center shrink-0">
            <Image size={15} />
          </div>
          <div>
            <h3 className="text-xs sm:text-sm font-bold text-[var(--text-primary)]">Add Answer Images</h3>
            <p className="text-[11px] text-[var(--text-muted)]">Add handwritten answer photos (No limit). Tap to zoom.</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 rounded-lg bg-[var(--bg-app)] border border-[var(--border-subtle)] text-[11px] font-mono-tabular font-semibold text-[var(--text-secondary)]">
            {images.length} {images.length === 1 ? 'Page' : 'Pages'}
          </span>
          {!isSubmitted && (
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-sky-500/12 hover:bg-sky-500/20 text-sky-600 dark:text-cyan-400 border border-sky-500/30 transition-colors"
            >
              <Camera size={13} />
              <span>Upload / Camera</span>
            </button>
          )}
        </div>
      </div>

      <div className="flex items-center gap-3 overflow-x-auto snap-x snap-mandatory scroll-smooth pb-1 pt-1">
        {!isSubmitted && (
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="snap-start w-20 h-24 sm:w-24 sm:h-28 rounded-xl border-2 border-dashed border-sky-500/50 hover:border-sky-500 bg-sky-500/8 hover:bg-sky-500/15 flex flex-col items-center justify-center gap-1.5 text-sky-600 dark:text-cyan-400 transition-all shrink-0 cursor-pointer"
          >
            <Plus size={24} />
            <span className="text-[10px] font-semibold">Add Page</span>
          </button>
        )}

        {images.map((imgUrl, idx) => (
          <div
            key={`page_${idx}`}
            onClick={() => setZoomedIndex(idx)}
            className="snap-start group relative w-20 h-24 sm:w-24 sm:h-28 rounded-xl overflow-hidden border border-[var(--border-subtle)] hover:border-sky-500 bg-[var(--bg-app)] shrink-0 cursor-pointer shadow-xs"
          >
            <img src={imgUrl} alt={`Answer Page ${idx + 1}`} className="w-full h-full object-cover" />
            <span className="absolute bottom-1.5 left-1.5 px-1.5 py-0.5 rounded-md bg-slate-950/80 text-white text-[10px] font-mono-tabular font-bold">
              P{idx + 1}
            </span>

            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); setZoomedIndex(idx); }}
              className="absolute bottom-1.5 right-1.5 p-1 rounded-md bg-slate-950/75 text-white hover:bg-sky-500 transition-colors"
              title="Zoom Page"
              aria-label={`Zoom Page ${idx + 1}`}
            >
              <ZoomIn size={12} />
            </button>

            {!isSubmitted && (
              <button
                type="button"
                onClick={(e) => { e.stopPropagation(); onRemoveImage(idx); }}
                className="absolute top-1.5 right-1.5 p-1 rounded-md bg-rose-600/90 hover:bg-rose-600 text-white shadow-xs transition-colors"
                title="Remove Page"
                aria-label={`Remove Page ${idx + 1}`}
              >
                <X size={13} />
              </button>
            )}
          </div>
        ))}
      </div>

      <ImageZoomModal
        imageUrl={zoomedIndex !== null ? images[zoomedIndex] || null : null}
        pageIndex={zoomedIndex ?? 0}
        totalPages={images.length}
        onPrevPage={() => setZoomedIndex((prev) => (prev !== null && prev > 0 ? prev - 1 : prev))}
        onNextPage={() => setZoomedIndex((prev) => (prev !== null && prev < images.length - 1 ? prev + 1 : prev))}
        onClose={() => setZoomedIndex(null)}
      />
    </div>
  );
};
