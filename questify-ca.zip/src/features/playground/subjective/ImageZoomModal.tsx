import React, { useEffect } from 'react';
import { ChevronLeft, ChevronRight, X } from '../../../ui/icons';

interface ImageZoomModalProps {
  imageUrl: string | null;
  pageIndex: number;
  totalPages: number;
  onPrevPage?: () => void;
  onNextPage?: () => void;
  onClose: () => void;
}

export const ImageZoomModal: React.FC<ImageZoomModalProps> = ({
  imageUrl,
  pageIndex,
  totalPages,
  onPrevPage,
  onNextPage,
  onClose,
}) => {
  useEffect(() => {
    if (!imageUrl) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      else if (e.key === 'ArrowLeft' && pageIndex > 0) onPrevPage?.();
      else if (e.key === 'ArrowRight' && pageIndex < totalPages - 1) onNextPage?.();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [imageUrl, pageIndex, totalPages, onPrevPage, onNextPage, onClose]);

  if (!imageUrl) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex flex-col items-center justify-center p-4 animate-in fade-in duration-150"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-5xl flex items-center justify-between gap-2 mb-3 px-2" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-2">
          <span className="px-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-700 text-xs font-mono-tabular font-semibold text-slate-100">
            Page {pageIndex + 1} of {totalPages}
          </span>
          {totalPages > 1 && (
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                disabled={pageIndex <= 0}
                onClick={() => onPrevPage?.()}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-900/90 hover:bg-slate-800 disabled:opacity-40 disabled:pointer-events-none border border-slate-700 text-slate-100 text-xs font-semibold transition-colors"
              >
                <ChevronLeft size={15} />
                <span>Prev Page</span>
              </button>
              <button
                type="button"
                disabled={pageIndex >= totalPages - 1}
                onClick={() => onNextPage?.()}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-900/90 hover:bg-slate-800 disabled:opacity-40 disabled:pointer-events-none border border-slate-700 text-slate-100 text-xs font-semibold transition-colors"
              >
                <span>Next Page</span>
                <ChevronRight size={15} />
              </button>
            </div>
          )}
        </div>
        <button
          type="button"
          onClick={onClose}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-slate-200 hover:text-white text-xs font-semibold transition-colors"
          aria-label="Close Zoom Preview"
        >
          <X size={18} />
          <span>Close</span>
        </button>
      </div>
      <img
        src={imageUrl}
        alt={`Handwritten Answer Sheet Page ${pageIndex + 1}`}
        onClick={(e) => e.stopPropagation()}
        className="max-h-[82vh] max-w-[90vw] object-contain rounded-lg shadow-2xl border border-slate-800"
      />
    </div>
  );
};
