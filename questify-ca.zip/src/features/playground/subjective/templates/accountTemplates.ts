export type AccountTemplateCategory =
  | 'Final Accounts'
  | 'Ledgers & T-Accounts'
  | 'Journal Entries'
  | 'Working Notes & Calculations';

export interface AccountTemplate {
  id: string;
  command: string;
  title: string;
  category: AccountTemplateCategory;
  description: string;
  fileName: string;
  keywords: string[];
  snippet: string;
}

export const ACCOUNT_TEMPLATE_CATEGORIES: AccountTemplateCategory[] = [
  'Final Accounts',
  'Ledgers & T-Accounts',
  'Journal Entries',
  'Working Notes & Calculations',
];

export const ACCOUNT_TEMPLATES: AccountTemplate[] = [
  {
    id: 'tpl_trading_account',
    command: '/Trading-Account',
    title: 'Trading Account (Dr./Cr.)',
    category: 'Final Accounts',
    description: 'ICAI standard horizontal Trading Account with Opening Stock, Purchases, Direct Wages, Sales & Gross Profit.',
    fileName: '01-Trading-Account-Format.txt',
    keywords: ['trading', 'gross profit', 'opening stock', 'purchases', 'sales', 'final accounts'],
    snippet: `Trading Account for the year ended [Date]:
| Particulars (Dr.) | Amount (₹) | Particulars (Cr.) | Amount (₹) |
| --- | --- | --- | --- |
| To Opening Stock | - | By Sales | - |
| To Purchases | - | Less: Returns | - |
| Less: Returns | - | By Closing Stock | - |
| To Direct Wages | - | | |
| To Gross Profit c/d | - | | |
| **Total** | **-** | **Total** | **-** |`,
  },
  {
    id: 'tpl_pnl_account',
    command: '/Profit-and-Loss-Account',
    title: 'Profit and Loss Account',
    category: 'Final Accounts',
    description: 'ICAI horizontal P&L Account for indirect expenses, provisions, depreciation, and Net Profit transfer.',
    fileName: '02-Profit-and-Loss-Account-Format.txt',
    keywords: ['profit', 'loss', 'pnl', 'provision', 'depreciation', 'net profit', 'final accounts'],
    snippet: `Profit and Loss Account for the year ended [Date]:
| Particulars (Dr.) | Amount (₹) | Particulars (Cr.) | Amount (₹) |
| --- | --- | --- | --- |
| To Salaries | - | By Gross Profit b/d | - |
| To Rent & Rates | - | By Discount Received | - |
| To Depreciation (W.N. 1) | - | By Interest on Deposits | - |
| To Provision for Bad Debts | - | | |
| To Net Profit transferred to Capital | - | | |
| **Total** | **-** | **Total** | **-** |`,
  },
  {
    id: 'tpl_balance_sheet',
    command: '/Balance-Sheet',
    title: 'Balance Sheet Statement',
    category: 'Final Accounts',
    description: 'Classified Balance Sheet with Capital adjustments, Fixed Assets less Depreciation, and Current Assets/Liabilities.',
    fileName: '03-Balance-Sheet-Format.txt',
    keywords: ['balance sheet', 'capital', 'liabilities', 'assets', 'drawings', 'final accounts'],
    snippet: `Balance Sheet as at [Date]:
| Capital & Liabilities | Amount (₹) | Assets | Amount (₹) |
| --- | --- | --- | --- |
| Capital Account | - | Fixed Assets (Machinery/Furniture) | - |
| Add: Net Profit | - | Less: Depreciation | - |
| Less: Drawings | - | Current Assets (Debtors/Stock/Bank) | - |
| Current Liabilities | - | Less: Provision for Bad Debts | - |
| **Total** | **-** | **Total** | **-** |`,
  },
  {
    id: 'tpl_ledger_account',
    command: '/Ledger-Account',
    title: 'Standard 8-Column Ledger (T-Account)',
    category: 'Ledgers & T-Accounts',
    description: 'Full 8-column Dr./Cr. Ledger Account with Date, Particulars, J.F., and Amount columns on both sides.',
    fileName: '04-Ledger-T-Account-Format.txt',
    keywords: ['ledger', 't-account', 'dr', 'cr', 'provision', 'machinery', 'account'],
    snippet: `Dr. [Account Name] Account Cr.
| Date | Particulars | J.F. | Amount (₹) | Date | Particulars | J.F. | Amount (₹) |
| --- | --- | --- | --- | --- | --- | --- | --- |
| [Date] | To Balance b/d | - | - | [Date] | By Depreciation A/c | - | - |
| [Date] | To Bank A/c | - | - | [Date] | By Balance c/d | - | - |
| | **Total** | | **-** | | **Total** | | **-** |`,
  },
  {
    id: 'tpl_journal_entry',
    command: '/Journal-Entry',
    title: 'ICAI Journal Book Entry',
    category: 'Journal Entries',
    description: '5-column Journal format with Date, Particulars, L.F., Debit (₹), Credit (₹), and narration row.',
    fileName: '05-Journal-Entry-Format.txt',
    keywords: ['journal', 'entry', 'debit', 'credit', 'narration', 'rectification'],
    snippet: `Journal Entries:
| Date | Particulars | L.F. | Debit (₹) | Credit (₹) |
| --- | --- | --- | --- | --- |
| [Date] | [Account Name] Dr. | - | - | |
| | To [Account Name] | | | - |
| | *(Being [Narration explaining entry])* | | | |`,
  },
  {
    id: 'tpl_working_note',
    command: '/Working-Note',
    title: 'Working Note Block (W.N.)',
    category: 'Working Notes & Calculations',
    description: 'Structured Working Note heading (### Working Note 1: [Title]) and calculation space inside your unified answer sheet.',
    fileName: '06-Working-Note-Format.txt',
    keywords: ['working-note', 'working note', 'wn', 'calculation', 'adjustment', 'schedule'],
    snippet: `### Working Note 1: [Title]
Calculation:
`,
  },
];

export function filterAccountTemplates(query: string): AccountTemplate[] {
  const clean = query.replace(/^\//, '').trim().toLowerCase();
  if (!clean) return ACCOUNT_TEMPLATES;
  return ACCOUNT_TEMPLATES.filter(
    (tpl) =>
      tpl.command.toLowerCase().includes(clean) ||
      tpl.title.toLowerCase().includes(clean) ||
      tpl.keywords.some((k) => k.toLowerCase().includes(clean))
  );
}
