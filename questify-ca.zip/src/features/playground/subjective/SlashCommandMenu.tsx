import React, { useEffect, useRef } from 'react';
import { Icon } from '../../../ui/icons';
import { AccountDefinition, filterAccountDefinitions } from '../accounts/accountDefinitions';

export interface SlashTriggerState {
  active: boolean;
  query: string;
  triggerIndex: number;
  cursorIndex: number;
}

export function detectSlashTrigger(text: string, cursorIndex: number): SlashTriggerState {
  const beforeCursor = text.slice(0, cursorIndex);
  const lastSlash = beforeCursor.lastIndexOf('/');
  if (lastSlash === -1) {
    return { active: false, query: '', triggerIndex: -1, cursorIndex };
  }
  const prevChar = lastSlash > 0 ? beforeCursor[lastSlash - 1] : '\n';
  if (prevChar !== '\n' && prevChar !== ' ' && prevChar !== '\t') {
    return { active: false, query: '', triggerIndex: -1, cursorIndex };
  }
  const candidate = beforeCursor.slice(lastSlash + 1);
  if (/[\s\n|]/.test(candidate) || candidate.length > 34) {
    return { active: false, query: '', triggerIndex: -1, cursorIndex };
  }
  return {
    active: true,
    query: candidate,
    triggerIndex: lastSlash,
    cursorIndex,
  };
}

interface SlashCommandMenuProps {
  isOpen: boolean;
  query: string;
  selectedIndex: number;
  onSelectDefinition: (def: AccountDefinition) => void;
  onClose: () => void;
}

export const SlashCommandMenu: React.FC<SlashCommandMenuProps> = ({
  isOpen,
  query,
  selectedIndex,
  onSelectDefinition,
  onClose,
}) => {
  const activeItemRef = useRef<HTMLButtonElement | null>(null);
  const matches = isOpen ? filterAccountDefinitions(query) : [];
  const activeIdx = matches.length > 0 ? selectedIndex % matches.length : 0;

  useEffect(() => {
    if (!isOpen || !activeItemRef.current) return;
    activeItemRef.current.scrollIntoView({ block: 'nearest' });
  }, [activeIdx, isOpen, matches.length]);

  if (!isOpen) return null;

  return (
    <div
      role="listbox"
      aria-label="Interactive Accounting Formats"
      className="absolute left-3 top-14 z-40 w-[calc(100%-1.5rem)] sm:w-[420px] rounded-xl border border-indigo-200 dark:border-indigo-800/80 bg-white dark:bg-slate-900 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-100"
    >
      <div className="px-3 py-1.5 bg-indigo-50/90 dark:bg-indigo-950/70 border-b border-indigo-100 dark:border-indigo-900/60 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-indigo-700 dark:text-indigo-300">
          <Icon name="table" size={12} />
          <span>Insert Interactive Account Card ({matches.length})</span>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="text-[10px] font-mono-tabular px-1.5 py-0.5 rounded bg-white/80 dark:bg-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 border border-slate-200 dark:border-slate-700"
        >
          ESC
        </button>
      </div>

      {matches.length === 0 ? (
        <div className="px-3.5 py-3 text-xs text-slate-500 dark:text-slate-400">
          No interactive format matching <span className="font-mono font-semibold">/{query}</span>. Keep typing or press Esc.
        </div>
      ) : (
        <div className="max-h-52 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
          {matches.map((def, idx) => {
            const isSelected = idx === activeIdx;
            return (
              <button
                key={def.id}
                ref={isSelected ? activeItemRef : null}
                type="button"
                onMouseDown={(e) => {
                  e.preventDefault();
                  onSelectDefinition(def);
                }}
                className={`w-full px-3.5 py-2 text-left flex items-start justify-between gap-2 transition-colors ${
                  isSelected
                    ? 'bg-indigo-600/12 dark:bg-indigo-500/25 text-indigo-700 dark:text-indigo-200'
                    : 'hover:bg-slate-50 dark:hover:bg-slate-800/70 text-slate-800 dark:text-slate-200'
                }`}
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono-tabular font-bold text-indigo-600 dark:text-indigo-400">
                      {def.command}
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 font-medium">
                      {def.category}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400 truncate mt-0.5">
                    {def.title} — {def.description}
                  </p>
                </div>
                <span className="text-[10px] font-mono-tabular text-slate-400 dark:text-slate-500 shrink-0 self-center">
                  Enter
                </span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};
