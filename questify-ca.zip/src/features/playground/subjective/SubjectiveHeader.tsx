import React from 'react';
import { formatDurationMMSS } from '../mcq/TimerPill';
import { ArrowLeft, CheckCircle2, FileText, Icon, Pause, Play, RotateCcw, Timer } from '../../../ui/icons';

interface SubjectiveHeaderProps {
  title: string;
  elapsedSeconds: number;
  isPaused: boolean;
  isSubmitted: boolean;
  isCalculatorOpen: boolean;
  onBackToExplorer: () => void;
  onTogglePause: () => void;
  onToggleCalculator: () => void;
  onOpenExport: () => void;
  onOpenModelAnswer: () => void;
  onToggleSubmitted: () => void;
}

export const SubjectiveHeader: React.FC<SubjectiveHeaderProps> = ({
  title,
  elapsedSeconds,
  isPaused,
  isSubmitted,
  isCalculatorOpen,
  onBackToExplorer,
  onTogglePause,
  onToggleCalculator,
  onOpenExport,
  onOpenModelAnswer,
  onToggleSubmitted,
}) => {
  return (
    <header className="h-14 flex-shrink-0 px-3 sm:px-6 flex items-center justify-between gap-2 border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 backdrop-blur z-20 no-select">
      <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
        <button
          type="button"
          onClick={onBackToExplorer}
          title="Back to Explorer"
          aria-label="Back to Explorer"
          className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-slate-400 text-slate-800 dark:text-slate-200 transition-colors shrink-0"
        >
          <ArrowLeft size={15} />
          <span className="hidden md:inline">Explorer</span>
        </button>
        <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
          <FileText size={16} className="text-sky-500 dark:text-cyan-400 shrink-0" />
          <span className="text-xs sm:text-sm font-bold text-slate-900 dark:text-slate-100 truncate">
            {title}
          </span>
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <button
          type="button"
          onClick={onTogglePause}
          title="Toggle Timer"
          aria-label="Toggle Timer"
          className="flex lg:hidden items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-mono-tabular font-bold bg-sky-500/12 text-sky-600 dark:text-cyan-300 border border-sky-500/30"
        >
          <Timer size={13} />
          <span>{formatDurationMMSS(elapsedSeconds)}</span>
          {!isSubmitted && (isPaused ? <Play size={11} /> : <Pause size={11} />)}
        </button>

        <button
          type="button"
          onClick={onToggleCalculator}
          className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors shadow-xs ${
            isCalculatorOpen
              ? 'text-indigo-600 bg-indigo-50 dark:bg-indigo-900/40 border-indigo-200 dark:border-indigo-700'
              : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:bg-slate-200/70'
          }`}
          title="Calculator"
          aria-label="Calculator"
        >
          <Icon name="calculator" size={14} />
          <span className="hidden md:inline">Calculator</span>
        </button>

        <button
          type="button"
          onClick={onOpenModelAnswer}
          title="Model Answer"
          aria-label="Model Answer"
          className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 transition-colors shadow-xs"
        >
          <Icon name="lightbulb" size={14} />
          <span className="hidden md:inline">Solution</span>
        </button>

        <button
          type="button"
          onClick={onOpenExport}
          className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:bg-slate-200/70 transition-colors"
          title="Export Question & Answer"
          aria-label="Export"
        >
          <Icon name="share-2" size={14} />
          <span className="hidden sm:inline">Export</span>
        </button>

        <button
          type="button"
          onClick={onToggleSubmitted}
          title={isSubmitted ? 'Resume Editing' : 'Mark Completed'}
          aria-label={isSubmitted ? 'Resume Editing' : 'Mark Completed'}
          className={`flex items-center gap-1.5 px-2.5 sm:px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
            isSubmitted
              ? 'bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200'
              : 'bg-emerald-600 hover:bg-emerald-700 text-white'
          }`}
        >
          {isSubmitted ? <RotateCcw size={14} /> : <CheckCircle2 size={14} />}
          <span className="hidden md:inline">{isSubmitted ? 'Resume' : 'Complete'}</span>
        </button>
      </div>
    </header>
  );
};
