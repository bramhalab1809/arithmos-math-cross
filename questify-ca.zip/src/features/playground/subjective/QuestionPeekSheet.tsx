import React, { useEffect, useState } from 'react';
import { Icon } from '../../../ui/icons';
import { RichContentRenderer } from '../../../ui/table/RichContentRenderer';
import { QuestionItem } from '../../explorer/engine/vfsTypes';

export type PeekDisplayMode = 'split' | 'floating';

export function getUnifiedQuestionStatement(question: QuestionItem): string {
  const parts: string[] = [];
  if (question.caseStudy && question.caseStudy.trim()) {
    parts.push(question.caseStudy.trim());
  }
  const main = (question.question || question.statement || question.requirement || '').trim();
  if (main && !parts.includes(main)) {
    parts.push(main);
  }
  return parts.join('\n\n');
}

interface QuestionPeekSheetProps {
  isOpen: boolean;
  question: QuestionItem;
  questionNumber: number;
  displayMode: PeekDisplayMode;
  onChangeDisplayMode: (mode: PeekDisplayMode) => void;
  onClose: () => void;
}

export const QuestionPeekSheet: React.FC<QuestionPeekSheetProps> = ({
  isOpen,
  question,
  questionNumber,
  displayMode,
  onChangeDisplayMode,
  onClose,
}) => {
  const [pos, setPos] = useState({ x: 64, y: 84 });
  const [dragging, setDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (!dragging) return;
    const handleMouseMove = (e: MouseEvent) => {
      const nextX = Math.max(12, Math.min(window.innerWidth - 320, e.clientX - dragOffset.x));
      const nextY = Math.max(12, Math.min(window.innerHeight - 140, e.clientY - dragOffset.y));
      setPos({ x: nextX, y: nextY });
    };
    const handleMouseUp = () => setDragging(false);

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [dragging, dragOffset]);

  if (!isOpen) return null;

  const unifiedText = getUnifiedQuestionStatement(question);

  const renderModeButtons = () => (
    <div className="flex items-center gap-1 shrink-0">
      <button
        type="button"
        onClick={() => onChangeDisplayMode('split')}
        className={`px-2 py-1 rounded-lg text-[11px] font-semibold flex items-center gap-1 border transition-colors ${
          displayMode === 'split'
            ? 'bg-indigo-600 text-white border-indigo-600'
            : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:border-indigo-400'
        }`}
        title="Side-by-Side 50/50 Split View"
      >
        <Icon name="split" size={12} />
        <span>Split 50/50</span>
      </button>
      <button
        type="button"
        onClick={() => onChangeDisplayMode('floating')}
        className={`px-2 py-1 rounded-lg text-[11px] font-semibold flex items-center gap-1 border transition-colors ${
          displayMode === 'floating'
            ? 'bg-indigo-600 text-white border-indigo-600'
            : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:border-indigo-400'
        }`}
        title="Draggable Floating Question Sheet"
      >
        <Icon name="maximize-2" size={12} />
        <span>Float Sheet</span>
      </button>
      <button
        type="button"
        onClick={onClose}
        className="p-1 rounded-lg text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800"
        title="Hide Question Statement"
        aria-label="Hide Question Statement"
      >
        <Icon name="x" size={14} />
      </button>
    </div>
  );

  if (displayMode === 'floating') {
    return (
      <div
        style={{ left: pos.x, top: pos.y }}
        className="fixed z-40 w-[92vw] max-w-xl rounded-2xl bg-white dark:bg-slate-900 border-2 border-indigo-500/40 shadow-2xl overflow-hidden animate-in fade-in duration-150"
      >
        <div
          onMouseDown={(e) => {
            setDragging(true);
            setDragOffset({ x: e.clientX - pos.x, y: e.clientY - pos.y });
          }}
          className="px-3.5 py-2.5 bg-indigo-50/90 dark:bg-slate-800 border-b border-indigo-200/70 dark:border-slate-700 flex items-center justify-between gap-2 cursor-move select-none"
        >
          <div className="flex items-center gap-2 min-w-0">
            <Icon name="grip-vertical" size={14} className="text-indigo-500 shrink-0" />
            <span className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
              Q{questionNumber}. {question.topic || 'Question Statement'}
            </span>
          </div>
          {renderModeButtons()}
        </div>

        <div className="p-4 sm:p-5 max-h-[68dvh] overflow-y-auto text-xs sm:text-sm text-slate-900 dark:text-slate-100 leading-relaxed select-text">
          <RichContentRenderer text={unifiedText} table={question.table} tables={question.tables} />
        </div>
      </div>
    );
  }

  return (
    <div className="w-full lg:w-1/2 h-full max-h-[42dvh] lg:max-h-full flex flex-col rounded-xl border border-indigo-200 dark:border-indigo-800/70 bg-slate-50/90 dark:bg-slate-900/90 overflow-hidden shrink-0">
      <div className="px-3.5 py-2 border-b border-indigo-200/70 dark:border-slate-800 bg-indigo-50/60 dark:bg-slate-800/80 flex items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <Icon name="eye" size={13} className="text-indigo-600 dark:text-indigo-400 shrink-0" />
          <span className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
            Q{questionNumber}. {question.topic || 'Question Statement'}
          </span>
        </div>
        {renderModeButtons()}
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto p-4 sm:p-5 text-xs sm:text-sm text-slate-900 dark:text-slate-100 leading-relaxed">
        <RichContentRenderer text={unifiedText} table={question.table} tables={question.tables} />
      </div>
    </div>
  );
};
