import React, { useEffect, useRef, useState } from 'react';
import { Icon } from '../../../ui/icons';
import { BlockWorkspace, makeTextBlock } from '../accounts/BlockWorkspace';
import { AccountDefinition, WorkspaceBlock, createAccountCardFromDef } from '../accounts/accountDefinitions';
import { LawAnswerWriter } from '../law/LawAnswerWriter';
import { FormatsDrawer } from './FormatsDrawer';

export interface SavedDigitalAnswer {
  blocks: WorkspaceBlock[];
  mainText: string;
  updatedAt: number;
}

export function getSavedAnswerKey(bankId: string, questionId: string): string {
  return `saved_answer_${bankId}_${questionId}`;
}

export function hasSavedBlocksContent(blocks: WorkspaceBlock[]): boolean {
  return blocks.some((b) =>
    b.type === 'text'
      ? b.content.trim().length > 0
      : b.data.leftRows.some((r) => r.amount.trim().length > 0) || (b.data.rightRows || []).some((r) => r.amount.trim().length > 0)
  );
}

export function loadSavedDigitalAnswer(bankId: string, questionId: string): SavedDigitalAnswer {
  try {
    const raw = localStorage.getItem(getSavedAnswerKey(bankId, questionId));
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed.blocks) && parsed.blocks.length > 0) {
        return { blocks: parsed.blocks, mainText: typeof parsed.mainText === 'string' ? parsed.mainText : '', updatedAt: typeof parsed.updatedAt === 'number' ? parsed.updatedAt : Date.now() };
      }
      const legacyText = typeof parsed.mainText === 'string' ? parsed.mainText : '';
      return { blocks: [makeTextBlock(legacyText)], mainText: legacyText, updatedAt: typeof parsed.updatedAt === 'number' ? parsed.updatedAt : Date.now() };
    }
  } catch { /* Ignore */ }
  return { blocks: [makeTextBlock('')], mainText: '', updatedAt: Date.now() };
}

interface DigitalAnswerWriterProps {
  bankId: string;
  questionId: string;
  isLawSubject?: boolean;
  isSubmitted: boolean;
  isQuestionPeekOpen: boolean;
  onToggleQuestionPeek: () => void;
  onAnswerStatusChange?: (hasContent: boolean) => void;
}

export const DigitalAnswerWriter: React.FC<DigitalAnswerWriterProps> = ({
  bankId, questionId, isLawSubject = false, isSubmitted, isQuestionPeekOpen, onToggleQuestionPeek, onAnswerStatusChange,
}) => {
  const [blocks, setBlocks] = useState<WorkspaceBlock[]>(() => [makeTextBlock('')]);
  const [isFormatsOpen, setIsFormatsOpen] = useState<boolean>(false);
  const statusCallbackRef = useRef(onAnswerStatusChange);
  statusCallbackRef.current = onAnswerStatusChange;

  useEffect(() => {
    if (!isLawSubject) setBlocks(loadSavedDigitalAnswer(bankId, questionId).blocks);
  }, [bankId, isLawSubject, questionId]);

  useEffect(() => {
    if (isLawSubject) return;
    const combinedText = blocks.map((b) => (b.type === 'text' ? b.content : b.data.title)).join('\n').trim();
    try { localStorage.setItem(getSavedAnswerKey(bankId, questionId), JSON.stringify({ blocks, mainText: combinedText, updatedAt: Date.now() })); } catch { /* Ignore */ }
    statusCallbackRef.current?.(hasSavedBlocksContent(blocks));
  }, [bankId, blocks, isLawSubject, questionId]);

  const textSummary = blocks
    .filter((b): b is { id: string; type: 'text'; content: string } => b.type === 'text')
    .map((b) => b.content)
    .join(' ')
    .trim();
  const wordCount = textSummary ? textSummary.split(/\s+/).length : 0;
  const accountCardCount = blocks.filter((b) => b.type === 'account').length;

  const wnCount = blocks.reduce((acc, b) => {
    if (b.type !== 'text') return acc;
    const m = b.content.match(/Working Note\s+\d+/gi);
    return acc + (m ? m.length : 0);
  }, 0);
  const nextWnNum = wnCount + 1;

  const handleAddWorkingNote = () => {
    if (isSubmitted) return;
    const heading = `Working Note ${nextWnNum} (W.N. ${nextWnNum}): `;
    setBlocks((prev) => {
      const last = prev[prev.length - 1];
      if (last && last.type === 'text' && !last.content.trim()) {
        return prev.map((b, i) => (i === prev.length - 1 ? { ...b, content: heading } : b));
      }
      return [...prev, makeTextBlock(heading)];
    });
  };

  const handleInsertFromDrawer = (def: AccountDefinition) => {
    if (def.isWorkingNoteText) {
      handleAddWorkingNote();
      return;
    }
    const cardBlock: WorkspaceBlock = {
      id: `blk_acc_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      type: 'account',
      data: createAccountCardFromDef(def),
    };
    setBlocks((prev) => [...prev, cardBlock, makeTextBlock('')]);
  };

  if (isLawSubject) {
    return (
      <div className="flex-1 min-h-0 h-full flex flex-col rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-xs overflow-hidden">
        <LawAnswerWriter
          bankId={bankId}
          questionId={questionId}
          disabled={isSubmitted}
          isQuestionPeekOpen={isQuestionPeekOpen}
          onToggleQuestionPeek={onToggleQuestionPeek}
          onStatusChange={onAnswerStatusChange}
        />
      </div>
    );
  }

  return (
    <div className="flex-1 min-h-0 h-full flex flex-col rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-xs overflow-hidden">
      <div className="px-3.5 py-2 border-b border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-800/80 flex flex-wrap items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            type="button"
            onClick={onToggleQuestionPeek}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold border flex items-center gap-1.5 transition-colors ${
              isQuestionPeekOpen
                ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-300 border-indigo-200 dark:border-indigo-700'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
            }`}
            title="View Question"
          >
            <Icon name="eye" size={13} />
            <span>Question</span>
          </button>

          <span className="h-4 w-px bg-slate-200 dark:bg-slate-700 mx-0.5" />

          <button
            type="button"
            disabled={isSubmitted}
            onClick={() => setIsFormatsOpen(true)}
            className="px-2.5 py-1 rounded-lg text-xs font-semibold border border-indigo-200 dark:border-indigo-700 bg-indigo-50 dark:bg-indigo-950/50 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-300 flex items-center gap-1.5 transition-colors disabled:opacity-40"
            title="Open Standard Account Formats Drawer (or type / in sheet)"
          >
            <Icon name="table" size={13} />
            <span>Formats</span>
          </button>

          <button
            type="button"
            disabled={isSubmitted}
            onClick={handleAddWorkingNote}
            className="px-2.5 py-1 rounded-lg text-xs font-semibold border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center gap-1 transition-colors disabled:opacity-40"
            title={`Add Working Note ${nextWnNum} (W.N.${nextWnNum})`}
          >
            <Icon name="plus" size={13} />
            <Icon name="bookmark" size={12} className="text-indigo-500" />
            <span className="text-[11px] font-mono-tabular">W.N.{nextWnNum}</span>
          </button>
        </div>

        <span className="text-[11px] font-mono-tabular text-slate-500 dark:text-slate-400">
          {accountCardCount} acc &middot; {wordCount} words
        </span>
      </div>

      <BlockWorkspace
        blocks={blocks}
        disabled={isSubmitted}
        onChangeBlocks={setBlocks}
        onOpenFormatsDrawer={() => setIsFormatsOpen(true)}
      />

      <FormatsDrawer
        isOpen={isFormatsOpen}
        onClose={() => setIsFormatsOpen(false)}
        onInsertDefinition={handleInsertFromDrawer}
      />
    </div>
  );
};
