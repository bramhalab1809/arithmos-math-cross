import React, { useState, useRef, useEffect } from 'react';
import { Icon } from '../../../ui/icons';
import { WorkingNoteColor, WorkingNoteRef } from './accountDefinitions';

export const WN_COLOR_HEX: Record<WorkingNoteColor, string> = {
  blue: '#0ea5e9',
  red: '#e11d48',
  green: '#10b981',
  orange: '#f59e0b',
  purple: '#8b5cf6',
  yellow: '#eab308',
  pink: '#ec4899',
  teal: '#06b6d4',
  indigo: '#6366f1',
  lime: '#84cc16',
};

const COLOR_KEYS = Object.keys(WN_COLOR_HEX) as WorkingNoteColor[];
const QUICK_TAGS = ['W.N. 1', 'W.N. 2', 'W.N. 3', 'W.N. 4', 'W.N. 5'];

interface WorkingNoteTagPickerProps {
  value?: WorkingNoteRef;
  disabled?: boolean;
  onChange: (nextRef?: WorkingNoteRef) => void;
  onJumpToWorkingNote?: (ref: WorkingNoteRef) => void;
}

export const WorkingNoteTagPicker: React.FC<WorkingNoteTagPickerProps> = ({
  value,
  disabled = false,
  onChange,
  onJumpToWorkingNote,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [draftLabel, setDraftLabel] = useState(value?.label || 'W.N. 1');
  const [draftColor, setDraftColor] = useState<WorkingNoteColor>(value?.color || 'indigo');
  const [coords, setCoords] = useState<{ top: number; left: number }>({ top: 100, left: 100 });
  const containerRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    setDraftLabel(value?.label || 'W.N. 1');
    setDraftColor(value?.color || 'indigo');
  }, [value?.label, value?.color]);

  useEffect(() => {
    if (!isOpen) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    window.addEventListener('mousedown', handleClickOutside);
    return () => window.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  const handleToggle = () => {
    if (disabled) {
      if (value && onJumpToWorkingNote) onJumpToWorkingNote(value);
      return;
    }
    if (!isOpen && buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      const popWidth = 228;
      const popHeight = 205;
      const clampedLeft = Math.max(12, Math.min(window.innerWidth - popWidth - 12, rect.left));
      const clampedTop =
        rect.bottom + popHeight + 12 > window.innerHeight
          ? Math.max(12, rect.top - popHeight - 6)
          : rect.bottom + 6;
      setCoords({ top: clampedTop, left: clampedLeft });
    }
    setIsOpen((p) => !p);
  };

  const applyTag = (nextLabel: string, nextColor: WorkingNoteColor) => {
    const clean = nextLabel.trim();
    if (!clean) {
      onChange(undefined);
      setIsOpen(false);
      return;
    }
    setDraftLabel(clean);
    setDraftColor(nextColor);
    onChange({
      id: value?.id || `wn_${Date.now()}`,
      label: clean,
      color: nextColor,
    });
    setIsOpen(false);
  };

  const clearTag = (e: React.MouseEvent) => {
    e.stopPropagation();
    onChange(undefined);
    setIsOpen(false);
  };

  const activeHex = value ? WN_COLOR_HEX[value.color] || '#6366f1' : '#6366f1';

  return (
    <div ref={containerRef} className="relative inline-flex items-center shrink-0">
      {value ? (
        <button
          ref={buttonRef}
          type="button"
          onClick={handleToggle}
          style={{
            backgroundColor: `${activeHex}22`,
            color: activeHex,
            borderColor: `${activeHex}55`,
          }}
          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10px] font-mono-tabular font-bold tracking-tight transition-transform hover:scale-105"
          title="Edit Working Note Tag"
        >
          <span>{value.label}</span>
          {!disabled && (
            <span
              onClick={clearTag}
              className="ml-0.5 hover:opacity-75 flex items-center"
              title="Remove Tag"
            >
              <Icon name="x" size={10} />
            </span>
          )}
        </button>
      ) : (
        !disabled && (
          <button
            ref={buttonRef}
            type="button"
            onClick={handleToggle}
            className="p-1 rounded-md text-slate-400 opacity-50 hover:opacity-100 hover:text-indigo-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all"
            title="Attach Working Note Tag (W.N.)"
          >
            <Icon name="bookmark" size={12} />
          </button>
        )
      )}

      {isOpen && !disabled && (
        <div
          style={{ position: 'fixed', top: coords.top, left: coords.left }}
          className="z-[80] w-56 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-2xl p-3 space-y-2.5 animate-in fade-in zoom-in-95 duration-100"
        >
          <div className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
            Quick Tag Pills
          </div>
          <div className="flex flex-wrap gap-1">
            {QUICK_TAGS.map((tag) => (
              <button
                key={tag}
                type="button"
                onClick={() => applyTag(tag, draftColor)}
                className={`px-2 py-1 rounded-md text-[10px] font-mono-tabular font-bold border transition-all ${
                  draftLabel === tag
                    ? 'bg-indigo-600 text-white border-indigo-600'
                    : 'bg-[var(--bg-app)] text-[var(--text-primary)] border-[var(--border-subtle)] hover:border-indigo-500'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1.5">
            <input
              type="text"
              value={draftLabel}
              onChange={(e) => setDraftLabel(e.target.value)}
              placeholder="Custom (e.g. W.N. 6)"
              className="flex-1 min-w-0 px-2 py-1 rounded-lg bg-[var(--bg-app)] border border-[var(--border-subtle)] text-[11px] font-mono-tabular text-[var(--text-primary)] focus:outline-none focus:border-indigo-500"
            />
            <button
              type="button"
              onClick={() => applyTag(draftLabel, draftColor)}
              className="px-2.5 py-1 rounded-lg bg-indigo-600 text-white text-[11px] font-semibold"
            >
              Save
            </button>
          </div>

          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)] mb-1.5">
              10 Ribbon Colors
            </div>
            <div className="flex items-center justify-between gap-1">
              {COLOR_KEYS.map((colorKey) => {
                const hex = WN_COLOR_HEX[colorKey];
                return (
                  <button
                    key={colorKey}
                    type="button"
                    onClick={() => {
                      setDraftColor(colorKey);
                      if (value) applyTag(draftLabel, colorKey);
                    }}
                    style={{ backgroundColor: hex }}
                    className={`w-4 h-4 rounded-full transition-transform shrink-0 ${
                      draftColor === colorKey
                        ? 'ring-2 ring-offset-1 ring-slate-900 dark:ring-white scale-110'
                        : 'hover:scale-110'
                    }`}
                  />
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
