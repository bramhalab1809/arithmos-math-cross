import React, { useState } from 'react';
import { Icon } from '../../../ui/icons';
import { AccountRowItem } from './AccountRowItem';
import {
  AccountCardData,
  AccountRow,
  WorkingNoteRef,
  formatInrAmount,
  makeRow,
  sumAccountRows,
} from './accountDefinitions';

interface InteractiveAccountCardProps {
  card: AccountCardData;
  disabled?: boolean;
  canMoveUp?: boolean;
  canMoveDown?: boolean;
  onChangeCard: (updated: AccountCardData) => void;
  onDeleteCard: () => void;
  onMoveUp?: () => void;
  onMoveDown?: () => void;
  onJumpToWorkingNote?: (ref: WorkingNoteRef) => void;
}

export const InteractiveAccountCard: React.FC<InteractiveAccountCardProps> = ({
  card,
  disabled = false,
  canMoveUp = false,
  canMoveDown = false,
  onChangeCard,
  onDeleteCard,
  onMoveUp,
  onMoveDown,
  onJumpToWorkingNote,
}) => {
  const [dragSource, setDragSource] = useState<{ side: 'left' | 'right'; index: number } | null>(null);
  const isTwoSided = Array.isArray(card.rightRows);
  const leftTotal = sumAccountRows(card.leftRows);
  const rightTotal = sumAccountRows(card.rightRows);
  const diff = Math.abs(leftTotal - rightTotal);
  const isTallied = isTwoSided && Math.abs(leftTotal - rightTotal) < 0.01;

  const updateSideRows = (side: 'left' | 'right', nextRows: AccountRow[]) => {
    if (side === 'left') onChangeCard({ ...card, leftRows: nextRows });
    else onChangeCard({ ...card, rightRows: nextRows });
  };

  const handleRowChange = (side: 'left' | 'right', rowId: string, patch: Partial<AccountRow>) => {
    const rows = side === 'left' ? card.leftRows : card.rightRows || [];
    updateSideRows(
      side,
      rows.map((r) => (r.id === rowId ? { ...r, ...patch } : r))
    );
  };

  const handleDeleteRow = (side: 'left' | 'right', rowId: string) => {
    const rows = side === 'left' ? card.leftRows : card.rightRows || [];
    if (rows.length <= 1) return;
    updateSideRows(
      side,
      rows.filter((r) => r.id !== rowId)
    );
  };

  const handleAddRow = (side: 'left' | 'right') => {
    const rows = side === 'left' ? card.leftRows : card.rightRows || [];
    const prefix = isTwoSided ? (side === 'left' ? 'To ' : 'By ') : '';
    updateSideRows(side, [...rows, makeRow(prefix, '')]);
  };

  const handleAutoBalance = () => {
    if (!isTwoSided || disabled || diff < 0.01) return;
    if (leftTotal > rightTotal) {
      const nextRight = [...(card.rightRows || []), makeRow('By Balance c/d (Balancing Figure)', String(diff))];
      onChangeCard({ ...card, rightRows: nextRight });
    } else {
      const nextLeft = [...card.leftRows, makeRow('To Balance c/d (Balancing Figure)', String(diff))];
      onChangeCard({ ...card, leftRows: nextLeft });
    }
  };

  const handleDropRow = (side: 'left' | 'right', targetIndex: number) => {
    if (!dragSource || dragSource.side !== side) return;
    const rows = [...(side === 'left' ? card.leftRows : card.rightRows || [])];
    const [moved] = rows.splice(dragSource.index, 1);
    rows.splice(targetIndex, 0, moved);
    updateSideRows(side, rows);
    setDragSource(null);
  };

  const renderColumn = (side: 'left' | 'right', headerTitle: string, rows: AccountRow[]) => (
    <div className="flex-1 min-w-0 flex flex-col justify-between p-2 sm:p-2.5 space-y-2">
      <div className="space-y-1.5">
        <div className="flex items-center justify-between px-2 py-1 rounded-md bg-slate-100/80 dark:bg-slate-800/80 text-[10px] font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300">
          <span>{headerTitle}</span>
          <span>Amount (Rs.)</span>
        </div>
        <div className="space-y-1">
          {rows.map((row, idx) => (
            <AccountRowItem
              key={row.id}
              row={row}
              index={idx}
              side={side}
              disabled={disabled}
              onChangeRow={(rowId, patch) => handleRowChange(side, rowId, patch)}
              onDeleteRow={(rowId) => handleDeleteRow(side, rowId)}
              onDragStartRow={(s, i) => setDragSource({ side: s, index: i })}
              onDropOnRow={handleDropRow}
              onJumpToWorkingNote={onJumpToWorkingNote}
            />
          ))}
        </div>
      </div>

      {!disabled && (
        <button
          type="button"
          onClick={() => handleAddRow(side)}
          className="w-full py-1.5 rounded-lg border border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 text-[11px] font-semibold text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 flex items-center justify-center gap-1 transition-colors"
        >
          <Icon name="plus" size={12} />
          <span>Add Row</span>
        </button>
      )}
    </div>
  );

  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-xs overflow-visible">
      <div className="px-3.5 py-2 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 rounded-t-xl flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0 flex-1">
          <button
            type="button"
            onClick={() => onChangeCard({ ...card, isOpen: !card.isOpen })}
            className="p-1 rounded-lg text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
          >
            <Icon name={card.isOpen ? 'chevron-down' : 'chevron-right'} size={14} />
          </button>
          <input
            type="text"
            disabled={disabled}
            value={card.title}
            onChange={(e) => onChangeCard({ ...card, title: e.target.value })}
            className="w-full bg-transparent text-xs sm:text-sm font-bold text-slate-900 dark:text-slate-100 focus:outline-none border-b border-transparent focus:border-indigo-500"
          />
        </div>

        {!disabled && (
          <div className="flex items-center gap-1 shrink-0">
            {isTwoSided && diff >= 0.01 && (
              <button
                type="button"
                onClick={handleAutoBalance}
                className="px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-600 dark:text-amber-400 text-[10px] font-bold hover:bg-amber-500/25"
                title="Insert Balancing Figure Row"
              >
                Balance
              </button>
            )}
            {canMoveUp && onMoveUp && (
              <button type="button" onClick={onMoveUp} className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200" title="Move Up">
                <Icon name="arrow-up" size={13} />
              </button>
            )}
            {canMoveDown && onMoveDown && (
              <button type="button" onClick={onMoveDown} className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200" title="Move Down">
                <Icon name="arrow-down" size={13} />
              </button>
            )}
            <button type="button" onClick={onDeleteCard} className="p-1 text-slate-400 hover:text-rose-500" title="Delete Account Card">
              <Icon name="trash-2" size={13} />
            </button>
          </div>
        )}
      </div>

      {card.isOpen && (
        <>
          <div className="flex flex-col lg:flex-row divide-y lg:divide-y-0 lg:divide-x divide-slate-200 dark:divide-slate-700">
            {renderColumn('left', card.leftTitle, card.leftRows)}
            {isTwoSided && renderColumn('right', card.rightTitle || 'Particulars (Cr.)', card.rightRows || [])}
          </div>

          <div className="px-3.5 py-2 bg-slate-50/90 dark:bg-slate-800/70 border-t border-slate-200 dark:border-slate-700 rounded-b-xl flex flex-wrap items-center justify-between gap-2 text-xs font-mono-tabular">
            <div>
              <span className="text-slate-500 mr-1.5">Total:</span>
              <span className="font-bold text-slate-900 dark:text-slate-100 border-b-4 border-double border-slate-800 dark:border-slate-200 px-1">
                Rs. {formatInrAmount(leftTotal)}
              </span>
            </div>

            {isTwoSided && (
              <>
                <div>
                  {leftTotal === 0 && rightTotal === 0 ? (
                    <span className="text-[11px] text-slate-400">Enter amounts</span>
                  ) : isTallied ? (
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold">
                      Tallied
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-600 dark:text-amber-400 text-[10px] font-bold">
                      Diff: Rs. {formatInrAmount(diff)}
                    </span>
                  )}
                </div>
                <div>
                  <span className="text-slate-500 mr-1.5">Total:</span>
                  <span className="font-bold text-slate-900 dark:text-slate-100 border-b-4 border-double border-slate-800 dark:border-slate-200 px-1">
                    Rs. {formatInrAmount(rightTotal)}
                  </span>
                </div>
              </>
            )}
          </div>
        </>
      )}
    </div>
  );
};
