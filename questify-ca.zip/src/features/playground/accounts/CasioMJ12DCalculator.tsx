import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Icon } from '../../../ui/icons';

interface CasioMJ12DCalculatorProps { isOpen?: boolean; onClose: () => void; }

function evalLeftToRight(tokens: string[]): number {
  let acc = parseFloat(tokens[0]) || 0;
  for (let i = 1; i < tokens.length; i += 2) {
    const op = tokens[i], nextRaw = tokens[i + 1];
    if (!nextRaw) break;
    const v = parseFloat(nextRaw) || 0;
    acc = op === '+' ? acc + v : op === '-' ? acc - v : op === '*' ? acc * v : op === '/' ? (v !== 0 ? acc / v : 0) : acc;
  }
  return Number.isFinite(acc) ? Number(acc.toFixed(4)) : 0;
}

function fmtNum(val: string | number, indianComma: boolean, apostrophe = false): string {
  const num = typeof val === 'number' ? val : parseFloat(val);
  if (!Number.isFinite(num)) return '0';
  const base = typeof val === 'string' && val.endsWith('.') ? `${num.toLocaleString(indianComma ? 'en-IN' : 'en-US')}.` : num.toLocaleString(indianComma ? 'en-IN' : 'en-US', { maximumFractionDigits: 4 });
  return apostrophe ? base.replace(/,/g, "'") : base;
}

export const CasioMJ12DCalculator: React.FC<CasioMJ12DCalculatorProps> = ({ isOpen = true, onClose }) => {
  const [tokens, setTokens] = useState<string[]>([]);
  const [curInput, setCurInput] = useState<string>('0');
  const [justFinalized, setJustFinalized] = useState<boolean>(false);
  const [memory, setMemory] = useState<number>(0);
  const [gt, setGt] = useState<number>(0);
  const [history, setHistory] = useState<string[]>([]);
  const [reviewIdx, setReviewIdx] = useState<number | null>(null);
  const [indianComma, setIndianComma] = useState<boolean>(true);
  const [showTape, setShowTape] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [scale, setScale] = useState<number>(1);
  const [pos, setPos] = useState({ x: 32, y: 64 });
  const [drag, setDrag] = useState<{ mode: 'move' | 'resize'; sx: number; sy: number; is: number } | null>(null);

  useEffect(() => {
    if (!drag) return;
    const onMove = (e: MouseEvent) => {
      if (drag.mode === 'move') setPos({ x: Math.max(8, e.clientX - drag.sx), y: Math.max(8, e.clientY - drag.sy) });
      else setScale(Number(Math.min(1.35, Math.max(0.7, drag.is + (e.clientX - drag.sx + (e.clientY - drag.sy)) / 340)).toFixed(2)));
    };
    const onUp = () => setDrag(null);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => { window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); };
  }, [drag]);

  const inputDigit = useCallback((d: string) => {
    setReviewIdx(null);
    if (justFinalized) { setTokens([]); setCurInput(d === '00' ? '0' : d); setJustFinalized(false); return; }
    setCurInput((prev) => {
      const next = (prev === '0' ? '' : prev) + d;
      return next === '' || next === '00' ? '0' : next.replace('.', '').length <= 12 ? next : prev;
    });
  }, [justFinalized]);

  const inputDot = useCallback(() => {
    setReviewIdx(null);
    if (justFinalized) { setTokens([]); setCurInput('0.'); setJustFinalized(false); return; }
    setCurInput((prev) => (prev.includes('.') ? prev : `${prev || '0'}.`));
  }, [justFinalized]);

  const pushOperator = useCallback((nextOp: string) => {
    setReviewIdx(null);
    if (justFinalized) { setTokens([curInput || '0', nextOp]); setCurInput(''); setJustFinalized(false); return; }
    if (curInput === '' && tokens.length >= 2) setTokens((prev) => [...prev.slice(0, -1), nextOp]);
    else { setTokens((prev) => [...prev, curInput || '0', nextOp]); setCurInput(''); }
  }, [curInput, justFinalized, tokens.length]);

  const finalizeEquals = useCallback(() => {
    setReviewIdx(null);
    const full = curInput !== '' ? [...tokens, curInput] : tokens.slice(0, -1);
    if (full.length === 0) return;
    const res = evalLeftToRight(full);
    setHistory((h) => [`${full.join(' ')} = ${res}`, ...h.slice(0, 149)]);
    setGt((g) => Number((g + res).toFixed(4)));
    setTokens([]); setCurInput(String(res)); setJustFinalized(true);
  }, [curInput, tokens]);

  const clearAll = useCallback(() => { setTokens([]); setCurInput('0'); setJustFinalized(false); setReviewIdx(null); }, []);
  const backspace = useCallback(() => { if (!justFinalized) setCurInput((prev) => (prev.length > 1 ? prev.slice(0, -1) : '0')); }, [justFinalized]);
  const applyUnary = (fn: (n: number) => number) => setCurInput(String(Number(fn(curInput !== '' ? parseFloat(curInput) || 0 : evalLeftToRight(tokens)).toFixed(4))));
  const handlePercent = () => {
    const cur = parseFloat(curInput || '0') || 0;
    setCurInput(String(Number((tokens.length >= 2 ? (evalLeftToRight(tokens.slice(0, -1)) * cur) / 100 : cur / 100).toFixed(4))));
  };

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t?.tagName === 'TEXTAREA' || t?.tagName === 'INPUT' || t?.isContentEditable) return;
      if (e.key >= '0' && e.key <= '9') { e.preventDefault(); inputDigit(e.key); }
      else if (e.key === '.') { e.preventDefault(); inputDot(); }
      else if (['+', '-', '*', '/'].includes(e.key)) { e.preventDefault(); pushOperator(e.key); }
      else if (e.key === 'Enter' || e.key === '=') { e.preventDefault(); finalizeEquals(); }
      else if (e.key === 'Backspace') { e.preventDefault(); backspace(); }
      else if (e.key === 'Escape') { e.preventDefault(); clearAll(); }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [backspace, clearAll, finalizeEquals, inputDigit, inputDot, isOpen, pushOperator]);

  const { exprLine, mainLcd, stepCount } = useMemo(() => {
    if (reviewIdx !== null && history[reviewIdx]) {
      const parts = history[reviewIdx].split(' = ');
      return { exprLine: parts[0] || '', mainLcd: fmtNum(parts[1] || '0', indianComma, true), stepCount: reviewIdx + 1 };
    }
    const activeTokens = curInput !== '' ? [...tokens, curInput] : tokens;
    const expr = activeTokens.map((tk) => (['+', '-', '*', '/'].includes(tk) ? (tk === '*' ? '×' : tk === '/' ? '÷' : tk === '-' ? '−' : tk) : fmtNum(tk, indianComma))).join(' ');
    const steps = Math.max(1, Math.ceil(activeTokens.length / 2));
    if (tokens.length >= 2 && curInput !== '') return { exprLine: expr, mainLcd: fmtNum(evalLeftToRight([...tokens, curInput]), indianComma, true), stepCount: steps };
    if (tokens.length >= 2 && curInput === '') return { exprLine: expr, mainLcd: fmtNum(evalLeftToRight(tokens.slice(0, -1)), indianComma, true), stepCount: steps };
    return { exprLine: expr || '0', mainLcd: fmtNum(curInput || '0', indianComma, true), stepCount: steps };
  }, [curInput, history, indianComma, reviewIdx, tokens]);

  if (!isOpen) return null;
  const dk = 'rounded-lg bg-gradient-to-b from-[#45454b] to-[#2e2e33] hover:from-[#505057] hover:to-[#35353b] active:translate-y-px text-white shadow-[0_2px_0_#151518,inset_0_1px_0_rgba(255,255,255,0.16)] border border-[#1d1d21] font-semibold flex items-center justify-center leading-none';
  const pk = 'rounded-lg bg-gradient-to-b from-[#913b66] to-[#6e284c] hover:from-[#a14372] hover:to-[#7c2e56] active:translate-y-px text-white shadow-[0_2px_0_#151518,inset_0_1px_0_rgba(255,255,255,0.22)] border border-[#2a131f] font-bold flex items-center justify-center leading-none';

  return (
    <div style={{ left: pos.x, top: pos.y, width: 308, zoom: scale } as React.CSSProperties} className="fixed z-50 rounded-[20px] bg-gradient-to-b from-[#323237] via-[#27272b] to-[#1e1e22] text-white border-[2.5px] border-[#43434a] shadow-[0_20px_45px_rgba(0,0,0,0.65),inset_0_1px_1px_rgba(255,255,255,0.2)] select-none overflow-hidden">
      <div onMouseDown={(e) => setDrag({ mode: 'move', sx: e.clientX - pos.x, sy: e.clientY - pos.y, is: scale })} className="px-3 py-1.5 bg-[#18181b] border-b border-[#34343b] flex items-center justify-between cursor-move text-[11px]">
        <div className="flex items-center gap-1.5" onMouseDown={(e) => e.stopPropagation()}>
          <button type="button" onClick={() => setShowTape((v) => !v)} className={`px-2 py-0.5 rounded font-semibold ${showTape ? 'bg-emerald-600 text-white' : 'bg-[#2a2a30] text-slate-300 hover:bg-[#36363e]'}`}>Tape</button>
          <button type="button" onClick={() => { navigator.clipboard?.writeText(mainLcd.replace(/['",]/g, '')); setCopied(true); setTimeout(() => setCopied(false), 1200); }} className="px-2 py-0.5 rounded bg-[#2a2a30] hover:bg-[#36363e] text-slate-300 font-semibold">{copied ? 'Copied' : 'Copy'}</button>
        </div>
        <div className="flex items-center gap-1" onMouseDown={(e) => e.stopPropagation()}>
          <button type="button" onClick={() => setScale((s) => Number(Math.max(0.7, s - 0.1).toFixed(2)))} className="w-5 h-5 rounded bg-[#2a2a30] hover:bg-[#36363e] text-slate-200 font-bold flex items-center justify-center" title="Smaller">-</button>
          <button type="button" onClick={() => setScale(1)} className="px-1 text-[10px] font-mono text-slate-300 hover:text-white" title="Reset Size">{Math.round(scale * 100)}%</button>
          <button type="button" onClick={() => setScale((s) => Number(Math.min(1.35, s + 0.1).toFixed(2)))} className="w-5 h-5 rounded bg-[#2a2a30] hover:bg-[#36363e] text-slate-200 font-bold flex items-center justify-center" title="Larger">+</button>
          <button type="button" onClick={onClose} className="ml-1 p-0.5 text-slate-400 hover:text-white" title="Close"><Icon name="x" size={14} /></button>
        </div>
      </div>

      <div className="px-3 pt-2.5 pb-2">
        <div className="p-2 rounded-lg bg-[#17171a] border border-[#3d3d44] shadow-inner">
          <div className="rounded bg-[#cfd8cc] text-[#111812] px-2.5 py-1.5 font-mono border border-[#96a393] shadow-[inset_0_2px_5px_rgba(0,0,0,0.22)]">
            <div className="flex items-center justify-between text-[10px] font-bold tracking-tight text-[#253026] gap-2">
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="px-1 rounded-xs bg-[#b7c4b3] font-black">{String(stepCount).padStart(3, '0')}</span>
                {reviewIdx !== null && <span className="underline">REV</span>}{gt !== 0 && <span>GT</span>}{memory !== 0 && <span>M</span>}
                <span className="opacity-75">{indianComma ? 'IND' : 'STD'}</span>
              </div>
              <div className="truncate text-right text-[11px] font-bold text-[#1b241c]">{exprLine}</div>
            </div>
            <div className="text-right text-2xl font-black tracking-tight truncate leading-tight mt-0.5">{mainLcd}</div>
          </div>
        </div>
        {showTape && (
          <div className="mt-1.5 max-h-24 overflow-y-auto rounded bg-[#151518] border border-[#34343b] p-1.5 text-[10px] font-mono text-slate-300 space-y-0.5">
            {history.length === 0 ? <div className="text-slate-500 text-center py-1">No steps recorded</div> : history.map((h, i) => <div key={i} className="truncate text-right">{h}</div>)}
          </div>
        )}
      </div>

      <div className="px-3 pb-3.5 grid grid-cols-6 gap-1.5 text-[13px]">
        {/* Row 0: Spacious Check & Step Navigation Row */}
        <button type="button" onClick={() => setReviewIdx((i) => (history.length ? ((i ?? -1) + 1) % history.length : null))} className={`col-span-2 h-7 ${dk} text-[10px]`}>AUTO REV</button>
        <button type="button" onClick={backspace} className={`col-span-2 h-7 ${dk} text-[10px]`}>CORRECT</button>
        <button type="button" onClick={() => setReviewIdx((i) => (history.length ? Math.max(0, (i ?? 0) - 1) : null))} className={`h-7 ${dk} text-xs`} title="Previous Step">&uarr;</button>
        <button type="button" onClick={() => setReviewIdx((i) => (history.length ? Math.min(history.length - 1, (i ?? -1) + 1) : null))} className={`h-7 ${dk} text-xs`} title="Next Step">&darr;</button>

        {/* Row 1: DISP | ▶ | +/- | √ | MU | GT */}
        <button type="button" onClick={() => setIndianComma((v) => !v)} className={`h-8 ${dk} ring-1 ring-[#b8bcc2] text-[10px] font-extrabold`}>DISP</button>
        <button type="button" onClick={backspace} className={`h-8 ${dk} text-[11px]`}>&#9654;</button>
        <button type="button" onClick={() => applyUnary((n) => -n)} className={`h-8 ${dk} text-xs`}>+/&minus;</button>
        <button type="button" onClick={() => applyUnary((n) => (n >= 0 ? Math.sqrt(n) : 0))} className={`h-8 ${dk} text-xs`}>&radic;</button>
        <button type="button" onClick={handlePercent} className={`h-8 ${dk} text-[11px]`}>MU</button>
        <button type="button" onClick={() => setCurInput(String(gt))} className={`h-8 ${dk} text-[11px]`}>GT</button>

        {/* Row 2: 7 | 8 | 9 | % | C | AC */}
        <button type="button" onClick={() => inputDigit('7')} className={`h-9 ${dk}`}>7</button>
        <button type="button" onClick={() => inputDigit('8')} className={`h-9 ${dk}`}>8</button>
        <button type="button" onClick={() => inputDigit('9')} className={`h-9 ${dk}`}>9</button>
        <button type="button" onClick={handlePercent} className={`h-9 ${dk}`}>%</button>
        <button type="button" onClick={() => setCurInput('0')} className={`h-9 ${pk}`}>C</button>
        <button type="button" onClick={clearAll} className={`h-9 ${pk}`}>AC</button>

        {/* Row 3: 4 | 5 | 6 | × | ÷ | MRC */}
        <button type="button" onClick={() => inputDigit('4')} className={`h-9 ${dk}`}>4</button>
        <button type="button" onClick={() => inputDigit('5')} className={`h-9 ${dk}`}>5</button>
        <button type="button" onClick={() => inputDigit('6')} className={`h-9 ${dk}`}>6</button>
        <button type="button" onClick={() => pushOperator('*')} className={`h-9 ${dk} text-base`}>&times;</button>
        <button type="button" onClick={() => pushOperator('/')} className={`h-9 ${dk} text-base`}>&divide;</button>
        <button type="button" onClick={() => { setCurInput(String(memory)); setMemory(0); }} className={`h-9 ${dk} text-[10px]`}>MRC</button>

        {/* Row 4: 1 | 2 | 3 | + (Tall 2-Row Span) | − | M- */}
        <button type="button" onClick={() => inputDigit('1')} className={`h-9 ${dk}`}>1</button>
        <button type="button" onClick={() => inputDigit('2')} className={`h-9 ${dk}`}>2</button>
        <button type="button" onClick={() => inputDigit('3')} className={`h-9 ${dk}`}>3</button>
        <button type="button" onClick={() => pushOperator('+')} className={`row-span-2 h-full ${dk} text-lg`}>+</button>
        <button type="button" onClick={() => pushOperator('-')} className={`h-9 ${dk} text-base`}>&minus;</button>
        <button type="button" onClick={() => setMemory((m) => Number((m - (parseFloat(curInput) || 0)).toFixed(4)))} className={`h-9 ${dk} text-[11px]`}>M&minus;</button>

        {/* Row 5: 0 | 00 | . | (Tall +) | = | M+ */}
        <button type="button" onClick={() => inputDigit('0')} className={`h-9 ${dk}`}>0</button>
        <button type="button" onClick={() => inputDigit('00')} className={`h-9 ${dk}`}>00</button>
        <button type="button" onClick={inputDot} className={`h-9 ${dk}`}>&bull;</button>
        <button type="button" onClick={finalizeEquals} className={`h-9 ${dk} text-base`}>=</button>
        <button type="button" onClick={() => setMemory((m) => Number((m + (parseFloat(curInput) || 0)).toFixed(4)))} className={`h-9 ${dk} text-[11px]`}>M+</button>
      </div>

      <div onMouseDown={(e) => { e.stopPropagation(); setDrag({ mode: 'resize', sx: e.clientX, sy: e.clientY, is: scale }); }} className="absolute bottom-0 right-0 w-5 h-5 cursor-nwse-resize flex items-end justify-end p-1 text-slate-400 hover:text-white" title="Drag corner to resize calculator">
        <svg width="10" height="10" viewBox="0 0 10 10" className="opacity-70"><path d="M9 1v8H1" fill="none" stroke="currentColor" strokeWidth="1.6" /><path d="M9 5v4H5" fill="none" stroke="currentColor" strokeWidth="1.6" /></svg>
      </div>
    </div>
  );
};
