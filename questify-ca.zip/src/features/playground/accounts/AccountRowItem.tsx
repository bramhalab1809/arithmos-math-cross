import React from 'react';
import { Icon } from '../../../ui/icons';
import { WorkingNoteTagPicker } from './WorkingNoteTagPicker';
import { AccountRow, WorkingNoteRef, normalizeAmountOnBlur } from './accountDefinitions';

interface AccountRowItemProps {
  row: AccountRow;
  index: number;
  side: 'left' | 'right';
  disabled?: boolean;
  onChangeRow: (rowId: string, patch: Partial<AccountRow>) => void;
  onDeleteRow: (rowId: string) => void;
  onDragStartRow: (side: 'left' | 'right', index: number) => void;
  onDropOnRow: (side: 'left' | 'right', targetIndex: number) => void;
  onJumpToWorkingNote?: (ref: WorkingNoteRef) => void;
}

export const AccountRowItem: React.FC<AccountRowItemProps> = ({
  row,
  index,
  side,
  disabled = false,
  onChangeRow,
  onDeleteRow,
  onDragStartRow,
  onDropOnRow,
  onJumpToWorkingNote,
}) => {
  const isBalancingRow = /balancing figure/i.test(row.particulars);

  return (
    <div
      draggable={!disabled}
      onDragStart={() => !disabled && onDragStartRow(side, index)}
      onDragOver={(e) => !disabled && e.preventDefault()}
      onDrop={() => !disabled && onDropOnRow(side, index)}
      className={`group flex items-center gap-1.5 px-2 py-1.5 rounded-lg border transition-colors ${
        isBalancingRow
          ? 'bg-amber-500/8 dark:bg-amber-500/12 border-amber-400/50 dark:border-amber-600/50'
          : disabled
          ? 'bg-white dark:bg-slate-800/70 border-slate-200/60 dark:border-slate-700/60'
          : 'bg-slate-50/70 dark:bg-slate-900/50 border-slate-200/80 dark:border-slate-700/80 hover:border-indigo-300 dark:hover:border-indigo-700'
      }`}
    >
      {!disabled && (
        <span
          className="cursor-grab active:cursor-grabbing text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-0.5 shrink-0"
          title="Drag to reorder row"
        >
          <Icon name="grip-vertical" size={14} />
        </span>
      )}

      <input
        type="text"
        readOnly={disabled}
        disabled={disabled}
        value={row.particulars}
        onChange={(e) => onChangeRow(row.id, { particulars: e.target.value })}
        placeholder={disabled ? '' : side === 'left' ? 'Particulars (e.g. To Purchases)' : 'Particulars (e.g. By Sales)'}
        className={`flex-1 min-w-0 bg-transparent text-xs sm:text-sm font-medium text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none ${
          disabled ? 'cursor-default select-none' : ''
        }`}
      />

      <WorkingNoteTagPicker
        value={row.workingNoteRef}
        disabled={disabled}
        onChange={(nextRef) => onChangeRow(row.id, { workingNoteRef: nextRef })}
        onJumpToWorkingNote={onJumpToWorkingNote}
      />

      <input
        type="text"
        inputMode="decimal"
        readOnly={disabled}
        disabled={disabled}
        value={row.amount}
        onChange={(e) => onChangeRow(row.id, { amount: e.target.value })}
        onBlur={(e) => {
          if (disabled) return;
          const normalized = normalizeAmountOnBlur(e.target.value);
          if (normalized !== row.amount) {
            onChangeRow(row.id, { amount: normalized });
          }
        }}
        onKeyDown={(e) => {
          if (disabled) return;
          if (e.key === 'Enter') {
            e.preventDefault();
            const normalized = normalizeAmountOnBlur(row.amount);
            if (normalized !== row.amount) {
              onChangeRow(row.id, { amount: normalized });
            }
          }
        }}
        placeholder={disabled ? '' : 'Amount (e.g. 1000+500)'}
        className={`w-24 sm:w-28 text-right px-2 py-1 rounded-md text-xs sm:text-sm font-mono-tabular font-semibold text-slate-900 dark:text-slate-100 placeholder:text-slate-400 placeholder:font-normal focus:outline-none shrink-0 ${
          disabled
            ? 'bg-transparent border-transparent cursor-default select-none'
            : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:border-indigo-500'
        }`}
      />

      {!disabled && (
        <button
          type="button"
          onClick={() => onDeleteRow(row.id)}
          className="p-1 rounded-md text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-500/10 transition-colors shrink-0"
          title="Remove row"
          aria-label="Remove row"
        >
          <Icon name="x" size={13} />
        </button>
      )}
    </div>
  );
};
