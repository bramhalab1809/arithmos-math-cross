import React, { useState } from 'react';
import { Icon } from '../../../ui/icons';
import { SlashCommandMenu, SlashTriggerState, detectSlashTrigger } from '../subjective/SlashCommandMenu';
import { InteractiveAccountCard } from './InteractiveAccountCard';
import { AccountDefinition, WorkspaceBlock, createAccountCardFromDef, filterAccountDefinitions } from './accountDefinitions';

export function makeTextBlock(content = ''): WorkspaceBlock {
  return { id: `blk_txt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`, type: 'text', content };
}

export interface BlockWorkspaceProps {
  blocks: WorkspaceBlock[];
  disabled?: boolean;
  onChangeBlocks: React.Dispatch<React.SetStateAction<WorkspaceBlock[]>>;
  onOpenFormatsDrawer?: () => void;
}

export const BlockWorkspace: React.FC<BlockWorkspaceProps> = ({ blocks, disabled = false, onChangeBlocks }) => {
  const [slashState, setSlashState] = useState<{ blockId: string; trigger: SlashTriggerState; selectedIndex: number } | null>(null);

  const updateBlock = (id: string, nextBlock: WorkspaceBlock) => {
    onChangeBlocks((prev) => prev.map((b) => (b.id === id ? nextBlock : b)));
  };

  const removeBlock = (id: string) => {
    onChangeBlocks((prev) => {
      const remaining = prev.filter((b) => b.id !== id);
      return remaining.length > 0 ? remaining : [makeTextBlock('')];
    });
  };

  const moveBlock = (index: number, direction: -1 | 1) => {
    onChangeBlocks((prev) => {
      const target = index + direction;
      if (target < 0 || target >= prev.length) return prev;
      const copy = [...prev];
      const [moved] = copy.splice(index, 1);
      copy.splice(target, 0, moved);
      return copy;
    });
  };

  const handleTextChange = (blockId: string, text: string, cursorIndex: number) => {
    updateBlock(blockId, { id: blockId, type: 'text', content: text });
    const trig = detectSlashTrigger(text, cursorIndex);
    if (trig.active && !disabled) {
      setSlashState({ blockId, trigger: trig, selectedIndex: 0 });
    } else {
      setSlashState(null);
    }
  };

  const handleInsertAccountDef = (def: AccountDefinition) => {
    if (!slashState) return;
    const { blockId, trigger } = slashState;

    onChangeBlocks((prev) => {
      const idx = prev.findIndex((b) => b.id === blockId);
      if (idx === -1) return prev;
      const targetBlock = prev[idx];
      if (targetBlock.type !== 'text') return prev;

      const before = targetBlock.content.slice(0, trigger.triggerIndex).trimEnd();
      const after = targetBlock.content.slice(trigger.cursorIndex).trimStart();

      if (def.isWorkingNoteText) {
        const wnText = `${before ? `${before}\n` : ''}Working Note (W.N.): ${after}`;
        return prev.map((b, i) => (i === idx ? { ...b, content: wnText } : b));
      }

      const nextList: WorkspaceBlock[] = [];
      prev.forEach((b, i) => {
        if (i !== idx) {
          nextList.push(b);
          return;
        }
        if (before) nextList.push({ id: b.id, type: 'text', content: before });
        nextList.push({
          id: `blk_acc_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          type: 'account',
          data: createAccountCardFromDef(def),
        });
        nextList.push(makeTextBlock(after));
      });
      return nextList;
    });

    setSlashState(null);
  };

  return (
    <div className="flex-1 min-h-0 overflow-y-auto bg-white dark:bg-slate-900 p-3 sm:p-4 space-y-3">
      {blocks.map((block, index) => {
        if (block.type === 'account') {
          return (
            <InteractiveAccountCard
              key={block.id}
              card={block.data}
              disabled={disabled}
              canMoveUp={index > 0}
              canMoveDown={index < blocks.length - 1}
              onChangeCard={(updated) =>
                updateBlock(block.id, { ...block, data: updated })
              }
              onDeleteCard={() => removeBlock(block.id)}
              onMoveUp={() => moveBlock(index, -1)}
              onMoveDown={() => moveBlock(index, 1)}
            />
          );
        }

        const isSlashHere = slashState?.blockId === block.id;
        const matches = isSlashHere ? filterAccountDefinitions(slashState.trigger.query) : [];

        return (
          <div
            key={block.id}
            className="relative rounded-xl border border-slate-200 dark:border-slate-700/80 bg-white dark:bg-slate-900 focus-within:border-indigo-400 dark:focus-within:border-indigo-500 transition-colors shadow-2xs"
          >
            <div className="px-3 py-1.5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 rounded-t-xl flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                <Icon name="file-text" size={11} />
                <span>NOTE</span>
              </div>
              {!disabled && (
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    disabled={index === 0}
                    onClick={() => moveBlock(index, -1)}
                    className="p-0.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 disabled:opacity-30"
                    title="Move Up"
                  >
                    <Icon name="arrow-up" size={11} />
                  </button>
                  <button
                    type="button"
                    disabled={index >= blocks.length - 1}
                    onClick={() => moveBlock(index, 1)}
                    className="p-0.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 disabled:opacity-30"
                    title="Move Down"
                  >
                    <Icon name="arrow-down" size={11} />
                  </button>
                  {blocks.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeBlock(block.id)}
                      className="p-0.5 text-slate-400 hover:text-rose-500"
                      title="Delete Note"
                    >
                      <Icon name="x" size={11} />
                    </button>
                  )}
                </div>
              )}
            </div>

            <textarea
              disabled={disabled}
              value={block.content}
              onChange={(e) =>
                handleTextChange(
                  block.id,
                  e.target.value,
                  e.target.selectionStart ?? e.target.value.length
                )
              }
              onKeyDown={(e) => {
                if (!isSlashHere || !slashState || matches.length === 0) return;
                if (e.key === 'ArrowDown') {
                  e.preventDefault();
                  setSlashState((s) =>
                    s ? { ...s, selectedIndex: (s.selectedIndex + 1) % matches.length } : null
                  );
                } else if (e.key === 'ArrowUp') {
                  e.preventDefault();
                  setSlashState((s) =>
                    s ? { ...s, selectedIndex: (s.selectedIndex - 1 + matches.length) % matches.length } : null
                  );
                } else if (e.key === 'Enter' || e.key === 'Tab') {
                  e.preventDefault();
                  const chosen = matches[slashState.selectedIndex % matches.length];
                  if (chosen) handleInsertAccountDef(chosen);
                } else if (e.key === 'Escape') {
                  e.preventDefault();
                  setSlashState(null);
                }
              }}
              rows={Math.max(3, block.content.split('\n').length)}
              placeholder={
                disabled
                  ? ''
                  : 'Draft Working Notes or type / to insert an Account (e.g. /trading, /pl, /bs)...'
              }
              className="w-full px-3.5 py-2.5 bg-transparent rounded-b-xl text-xs sm:text-sm font-mono text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none leading-relaxed resize-y"
            />

            {isSlashHere && slashState && (
              <SlashCommandMenu
                isOpen={true}
                query={slashState.trigger.query}
                selectedIndex={slashState.selectedIndex}
                onSelectDefinition={handleInsertAccountDef}
                onClose={() => setSlashState(null)}
              />
            )}
          </div>
        );
      })}
    </div>
  );
};
