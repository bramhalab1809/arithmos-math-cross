import { getSubjectScopedTxtFiles } from '../shared/vfsSubjectScoped';

export type WorkingNoteColor = 'blue' | 'red' | 'green' | 'orange' | 'purple' | 'yellow' | 'pink' | 'teal' | 'indigo' | 'lime';

export interface WorkingNoteRef { id: string; label: string; color: WorkingNoteColor; }
export interface AccountRow { id: string; particulars: string; amount: string; workingNoteRef?: WorkingNoteRef; }
export interface AccountCardData {
  id: string; title: string; leftTitle: string; rightTitle?: string;
  leftRows: AccountRow[]; rightRows?: AccountRow[]; isOpen: boolean;
}

export type WorkspaceBlock = { id: string; type: 'text'; content: string } | { id: string; type: 'account'; data: AccountCardData };
export type AccountDefCategory =
  | 'Final Accounts' | 'Depreciation & Fixed Assets' | 'BRS & Cash Book'
  | 'Bills, NPO & Incomplete Records' | 'Partnership Accounts' | 'Company Accounts' | 'General Ledgers & Notes';

export interface AccountDefinition {
  id: string; command: string; title: string; category: AccountDefCategory; description: string;
  leftTitle: string; rightTitle?: string; defaultLeft: Array<[string, string]>; defaultRight?: Array<[string, string]>;
  isWorkingNoteText?: boolean; isCustom?: boolean; fileName?: string;
}

export const ACCOUNT_DEF_CATEGORIES: AccountDefCategory[] = [
  'Final Accounts', 'Depreciation & Fixed Assets', 'BRS & Cash Book', 'Bills, NPO & Incomplete Records', 'Partnership Accounts', 'Company Accounts', 'General Ledgers & Notes',
];

export const CUSTOM_ACCOUNTS_STORAGE_KEY = 'custom_interactive_accounts_v1';

export const SEED_ACC_FORMAT_TXT_FILES: { id: string; name: string; content: string }[] = [
  {
    id: 'fil_acc_fmt_01', name: '01_Trading_Account.txt',
    content: `Command: /Trading-Account\nTitle: Trading Account for the year ended ...\nCategory: Final Accounts\nDescription: Dr./Cr. Trading Account with Opening Stock, Purchases, Direct Wages, Sales & Closing Stock.\nLeft Column: Particulars (Dr.)\nRight Column: Particulars (Cr.)\n\n[Left Rows]\nTo Opening Stock\nTo Purchases (Less Returns)\nTo Direct Wages & Carriage Inward\nTo Gross Profit c/d\n\n[Right Rows]\nBy Sales (Less Returns)\nBy Closing Stock`,
  },
  {
    id: 'fil_acc_fmt_02', name: '02_Profit_and_Loss_Account.txt',
    content: `Command: /Profit-and-Loss-Account\nTitle: Profit and Loss Account for the year ended ...\nCategory: Final Accounts\nDescription: Dr./Cr. P&L Account for Salaries, Rent, Depreciation, Provisions, and Net Profit.\nLeft Column: Particulars (Dr.)\nRight Column: Particulars (Cr.)\n\n[Left Rows]\nTo Salaries & Wages\nTo Rent, Rates & Taxes\nTo Depreciation (W.N. 1)\nTo Provision for Doubtful Debts\nTo Net Profit transferred to Capital A/c\n\n[Right Rows]\nBy Gross Profit b/d\nBy Discount & Commission Received`,
  },
  {
    id: 'fil_acc_fmt_03', name: '03_Balance_Sheet.txt',
    content: `Command: /Balance-Sheet\nTitle: Balance Sheet as at ...\nCategory: Final Accounts\nDescription: Classified Balance Sheet with Capital & Liabilities on left and Fixed/Current Assets on right.\nLeft Column: Capital & Liabilities (Rs.)\nRight Column: Assets & Properties (Rs.)\n\n[Left Rows]\nCapital Account (Add Net Profit, Less Drawings)\nLong-Term Loans / Bank Overdraft\nSundry Creditors & Bills Payable\nOutstanding Expenses\n\n[Right Rows]\nFixed Assets (Less Depreciation)\nClosing Stock\nSundry Debtors (Less Provision)\nCash in Hand & Cash at Bank`,
  },
  {
    id: 'fil_acc_fmt_04', name: '04_Manufacturing_Account.txt',
    content: `Command: /Manufacturing-Account\nTitle: Manufacturing Account for the year ended ...\nCategory: Final Accounts\nDescription: Cost of Production account with Raw Material Consumed, Direct Factory Wages & Overheads.\nLeft Column: Particulars (Dr.)\nRight Column: Particulars (Cr.)\n\n[Left Rows]\nTo Opening Work-in-Progress\nTo Raw Materials Consumed\nTo Direct Factory Wages\nTo Factory Overheads & Machinery Depr.\n\n[Right Rows]\nBy Closing Work-in-Progress\nBy Sale of Scrap\nBy Cost of Production trf. to Trading A/c`,
  },
  {
    id: 'fil_acc_fmt_05', name: '05_Machinery_and_Depreciation.txt',
    content: `Command: /Machinery-Account\nTitle: Dr. Machinery Account Cr.\nCategory: Depreciation & Fixed Assets\nDescription: Fixed Asset Ledger for Additions, Sale/Disposal, Depreciation, and Closing Balance c/d.\nLeft Column: Particulars (Dr.)\nRight Column: Particulars (Cr.)\n\n[Left Rows]\nTo Balance b/d\nTo Bank A/c (Additions)\n\n[Right Rows]\nBy Depreciation A/c\nBy Bank A/c (Sale Proceeds)\nBy P&L A/c (Loss on Sale)\nBy Balance c/d`,
  },
  {
    id: 'fil_acc_fmt_06', name: '06_Provision_for_Depreciation.txt',
    content: `Command: /Provision-for-Depreciation\nTitle: Dr. Provision for Depreciation Account Cr.\nCategory: Depreciation & Fixed Assets\nDescription: Accumulated Depreciation Ledger tracking opening reserve, current year charge, and disposal.\nLeft Column: Particulars (Dr.)\nRight Column: Particulars (Cr.)\n\n[Left Rows]\nTo Asset Disposal A/c\nTo Balance c/d\n\n[Right Rows]\nBy Balance b/d\nBy Depreciation A/c (Current Year)`,
  },
  {
    id: 'fil_acc_fmt_07', name: '07_Bank_Reconciliation_Statement.txt',
    content: `Command: /Bank-Reconciliation-Statement\nTitle: Bank Reconciliation Statement as on ...\nCategory: BRS & Cash Book\nDescription: Two-column Plus (+) and Minus (-) items statement reconciling Cash Book and Pass Book.\nLeft Column: Add: Plus Items (+)\nRight Column: Less: Minus Items (-)\n\n[Left Rows]\nBalance as per Cash Book (Dr.)\nCheques issued but not yet presented\nInterest credited directly by Bank\n\n[Right Rows]\nCheques deposited but not yet cleared\nBank charges debited in Pass Book only`,
  },
  {
    id: 'fil_acc_fmt_08', name: '08_Consignment_Account.txt',
    content: `Command: /Consignment-Account\nTitle: Dr. Consignment Account Cr.\nCategory: Bills, NPO & Incomplete Records\nDescription: Consignment ledger for Goods Sent, Expenses, Commission, and Unsold Stock.\nLeft Column: Particulars (Dr.)\nRight Column: Particulars (Cr.)\n\n[Left Rows]\nTo Goods Sent on Consignment A/c\nTo Bank A/c (Freight & Insurance)\nTo Consignee A/c (Expenses & Commission)\nTo Profit & Loss A/c (Profit)\n\n[Right Rows]\nBy Consignee A/c (Gross Sales)\nBy Inventory on Consignment A/c`,
  },
  {
    id: 'fil_acc_fmt_09', name: '09_Income_and_Expenditure_Account.txt',
    content: `Command: /Income-and-Expenditure-Account\nTitle: Income and Expenditure Account for the year ended ...\nCategory: Bills, NPO & Incomplete Records\nDescription: NPO Revenue statement with Expenditure (Dr.) and Income/Subscriptions (Cr.).\nLeft Column: Expenditure (Dr.)\nRight Column: Income (Cr.)\n\n[Left Rows]\nTo Salaries & Upkeep\nTo Stationery & Sports Material Consumed\nTo Depreciation on Equipment\nTo Surplus (Excess of Income over Exp.)\n\n[Right Rows]\nBy Subscriptions (Adjusted)\nBy Entrance Fees & Donations`,
  },
  {
    id: 'fil_acc_fmt_10', name: '10_Partnership_Revaluation_Account.txt',
    content: `Command: /Revaluation-Account\nTitle: Dr. Revaluation Account Cr.\nCategory: Partnership Accounts\nDescription: Partnership admission/retirement asset & liability revaluation account.\nLeft Column: Particulars (Dr.)\nRight Column: Particulars (Cr.)\n\n[Left Rows]\nTo Decrease in Value of Assets\nTo Increase in Liabilities\nTo Partners Capital A/c (Profit)\n\n[Right Rows]\nBy Increase in Value of Assets\nBy Decrease in Liabilities`,
  },
  {
    id: 'fil_acc_fmt_11', name: '11_Share_Capital_Account.txt',
    content: `Command: /Share-Capital-Account\nTitle: Dr. Share Capital & Forfeiture Account Cr.\nCategory: Company Accounts\nDescription: Issue, Allotment, Call, and Forfeiture/Reissue of Equity & Preference Shares.\nLeft Column: Particulars (Dr.)\nRight Column: Particulars (Cr.)\n\n[Left Rows]\nTo Share Forfeiture A/c\nTo Calls-in-Arrears A/c\nTo Balance c/d\n\n[Right Rows]\nBy Share Application A/c\nBy Share Allotment A/c\nBy Share First & Final Call A/c`,
  },
  {
    id: 'fil_acc_fmt_12', name: '12_General_Ledger_and_Journal.txt',
    content: `Command: /Ledger-Account\nTitle: Dr. General Ledger Account Cr.\nCategory: General Ledgers & Notes\nDescription: Universal 2-sided Dr./Cr. T-Account for any custom ledger or journal entry.\nLeft Column: Particulars (Dr.)\nRight Column: Particulars (Cr.)\n\n[Left Rows]\nTo Balance b/d\nTo Bank / Particulars\n\n[Right Rows]\nBy Bank / Particulars\nBy Balance c/d`,
  },
];

export function parseTxtFileToAccountDef(file: { id: string; name: string; content: string }, folderName?: string): AccountDefinition {
  const stem = file.name.replace(/\.txt$/i, '').replace(/^\d+[_-]/, '').trim();
  const slug = stem.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'account';
  const raw = file.content || '';
  const getHeader = (key: string) => {
    const m = raw.match(new RegExp(`^${key}:\\s*(.+)$`, 'im'));
    return m ? m[1].trim() : '';
  };

  const command = getHeader('Command') || `/${slug}`;
  const title = getHeader('Title') || stem.replace(/_/g, ' ');
  const rawCat = getHeader('Category') as AccountDefCategory;
  const category: AccountDefCategory = ACCOUNT_DEF_CATEGORIES.includes(rawCat) ? rawCat : 'General Ledgers & Notes';
  const description = getHeader('Description') || (folderName ? `Format from ${folderName}/${file.name}` : `Format from ${file.name}`);
  const leftTitle = getHeader('Left Column') || 'Particulars (Dr.)';
  const rightTitle = getHeader('Right Column') || 'Particulars (Cr.)';

  const leftMatch = raw.match(/\[Left Rows\]([\s\S]*?)(?:\[Right Rows\]|$)/i);
  const rightMatch = raw.match(/\[Right Rows\]([\s\S]*?)$/i);

  const parseLines = (chunk?: string): Array<[string, string]> =>
    (chunk || '').split('\n').map((l) => l.trim()).filter(Boolean).map((l) => [l, '']);

  let defaultLeft = parseLines(leftMatch?.[1]);
  let defaultRight = parseLines(rightMatch?.[1]);

  if (defaultLeft.length === 0 && defaultRight.length === 0) {
    const bodyLines = raw.split('\n').map((l) => l.trim()).filter((l) => l && !/^(Command|Title|Category|Description|Left Column|Right Column):/i.test(l) && !l.startsWith('#'));
    const toLines = bodyLines.filter((l) => /^to\b/i.test(l));
    const byLines = bodyLines.filter((l) => /^by\b/i.test(l));
    if (toLines.length > 0 || byLines.length > 0) {
      defaultLeft = (toLines.length ? toLines : ['To Balance b/d']).map((l) => [l, '']);
      defaultRight = (byLines.length ? byLines : ['By Balance c/d']).map((l) => [l, '']);
    } else {
      defaultLeft = (bodyLines.length ? bodyLines.slice(0, 6) : ['To Opening Balance / Item']).map((l) => [l, '']);
      defaultRight = [['By Closing Balance / Item', '']];
    }
  }

  return {
    id: `vfs_acc_${file.id}`, command, title, category, description,
    leftTitle, rightTitle, defaultLeft, defaultRight, isCustom: true, fileName: file.name,
  };
}

export function evaluateMathAmount(raw: string): number {
  const cleaned = String(raw || '').replace(/,/g, '').replace(/₹|Rs\.?/gi, '').trim();
  if (!cleaned) return 0;
  if (/^[+-]?\d+(\.\d+)?$/.test(cleaned)) return parseFloat(cleaned) || 0;
  if (!/^[0-9+\-*/().\s]+$/.test(cleaned)) return 0;
  try {
    const tokens = cleaned.match(/(\d+(?:\.\d+)?|[+\-*/()])/g);
    if (!tokens) return 0;
    let total = 0, op = '+';
    for (const tk of tokens) {
      if (tk === '+' || tk === '-' || tk === '*' || tk === '/') op = tk;
      else {
        const v = parseFloat(tk);
        if (!Number.isFinite(v)) continue;
        total = op === '+' ? total + v : op === '-' ? total - v : op === '*' ? total * v : op === '/' && v !== 0 ? total / v : total;
      }
    }
    return Number.isFinite(total) ? Math.round(total * 100) / 100 : 0;
  } catch { return 0; }
}

export function normalizeAmountOnBlur(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) return '';
  if (/[+\-*/]/.test(trimmed.slice(1))) {
    const evaluated = evaluateMathAmount(trimmed);
    return evaluated !== 0 ? String(evaluated) : trimmed;
  }
  return trimmed;
}

export const sumAccountRows = (rows?: AccountRow[]): number => (rows ? rows.reduce((acc, r) => acc + evaluateMathAmount(r.amount), 0) : 0);
export const formatInrAmount = (val: number): string => (Number.isFinite(val) ? val.toLocaleString('en-IN', { maximumFractionDigits: 2 }) : '0');

let rowSeq = 1;
export const makeRow = (particulars = '', amount = ''): AccountRow => ({ id: `row_${Date.now()}_${++rowSeq}`, particulars, amount });

export function createAccountCardFromDef(def: AccountDefinition): AccountCardData {
  return {
    id: `acc_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    title: def.title, leftTitle: def.leftTitle, rightTitle: def.rightTitle,
    leftRows: def.defaultLeft.map(([p, a]) => makeRow(p, a)),
    rightRows: def.defaultRight ? def.defaultRight.map(([p, a]) => makeRow(p, a)) : undefined,
    isOpen: true,
  };
}

export const WORKING_NOTE_DEF: AccountDefinition = {
  id: 'def_working_note', command: '/Working-Note', title: 'Working Note Section Header', category: 'General Ledgers & Notes',
  description: 'Inserts a clean Working Note section heading directly in your answer flow.',
  leftTitle: 'Working Note', defaultLeft: [], isWorkingNoteText: true,
};

export const ACCOUNT_DEFINITIONS: AccountDefinition[] = [
  ...SEED_ACC_FORMAT_TXT_FILES.map((f) => parseTxtFileToAccountDef(f, 'Standard Account Formats')),
  WORKING_NOTE_DEF,
];

export function loadCustomAccountDefinitions(): AccountDefinition[] {
  try {
    const parsed = JSON.parse(localStorage.getItem(CUSTOM_ACCOUNTS_STORAGE_KEY) || '[]');
    return Array.isArray(parsed) ? parsed : [];
  } catch { return []; }
}

export function saveCustomAccountDefinition(def: AccountDefinition): AccountDefinition[] {
  const next = [def, ...loadCustomAccountDefinitions().filter((d) => d.id !== def.id)];
  try { localStorage.setItem(CUSTOM_ACCOUNTS_STORAGE_KEY, JSON.stringify(next)); } catch { /* ignore */ }
  return next;
}

export function getAllAccountDefinitions(selectedFolderId: string | 'ALL' = 'ALL'): AccountDefinition[] {
  const vfsDefs = getSubjectScopedTxtFiles('fld_accounting', selectedFolderId).map(({ file, folderName }) => parseTxtFileToAccountDef(file, folderName));
  if (vfsDefs.length > 0 || selectedFolderId !== 'ALL') return [...loadCustomAccountDefinitions(), ...vfsDefs, WORKING_NOTE_DEF];
  return [...loadCustomAccountDefinitions(), ...ACCOUNT_DEFINITIONS];
}

export function filterAccountDefinitions(query: string, selectedFolderId: string | 'ALL' = 'ALL'): AccountDefinition[] {
  const all = getAllAccountDefinitions(selectedFolderId);
  const clean = query.replace(/^\//, '').trim().toLowerCase();
  return !clean ? all : all.filter((d) => d.command.toLowerCase().includes(clean) || d.title.toLowerCase().includes(clean) || d.category.toLowerCase().includes(clean) || (clean === 'wn' && d.isWorkingNoteText));
}
