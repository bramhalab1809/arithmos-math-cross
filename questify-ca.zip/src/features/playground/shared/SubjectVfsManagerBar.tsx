import React, { useState } from 'react';
import { Icon } from '../../../ui/icons';
import {
  SubjectRootId,
  SubjectFolderOption,
  createSubjectSubfolder,
  createSubjectTxtFile,
} from './vfsSubjectScoped';

interface SubjectVfsManagerBarProps {
  rootFolderId: SubjectRootId;
  folders: SubjectFolderOption[];
  selectedFolderId: string | 'ALL';
  onSelectFolder: (folderId: string | 'ALL') => void;
  onRefresh: () => void;
  txtPlaceholderTitle?: string;
  txtPlaceholderBody?: string;
}

export const SubjectVfsManagerBar: React.FC<SubjectVfsManagerBarProps> = ({
  rootFolderId,
  folders,
  selectedFolderId,
  onSelectFolder,
  onRefresh,
  txtPlaceholderTitle = 'Section_or_Format_Note.txt',
  txtPlaceholderBody = 'Enter statutory provision, precedent, or accounting note...',
}) => {
  const [mode, setMode] = useState<'none' | 'folder' | 'txt'>('none');
  const [nameInput, setNameInput] = useState('');
  const [bodyInput, setBodyInput] = useState('');

  const targetParentId = selectedFolderId === 'ALL' ? rootFolderId : selectedFolderId;

  const handleCreateFolder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim()) return;
    const created = createSubjectSubfolder(targetParentId, nameInput);
    setNameInput('');
    setMode('none');
    onRefresh();
    if (created) onSelectFolder(created.id);
  };

  const handleCreateTxt = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim() || !bodyInput.trim()) return;
    createSubjectTxtFile(targetParentId, nameInput, bodyInput);
    setNameInput('');
    setBodyInput('');
    setMode('none');
    onRefresh();
  };

  return (
    <div className="space-y-2 pt-1">
      <div className="flex items-center gap-1.5">
        <div className="relative flex-1 min-w-0">
          <Icon
            name="folder"
            size={13}
            className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)] pointer-events-none"
          />
          <select
            value={selectedFolderId}
            onChange={(e) => onSelectFolder(e.target.value)}
            className="w-full pl-7 pr-6 py-1.5 rounded-lg bg-[var(--bg-app)] border border-[var(--border-subtle)] text-[11px] font-medium text-[var(--text-primary)] focus:outline-none focus:border-indigo-500 truncate"
            title="Filter by Subject Folder"
          >
            <option value="ALL">All Subject Folders ({folders.length})</option>
            {folders.map((f) => (
              <option key={f.id} value={f.id}>
                {'\u00A0'.repeat(f.depth * 2)}
                {f.name}
              </option>
            ))}
          </select>
        </div>

        <button
          type="button"
          onClick={() => {
            setMode(mode === 'folder' ? 'none' : 'folder');
            setNameInput('');
          }}
          className={`px-2.5 py-1.5 rounded-lg border text-[11px] font-semibold flex items-center gap-1 transition-all shrink-0 ${
            mode === 'folder'
              ? 'bg-indigo-600 text-white border-indigo-600'
              : 'bg-[var(--bg-surface)] text-[var(--text-primary)] border-[var(--border-subtle)] hover:border-indigo-500'
          }`}
          title="Create New Folder in Subject"
        >
          <Icon name="folder-plus" size={12} />
          <span>+ Folder</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setMode(mode === 'txt' ? 'none' : 'txt');
            setNameInput('');
            setBodyInput('');
          }}
          className={`px-2.5 py-1.5 rounded-lg border text-[11px] font-semibold flex items-center gap-1 transition-all shrink-0 ${
            mode === 'txt'
              ? 'bg-indigo-600 text-white border-indigo-600'
              : 'bg-[var(--bg-surface)] text-[var(--text-primary)] border-[var(--border-subtle)] hover:border-indigo-500'
          }`}
          title="Create New .txt Note in Subject Folder"
        >
          <Icon name="file-plus" size={12} />
          <span>+ TXT</span>
        </button>
      </div>

      {mode === 'folder' && (
        <form
          onSubmit={handleCreateFolder}
          className="p-2.5 rounded-xl bg-[var(--bg-app)] border border-[var(--border-subtle)] flex items-center gap-2"
        >
          <input
            type="text"
            value={nameInput}
            onChange={(e) => setNameInput(e.target.value)}
            placeholder="New subfolder name (e.g. Indian Contract Act)..."
            autoFocus
            className="flex-1 px-2.5 py-1.5 rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-xs text-[var(--text-primary)] focus:outline-none focus:border-indigo-500"
          />
          <button
            type="submit"
            className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-500"
          >
            Create
          </button>
        </form>
      )}

      {mode === 'txt' && (
        <form
          onSubmit={handleCreateTxt}
          className="p-2.5 rounded-xl bg-[var(--bg-app)] border border-[var(--border-subtle)] space-y-2"
        >
          <input
            type="text"
            value={nameInput}
            onChange={(e) => setNameInput(e.target.value)}
            placeholder={txtPlaceholderTitle}
            autoFocus
            className="w-full px-2.5 py-1.5 rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-xs text-[var(--text-primary)] focus:outline-none focus:border-indigo-500"
          />
          <textarea
            value={bodyInput}
            onChange={(e) => setBodyInput(e.target.value)}
            placeholder={txtPlaceholderBody}
            rows={3}
            className="w-full px-2.5 py-1.5 rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-xs text-[var(--text-primary)] focus:outline-none focus:border-indigo-500 resize-none font-mono"
          />
          <div className="flex justify-end gap-1.5">
            <button
              type="button"
              onClick={() => setMode('none')}
              className="px-2.5 py-1 rounded-lg text-[11px] font-medium text-[var(--text-muted)] hover:text-[var(--text-primary)]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-3 py-1 rounded-lg bg-indigo-600 text-white text-[11px] font-semibold hover:bg-indigo-500"
            >
              Save .txt to Explorer
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
