import { loadOrSeedVFS, saveVFS } from '../../../app/boot/initBoot';
import { addFolder } from '../../explorer/engine/vfsEngine';
import { addTxtFile } from '../../explorer/engine/vfsImport';
import { VFSFileNode, VFSFolderNode, VFSState } from '../../explorer/engine/vfsTypes';

export type SubjectRootId = 'fld_accounting' | 'fld_business_law';

export interface SubjectFolderOption {
  id: string;
  name: string;
  depth: number;
  pathLabel: string;
}

export function getSubjectDescendantFolders(
  rootFolderId: SubjectRootId,
  stateInput?: VFSState
): SubjectFolderOption[] {
  const state = stateInput || loadOrSeedVFS();
  const rootNode = state.nodes[rootFolderId];
  const result: SubjectFolderOption[] = [];

  if (rootNode && rootNode.type === 'folder') {
    result.push({ id: rootNode.id, name: rootNode.name, depth: 0, pathLabel: rootNode.name });
  } else {
    const fallbackName = rootFolderId === 'fld_business_law' ? 'Business Law' : 'Accounting';
    result.push({ id: rootFolderId, name: fallbackName, depth: 0, pathLabel: fallbackName });
  }

  const walk = (parentId: string, depth: number, parentPath: string) => {
    const parent = state.nodes[parentId];
    if (!parent || parent.type !== 'folder') return;
    for (const cid of parent.childrenIds) {
      const child = state.nodes[cid];
      if (child && child.type === 'folder' && child.id !== 'fld_ai_prompts') {
        const pathLabel = `${parentPath} / ${child.name}`;
        result.push({ id: child.id, name: child.name, depth, pathLabel });
        walk(child.id, depth + 1, pathLabel);
      }
    }
  };

  walk(rootFolderId, 1, result[0].name);
  return result;
}

export function getSubjectScopedTxtFiles(
  rootFolderId: SubjectRootId,
  selectedFolderId: string | 'ALL',
  stateInput?: VFSState
): { file: VFSFileNode; folderName: string }[] {
  const state = stateInput || loadOrSeedVFS();
  const allowedFolders = getSubjectDescendantFolders(rootFolderId, state);
  const allowedMap = new Map<string, string>();
  for (const f of allowedFolders) {
    allowedMap.set(f.id, f.name);
  }

  return Object.values(state.nodes)
    .filter((n): n is VFSFileNode => {
      if (n.type !== 'file') return false;
      const isTxt = n.fileType === 'txt' || n.name.toLowerCase().endsWith('.txt');
      if (!isTxt) return false;
      if (!n.parentId || !allowedMap.has(n.parentId)) return false;
      if (selectedFolderId !== 'ALL' && n.parentId !== selectedFolderId) return false;
      return true;
    })
    .map((file) => ({
      file,
      folderName: allowedMap.get(file.parentId) || 'Subject Folder',
    }));
}

export function createSubjectSubfolder(parentFolderId: string, name: string): VFSFolderNode | null {
  const trimmed = name.trim();
  if (!trimmed) return null;
  const state = loadOrSeedVFS();
  const nextState = addFolder(state, parentFolderId, trimmed);
  saveVFS(nextState);
  window.dispatchEvent(new CustomEvent('vfs-updated'));
  const parent = nextState.nodes[parentFolderId];
  if (parent && parent.type === 'folder') {
    const createdId = parent.childrenIds[parent.childrenIds.length - 1];
    const created = nextState.nodes[createdId];
    if (created && created.type === 'folder') return created;
  }
  return null;
}

export function createSubjectTxtFile(
  parentFolderId: string,
  fileNameRaw: string,
  content: string
): VFSFileNode | null {
  const trimmed = fileNameRaw.trim();
  if (!trimmed) return null;
  const state = loadOrSeedVFS();
  const nextState = addTxtFile(state, parentFolderId, trimmed, content);
  saveVFS(nextState);
  window.dispatchEvent(new CustomEvent('vfs-updated'));
  const parent = nextState.nodes[parentFolderId];
  if (parent && parent.type === 'folder') {
    const createdId = parent.childrenIds[parent.childrenIds.length - 1];
    const created = nextState.nodes[createdId];
    if (created && created.type === 'file') return created;
  }
  return null;
}
