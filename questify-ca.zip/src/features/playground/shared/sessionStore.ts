import { QuestionBankJSON, isTrueFalseQuestion } from '../../explorer/engine/vfsTypes';

export type BankSessionStatus = 'not-started' | 'in-progress' | 'completed';

export type QuestionSourceTag =
  | 'PYQ'
  | 'RTP'
  | 'MTP'
  | 'ICAI Study Material'
  | 'Other Faculties';

export type CanonicalSubject =
  | 'Accounting'
  | 'Business Law'
  | 'Business Economics'
  | 'Quantitative Aptitude';

export interface BankSessionRecord {
  fileId: string;
  fileName: string;
  title: string;
  subject: CanonicalSubject;
  sourceTag: QuestionSourceTag;
  bankType: 'mcq' | 'true-false' | 'subjective';
  status: BankSessionStatus;
  totalQuestions: number;
  attemptedCount: number;
  correctCount: number;
  accuracyPercent: number;
  currentIndex: number;
  elapsedSeconds: number;
  selectedAnswers: Record<number, number>;
  reasonNotes: Record<number, string>;
  visitedIndices: number[];
  updatedAt: string;
}

const SESSION_STORAGE_KEY = 'questify_ca_sessions_v1';

export function detectQuestionSourceTag(
  fileName: string,
  title: string,
  chapter?: string
): QuestionSourceTag {
  const combined = `${fileName} ${title} ${chapter || ''}`.toUpperCase();
  if (
    combined.includes('PYQ') ||
    combined.includes('PAST YEAR') ||
    combined.includes('SEP_20') ||
    combined.includes('JUN_20') ||
    combined.includes('DEC_20') ||
    combined.includes('JAN_20') ||
    combined.includes('MAY_20')
  ) {
    return 'PYQ';
  }
  if (combined.includes('RTP') || combined.includes('REVISION TEST')) {
    return 'RTP';
  }
  if (combined.includes('MTP') || combined.includes('MOCK TEST') || combined.includes('MOCK')) {
    return 'MTP';
  }
  if (combined.includes('FACULTY') || combined.includes('COACHING') || combined.includes('NOTES')) {
    return 'Other Faculties';
  }
  return 'ICAI Study Material';
}

export function detectCanonicalSubject(
  subjectRaw: string,
  fileName: string,
  title: string
): CanonicalSubject {
  const combined = `${subjectRaw} ${fileName} ${title}`.toLowerCase();
  if (
    combined.includes('law') ||
    combined.includes('contract') ||
    combined.includes('companies') ||
    combined.includes('partnership')
  ) {
    return 'Business Law';
  }
  if (
    combined.includes('econ') ||
    combined.includes('demand') ||
    combined.includes('national income') ||
    combined.includes('indian economy')
  ) {
    return 'Business Economics';
  }
  if (
    combined.includes('quant') ||
    combined.includes('math') ||
    combined.includes('stat') ||
    combined.includes('logical') ||
    combined.includes('finance') ||
    combined.includes('ratio')
  ) {
    return 'Quantitative Aptitude';
  }
  return 'Accounting';
}

export function getAllBankSessions(): Record<string, BankSessionRecord> {
  try {
    const raw = localStorage.getItem(SESSION_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return typeof parsed === 'object' && parsed !== null ? parsed : {};
  } catch {
    return {};
  }
}

export function getBankSession(fileId: string): BankSessionRecord | null {
  if (!fileId) return null;
  const all = getAllBankSessions();
  return all[fileId] || null;
}

export function saveBankSession(record: BankSessionRecord): void {
  try {
    const all = getAllBankSessions();
    all[record.fileId] = {
      ...record,
      updatedAt: new Date().toISOString(),
    };
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(all));
    window.dispatchEvent(new CustomEvent('session-updated', { detail: { fileId: record.fileId } }));
  } catch {
    // Ignore storage quota errors
  }
}

export function clearBankSessionForFreshStart(fileId: string): void {
  try {
    const all = getAllBankSessions();
    if (all[fileId]) {
      delete all[fileId];
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(all));
    }
    for (let i = localStorage.length - 1; i >= 0; i -= 1) {
      const k = localStorage.key(i);
      if (k && (k.startsWith(`saved_answer_${fileId}_`) || k.startsWith(`saved_law_answer_${fileId}_`))) {
        localStorage.removeItem(k);
      }
    }
    window.dispatchEvent(new CustomEvent('session-updated', { detail: { fileId } }));
  } catch {
    // Ignore errors
  }
}

export function buildInitialSessionFromBank(
  fileId: string,
  fileName: string,
  bank: QuestionBankJSON
): BankSessionRecord {
  const totalQuestions = bank.questions.length;
  const firstQ = bank.questions[0];
  const isTF = isTrueFalseQuestion(firstQ, bank.type);
  const isSubj = bank.type === 'subjective' || bank.type === 'accounts';
  const bankType: 'mcq' | 'true-false' | 'subjective' = isSubj
    ? 'subjective'
    : isTF
    ? 'true-false'
    : 'mcq';

  return {
    fileId,
    fileName,
    title: bank.title || fileName.replace(/\.json$/i, ''),
    subject: detectCanonicalSubject(bank.subject || '', fileName, bank.title || ''),
    sourceTag: detectQuestionSourceTag(fileName, bank.title || '', bank.chapter),
    bankType,
    status: 'not-started',
    totalQuestions,
    attemptedCount: 0,
    correctCount: 0,
    accuracyPercent: 0,
    currentIndex: 0,
    elapsedSeconds: 0,
    selectedAnswers: {},
    reasonNotes: {},
    visitedIndices: [0],
    updatedAt: new Date().toISOString(),
  };
}
