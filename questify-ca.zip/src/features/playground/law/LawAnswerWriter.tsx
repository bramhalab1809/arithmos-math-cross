import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Icon } from '../../../ui/icons';
import { LawPrecedentsDrawer } from './LawPrecedentsDrawer';
import { LawSlashItem, filterLawSlashItems } from './lawDefinitions';

export const getLawAnswerStorageKey = (bankId: string, questionId: string): string => `saved_law_answer_${bankId}_${questionId}`;

export function loadSavedLawAnswer(bankId: string, questionId: string): string {
  try {
    const raw = localStorage.getItem(getLawAnswerStorageKey(bankId, questionId));
    if (raw) { const p = JSON.parse(raw); if (typeof p.content === 'string') return p.content; }
    const legacy = localStorage.getItem(`law_frame_${bankId}_${questionId}`);
    if (legacy) {
      const f = JSON.parse(legacy);
      const parts = [f.issue, f.provision, f.caseLaw, f.application, f.conclusion].filter((p) => typeof p === 'string' && p.trim());
      if (parts.length > 0) return parts.join('\n\n');
    }
  } catch { /* ignore */ }
  return '';
}

export const hasSavedLawContent = (bankId: string, questionId: string): boolean =>
  loadSavedLawAnswer(bankId, questionId).replace(/<[^>]+>/g, '').trim().length > 0;

export function normalizeLegacyLawMarkupToHtml(raw: string): string {
  if (!raw) return '';
  return raw
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/&lt;(\/?(?:u|b|strong|i|em|br)\s*\/?)&gt;/gi, '<$1>')
    .replace(/^###\s*(.+)$/gm, '<strong><u>$1</u></strong>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/\*([^*]+)\*/g, '<em>$1</em>')
    .replace(/\n/g, '<br/>');
}

function htmlToSavedMarkup(editorEl: HTMLDivElement): string {
  const clone = editorEl.cloneNode(true) as HTMLDivElement;
  clone.querySelectorAll('strong, b').forEach((el) => el.replaceWith(`**${el.textContent || ''}**`));
  clone.querySelectorAll('em, i').forEach((el) => el.replaceWith(`*${el.textContent || ''}*`));
  clone.querySelectorAll('u').forEach((el) => el.replaceWith(`<u>${el.textContent || ''}</u>`));
  clone.querySelectorAll('br').forEach((el) => el.replaceWith('\n'));
  clone.querySelectorAll('div, p').forEach((el) => el.prepend('\n'));
  return (clone.textContent || '').replace(/\u00A0/g, ' ').replace(/^\n+/, '');
}

function formatSnippetHtml(item: LawSlashItem): string {
  const colonIdx = item.snippet.indexOf(':');
  if (colonIdx > 0 && colonIdx < 65) {
    const head = item.snippet.slice(0, colonIdx + 1).replace(/^\*+|\*+$/g, '');
    const rest = normalizeLegacyLawMarkupToHtml(item.snippet.slice(colonIdx + 1));
    return item.category.toLowerCase().includes('case') ? `<strong><em>${head}</em></strong>${rest}` : `<strong><u>${head}</u></strong>${rest}`;
  }
  return normalizeLegacyLawMarkupToHtml(item.snippet);
}

interface LawAnswerWriterProps {
  bankId: string; questionId: string; disabled?: boolean; isQuestionPeekOpen?: boolean;
  onToggleQuestionPeek?: () => void; onStatusChange?: (hasContent: boolean) => void;
}

export const LawAnswerWriter: React.FC<LawAnswerWriterProps> = ({
  bankId, questionId, disabled = false, isQuestionPeekOpen = false, onToggleQuestionPeek, onStatusChange,
}) => {
  const [plainText, setPlainText] = useState<string>('');
  const [isPrecedentsOpen, setIsPrecedentsOpen] = useState<boolean>(false);
  const [slashQuery, setSlashQuery] = useState<string | null>(null);
  const [slashIndex, setSlashIndex] = useState<number>(0);
  const editorRef = useRef<HTMLDivElement | null>(null);
  const activeSlashItemRef = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    const saved = loadSavedLawAnswer(bankId, questionId);
    if (editorRef.current) {
      editorRef.current.innerHTML = normalizeLegacyLawMarkupToHtml(saved);
      setPlainText(editorRef.current.innerText || '');
    }
    setSlashQuery(null);
  }, [bankId, questionId]);

  const syncFromDom = () => {
    const el = editorRef.current;
    if (!el) return;
    const text = (el.innerText || '').replace(/\u00A0/g, ' ');
    setPlainText(text);
    try { localStorage.setItem(getLawAnswerStorageKey(bankId, questionId), JSON.stringify({ content: htmlToSavedMarkup(el), updatedAt: Date.now() })); } catch { /* ignore */ }
    onStatusChange?.(text.trim().length > 0);

    const sel = window.getSelection();
    if (sel && sel.rangeCount > 0 && sel.anchorNode && el.contains(sel.anchorNode)) {
      const nodeText = (sel.anchorNode.textContent || '').slice(0, sel.anchorOffset);
      const m = nodeText.match(/(?:^|[\s\u00A0(])\/([a-zA-Z0-9()-]{0,28})$/);
      if (m) { setSlashQuery(m[1]); setSlashIndex(0); return; }
    }
    setSlashQuery(null);
  };

  const slashMatches = useMemo(() => (slashQuery !== null && !disabled ? filterLawSlashItems(slashQuery) : []), [disabled, slashQuery]);
  const activeSlashIdx = slashMatches.length > 0 ? slashIndex % slashMatches.length : 0;
  const wordCount = useMemo(() => (plainText.trim() ? plainText.trim().split(/\s+/).length : 0), [plainText]);

  useEffect(() => {
    if (slashQuery !== null && activeSlashItemRef.current) activeSlashItemRef.current.scrollIntoView({ block: 'nearest' });
  }, [activeSlashIdx, slashQuery, slashMatches.length]);

  const execFormat = (cmd: 'bold' | 'underline' | 'heading') => {
    const el = editorRef.current;
    if (!el || disabled) return;
    el.focus();
    if (cmd === 'bold') document.execCommand('bold', false);
    else if (cmd === 'underline') document.execCommand('underline', false);
    else if (window.getSelection()?.toString().trim()) {
      document.execCommand('bold', false);
      document.execCommand('underline', false);
    } else {
      document.execCommand('insertHTML', false, '<strong><u>Issue / Legal Provision:</u></strong>&nbsp;');
    }
    syncFromDom();
  };

  const handleInsertPrecedent = (item: LawSlashItem, replaceSlashToken = false) => {
    const el = editorRef.current;
    if (!el || disabled) return;
    el.focus();
    const sel = window.getSelection();
    if (replaceSlashToken && sel && sel.rangeCount > 0 && sel.anchorNode && el.contains(sel.anchorNode)) {
      const node = sel.anchorNode;
      const offset = sel.anchorOffset;
      const slashPos = (node.textContent || '').slice(0, offset).lastIndexOf('/');
      if (slashPos !== -1 && node.nodeType === Node.TEXT_NODE) {
        const range = document.createRange();
        range.setStart(node, slashPos);
        range.setEnd(node, offset);
        sel.removeAllRanges();
        sel.addRange(range);
        document.execCommand('delete', false);
      }
    }
    document.execCommand('insertHTML', false, `${formatSnippetHtml(item)}<br/>`);
    setSlashQuery(null);
    syncFromDom();
  };

  const fmtBtnCls = 'w-7 h-7 rounded-lg text-xs font-bold border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 flex items-center justify-center transition-colors disabled:opacity-40 disabled:pointer-events-none';

  return (
    <div className="flex-1 min-h-0 flex flex-col overflow-hidden bg-white dark:bg-slate-900">
      <div className="px-3.5 py-2 border-b border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-800/80 flex flex-wrap items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-1.5 flex-wrap">
          {onToggleQuestionPeek && (
            <>
              <button type="button" onClick={onToggleQuestionPeek} title="View Question" className={`px-2.5 py-1 rounded-lg text-xs font-semibold border flex items-center gap-1.5 transition-colors ${isQuestionPeekOpen ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-300 border-indigo-200 dark:border-indigo-700' : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-100'}`}>
                <Icon name="eye" size={13} /><span>Question</span>
              </button>
              <span className="h-4 w-px bg-slate-200 dark:bg-slate-700 mx-0.5" />
            </>
          )}
          <button type="button" disabled={disabled} onMouseDown={(e) => { e.preventDefault(); execFormat('bold'); }} className={fmtBtnCls} title="Bold (Ctrl+B)">B</button>
          <button type="button" disabled={disabled} onMouseDown={(e) => { e.preventDefault(); execFormat('underline'); }} className={`${fmtBtnCls} underline`} title="Underline (Ctrl+U)">U</button>
          <button type="button" disabled={disabled} onMouseDown={(e) => { e.preventDefault(); execFormat('heading'); }} className={fmtBtnCls} title="Bold + Underlined Heading">H</button>
          <button type="button" disabled={disabled} onClick={() => setIsPrecedentsOpen(true)} title="Open Legal Precedents & Sections Drawer (or type / in sheet)" className="px-2.5 py-1 rounded-lg text-xs font-semibold border border-indigo-200 dark:border-indigo-700 bg-indigo-50 dark:bg-indigo-950/50 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-300 flex items-center gap-1.5 transition-colors disabled:opacity-40">
            <Icon name="scale" size={13} /><span>Precedents</span>
          </button>
        </div>
        <span className="text-[11px] font-mono-tabular text-slate-500 dark:text-slate-400">{wordCount} words &middot; {plainText.trim().length} chars</span>
      </div>

      <div className="relative flex-1 min-h-0 flex flex-col overflow-hidden">
        {!disabled && slashQuery !== null && (
          <div className="absolute top-11 left-3 sm:left-5 z-50 w-[calc(100%-1.5rem)] sm:w-[430px] rounded-xl border border-indigo-200 dark:border-indigo-800 bg-white dark:bg-slate-900 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-100">
            <div className="px-3 py-1.5 bg-indigo-50/90 dark:bg-indigo-950/70 border-b border-indigo-100 dark:border-indigo-900 flex items-center justify-between text-[11px] font-bold text-indigo-700 dark:text-indigo-300">
              <span className="flex items-center gap-1.5"><Icon name="scale" size={12} /><span>Legal Sections &amp; Precedents ({slashMatches.length})</span></span>
              <button type="button" onMouseDown={(e) => { e.preventDefault(); setSlashQuery(null); }} className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-white dark:bg-slate-800 text-slate-500 border border-slate-200 dark:border-slate-700">ESC</button>
            </div>
            <div className="max-h-52 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
              {slashMatches.length === 0 ? (
                <div className="px-3 py-2.5 text-xs text-slate-500">No section or case matching /{slashQuery}</div>
              ) : (
                slashMatches.map((item, idx) => {
                  const active = idx === activeSlashIdx;
                  return (
                    <button key={item.id} ref={active ? activeSlashItemRef : null} type="button" onMouseDown={(e) => { e.preventDefault(); handleInsertPrecedent(item, true); }} className={`w-full px-3 py-2 text-left flex items-start justify-between gap-2 transition-colors ${active ? 'bg-indigo-600/12 dark:bg-indigo-500/25 text-indigo-700 dark:text-indigo-200' : 'hover:bg-slate-50 dark:hover:bg-slate-800/70'}`}>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-mono font-bold text-indigo-600 dark:text-indigo-400">{item.command}</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500 truncate">{item.category}</span>
                        </div>
                        <p className="text-[11px] font-semibold text-slate-800 dark:text-slate-200 truncate mt-0.5">{item.title}</p>
                      </div>
                      <span className="text-[10px] font-mono text-slate-400 self-center shrink-0">Enter</span>
                    </button>
                  );
                })
              )}
            </div>
          </div>
        )}

        <div className="relative flex-1 min-h-0 overflow-y-auto bg-white dark:bg-slate-900">
          {!plainText.trim() && (
            <div className="pointer-events-none absolute top-3.5 left-4 sm:left-6 right-4 text-sm text-slate-400 dark:text-slate-500 font-mono select-none">
              {disabled ? 'Sheet is locked in Read-Only View Mode.' : 'Draft your Business Law answer here on this ruled answer sheet... (type / for sections & case laws)'}
            </div>
          )}
          <div
            ref={editorRef} contentEditable={!disabled} suppressContentEditableWarning onInput={syncFromDom} onClick={syncFromDom}
            onKeyUp={(e) => { if (!['ArrowDown', 'ArrowUp', 'Enter', 'Escape'].includes(e.key)) syncFromDom(); }}
            onKeyDown={(e) => {
              if (disabled) return;
              if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'b') { e.preventDefault(); execFormat('bold'); return; }
              if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'u') { e.preventDefault(); execFormat('underline'); return; }
              if (slashQuery === null || slashMatches.length === 0) return;
              if (e.key === 'ArrowDown') { e.preventDefault(); setSlashIndex((p) => (p + 1) % slashMatches.length); }
              else if (e.key === 'ArrowUp') { e.preventDefault(); setSlashIndex((p) => (p - 1 + slashMatches.length) % slashMatches.length); }
              else if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); handleInsertPrecedent(slashMatches[slashIndex % slashMatches.length], true); }
              else if (e.key === 'Escape') { e.preventDefault(); setSlashQuery(null); }
            }}
            className={`min-h-full w-full px-4 sm:px-6 py-3.5 law-ruled-sheet text-sm text-slate-900 dark:text-slate-100 focus:outline-none font-mono whitespace-pre-wrap break-words ${disabled ? 'cursor-default select-none' : ''}`}
          />
        </div>
      </div>

      <LawPrecedentsDrawer isOpen={isPrecedentsOpen} onClose={() => setIsPrecedentsOpen(false)} onInsertPrecedent={(item) => handleInsertPrecedent(item, false)} />
    </div>
  );
};
