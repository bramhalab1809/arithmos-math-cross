import { getSubjectScopedTxtFiles } from '../shared/vfsSubjectScoped';

export interface LawSlashItem {
  id: string;
  command: string;
  title: string;
  category: string;
  snippet: string;
}

export const LAW_SLASH_CATALOG: LawSlashItem[] = [
  {
    id: 'law_heading_issue',
    command: '/issue',
    title: '1. Legal Issue / Question of Law Heading',
    category: 'ICAI Answer Framework',
    snippet: '1. Legal Issue: Whether under the provisions of the relevant Act, ',
  },
  {
    id: 'law_heading_provision',
    command: '/provision',
    title: '2. Relevant Legal Provision & Section Heading',
    category: 'ICAI Answer Framework',
    snippet: '2. Relevant Legal Provision: As per the applicable provisions of the Act, ',
  },
  {
    id: 'law_heading_analysis',
    command: '/analysis',
    title: '3. Analysis & Application to Facts Heading',
    category: 'ICAI Answer Framework',
    snippet: '3. Analysis & Application: Applying the aforesaid statutory provisions and judicial precedent to the given facts, ',
  },
  {
    id: 'law_heading_conclusion',
    command: '/conclusion',
    title: '4. Final Conclusion Heading',
    category: 'ICAI Answer Framework',
    snippet: '4. Conclusion: Therefore, in view of the above legal provision, ',
  },
  {
    id: 'law_sec_2_20',
    command: '/sec2(20)',
    title: 'Section 2(20) - Definition of Company (Companies Act, 2013)',
    category: 'Companies Act, 2013',
    snippet: 'Section 2(20) of the Companies Act, 2013: "Company" means a company incorporated under this Act or under any previous company law.',
  },
  {
    id: 'law_case_salomon',
    command: '/salomon',
    title: 'Salomon v. Salomon & Co. Ltd. - Separate Legal Entity',
    category: 'Case Law Precedent',
    snippet: 'Salomon v. Salomon & Co. Ltd. (1897): A company once incorporated becomes a separate legal person distinct from its members and shareholders.',
  },
  {
    id: 'law_case_dinshaw',
    command: '/dinshaw',
    title: 'Re Sir Dinshaw Maneckjee Petit - Lifting of Corporate Veil',
    category: 'Case Law Precedent',
    snippet: 'In Re, Sir Dinshaw Maneckjee Petit (1927): Where the corporate facade is formed solely for tax evasion or to circumvent revenue obligations, the Court will lift the corporate veil.',
  },
  {
    id: 'law_case_daimler',
    command: '/daimler',
    title: 'Daimler Co. Ltd. v. Continental Tyre & Rubber Co. - Enemy Character',
    category: 'Case Law Precedent',
    snippet: 'Daimler Co. Ltd. v. Continental Tyre & Rubber Co. (1916): The corporate veil may be lifted to ascertain whether the company is controlled by alien enemies.',
  },
  {
    id: 'law_case_gilford',
    command: '/gilford',
    title: 'Gilford Motor Co. v. Horne - Avoidance of Legal Obligation',
    category: 'Case Law Precedent',
    snippet: 'Gilford Motor Co. Ltd. v. Horne (1933): Where a company is incorporated as a mere cloak or sham to evade a contractual restraint, the court will pierce the corporate veil.',
  },
  {
    id: 'law_sec_2_62',
    command: '/sec2(62)',
    title: 'Section 2(62) - One Person Company (OPC)',
    category: 'Companies Act, 2013',
    snippet: 'Section 2(62) of the Companies Act, 2013: "One Person Company" means a company which has only one person as a member.',
  },
  {
    id: 'law_sec_2_85',
    command: '/sec2(85)',
    title: 'Section 2(85) - Small Company Definition & Thresholds',
    category: 'Companies Act, 2013',
    snippet: 'Section 2(85) of the Companies Act, 2013: "Small Company" means a company, other than a public company, whose paid-up share capital does not exceed Rs. 4 Crore and turnover does not exceed Rs. 40 Crore.',
  },
  {
    id: 'law_sec_8',
    command: '/sec8',
    title: 'Section 8 - Formation of Companies with Charitable Objects',
    category: 'Companies Act, 2013',
    snippet: 'Section 8 of the Companies Act, 2013: A company registered for promotion of commerce, art, science, sports, education, or charity applies its profits strictly to promote its objects and is prohibited from paying any dividend to its members.',
  },
  {
    id: 'law_doctrine_uv',
    command: '/ultravires',
    title: 'Ashbury Railway Carriage Co. v. Riche - Doctrine of Ultra Vires',
    category: 'Case Law Precedent',
    snippet: 'Ashbury Railway Carriage and Iron Co. Ltd. v. Riche (1875): Any act done or contract made by a company which travels beyond the powers stated in the Object Clause of its Memorandum of Association is wholly ultra vires, void ab initio, and cannot be ratified even by unanimous consent of all shareholders.',
  },
  {
    id: 'law_doctrine_turquand',
    command: '/turquand',
    title: 'Royal British Bank v. Turquand - Doctrine of Indoor Management',
    category: 'Case Law Precedent',
    snippet: 'Royal British Bank v. Turquand (1856): Outsiders dealing with a company in good faith are entitled to assume that internal company proceedings and approvals required by the Articles have been regularly complied with.',
  },
  {
    id: 'law_sec_10_ica',
    command: '/sec10',
    title: 'Section 10 - What Agreements are Contracts (Indian Contract Act, 1872)',
    category: 'Indian Contract Act, 1872',
    snippet: 'Section 10 of the Indian Contract Act, 1872: All agreements are contracts if they are made by the free consent of parties competent to contract, for a lawful consideration and with a lawful object, and are not hereby expressly declared to be void.',
  },
  {
    id: 'law_case_carbolic',
    command: '/carbolic',
    title: 'Carlill v. Carbolic Smoke Ball Co. - General Offer',
    category: 'Case Law Precedent',
    snippet: 'Carlill v. Carbolic Smoke Ball Co. (1893): A general offer made to the public at large can be accepted by anyone who performs the stipulated conditions with knowledge of the offer.',
  },
  {
    id: 'law_case_balfour',
    command: '/balfour',
    title: 'Balfour v. Balfour - Intention to Create Legal Relationship',
    category: 'Case Law Precedent',
    snippet: 'Balfour v. Balfour (1919): Domestic and social agreements between spouses do not result in a legally binding contract in the absence of a clear intention to create legal relations.',
  },
  {
    id: 'law_case_mohori',
    command: '/mohori',
    title: 'Mohori Bibee v. Dharmodas Ghose - Minor Agreement Void Ab Initio',
    category: 'Case Law Precedent',
    snippet: 'Mohori Bibee v. Dharmodas Ghose (1903): Under Section 11 of the Indian Contract Act, 1872, an agreement with a minor is void ab initio and completely unenforceable.',
  },
  {
    id: 'law_sec_73_ica',
    command: '/sec73',
    title: 'Section 73 - Compensation for Loss or Damage Caused by Breach',
    category: 'Indian Contract Act, 1872',
    snippet: 'Section 73 of the Indian Contract Act, 1872 (Hadley v. Baxendale): The party who suffers by a breach of contract is entitled to receive compensation for any loss or damage which naturally arose in the usual course of things from such breach.',
  },
  {
    id: 'law_sec_12_soga',
    command: '/sec12soga',
    title: 'Section 12 - Condition and Warranty (Sale of Goods Act, 1930)',
    category: 'Sale of Goods Act, 1930',
    snippet: 'Section 12 of the Sale of Goods Act, 1930: A Condition is a stipulation essential to the main purpose of the contract, breach of which gives a right to repudiate the contract; a Warranty is collateral to the main purpose, breach of which gives rise to a claim for damages only.',
  },
  {
    id: 'law_sec_16_soga',
    command: '/caveatemptor',
    title: 'Section 16 - Doctrine of Caveat Emptor & Implied Conditions',
    category: 'Sale of Goods Act, 1930',
    snippet: 'Section 16 of the Sale of Goods Act, 1930: Subject to the provisions of this Act, there is no implied warranty or condition as to the quality or fitness for any particular purpose of goods supplied under a contract of sale (Caveat Emptor), except where the buyer makes known the purpose and relies on the seller skill and judgment.',
  },
  {
    id: 'law_sec_4_ipa',
    command: '/sec4ipa',
    title: 'Section 4 & 6 - Partnership & Mutual Agency (Cox v. Hickman)',
    category: 'Indian Partnership Act, 1932',
    snippet: 'Section 4 & Section 6 of the Indian Partnership Act, 1932 (Cox v. Hickman): Mutual agency—that business must be carried on by all or any of them acting for all—is the cardinal test of partnership.',
  },
  {
    id: 'law_sec_5_llp',
    command: '/llp',
    title: 'Section 3 & 27 - LLP Separate Legal Entity & Limited Liability',
    category: 'LLP Act, 2008',
    snippet: 'Section 3 of the Limited Liability Partnership Act, 2008: An LLP is a body corporate formed and incorporated under this Act and is a legal entity separate from that of its partners, having perpetual succession.',
  },
];

export function getAllLawSlashItems(selectedFolderId: string | 'ALL' = 'ALL'): LawSlashItem[] {
  const customFiles = getSubjectScopedTxtFiles('fld_business_law', selectedFolderId);
  const dynamicItems: LawSlashItem[] = customFiles.map(({ file, folderName }) => {
    const cleanStem = file.name.replace(/\.txt$/i, '').trim();
    const slug = cleanStem.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 18) || 'note';
    const snippetText = (file.content || '').trim() || cleanStem;
    return {
      id: `vfs_law_${file.id}`,
      command: `/${slug}`,
      title: cleanStem,
      category: folderName || 'Business Law Note (.txt)',
      snippet: `${cleanStem}: ${snippetText.replace(/^#+\s*/gm, '').replace(/\n+/g, ' ')}`,
    };
  });

  if (selectedFolderId !== 'ALL') {
    return [...dynamicItems, ...LAW_SLASH_CATALOG];
  }
  return [...LAW_SLASH_CATALOG, ...dynamicItems];
}

export function filterLawSlashItems(query: string, selectedFolderId: string | 'ALL' = 'ALL'): LawSlashItem[] {
  const all = getAllLawSlashItems(selectedFolderId);
  const clean = query.replace(/^\//, '').trim().toLowerCase();
  if (!clean) return all;
  return all.filter(
    (item) =>
      item.command.toLowerCase().includes(clean) ||
      item.title.toLowerCase().includes(clean) ||
      item.category.toLowerCase().includes(clean) ||
      item.snippet.toLowerCase().includes(clean)
  );
}
