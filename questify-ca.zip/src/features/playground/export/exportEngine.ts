import { QuestionItem, TableData } from '../../explorer/engine/vfsTypes';
import { AccountCardData, WorkspaceBlock, evaluateMathAmount, formatInrAmount, sumAccountRows } from '../accounts/accountDefinitions';
import { loadSavedLawAnswer } from '../law/LawAnswerWriter';
import { loadSavedDigitalAnswer } from '../subjective/DigitalAnswerWriter';
import { getUnifiedQuestionStatement } from '../subjective/QuestionPeekSheet';

export interface JpgExportOptions {
  includeQuestion: boolean;
  includeAccounts: boolean;
  includeWorkingNotes: boolean;
}

export interface ExportContext {
  bankId: string;
  bankTitle: string;
  subject: string;
  questionNumber: number;
  question: QuestionItem;
  isLawSubject: boolean;
}

export interface ResolvedStudentSolution {
  blocks: WorkspaceBlock[];
  accountCards: AccountCardData[];
  workingNotesText: string[];
  lawText: string;
}

export function resolveStudentSolution(ctx: ExportContext): ResolvedStudentSolution {
  const qId = ctx.question.id || `q_${ctx.questionNumber - 1}`;
  const savedDigital = loadSavedDigitalAnswer(ctx.bankId, qId);
  const lawText = loadSavedLawAnswer(ctx.bankId, qId);

  const accountCards: AccountCardData[] = [];
  const workingNotesText: string[] = [];

  savedDigital.blocks.forEach((b) => {
    if (b.type === 'account') accountCards.push(b.data);
    else if (b.content.trim()) workingNotesText.push(b.content.trim());
  });

  return { blocks: savedDigital.blocks, accountCards, workingNotesText, lawText };
}

export function triggerBlobDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.setTimeout(() => URL.revokeObjectURL(url), 3000);
}

export function safeFileSlug(title: string, qNum: number): string {
  const base = title.replace(/[^a-zA-Z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 36) || 'CA_Practice';
  return `${base}_Q${qNum}`;
}

function formatTableAsMarkdown(tbl: TableData): string {
  const lines: string[] = [];
  if (tbl.title) lines.push(`#### ${tbl.title}`);
  lines.push(`| ${tbl.headers.join(' | ')} |`);
  lines.push(`| ${tbl.headers.map(() => '---').join(' | ')} |`);
  tbl.rows.forEach((r) => lines.push(`| ${r.join(' | ')} |`));
  if (tbl.totals && tbl.totals.length > 0) {
    lines.push(`| ${tbl.totals.map((t) => `**${t}**`).join(' | ')} |`);
  }
  return lines.join('\n');
}

function formatAccountCardAsMarkdown(card: AccountCardData): string {
  const maxRows = Math.max(card.leftRows.length, (card.rightRows || []).length, 1);
  const lines: string[] = [
    `### ${card.title}`,
    `| ${card.leftTitle} | W.N. | Amount (Rs.) | ${card.rightTitle || 'Particulars (Cr.)'} | W.N. | Amount (Rs.) |`,
    `| --- | :---: | ---: | --- | :---: | ---: |`,
  ];
  for (let i = 0; i < maxRows; i += 1) {
    const l = card.leftRows[i];
    const r = (card.rightRows || [])[i];
    const lAmt = l?.amount ? formatInrAmount(evaluateMathAmount(l.amount)) : '';
    const rAmt = r?.amount ? formatInrAmount(evaluateMathAmount(r.amount)) : '';
    const lWn = l?.workingNoteRef?.label || '';
    const rWn = r?.workingNoteRef?.label || '';
    lines.push(`| ${l?.particulars || ''} | ${lWn} | ${lAmt} | ${r?.particulars || ''} | ${rWn} | ${rAmt} |`);
  }
  const lTot = formatInrAmount(sumAccountRows(card.leftRows));
  const rTot = formatInrAmount(sumAccountRows(card.rightRows));
  lines.push(`| **Total** | | **${lTot}** | **Total** | | **${rTot}** |`);
  return lines.join('\n');
}

export function buildMarkdownDocument(ctx: ExportContext): string {
  const sol = resolveStudentSolution(ctx);
  const qText = getUnifiedQuestionStatement(ctx.question);
  const allTables = [...(ctx.question.table ? [ctx.question.table] : []), ...(ctx.question.tables || [])];
  const parts: string[] = [
    `# ${ctx.bankTitle}`,
    `**Question ${ctx.questionNumber}** · **Marks:** ${ctx.question.marks || 5} · **Topic:** ${ctx.question.topic || ctx.subject || 'CA Foundation'}`,
    `---`,
    `## Question Statement`,
    qText,
  ];
  allTables.forEach((t) => parts.push(formatTableAsMarkdown(t)));
  parts.push(`---`, `## Student Answer`);

  if (ctx.isLawSubject) {
    parts.push(sol.lawText.trim() || '*No legal answer recorded.*');
  } else {
    sol.accountCards.forEach((c) => parts.push(formatAccountCardAsMarkdown(c)));
    if (sol.workingNotesText.length > 0) {
      parts.push(`### Working Notes & Calculations`, sol.workingNotesText.join('\n\n'));
    }
    if (sol.accountCards.length === 0 && sol.workingNotesText.length === 0) {
      parts.push('*No solution recorded.*');
    }
  }
  return parts.join('\n\n');
}

export function buildTxtDocument(ctx: ExportContext): string {
  const sol = resolveStudentSolution(ctx);
  const qText = getUnifiedQuestionStatement(ctx.question).replace(/\*\*/g, '');
  const allTables = [...(ctx.question.table ? [ctx.question.table] : []), ...(ctx.question.tables || [])];
  const lines: string[] = [
    `================================================================================`,
    `${ctx.bankTitle.toUpperCase()}`,
    `Question ${ctx.questionNumber} (${ctx.question.marks || 5} Marks) - ${ctx.question.topic || ctx.subject || 'CA Foundation'}`,
    `================================================================================`,
    ``,
    `QUESTION STATEMENT:`,
    qText,
  ];

  allTables.forEach((tbl) => {
    lines.push(``, tbl.title ? `[${tbl.title}]` : `[Schedule]`, tbl.headers.join(' | '), `-`.repeat(72));
    tbl.rows.forEach((r) => lines.push(r.join(' | ')));
    if (tbl.totals) lines.push(`-`.repeat(72), tbl.totals.join(' | '));
  });

  lines.push(``, `--------------------------------------------------------------------------------`, `STUDENT SOLUTION:`, `--------------------------------------------------------------------------------`);

  if (ctx.isLawSubject) {
    lines.push((sol.lawText.trim() || 'No legal answer written.').replace(/<\/?u>/gi, '').replace(/\*\*/g, ''));
  } else {
    sol.accountCards.forEach((card) => {
      lines.push(``, `>>> ${card.title} <<<`, `-`.repeat(78));
      const maxR = Math.max(card.leftRows.length, (card.rightRows || []).length, 1);
      for (let i = 0; i < maxR; i += 1) {
        const l = card.leftRows[i], r = (card.rightRows || [])[i];
        const lWn = l?.workingNoteRef?.label ? ` (${l.workingNoteRef.label})` : '';
        const rWn = r?.workingNoteRef?.label ? ` (${r.workingNoteRef.label})` : '';
        const lAmt = l?.amount ? formatInrAmount(evaluateMathAmount(l.amount)) : '';
        const rAmt = r?.amount ? formatInrAmount(evaluateMathAmount(r.amount)) : '';
        lines.push(`${(`${(l?.particulars || '') + lWn}`.padEnd(26).slice(0, 26) + lAmt.padStart(11))} | ${(`${(r?.particulars || '') + rWn}`.padEnd(26).slice(0, 26) + rAmt.padStart(11))}`);
      }
      lines.push(`-`.repeat(78));
      lines.push(`${'Total'.padEnd(26)}${formatInrAmount(sumAccountRows(card.leftRows)).padStart(11)} | ${'Total'.padEnd(26)}${formatInrAmount(sumAccountRows(card.rightRows)).padStart(11)}`);
    });
    if (sol.workingNotesText.length > 0) {
      lines.push(``, `WORKING NOTES & CALCULATIONS:`, sol.workingNotesText.join('\n\n'));
    }
  }
  return lines.join('\n');
}

export function exportAsTxt(ctx: ExportContext): void {
  triggerBlobDownload(new Blob([buildTxtDocument(ctx)], { type: 'text/plain;charset=utf-8' }), `${safeFileSlug(ctx.bankTitle, ctx.questionNumber)}.txt`);
}

export function exportAsMarkdown(ctx: ExportContext): void {
  triggerBlobDownload(new Blob([buildMarkdownDocument(ctx)], { type: 'text/markdown;charset=utf-8' }), `${safeFileSlug(ctx.bankTitle, ctx.questionNumber)}.md`);
}

export function exportAsJson(ctx: ExportContext): void {
  const sol = resolveStudentSolution(ctx);
  const payload = {
    exportedAt: new Date().toISOString(),
    bankTitle: ctx.bankTitle,
    subject: ctx.subject,
    questionNumber: ctx.questionNumber,
    question: ctx.question,
    studentSolution: ctx.isLawSubject
      ? { subjectType: 'Business Law', lawAnswer: sol.lawText }
      : { subjectType: 'Accounting', accountCards: sol.accountCards, workingNotes: sol.workingNotesText },
  };
  triggerBlobDownload(new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json;charset=utf-8' }), `${safeFileSlug(ctx.bankTitle, ctx.questionNumber)}.json`);
}
