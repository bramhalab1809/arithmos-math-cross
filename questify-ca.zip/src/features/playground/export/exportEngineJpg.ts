import { TableData } from '../../explorer/engine/vfsTypes';
import { AccountCardData, evaluateMathAmount, formatInrAmount, sumAccountRows } from '../accounts/accountDefinitions';
import { getUnifiedQuestionStatement } from '../subjective/QuestionPeekSheet';
import { ExportContext, JpgExportOptions, resolveStudentSolution, triggerBlobDownload } from './exportEngine';

const PAGE_W = 1240;
const PAD = 56;
const CONTENT_W = PAGE_W - PAD * 2;

function wrapLines(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
  const result: string[] = [];
  for (const rawLine of text.split('\n')) {
    const clean = rawLine.replace(/<\/?u>/gi, '').replace(/\*\*/g, '');
    if (!clean.trim()) { result.push(''); continue; }
    let current = '';
    for (const w of clean.split(/\s+/)) {
      const test = current ? `${current} ${w}` : w;
      if (ctx.measureText(test).width > maxWidth && current) { result.push(current); current = w; }
      else current = test;
    }
    if (current) result.push(current);
  }
  return result;
}

function makeSheetCanvas(height: number, exportCtx: ExportContext, subtitle: string): { canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D; y: number } {
  const canvas = document.createElement('canvas');
  canvas.width = PAGE_W;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, PAGE_W, height);
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(PAD, 40, CONTENT_W, 74);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 21px Inter, sans-serif';
  ctx.fillText(`${exportCtx.bankTitle.toUpperCase()} — Q${exportCtx.questionNumber}`, PAD + 20, 72);
  ctx.font = '600 14px Inter, sans-serif';
  ctx.fillStyle = '#cbd5e1';
  ctx.fillText(`${subtitle}  |  Topic: ${exportCtx.question.topic || exportCtx.subject}  |  ${exportCtx.question.marks || 5} Marks`, PAD + 20, 98);
  return { canvas, ctx, y: 144 };
}

function saveJpg(canvas: HTMLCanvasElement, filename: string): void {
  canvas.toBlob((blob) => { if (blob) triggerBlobDownload(blob, filename); }, 'image/jpeg', 0.95);
}

function renderQuestionStatementJpg(exportCtx: ExportContext, qNum: number): void {
  const probe = document.createElement('canvas').getContext('2d')!;
  probe.font = '16px Inter, sans-serif';
  const qLines = wrapLines(probe, getUnifiedQuestionStatement(exportCtx.question), CONTENT_W - 24);
  const tables: TableData[] = [...(exportCtx.question.table ? [exportCtx.question.table] : []), ...(exportCtx.question.tables || [])];
  const tablesH = tables.reduce((s, t) => s + 76 + (t.rows.length + (t.totals ? 1 : 0)) * 34, 0);
  const { canvas, ctx, y: startY } = makeSheetCanvas(Math.max(520, 190 + qLines.length * 26 + tablesH + 70), exportCtx, 'SHEET 1: QUESTION STATEMENT');
  let y = startY;
  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 16px Inter, sans-serif';
  ctx.fillText('QUESTION STATEMENT', PAD, y);
  y += 26;
  ctx.font = '16px Inter, sans-serif';
  ctx.fillStyle = '#1e293b';
  for (const line of qLines) { ctx.fillText(line, PAD, y); y += 26; }

  for (const tbl of tables) {
    y += 14;
    if (tbl.title) { ctx.font = 'bold 15px Inter, sans-serif'; ctx.fillStyle = '#0f172a'; ctx.fillText(tbl.title.toUpperCase(), PAD, y); y += 14; }
    const colW = CONTENT_W / Math.max(1, tbl.headers.length);
    ctx.fillStyle = '#e2e8f0'; ctx.fillRect(PAD, y, CONTENT_W, 34);
    ctx.strokeStyle = '#0f172a'; ctx.strokeRect(PAD, y, CONTENT_W, 34);
    ctx.fillStyle = '#0f172a'; ctx.font = 'bold 14px Inter, sans-serif';
    tbl.headers.forEach((h, i) => ctx.fillText(h.slice(0, 34), PAD + i * colW + 10, y + 22));
    y += 34;
    const allRows = [...tbl.rows, ...(tbl.totals ? [tbl.totals] : [])];
    allRows.forEach((row, rIdx) => {
      const isTot = Boolean(tbl.totals && rIdx === allRows.length - 1);
      ctx.fillStyle = isTot ? '#f1f5f9' : '#ffffff';
      ctx.fillRect(PAD, y, CONTENT_W, 32); ctx.strokeRect(PAD, y, CONTENT_W, 32);
      ctx.fillStyle = '#0f172a'; ctx.font = isTot ? 'bold 14px Inter, sans-serif' : '14px Inter, sans-serif';
      row.forEach((cell, cIdx) => ctx.fillText(String(cell).slice(0, 36), PAD + cIdx * colW + 10, y + 21));
      y += 32;
    });
  }
  saveJpg(canvas, `Q${qNum}_1_Question_Statement.jpg`);
}

function renderSolutionAccountsJpg(exportCtx: ExportContext, qNum: number): void {
  const sol = resolveStudentSolution(exportCtx);
  const probe = document.createElement('canvas').getContext('2d')!;
  probe.font = '16px Inter, sans-serif';

  if (exportCtx.isLawSubject) {
    const lawLines = wrapLines(probe, sol.lawText.trim() || 'No legal solution recorded.', CONTENT_W - 36);
    const totalH = Math.max(540, 200 + lawLines.length * 30 + 70);
    const { canvas, ctx, y: startY } = makeSheetCanvas(totalH, exportCtx, 'SHEET 2: BUSINESS LAW DESCRIPTIVE SOLUTION');
    let y = startY;
    ctx.strokeStyle = '#dc2626'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(PAD + 14, y - 10); ctx.lineTo(PAD + 14, totalH - 40); ctx.stroke();
    for (const line of lawLines) {
      ctx.strokeStyle = '#e2e8f0'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(PAD, y + 8); ctx.lineTo(PAGE_W - PAD, y + 8); ctx.stroke();
      const isHeading = /^(issue|provision|statutory|analysis|application|conclusion|section)/i.test(line.trim());
      ctx.font = isHeading ? 'bold 16px Inter, sans-serif' : '16px Inter, sans-serif';
      ctx.fillStyle = '#0f172a'; ctx.fillText(line, PAD + 26, y);
      y += 30;
    }
    saveJpg(canvas, `Q${qNum}_2_Solution_Accounts.jpg`);
    return;
  }

  const cards: AccountCardData[] = sol.accountCards;
  const cardsH = cards.reduce((acc, c) => acc + 115 + Math.max(c.leftRows.length, (c.rightRows || []).length, 1) * 34, 0);
  const { canvas, ctx, y: startY } = makeSheetCanvas(Math.max(520, 180 + Math.max(120, cardsH) + 60), exportCtx, 'SHEET 2: LEDGER ACCOUNTS & STATEMENTS');
  let y = startY;
  const halfW = CONTENT_W / 2;
  const amtW = 155;

  cards.forEach((card) => {
    ctx.fillStyle = '#0f172a'; ctx.font = 'bold 17px Inter, sans-serif';
    ctx.fillText(card.title.toUpperCase(), PAD, y); y += 12;
    ctx.fillStyle = '#e2e8f0'; ctx.fillRect(PAD, y, CONTENT_W, 34);
    ctx.strokeStyle = '#0f172a'; ctx.lineWidth = 1.5; ctx.strokeRect(PAD, y, CONTENT_W, 34);
    ctx.font = 'bold 14px Inter, sans-serif'; ctx.fillStyle = '#0f172a';
    ctx.fillText(card.leftTitle || 'Particulars (Dr.)', PAD + 10, y + 22);
    ctx.fillText('Amount (Rs.)', PAD + halfW - amtW + 14, y + 22);
    ctx.fillText(card.rightTitle || 'Particulars (Cr.)', PAD + halfW + 10, y + 22);
    ctx.fillText('Amount (Rs.)', PAD + CONTENT_W - amtW + 14, y + 22);
    y += 34;

    const maxR = Math.max(card.leftRows.length, (card.rightRows || []).length, 1);
    for (let i = 0; i < maxR; i += 1) {
      const dr = card.leftRows[i]; const cr = (card.rightRows || [])[i];
      ctx.strokeRect(PAD, y, halfW, 32); ctx.strokeRect(PAD + halfW, y, halfW, 32);
      ctx.font = '14px Inter, sans-serif'; ctx.fillStyle = '#0f172a';
      ctx.fillText(`${dr?.particulars || ''}${dr?.workingNoteRef ? ` (${dr.workingNoteRef.label})` : ''}`.slice(0, 38), PAD + 10, y + 21);
      ctx.fillText(`${cr?.particulars || ''}${cr?.workingNoteRef ? ` (${cr.workingNoteRef.label})` : ''}`.slice(0, 38), PAD + halfW + 10, y + 21);
      if (dr?.amount) ctx.fillText(formatInrAmount(evaluateMathAmount(dr.amount)), PAD + halfW - amtW + 14, y + 21);
      if (cr?.amount) ctx.fillText(formatInrAmount(evaluateMathAmount(cr.amount)), PAD + CONTENT_W - amtW + 14, y + 21);
      y += 32;
    }

    ctx.fillStyle = '#f1f5f9'; ctx.fillRect(PAD, y, CONTENT_W, 34); ctx.strokeRect(PAD, y, CONTENT_W, 34);
    ctx.fillStyle = '#0f172a'; ctx.font = 'bold 14px Inter, sans-serif';
    ctx.fillText('Total', PAD + 10, y + 22);
    ctx.fillText(formatInrAmount(sumAccountRows(card.leftRows)), PAD + halfW - amtW + 14, y + 22);
    ctx.fillText('Total', PAD + halfW + 10, y + 22);
    ctx.fillText(formatInrAmount(sumAccountRows(card.rightRows)), PAD + CONTENT_W - amtW + 14, y + 22);
    y += 52;
  });

  saveJpg(canvas, `Q${qNum}_2_Solution_Accounts.jpg`);
}

function renderWorkingNotesJpg(exportCtx: ExportContext, qNum: number): void {
  const sol = resolveStudentSolution(exportCtx);
  const probe = document.createElement('canvas').getContext('2d')!;
  probe.font = '16px Inter, sans-serif';
  const lines = wrapLines(probe, sol.workingNotesText.join('\n\n') || 'No working notes recorded.', CONTENT_W - 24);
  const { canvas, ctx, y: startY } = makeSheetCanvas(Math.max(480, 190 + lines.length * 28 + 60), exportCtx, 'SHEET 3: WORKING NOTES & CALCULATIONS');
  let y = startY;
  for (const line of lines) {
    const isWn = /^(working note\s*\d+)/i.test(line.trim());
    ctx.font = isWn ? 'bold 16px Inter, sans-serif' : '15px Inter, sans-serif';
    ctx.fillStyle = isWn ? '#0f172a' : '#1e293b';
    ctx.fillText(line, PAD, y); y += 28;
  }
  saveJpg(canvas, `Q${qNum}_3_Working_Notes.jpg`);
}

export function exportAsJpg(exportCtx: ExportContext, options: JpgExportOptions): void {
  const qNum = exportCtx.questionNumber;
  let delay = 0;
  if (options.includeQuestion) { window.setTimeout(() => renderQuestionStatementJpg(exportCtx, qNum), delay); delay += 180; }
  if (options.includeAccounts) { window.setTimeout(() => renderSolutionAccountsJpg(exportCtx, qNum), delay); delay += 180; }
  if (!exportCtx.isLawSubject && options.includeWorkingNotes) { window.setTimeout(() => renderWorkingNotesJpg(exportCtx, qNum), delay); }
}
