import React, { useState } from 'react';
import { Icon } from '../../../ui/icons';
import {
  ExportContext,
  JpgExportOptions,
  exportAsJson,
  exportAsMarkdown,
  exportAsTxt,
} from './exportEngine';
import { exportAsJpg } from './exportEngineJpg';
import { exportAsPdf } from './exportEnginePdf';

interface ExportModalProps {
  isOpen: boolean;
  exportContext: ExportContext | null;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, exportContext, onClose }) => {
  const [jpgOptions, setJpgOptions] = useState<JpgExportOptions>({
    includeQuestion: true,
    includeAccounts: true,
    includeWorkingNotes: true,
  });
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  if (!isOpen || !exportContext) return null;
  const isLaw = exportContext.isLawSubject;

  const notifyExport = (label: string) => {
    setStatusMessage(`Exported ${label} successfully!`);
    window.setTimeout(() => setStatusMessage(null), 2200);
  };

  const handleExportPdf = () => {
    exportAsPdf(exportContext);
    notifyExport('PDF Printable Exam Document');
  };

  const handleExportJpg = () => {
    if (!jpgOptions.includeQuestion && !jpgOptions.includeAccounts && (isLaw || !jpgOptions.includeWorkingNotes)) return;
    exportAsJpg(exportContext, jpgOptions);
    notifyExport('Separate High-Res JPG Sheets');
  };

  const toggleJpgCheck = (key: keyof JpgExportOptions) => setJpgOptions((prev) => ({ ...prev, [key]: !prev[key] }));

  const checkboxItems: { key: keyof JpgExportOptions; label: string }[] = isLaw
    ? [
        { key: 'includeQuestion', label: 'Question Statement' },
        { key: 'includeAccounts', label: 'Legal Answer Solution' },
      ]
    : [
        { key: 'includeQuestion', label: 'Question Statement' },
        { key: 'includeAccounts', label: 'Ledger Accounts & Solution' },
        { key: 'includeWorkingNotes', label: 'Working Notes & Calculations' },
      ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150" onClick={onClose}>
      <div className="w-full max-w-lg rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-2xl overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-800/60">
          <div className="flex items-center gap-2.5">
            <span className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center">
              <Icon name="download" size={16} />
            </span>
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">Multi-Format Solution Export Suite</h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Q{exportContext.questionNumber} &middot; {exportContext.bankTitle} ({isLaw ? 'Business Law' : 'Accounting'})
              </p>
            </div>
          </div>
          <button type="button" onClick={onClose} className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200/50 dark:hover:bg-slate-800" aria-label="Close Export Modal">
            <Icon name="x" size={16} />
          </button>
        </div>

        <div className="p-5 space-y-3.5 max-h-[78dvh] overflow-y-auto">
          {statusMessage && (
            <div className="px-3.5 py-2 rounded-xl bg-emerald-500/12 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 text-xs font-semibold flex items-center gap-2">
              <Icon name="check" size={14} /><span>{statusMessage}</span>
            </div>
          )}

          <div className="p-3.5 rounded-xl border border-indigo-200 dark:border-indigo-800/70 bg-indigo-50/40 dark:bg-indigo-950/25 flex items-center justify-between gap-3">
            <div className="min-w-0">
              <div className="text-xs font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                <Icon name="file-text" size={14} className="text-indigo-600 dark:text-indigo-400" />
                <span>PDF Printable Exam Document (.pdf)</span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                {isLaw
                  ? 'Full Question Statement & Ruled Legal Answer Sheet with Case Citations'
                  : 'Full Question Statement, HTML Dr/Cr Ledger Tables, Totals & Working Notes'}
              </p>
            </div>
            <button type="button" onClick={handleExportPdf} className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shrink-0 flex items-center gap-1.5 transition-colors shadow-2xs">
              <Icon name="download" size={13} /><span>Export PDF</span>
            </button>
          </div>

          <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/60 dark:bg-slate-800/40 space-y-3">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-xs font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                  <Icon name="image" size={14} className="text-sky-600 dark:text-cyan-400" />
                  <span>Separate High-Resolution JPG Sheets (.jpg)</span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  Downloads dedicated, crystal-clear JPG files for each selected section
                </p>
              </div>
              <button type="button" onClick={handleExportJpg} className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-sky-600 hover:bg-sky-700 text-white shrink-0 flex items-center gap-1.5 transition-colors shadow-2xs">
                <Icon name="download" size={13} /><span>Export JPG</span>
              </button>
            </div>

            <div className={`grid grid-cols-1 ${isLaw ? 'sm:grid-cols-2' : 'sm:grid-cols-3'} gap-2 pt-1`}>
              {checkboxItems.map((item) => {
                const checked = jpgOptions[item.key];
                return (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => toggleJpgCheck(item.key)}
                    className={`px-2.5 py-2 rounded-lg border text-left text-[11px] font-semibold flex items-center gap-2 transition-colors ${
                      checked
                        ? 'bg-white dark:bg-slate-900 border-sky-500 text-slate-900 dark:text-slate-100'
                        : 'bg-slate-100/60 dark:bg-slate-900/40 border-slate-200 dark:border-slate-700 text-slate-400'
                    }`}
                  >
                    <span className={`w-4 h-4 rounded flex items-center justify-center border shrink-0 ${checked ? 'bg-sky-600 border-sky-600 text-white' : 'border-slate-300 dark:border-slate-600'}`}>
                      {checked && <Icon name="check" size={11} />}
                    </span>
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <button type="button" onClick={() => { exportAsTxt(exportContext); notifyExport('Plain-Text (.txt)'); }} className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-indigo-400 text-left transition-colors space-y-1">
              <div className="flex items-center justify-between text-xs font-bold text-slate-900 dark:text-slate-100"><span>TXT Export</span><Icon name="file-text" size={14} className="text-slate-500" /></div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">Aligned plain-text transcript</p>
            </button>
            <button type="button" onClick={() => { exportAsMarkdown(exportContext); notifyExport('Markdown (.md)'); }} className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-indigo-400 text-left transition-colors space-y-1">
              <div className="flex items-center justify-between text-xs font-bold text-slate-900 dark:text-slate-100"><span>MD Export</span><Icon name="share-2" size={14} className="text-indigo-500" /></div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">Markdown with pipe tables</p>
            </button>
            <button type="button" onClick={() => { exportAsJson(exportContext); notifyExport('JSON Backup (.json)'); }} className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-indigo-400 text-left transition-colors space-y-1">
              <div className="flex items-center justify-between text-xs font-bold text-slate-900 dark:text-slate-100"><span>JSON Export</span><Icon name="file-json" size={14} className="text-emerald-500" /></div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">Structured state backup</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
