import { TableData } from '../../explorer/engine/vfsTypes';
import {
  AccountCardData,
  evaluateMathAmount,
  formatInrAmount,
  sumAccountRows,
} from '../accounts/accountDefinitions';
import { getUnifiedQuestionStatement } from '../subjective/QuestionPeekSheet';
import { ExportContext, resolveStudentSolution } from './exportEngine';

function escapeHtml(raw: string): string {
  return raw.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function formatInlineLegalHtml(raw: string): string {
  return escapeHtml(raw)
    .replace(/&lt;u&gt;([\s\S]*?)&lt;\/u&gt;/gi, '<u>$1</u>')
    .replace(/\*\*([\s\S]*?)\*\*/g, '<strong>$1</strong>');
}

function renderQuestionTableHtml(tbl: TableData): string {
  const ths = tbl.headers.map((h) => `<th>${escapeHtml(h)}</th>`).join('');
  const trs = tbl.rows.map((r) => `<tr>${r.map((c) => `<td>${escapeHtml(c)}</td>`).join('')}</tr>`).join('');
  const totalsRow =
    tbl.totals && tbl.totals.length > 0
      ? `<tr class="total-row">${tbl.totals.map((t) => `<td><strong>${escapeHtml(t)}</strong></td>`).join('')}</tr>`
      : '';
  return `<div class="question-table-wrap">${tbl.title ? `<h4>${escapeHtml(tbl.title)}</h4>` : ''}<table><thead><tr>${ths}</tr></thead><tbody>${trs}${totalsRow}</tbody></table></div>`;
}

function renderLedgerAccountHtml(acc: AccountCardData): string {
  const debitRows = acc.leftRows || [];
  const creditRows = acc.rightRows || [];
  const maxRows = Math.max(debitRows.length, creditRows.length, 1);
  const bodyRows: string[] = [];

  for (let i = 0; i < maxRows; i += 1) {
    const dr = debitRows[i];
    const cr = creditRows[i];
    const drWn = dr?.workingNoteRef?.label ? ` <strong class="wn-tag">(${escapeHtml(dr.workingNoteRef.label)})</strong>` : '';
    const crWn = cr?.workingNoteRef?.label ? ` <strong class="wn-tag">(${escapeHtml(cr.workingNoteRef.label)})</strong>` : '';
    const drAmt = dr?.amount ? formatInrAmount(evaluateMathAmount(dr.amount)) : '';
    const crAmt = cr?.amount ? formatInrAmount(evaluateMathAmount(cr.amount)) : '';

    bodyRows.push(`<tr><td>${escapeHtml(dr?.particulars || '')}${drWn}</td><td style="text-align:right" class="amt-cell">${escapeHtml(drAmt)}</td><td>${escapeHtml(cr?.particulars || '')}${crWn}</td><td style="text-align:right" class="amt-cell">${escapeHtml(crAmt)}</td></tr>`);
  }

  const drTotal = formatInrAmount(sumAccountRows(debitRows));
  const crTotal = formatInrAmount(sumAccountRows(creditRows));

  return `
    <div class="account-block">
      <h3>${escapeHtml(acc.title)}</h3>
      <table>
        <thead>
          <tr>
            <th style="width:35%">${escapeHtml(acc.leftTitle || 'Particulars (Dr.)')}</th>
            <th style="width:15%; text-align:right">Amount (Rs.)</th>
            <th style="width:35%">${escapeHtml(acc.rightTitle || 'Particulars (Cr.)')}</th>
            <th style="width:15%; text-align:right">Amount (Rs.)</th>
          </tr>
        </thead>
        <tbody>
          ${bodyRows.join('')}
          <tr class="ledger-total-row">
            <td><strong>Total</strong></td>
            <td style="text-align:right" class="double-underline"><strong>${escapeHtml(drTotal)}</strong></td>
            <td><strong>Total</strong></td>
            <td style="text-align:right" class="double-underline"><strong>${escapeHtml(crTotal)}</strong></td>
          </tr>
        </tbody>
      </table>
    </div>
  `;
}

export function buildPrintableExamHtml(ctx: ExportContext): string {
  const sol = resolveStudentSolution(ctx);
  const qStatement = getUnifiedQuestionStatement(ctx.question);
  const allQuestionTables = [...(ctx.question.table ? [ctx.question.table] : []), ...(ctx.question.tables || [])];
  const questionParagraphsHtml = qStatement
    .split('\n')
    .filter((l) => l.trim().length > 0)
    .map((line) => `<p>${formatInlineLegalHtml(line)}</p>`)
    .join('');
  const questionTablesHtml = allQuestionTables.map(renderQuestionTableHtml).join('');

  let solutionSectionHtml = '';
  if (ctx.isLawSubject) {
    const rawLaw = sol.lawText.trim() || 'No legal answer recorded.';
    const lawLinesHtml = rawLaw
      .split('\n')
      .map((line) => `<div class="law-line">${formatInlineLegalHtml(line) || '&nbsp;'}</div>`)
      .join('');
    solutionSectionHtml = `<div class="section-heading">Business Law Descriptive Answer Sheet</div><div class="law-sheet">${lawLinesHtml}</div>`;
  } else {
    const accountsHtml =
      sol.accountCards.length > 0
        ? sol.accountCards.map(renderLedgerAccountHtml).join('')
        : `<p class="muted-note">No ledger accounts recorded.</p>`;
    const wnHtml =
      sol.workingNotesText.length > 0
        ? `<div class="wn-block"><h3>Working Notes &amp; Calculations</h3>${sol.workingNotesText
            .map((wn) => `<pre class="wn-pre">${escapeHtml(wn)}</pre>`)
            .join('')}</div>`
        : '';
    solutionSectionHtml = `<div class="section-heading">Accounting Solution &amp; Ledgers</div>${accountsHtml}${wnHtml}`;
  }

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>${escapeHtml(ctx.bankTitle)} - Q${ctx.questionNumber}</title>
  <style>
    @page { size: A4; margin: 14mm; }
    body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; color: #0f172a; line-height: 1.5; font-size: 12px; margin: 0; padding: 0; }
    .exam-banner { border-bottom: 2px solid #0f172a; padding-bottom: 10px; margin-bottom: 14px; display: flex; justify-content: space-between; align-items: flex-end; }
    .exam-banner h1 { font-size: 16px; margin: 0 0 4px 0; text-transform: uppercase; letter-spacing: 0.03em; }
    .exam-meta { font-size: 11px; color: #334155; font-weight: 600; }
    .marks-badge { border: 1.5px solid #0f172a; padding: 3px 9px; font-weight: 700; font-size: 11px; border-radius: 4px; }
    .section-heading { font-size: 12px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; background: #f1f5f9; border-left: 4px solid #1e293b; padding: 6px 10px; margin: 16px 0 10px 0; }
    .question-box p { margin: 0 0 8px 0; text-align: justify; }
    table { width: 100%; border-collapse: collapse; margin: 8px 0 14px 0; font-size: 11.5px; }
    th, td { border: 1px solid #0f172a; padding: 5px 8px; vertical-align: top; }
    th { background: #e2e8f0; font-weight: 700; text-align: left; }
    .account-block { margin-bottom: 18px; page-break-inside: avoid; }
    .account-block h3 { text-align: center; font-size: 13px; font-weight: 800; text-transform: uppercase; margin: 8px 0 4px 0; }
    .amt-cell { font-family: 'JetBrains Mono', monospace; font-variant-numeric: tabular-nums; }
    .wn-tag { font-style: italic; color: #1e3a8a; }
    .double-underline { border-bottom: 3px double #0f172a !important; font-family: 'JetBrains Mono', monospace; }
    .wn-block h3 { font-size: 12.5px; font-weight: 800; text-transform: uppercase; margin: 14px 0 6px 0; }
    .wn-pre { font-family: inherit; white-space: pre-wrap; background: #f8fafc; border: 1px solid #cbd5e1; padding: 8px 10px; border-radius: 4px; margin: 0 0 8px 0; }
    .law-sheet { border: 1px solid #94a3b8; border-left: 3px solid #dc2626; padding: 8px 14px; background: #fff; }
    .law-line { border-bottom: 1px solid #e2e8f0; padding: 4px 0; min-height: 20px; }
  </style>
</head>
<body>
  <div class="exam-banner">
    <div>
      <h1>${escapeHtml(ctx.bankTitle)}</h1>
      <div class="exam-meta">Question ${ctx.questionNumber} &middot; ${escapeHtml(ctx.question.topic || ctx.subject)}</div>
    </div>
    <div class="marks-badge">${ctx.question.marks || 5} Marks</div>
  </div>
  <div class="section-heading">Question Statement</div>
  <div class="question-box">${questionParagraphsHtml}${questionTablesHtml}</div>
  ${solutionSectionHtml}
</body>
</html>`;
}

export function exportAsPdf(ctx: ExportContext): void {
  const html = buildPrintableExamHtml(ctx);
  const iframe = document.createElement('iframe');
  iframe.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
  document.body.appendChild(iframe);
  const doc = iframe.contentWindow?.document;
  if (doc && iframe.contentWindow) {
    doc.open();
    doc.write(html);
    doc.close();
    window.setTimeout(() => {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
      window.setTimeout(() => document.body.removeChild(iframe), 2000);
    }, 250);
  }
}
