import React from 'react';
import { ArrowLeft, Award, CheckCircle2, Clock, Eye, RotateCcw } from '../../../ui/icons';
import { formatDurationMMSS } from './TimerPill';

interface ScoreModalProps {
  isOpen: boolean;
  correctCount: number;
  totalQuestions: number;
  answeredCount: number;
  elapsedSeconds: number;
  onReviewAnswers: () => void;
  onRetakeTest: () => void;
  onBackToExplorer: () => void;
}

export const ScoreModal: React.FC<ScoreModalProps> = ({
  isOpen,
  correctCount,
  totalQuestions,
  answeredCount,
  elapsedSeconds,
  onReviewAnswers,
  onRetakeTest,
  onBackToExplorer,
}) => {
  if (!isOpen) return null;

  const percentage = totalQuestions > 0 ? Math.round((correctCount / totalQuestions) * 100) : 0;
  const radius = 38;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/65 backdrop-blur-xs">
      <div className="w-full max-w-md rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-2xl p-6 text-center space-y-6">
        <div className="relative w-28 h-28 mx-auto flex items-center justify-center">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 96 96">
            <circle cx="48" cy="48" r={radius} stroke="currentColor" strokeWidth="7" fill="transparent" className="text-slate-200 dark:text-slate-800" />
            <circle
              cx="48"
              cy="48"
              r={radius}
              stroke="currentColor"
              strokeWidth="7"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              fill="transparent"
              className="text-emerald-500 transition-all duration-500"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <Award size={20} className="text-amber-500 mb-0.5" />
            <span className="text-lg font-bold font-mono-tabular text-[var(--text-primary)]">{percentage}%</span>
          </div>
        </div>

        <div>
          <h2 className="text-lg font-bold text-[var(--text-primary)]">Practice Session Complete</h2>
          <p className="text-xs text-[var(--text-secondary)] mt-1">CA Foundation Objective Assessment Summary</p>
        </div>

        <div className="grid grid-cols-3 gap-3 p-3.5 rounded-xl bg-[var(--bg-app)] border border-[var(--border-subtle)] font-mono-tabular">
          <div>
            <div className="text-[11px] text-[var(--text-muted)] flex items-center justify-center gap-1">
              <CheckCircle2 size={12} className="text-emerald-500" />
              <span>Score</span>
            </div>
            <div className="text-sm font-bold text-[var(--text-primary)] mt-1">{correctCount} / {totalQuestions}</div>
          </div>
          <div>
            <div className="text-[11px] text-[var(--text-muted)]">Attempted</div>
            <div className="text-sm font-bold text-[var(--text-primary)] mt-1">{answeredCount} / {totalQuestions}</div>
          </div>
          <div>
            <div className="text-[11px] text-[var(--text-muted)] flex items-center justify-center gap-1">
              <Clock size={12} className="text-sky-500" />
              <span>Time</span>
            </div>
            <div className="text-sm font-bold text-[var(--text-primary)] mt-1">{formatDurationMMSS(elapsedSeconds)}</div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-2.5 pt-1">
          <button
            type="button"
            onClick={onReviewAnswers}
            className="w-full flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold bg-sky-500 hover:bg-sky-600 text-white transition-colors"
          >
            <Eye size={14} />
            <span>Review Answers</span>
          </button>
          <button
            type="button"
            onClick={onRetakeTest}
            className="w-full flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold bg-[var(--bg-app)] border border-[var(--border-subtle)] hover:border-[var(--border-strong)] text-[var(--text-primary)] transition-colors"
          >
            <RotateCcw size={14} />
            <span>Retake Test</span>
          </button>
          <button
            type="button"
            onClick={onBackToExplorer}
            className="w-full flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-app)] transition-colors"
          >
            <ArrowLeft size={14} />
            <span>Back to Explorer</span>
          </button>
        </div>
      </div>
    </div>
  );
};
