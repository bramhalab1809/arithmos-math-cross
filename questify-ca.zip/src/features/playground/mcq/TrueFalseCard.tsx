import React, { useState } from 'react';
import { CheckCircle2, Eye, HelpCircle, XCircle } from '../../../ui/icons';
import { QuestionItem } from '../../explorer/engine/vfsTypes';
import { RichContentRenderer } from '../components/RichContentRenderer';
import { getQuestionHintText } from './QuestionCard';

export interface TrueFalseCardProps {
  question: QuestionItem;
  selectedOption: number | undefined;
  userReason: string;
  isSubmitted: boolean;
  showHint?: boolean;
  onSelectOption: (optionIdx: number) => void;
  onChangeReason: (text: string) => void;
}

export const TrueFalseCard: React.FC<TrueFalseCardProps> = ({
  question,
  selectedOption,
  userReason,
  isSubmitted,
  showHint = false,
  onSelectOption,
  onChangeReason,
}) => {
  const [revealReason, setRevealReason] = useState(false);
  const correctIdx = typeof question.correctAnswer === 'number' ? question.correctAnswer : 0;
  const statementText = question.question || question.statement || '';
  const officialReason = question.reason || question.explanation || question.modelAnswer || '';
  const showOfficialReason = isSubmitted || revealReason;

  return (
    <div className="space-y-4 sm:space-y-5 no-select">
      <div className="p-4 sm:p-5 rounded-xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 space-y-2">
        <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
          State with reasons whether the following statement is True or False:
        </div>
        <div className="text-sm sm:text-base font-semibold text-slate-900 dark:text-slate-100 leading-relaxed break-words">
          <RichContentRenderer content={statementText} table={question.table} />
        </div>
      </div>

      {showHint && (
        <div className="p-3 rounded-xl bg-amber-50/90 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/70 flex items-start gap-2.5 text-xs sm:text-sm text-amber-900 dark:text-amber-200 animate-in fade-in duration-150">
          <HelpCircle size={16} className="text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-0.5 min-w-0 flex-1">
            <div className="text-[11px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
              Formula / Statutory Principle Hint
            </div>
            <div className="leading-relaxed font-medium break-words">
              <RichContentRenderer content={getQuestionHintText(question)} />
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-3 sm:gap-4">
        {[
          { idx: 0, label: 'TRUE', badge: 'T' },
          { idx: 1, label: 'FALSE', badge: 'F' },
        ].map(({ idx, label, badge }) => {
          const isSelected = selectedOption === idx;
          const isCorrect = idx === correctIdx;

          let btnCls =
            'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:border-indigo-400';
          if (isSubmitted) {
            if (isCorrect) {
              btnCls = 'bg-emerald-500/12 border-emerald-500 text-emerald-800 dark:text-emerald-200 font-bold';
            } else if (isSelected) {
              btnCls = 'bg-rose-500/12 border-rose-500 text-rose-800 dark:text-rose-200 font-bold';
            }
          } else if (isSelected) {
            btnCls =
              'bg-indigo-600/10 dark:bg-indigo-500/20 border-indigo-600 dark:border-indigo-400 text-indigo-700 dark:text-indigo-200 font-bold shadow-2xs';
          }

          return (
            <button
              key={idx}
              type="button"
              disabled={isSubmitted}
              onClick={() => onSelectOption(idx)}
              className={`min-h-[54px] px-4 py-3 rounded-xl border flex items-center justify-center gap-2.5 text-xs sm:text-sm font-bold transition-all ${btnCls} ${
                isSubmitted ? 'cursor-default' : 'cursor-pointer'
              }`}
            >
              <span className="w-6 h-6 rounded-full border border-current flex items-center justify-center text-xs font-mono-tabular">
                {badge}
              </span>
              <span>{label}</span>
              {isSubmitted && isCorrect && <CheckCircle2 size={16} className="text-emerald-500 shrink-0" />}
              {isSubmitted && isSelected && !isCorrect && <XCircle size={16} className="text-rose-500 shrink-0" />}
            </button>
          );
        })}
      </div>

      <div className="p-3.5 sm:p-4 rounded-xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 space-y-2.5">
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
            Student Reasoning (1-2 Lines):
          </span>
          {officialReason && !isSubmitted && (
            <button
              type="button"
              onClick={() => setRevealReason((v) => !v)}
              className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-amber-500/12 text-amber-700 dark:text-amber-300 border border-amber-500/30 hover:bg-amber-500/20 flex items-center gap-1 transition-colors"
            >
              <Eye size={12} />
              <span>{revealReason ? 'Hide ICAI Reason' : 'Show ICAI Reason'}</span>
            </button>
          )}
        </div>

        <textarea
          value={userReason}
          disabled={isSubmitted}
          onChange={(e) => onChangeReason(e.target.value)}
          rows={2}
          placeholder="Write your brief 1-2 line accounting or legal reason here before checking the ICAI official reason..."
          className="w-full p-2.5 rounded-lg text-xs sm:text-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-indigo-500 resize-y"
        />
      </div>

      {showOfficialReason && officialReason && (
        <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 space-y-1.5 animate-in fade-in duration-150">
          <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 dark:text-emerald-400">
            <CheckCircle2 size={14} />
            <span>ICAI Official Answer: {correctIdx === 0 ? 'True' : 'False'}</span>
          </div>
          <div className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed break-words">
            <RichContentRenderer content={officialReason} />
          </div>
        </div>
      )}
    </div>
  );
};
