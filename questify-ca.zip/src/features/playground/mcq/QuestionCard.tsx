import React from 'react';
import { CheckCircle2, HelpCircle, XCircle } from '../../../ui/icons';
import { QuestionItem } from '../../explorer/engine/vfsTypes';
import { RichContentRenderer, renderFormattedInline } from '../components/RichContentRenderer';

export interface QuestionCardProps {
  question: QuestionItem;
  questionNumber: number;
  totalQuestions: number;
  chapterTitle?: string;
  selectedOption: number | undefined;
  isSubmitted: boolean;
  showHint?: boolean;
  onSelectOption: (optionIdx: number) => void;
}

export function getQuestionHintText(question: QuestionItem): string {
  if (question.hint?.trim()) {
    return question.hint.trim();
  }
  const raw = (question.explanation || question.reason || '').trim();
  if (raw) {
    const eqIdx = raw.indexOf('=');
    const dotIdx = raw.indexOf('. ');
    if (eqIdx > 0 && (dotIdx === -1 || eqIdx < dotIdx)) {
      const lhs = raw.slice(0, eqIdx).trim();
      if (lhs.length >= 2 && lhs.length <= 70) {
        return `Key Formula / Approach: Use ${lhs} with the given values (${question.topic || 'Concept'}).`;
      }
    }
    const firstSentence = dotIdx > 0 ? raw.slice(0, dotIdx + 1) : raw;
    const masked = firstSentence.replace(/=>.*$/g, '').replace(/=\s*(Rs\.?\s*)?\d[\d,.]*%?.*$/i, '').trim();
    if (masked.length > 8) return masked;
  }
  return `Recall core principle / formula for: ${question.topic || 'CA Foundation Concept'}.`;
}

export const QuestionCard: React.FC<QuestionCardProps> = ({
  question,
  selectedOption,
  isSubmitted,
  showHint = false,
  onSelectOption,
}) => {
  const correctIdx = typeof question.correctAnswer === 'number' ? question.correctAnswer : 0;
  const options = question.options || [];
  const statementText = question.question || question.statement || '';
  const explanationText = question.explanation || question.reason || '';

  return (
    <div className="space-y-4 sm:space-y-5 no-select">
      <div className="p-4 sm:p-5 rounded-xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 space-y-2.5">
        {question.caseStudy && (
          <div className="p-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
            <RichContentRenderer text={question.caseStudy} table={question.table} tables={question.tables} />
          </div>
        )}

        <div className="text-sm sm:text-base font-semibold text-slate-900 dark:text-slate-100 leading-relaxed break-words">
          <RichContentRenderer content={statementText} table={!question.caseStudy ? question.table : undefined} />
        </div>
      </div>

      {showHint && (
        <div className="p-3 rounded-xl bg-amber-50/90 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/70 flex items-start gap-2.5 text-xs sm:text-sm text-amber-900 dark:text-amber-200 animate-in fade-in duration-150">
          <HelpCircle size={16} className="text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-0.5 min-w-0 flex-1">
            <div className="text-[11px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
              Formula / Concept Hint
            </div>
            <div className="leading-relaxed font-medium break-words">
              <RichContentRenderer content={getQuestionHintText(question)} />
            </div>
          </div>
        </div>
      )}

      <div className="space-y-2.5 sm:space-y-3">
        {options.map((optText, idx) => {
          const letter = String.fromCharCode(65 + idx);
          const isSelected = selectedOption === idx;
          const isCorrectOption = idx === correctIdx;

          let cardClasses =
            'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:border-sky-500/60';
          let badgeClasses =
            'bg-slate-100 dark:bg-slate-700 border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300';

          if (isSubmitted) {
            if (isCorrectOption) {
              cardClasses = 'bg-emerald-500/12 border-emerald-500 text-emerald-800 dark:text-emerald-200 font-medium';
              badgeClasses = 'bg-emerald-500 border-emerald-500 text-white';
            } else if (isSelected) {
              cardClasses = 'bg-rose-500/12 border-rose-500 text-rose-800 dark:text-rose-200';
              badgeClasses = 'bg-rose-500 border-rose-500 text-white';
            }
          } else if (isSelected) {
            cardClasses =
              'bg-sky-500/12 dark:bg-cyan-400/12 border-sky-500 dark:border-cyan-400 text-slate-900 dark:text-slate-100 font-medium shadow-2xs';
            badgeClasses =
              'bg-sky-500 dark:bg-cyan-400 border-sky-500 dark:border-cyan-400 text-white dark:text-slate-950';
          }

          return (
            <button
              key={idx}
              type="button"
              disabled={isSubmitted}
              onClick={() => onSelectOption(idx)}
              className={`w-full min-h-[50px] flex items-center justify-between gap-3 sm:gap-4 p-3.5 sm:p-4 rounded-xl border text-left text-xs sm:text-sm transition-all ${cardClasses} ${
                isSubmitted ? 'cursor-default' : 'cursor-pointer'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <span
                  className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg border flex items-center justify-center text-xs font-bold font-mono-tabular shrink-0 transition-colors ${badgeClasses}`}
                >
                  {letter}
                </span>
                <span className="break-words leading-relaxed">{renderFormattedInline(optText)}</span>
              </div>
              {isSubmitted && isCorrectOption && <CheckCircle2 size={18} className="text-emerald-500 shrink-0" />}
              {isSubmitted && isSelected && !isCorrectOption && <XCircle size={18} className="text-rose-500 shrink-0" />}
            </button>
          );
        })}
      </div>

      {isSubmitted && explanationText && (
        <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 space-y-1.5">
          <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 dark:text-emerald-400">
            <HelpCircle size={14} />
            <span>Official Explanation (Correct Option: {String.fromCharCode(65 + correctIdx)})</span>
          </div>
          <div className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed break-words">
            <RichContentRenderer content={explanationText} />
          </div>
        </div>
      )}
    </div>
  );
};
