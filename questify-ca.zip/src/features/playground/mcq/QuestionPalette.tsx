import React from 'react';
import { Check, Lock } from '../../../ui/icons';
import { QuestionItem } from '../../explorer/engine/vfsTypes';

interface QuestionPaletteProps {
  questions: QuestionItem[];
  currentIndex: number;
  selectedAnswers: Record<number, number>;
  visitedIndices: Set<number>;
  isSubmitted: boolean;
  sequentialLock?: boolean;
  onSelectQuestion: (index: number) => void;
}

export const QuestionPalette: React.FC<QuestionPaletteProps> = ({
  questions,
  currentIndex,
  selectedAnswers,
  visitedIndices,
  isSubmitted,
  sequentialLock = false,
  onSelectQuestion,
}) => {
  const totalCount = questions.length;
  const isCompactBank = totalCount <= 9;

  const getButtonStyle = (q: QuestionItem, idx: number) => {
    const isCurrent = idx === currentIndex;
    const isAnswered = selectedAnswers[idx] !== undefined;
    const isVisited = visitedIndices.has(idx);
    const isCorrect = isSubmitted && isAnswered && selectedAnswers[idx] === Number(q.correctAnswer);
    const isWrong = isSubmitted && isAnswered && selectedAnswers[idx] !== Number(q.correctAnswer);

    let style =
      'bg-[var(--bg-app)] border-[var(--border-subtle)] text-[var(--text-secondary)] hover:border-[var(--border-strong)]';

    if (isSubmitted) {
      if (isCorrect) style = 'bg-emerald-500/15 border-emerald-500/60 text-emerald-600 dark:text-emerald-300 font-semibold';
      else if (isWrong) style = 'bg-rose-500/15 border-rose-500/60 text-rose-600 dark:text-rose-300 font-semibold';
    } else if (isAnswered) {
      style = 'bg-emerald-500/15 border-emerald-500/60 text-emerald-600 dark:text-emerald-300 font-semibold';
    } else if (isVisited) {
      style = 'bg-[var(--bg-app)] border-slate-400 dark:border-slate-600 text-[var(--text-primary)]';
    }

    if (isCurrent) {
      style +=
        ' ring-2 ring-offset-1 ring-offset-[var(--bg-surface)] ring-sky-500 dark:ring-cyan-400 border-sky-500 dark:border-cyan-400 text-sky-600 dark:text-cyan-300 font-bold';
    }
    return style;
  };

  return (
    <div
      className={`flex flex-col min-h-0 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] p-3.5 sm:p-4 shadow-xs no-select ${
        isCompactBank ? 'max-h-fit' : 'flex-1'
      }`}
    >
      <div className="flex items-center justify-between mb-2.5 shrink-0">
        <span className="text-xs font-bold text-[var(--text-primary)]">Question Palette</span>
        <span className="text-[11px] font-mono-tabular text-[var(--text-muted)]">
          Q1 - Q{totalCount}
        </span>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto p-1">
        <div className="grid grid-cols-3 gap-2.5">
          {questions.map((q, idx) => {
            const isAnswered = selectedAnswers[idx] !== undefined;
            const isLocked = sequentialLock && !isSubmitted && idx > 0 && selectedAnswers[idx - 1] === undefined;
            return (
              <button
                key={q.id || idx}
                type="button"
                disabled={isLocked}
                onClick={() => onSelectQuestion(idx)}
                className={`relative h-10 sm:h-11 rounded-xl border text-xs font-mono-tabular flex items-center justify-center transition-all ${getButtonStyle(q, idx)} ${
                  isLocked ? 'opacity-45 cursor-not-allowed' : 'cursor-pointer'
                }`}
                title={`Question ${idx + 1}`}
              >
                <span>Q{idx + 1}</span>
                {isAnswered && !isLocked && (
                  <span className="absolute top-1 right-1 text-emerald-500">
                    <Check size={10} />
                  </span>
                )}
                {isLocked && (
                  <span className="absolute top-1 right-1 text-[var(--text-muted)]">
                    <Lock size={10} />
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
