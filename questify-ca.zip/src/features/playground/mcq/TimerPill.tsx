import React from 'react';
import { Pause, Play, Timer } from '../../../ui/icons';

interface TimerPillProps {
  elapsedSeconds: number;
  timeLimitSeconds?: number;
  isPaused: boolean;
  isSubmitted: boolean;
  onTogglePause: () => void;
}

export function formatDurationMMSS(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export const TimerPill: React.FC<TimerPillProps> = ({
  elapsedSeconds,
  timeLimitSeconds,
  isPaused,
  isSubmitted,
  onTogglePause,
}) => {
  const displaySeconds =
    typeof timeLimitSeconds === 'number' && timeLimitSeconds > 0
      ? Math.max(0, timeLimitSeconds - elapsedSeconds)
      : elapsedSeconds;

  const formatted = formatDurationMMSS(displaySeconds);

  return (
    <div className="w-full p-2.5 sm:p-3.5 rounded-xl sm:rounded-2xl bg-[var(--bg-surface)] border border-sky-500/30 dark:border-cyan-400/30 shadow-[0_0_20px_-6px_rgba(14,165,233,0.28)] flex items-center justify-between gap-2.5 shrink-0">
      <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
        <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-sky-500/12 dark:bg-cyan-400/12 text-sky-600 dark:text-cyan-400 flex items-center justify-center shrink-0">
          <Timer size={17} />
        </div>
        <div className="min-w-0">
          <div className="text-[10px] sm:text-[11px] font-medium text-[var(--text-muted)]">
            {isSubmitted ? 'Final Time' : isPaused ? 'Timer Paused' : 'Session Timer'}
          </div>
          <div
            className={`text-xs sm:text-sm font-bold font-mono-tabular tracking-wider text-sky-600 dark:text-cyan-300 ${
              isPaused && !isSubmitted ? 'animate-pulse' : ''
            }`}
          >
            Time {formatted}
          </div>
        </div>
      </div>

      {!isSubmitted && (
        <button
          type="button"
          onClick={onTogglePause}
          className="p-2 rounded-xl bg-[var(--bg-app)] border border-[var(--border-subtle)] hover:border-sky-500/50 text-[var(--text-secondary)] hover:text-sky-500 transition-colors shrink-0"
          title={isPaused ? 'Resume Timer' : 'Pause Timer'}
          aria-label={isPaused ? 'Resume Timer' : 'Pause Timer'}
        >
          {isPaused ? <Play size={14} /> : <Pause size={14} />}
        </button>
      )}
    </div>
  );
};
