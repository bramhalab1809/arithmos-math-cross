import { QuestionBankJSON } from '../features/explorer/engine/vfsTypes';

export const ACCOUNTING_TRUE_FALSE_BANK: QuestionBankJSON = {
  type: 'true-false',
  title: 'CA Foundation Accounting - Q1(a) Compulsory True / False with Reasons',
  subject: 'Accounting (Paper 1)',
  chapter: 'Chapter 1 & 7 - Accounting Concepts & Final Accounts',
  examSession: 'ICAI Compulsory Q1(a) Drill',
  questions: [
    {
      id: 'TF-1',
      question: 'State with reasons whether the following statement is **True** or **False**:\n"Closing Stock appearing in the **Trial Balance** is taken only to the **Balance Sheet**."',
      options: ['True', 'False'],
      correctAnswer: 0,
      topic: 'Final Accounts - Closing Stock Treatment',
      marks: 2,
      reason:
        '**True**: Closing Stock appearing inside the **Trial Balance** indicates that its double-entry adjustment has already been passed by deducting it from Opening Stock and Purchases (Adjusted Purchases). Therefore, it is an asset balance and is taken **only to the Asset side of the Balance Sheet** and not to the Trading Account.',
      explanation:
        '**True**: Closing Stock appearing inside the **Trial Balance** indicates that its double-entry adjustment has already been passed by deducting it from Opening Stock and Purchases (Adjusted Purchases). Therefore, it is an asset balance and is taken **only to the Asset side of the Balance Sheet** and not to the Trading Account.',
    },
    {
      id: 'TF-2',
      question: 'State with reasons whether the following statement is **True** or **False**:\n"**Depreciation** is a non-cash expense and does not reduce accounting profit."',
      options: ['True', 'False'],
      correctAnswer: 1,
      topic: 'AS 10 & Matching Concept - Depreciation',
      marks: 2,
      reason:
        '**False**: While **depreciation** is a non-cash operating expense involving no outflow of cash, in accordance with the **Matching Concept** and **AS 10 (Property, Plant and Equipment)**, it is compulsorily charged (debited) to the **Profit & Loss Account** and directly reduces net accounting profit.',
      explanation:
        '**False**: While **depreciation** is a non-cash operating expense involving no outflow of cash, in accordance with the **Matching Concept** and **AS 10 (Property, Plant and Equipment)**, it is compulsorily charged (debited) to the **Profit & Loss Account** and directly reduces net accounting profit.',
    },
    {
      id: 'TF-3',
      question: 'State with reasons whether the following statement is **True** or **False**:\n"**Provision for bad debts** is created based on the debtor balance before deducting **further bad debts**."',
      options: ['True', 'False'],
      correctAnswer: 1,
      topic: 'Final Accounts - Provision for Doubtful Debts',
      marks: 2,
      reason:
        '**False**: **Further bad debts** given in adjustments represent an actual confirmed loss and must be deducted from **Sundry Debtors** first. The percentage for **Provision for Doubtful Debts** is calculated only on the remaining *good and doubtful* debtors balance.',
      explanation:
        '**False**: **Further bad debts** given in adjustments represent an actual confirmed loss and must be deducted from **Sundry Debtors** first. The percentage for **Provision for Doubtful Debts** is calculated only on the remaining *good and doubtful* debtors balance.',
    },
    {
      id: 'TF-4',
      question: 'State with reasons whether the following statement is **True** or **False**:\n"Wages paid for installation of a new machine are debited to **Trading Account**."',
      options: ['True', 'False'],
      correctAnswer: 1,
      topic: 'Capital vs Revenue Expenditure (AS 10)',
      marks: 2,
      reason:
        '**False**: Under **AS 10 (Property, Plant and Equipment)**, wages paid for the installation and erection of a new machine are directly attributable costs required to bring the asset to its working condition. Hence, it is a **Capital Expenditure** and must be debited to the **Machinery Account**, not the Trading Account.',
      explanation:
        '**False**: Under **AS 10 (Property, Plant and Equipment)**, wages paid for the installation and erection of a new machine are directly attributable costs required to bring the asset to its working condition. Hence, it is a **Capital Expenditure** and must be debited to the **Machinery Account**, not the Trading Account.',
    },
    {
      id: 'TF-5',
      question: 'State with reasons whether the following statement is **True** or **False**:\n"**Freight inward** is included in the cost of purchase."',
      options: ['True', 'False'],
      correctAnswer: 0,
      topic: 'AS 2 - Valuation of Inventories',
      marks: 2,
      reason:
        '**True**: Under **AS 2 (Valuation of Inventories)**, cost of purchase includes duties, taxes, **freight inward** (carriage inward), and other expenditure directly attributable to bringing the goods to their present location and condition. Hence, it is debited to the **Trading Account** as part of cost of purchase.',
      explanation:
        '**True**: Under **AS 2 (Valuation of Inventories)**, cost of purchase includes duties, taxes, **freight inward** (carriage inward), and other expenditure directly attributable to bringing the goods to their present location and condition. Hence, it is debited to the **Trading Account** as part of cost of purchase.',
    },
  ],
};
