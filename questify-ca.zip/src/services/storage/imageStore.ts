const DB_NAME = 'questify_ca_handwritten_db';
const STORE_NAME = 'answer_pages_v1';
const FALLBACK_PREFIX = 'questify_ca_img_';

function openImageDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB unavailable'));
      return;
    }
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function loadBankAnswerImages(
  bankKey: string
): Promise<Record<string, string[]>> {
  if (!bankKey) return {};
  try {
    const db = await openImageDb();
    return await new Promise((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get(bankKey);
      req.onsuccess = () => {
        resolve((req.result as Record<string, string[]>) || {});
      };
      req.onerror = () => resolve({});
    });
  } catch {
    try {
      const raw = localStorage.getItem(`${FALLBACK_PREFIX}${bankKey}`);
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  }
}

export async function saveBankAnswerImages(
  bankKey: string,
  pagesByQuestion: Record<string, string[]>
): Promise<void> {
  if (!bankKey) return;
  try {
    const db = await openImageDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put(pagesByQuestion, bankKey);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch {
    try {
      localStorage.setItem(`${FALLBACK_PREFIX}${bankKey}`, JSON.stringify(pagesByQuestion));
    } catch {
      // Ignore quota errors
    }
  }
}

export async function clearBankAnswerImages(bankKey: string): Promise<void> {
  if (!bankKey) return;
  try {
    const db = await openImageDb();
    await new Promise<void>((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      store.delete(bankKey);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
  } catch {
    // Ignore
  }
  try {
    localStorage.removeItem(`${FALLBACK_PREFIX}${bankKey}`);
  } catch {
    // Ignore
  }
}
