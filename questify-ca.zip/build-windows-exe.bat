@echo off
echo ===================================================
echo       Questify CA - Windows EXE Local Builder
echo ===================================================
echo.
call npm install
call node scripts/generate-icons.mjs
call npm run build
call npx electron-builder --win portable nsis --config electron-builder.json
echo.
echo Build completed! Check the 'release-builds' folder for your .exe files.
pause
