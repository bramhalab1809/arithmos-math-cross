export function playChimniChirp(
  ctx: AudioContext,
  destination: AudioNode,
  volume = 0.25,
  urgent = false
): void {
  try {
    const now = ctx.currentTime;
    const notes = urgent ? [0, 0.11, 0.22] : [0, 0.13];

    notes.forEach((offset, idx) => {
      const start = now + offset;
      const dur = urgent ? 0.085 : 0.095;

      const osc = ctx.createOscillator();
      const mod = ctx.createOscillator();
      const modGain = ctx.createGain();
      const env = ctx.createGain();

      osc.type = 'sine';
      const baseFreq = idx % 2 === 0 ? 2950 : 3450;
      const peakFreq = idx % 2 === 0 ? 4100 : 4550;
      osc.frequency.setValueAtTime(baseFreq, start);
      osc.frequency.exponentialRampToValueAtTime(peakFreq, start + dur * 0.55);
      osc.frequency.exponentialRampToValueAtTime(baseFreq * 1.08, start + dur);

      mod.type = 'sine';
      mod.frequency.setValueAtTime(52, start);
      modGain.gain.setValueAtTime(240, start);

      env.gain.setValueAtTime(0.0001, start);
      env.gain.linearRampToValueAtTime(volume * 0.42, start + 0.015);
      env.gain.exponentialRampToValueAtTime(0.0001, start + dur);

      mod.connect(modGain);
      modGain.connect(osc.frequency);
      osc.connect(env);
      env.connect(destination);

      osc.start(start);
      mod.start(start);
      osc.stop(start + dur + 0.01);
      mod.stop(start + dur + 0.01);
    });
  } catch {
    // ignore audio errors
  }
}

export function playCrowKavKav(
  ctx: AudioContext,
  destination: AudioNode,
  volume = 0.28
): void {
  try {
    const now = ctx.currentTime;
    const syllables = [0, 0.24];

    syllables.forEach((offset) => {
      const start = now + offset;
      const dur = 0.17;

      const osc = ctx.createOscillator();
      const sub = ctx.createOscillator();
      const filter1 = ctx.createBiquadFilter();
      const filter2 = ctx.createBiquadFilter();
      const env = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(430, start);
      osc.frequency.linearRampToValueAtTime(360, start + dur * 0.5);
      osc.frequency.exponentialRampToValueAtTime(245, start + dur);

      sub.type = 'triangle';
      sub.frequency.setValueAtTime(215, start);
      sub.frequency.exponentialRampToValueAtTime(135, start + dur);

      filter1.type = 'bandpass';
      filter1.frequency.setValueAtTime(720, start);
      filter1.Q.setValueAtTime(3.2, start);

      filter2.type = 'bandpass';
      filter2.frequency.setValueAtTime(1420, start);
      filter2.Q.setValueAtTime(4.0, start);

      env.gain.setValueAtTime(0.0001, start);
      env.gain.linearRampToValueAtTime(volume * 0.48, start + 0.022);
      env.gain.exponentialRampToValueAtTime(0.0001, start + dur);

      osc.connect(filter1);
      sub.connect(filter1);
      filter1.connect(filter2);
      filter2.connect(env);
      env.connect(destination);

      osc.start(start);
      sub.start(start);
      osc.stop(start + dur + 0.01);
      sub.stop(start + dur + 0.01);
    });
  } catch {
    // ignore audio errors
  }
}
