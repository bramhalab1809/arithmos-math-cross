import { CueId, makePcm } from './audioBuffers';
import { compileExpression, validateExpression } from './expr';

export type CustomTargetId = CueId;

export const ALL_SFX_CUES: Array<{ id: CueId; label: string; desc: string }> = [
  { id: 'tick', label: '1. Cell Tap (Tick)', desc: 'Every number entered in a box' },
  { id: 'equationSolved', label: '2. Row / Col Solved', desc: 'Line equation completed' },
  { id: 'starEarned', label: '3. Star Box Solved', desc: 'Star cell collected on board' },
  { id: 'hint', label: '4. Hint Used', desc: 'Logical hint revealed' },
  { id: 'error', label: '5. Mistake / Wrong', desc: 'Invalid line or wrong entry' },
  { id: 'heartLost', label: '6. Heart Lost (Swap)', desc: 'Puzzle swap heart used' },
  { id: 'alert30s', label: '7. 30s Red Alert', desc: '30 seconds remaining warning' },
  { id: 'timeWarning', label: '8. 10s Countdown', desc: 'Final 10 seconds tick' },
  { id: 'timeUp', label: '9. Time Up (Lose)', desc: 'Timer expired round over' },
  { id: 'victory', label: '10. Level Win (Victory)', desc: 'Puzzle solved celebration' },
];

export const ALL_STUDIO_TARGETS = ALL_SFX_CUES;

export interface CueCustomCode {
  enabled: boolean;
  formula: string;
  durationSec: number;
}

export type StudioConfigMap = Record<CueId, CueCustomCode>;

export const AUDIO_STUDIO_STORAGE_KEY_V2 = 'arithmos_audio_studio_v2';
export const AUDIO_STUDIO_STORAGE_KEY = 'arithmos_audio_studio_v1';

export const AI_STUDIO_PROMPT = `You are the Sound Designer for Arithmos (Code-to-Audio Studio).
Output a single mathematical wave formula (no quotes, no brackets, no statements).
Variables: t (seconds elapsed), sr (sample rate), freq (base note Hz), pi2 (2 * Math.PI)
Functions: Math.sin, Math.cos, Math.tan, Math.exp, Math.abs, Math.min, Math.max, Math.pow, Math.sqrt
Format:
Formula: Math.sin(pi2 * 440 * t) * Math.exp(-t * 18)
Duration: 0.15s`;

export function validateCustomFormula(formula: string): boolean {
  return validateExpression(formula);
}

export function parseAiPasteInput(raw: string, currentDuration: number): { formula: string; durationSec: number } {
  let text = raw.replace(/```[a-zA-Z]*\n?/g, '').replace(/```/g, '').trim();
  let durationSec = currentDuration;
  const durMatch = text.match(/Duration\s*:\s*([0-9]*\.?[0-9]+)\s*s?/i);
  if (durMatch) {
    const parsedDur = parseFloat(durMatch[1]);
    if (parsedDur >= 0.04 && parsedDur <= 1.2) durationSec = parsedDur;
  }
  text = text
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l !== '' && !/^Duration\s*:/i.test(l) && !/^\/\//.test(l))
    .join(' ')
    .replace(/^Formula\s*:\s*/i, '')
    .replace(/;+\s*$/, '')
    .trim();
  return { formula: text || raw, durationSec };
}

export function createDefaultStudioMap(): StudioConfigMap {
  const map = {} as StudioConfigMap;
  ALL_SFX_CUES.forEach((c) => {
    map[c.id] = { enabled: false, formula: 'Math.sin(pi2 * 440 * t) * Math.exp(-t * 16)', durationSec: 0.15 };
  });
  return map;
}

export function loadStudioConfigMap(): StudioConfigMap {
  const defaults = createDefaultStudioMap();
  if (typeof window === 'undefined') return defaults;
  try {
    const raw = localStorage.getItem(AUDIO_STUDIO_STORAGE_KEY_V2);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') {
        ALL_SFX_CUES.forEach((c) => {
          if (parsed[c.id]?.formula && validateExpression(parsed[c.id].formula)) {
            defaults[c.id] = {
              enabled: Boolean(parsed[c.id].enabled),
              formula: parsed[c.id].formula,
              durationSec: Math.max(0.04, Math.min(1.2, Number(parsed[c.id].durationSec) || 0.15)),
            };
          }
        });
      }
    }
  } catch {}
  return defaults;
}

export function saveStudioCueConfig(cues: CueId[], formula: string, durationSec: number): StudioConfigMap {
  const current = loadStudioConfigMap();
  const dur = Math.max(0.04, Math.min(1.2, durationSec));
  cues.forEach((c) => {
    current[c] = { enabled: true, formula, durationSec: dur };
  });
  try { localStorage.setItem(AUDIO_STUDIO_STORAGE_KEY_V2, JSON.stringify(current)); } catch {}
  return current;
}

export function resetStudioCueConfig(cues?: CueId[]): StudioConfigMap {
  const current = loadStudioConfigMap();
  const targetCues = cues && cues.length > 0 ? cues : ALL_SFX_CUES.map((c) => c.id);
  const defaults = createDefaultStudioMap();
  targetCues.forEach((c) => {
    current[c] = { enabled: false, formula: defaults[c].formula, durationSec: defaults[c].durationSec };
  });
  try { localStorage.setItem(AUDIO_STUDIO_STORAGE_KEY_V2, JSON.stringify(current)); } catch {}
  return current;
}

export function compileCustomBuffer(ctx: AudioContext, formula: string, durationSec = 0.2): AudioBuffer | null {
  try {
    const evaluator = compileExpression(formula);
    if (!evaluator) return null;
    const pi2 = 2 * Math.PI;
    const dur = Math.max(0.04, Math.min(1.2, durationSec));
    return makePcm(ctx, dur, (t, sr) => {
      const val = evaluator(t, sr, 440, pi2);
      return Math.max(-1, Math.min(1, val));
    });
  } catch {
    return null;
  }
}
