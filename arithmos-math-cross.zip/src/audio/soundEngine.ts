import { loadState, saveState } from '../storage/storage';
import { CueId, createProceduralBuffers } from './audioBuffers';
import { BgmPlayer } from './bgmPlayer';
import { playChimniChirp, playCrowKavKav } from './birdVoices';
import { ALL_SFX_CUES, compileCustomBuffer, loadStudioConfigMap } from './customAudioSynth';
import {
  CueSetting,
  loadBgmStorage,
  loadDefaultMixer,
  saveBgmStorage,
  saveMixerStorage,
  BGM_STORAGE_KEY,
  SFX_MIXER_KEY,
} from './soundMixer';

export { BGM_STORAGE_KEY, SFX_MIXER_KEY };
export type { CueSetting };

const THROTTLE_MS = 35;

class SoundEngine {
  private ctx: AudioContext | null = null;
  private compressor: DynamicsCompressorNode | null = null;
  private limiterCeiling: GainNode | null = null;
  private masterGain: GainNode | null = null;
  private buffers = new Map<CueId, AudioBuffer>();
  private previewSource: AudioBufferSourceNode | null = null;
  private muted = false;
  private volume = 0.7;
  private bgmEnabled = true;
  private bgmVolume = 0.5;
  private lastPlayedAt: Record<string, number> = {};
  private mixer: Record<CueId, CueSetting>;
  private bgm = new BgmPlayer();

  constructor() {
    const s = loadState();
    this.muted = s.settings.muted;
    this.volume = s.settings.volume;
    const bgmCfg = loadBgmStorage();
    this.bgmEnabled = bgmCfg.enabled;
    this.bgmVolume = bgmCfg.volume;
    this.mixer = loadDefaultMixer();
    this.initAudioHooks();
  }

  private initAudioHooks(): void {
    if (typeof window === 'undefined') return;
    const unlock = () => {
      const c = this.getContext();
      if (c?.state === 'suspended') c.resume().catch(() => {});
      this.updateBgmPlayback();
      ['pointerdown', 'keydown'].forEach((e) => window.removeEventListener(e, unlock));
    };
    ['pointerdown', 'keydown'].forEach((e) => window.addEventListener(e, unlock, { passive: true }));
    document.addEventListener('visibilitychange', () => {
      document.visibilityState === 'hidden' ? this.bgm.pauseAll() : this.updateBgmPlayback();
    });
  }

  public updateBgmPlayback(): void {
    this.bgm.update(this.muted, this.volume, this.bgmEnabled, this.bgmVolume);
  }

  private getContext(): AudioContext | null {
    if (this.ctx) return this.ctx;
    if (typeof window === 'undefined') return null;
    try {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return null;
      this.ctx = new AC();
      this.compressor = this.ctx.createDynamicsCompressor();
      this.compressor.threshold.setValueAtTime(-6, this.ctx.currentTime);
      this.compressor.knee.setValueAtTime(12, this.ctx.currentTime);
      this.compressor.ratio.setValueAtTime(8, this.ctx.currentTime);

      this.limiterCeiling = this.ctx.createGain();
      this.limiterCeiling.gain.setValueAtTime(0.92, this.ctx.currentTime);
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.muted ? 0 : this.volume, this.ctx.currentTime);

      this.masterGain.connect(this.compressor);
      this.compressor.connect(this.limiterCeiling);
      this.limiterCeiling.connect(this.ctx.destination);

      this.bgm.init();
      this.reloadBuffers();
      return this.ctx;
    } catch {
      return null;
    }
  }

  public reloadBuffers(): void {
    const ctx = this.getContext();
    if (!ctx) return;
    const proc = createProceduralBuffers(ctx);
    this.buffers.clear();
    (Object.keys(proc) as CueId[]).forEach((id) => this.buffers.set(id, proc[id]));

    const customConfigs = loadStudioConfigMap();
    ALL_SFX_CUES.forEach((c) => {
      const cfg = customConfigs[c.id];
      if (cfg?.enabled && cfg.formula) {
        const customBuf = compileCustomBuffer(ctx, cfg.formula, cfg.durationSec);
        if (customBuf) this.buffers.set(c.id, customBuf);
      }
    });
  }

  public previewCustomFormula(formula: string, durationSec = 0.2): boolean {
    const ctx = this.getContext();
    if (!ctx) return false;
    this.stopPreview();
    const buf = compileCustomBuffer(ctx, formula, durationSec);
    if (!buf) return false;
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.connect(this.masterGain ?? ctx.destination);
    src.start();
    this.previewSource = src;
    return true;
  }

  public stopPreview(): void {
    if (this.previewSource) {
      try { this.previewSource.stop(); this.previewSource.disconnect(); } catch {}
      this.previewSource = null;
    }
  }

  public playBuffer(id: CueId, semitones = 0, gainMult = 1.0, ignoreToggle = false): void {
    if (this.muted || this.volume <= 0) return;
    const cueSet = this.mixer[id] ?? { enabled: true, volume: 1.0 };
    if (!ignoreToggle && (!cueSet.enabled || cueSet.volume <= 0)) return;
    const now = Date.now();
    if (now - (this.lastPlayedAt[id] || 0) < THROTTLE_MS) return;
    this.lastPlayedAt[id] = now;

    const ctx = this.getContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    const buf = this.buffers.get(id);
    if (!buf) return;

    const src = ctx.createBufferSource();
    src.buffer = buf;
    if (semitones !== 0) src.playbackRate.value = Math.pow(2, semitones / 12);
    const cueGain = ctx.createGain();
    const vol = cueSet.volume > 0 ? cueSet.volume : 1.0;
    cueGain.gain.setValueAtTime(vol * gainMult, ctx.currentTime);
    src.connect(cueGain);
    cueGain.connect(this.masterGain ?? ctx.destination);
    src.start();
  }

  public playCue(id: CueId, ignoreToggle = false): void {
    this.playBuffer(id, 0, 1.0, ignoreToggle);
  }

  public playTick(pitchOffset = 0): void { this.playBuffer('tick', pitchOffset, 0.7); }
  public playNumberEntry(pitchOffset = 0): void { this.playTick(pitchOffset); }
  public playEquationSolved(pitchOffset = 0): void { this.playBuffer('equationSolved', pitchOffset, 0.9); }
  public playEquationComplete(pitchOffset = 0): void { this.playEquationSolved(pitchOffset); }
  public playStarEarned(pitchOffset = 0): void { this.playBuffer('starEarned', pitchOffset, 0.95); }
  public playHint(): void { this.playBuffer('hint', 0, 0.85); }
  public playError(): void { this.playBuffer('error', 0, 0.75); }
  public playHeartLost(): void { this.playBuffer('heartLost', 0, 0.85); }
  public playAlert30s(): void { this.playBuffer('alert30s', 0, 0.95); }
  public playTimeWarning(): void { this.playBuffer('timeWarning', 0, 0.8); }
  public playTimeUp(): void { this.playBuffer('timeUp', 0, 0.95); }
  public playVictory(): void { this.playBuffer('victory', 0, 0.95); }

  public playChimniVoice(urgent = false): void {
    if (this.muted || this.volume <= 0) return;
    const ctx = this.getContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    playChimniChirp(ctx, this.masterGain ?? ctx.destination, this.volume * 0.45, urgent);
  }

  public playCrowVoice(): void {
    if (this.muted || this.volume <= 0) return;
    const ctx = this.getContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    playCrowKavKav(ctx, this.masterGain ?? ctx.destination, this.volume * 0.5);
  }

  public isBgmPlaying(): boolean { return this.bgm.isPlaying(); }
  public getBgmTime(): number { return this.bgm.getCurrentTime(); }

  public setVolume(v: number): void {
    this.volume = Math.max(0, Math.min(1, v));
    if (this.masterGain && this.ctx) this.masterGain.gain.setValueAtTime(this.muted ? 0 : this.volume, this.ctx.currentTime);
    this.updateBgmPlayback();
    saveState({ volume: this.volume });
  }

  public setMuted(m: boolean): void {
    this.muted = m;
    if (this.masterGain && this.ctx) this.masterGain.gain.setValueAtTime(this.muted ? 0 : this.volume, this.ctx.currentTime);
    this.updateBgmPlayback();
    saveState({ muted: this.muted });
  }

  public toggleMute(): boolean { this.setMuted(!this.muted); return this.muted; }
  public isMuted(): boolean { return this.muted; }
  public getVolume(): number { return this.volume; }
  public setBgmVolume(v: number): void { this.bgmVolume = Math.max(0, Math.min(1, v)); saveBgmStorage(this.bgmEnabled, this.bgmVolume); this.updateBgmPlayback(); }
  public setBgmEnabled(e: boolean): void { this.bgmEnabled = e; saveBgmStorage(this.bgmEnabled, this.bgmVolume); this.updateBgmPlayback(); }
  public getBgmVolume(): number { return this.bgmVolume; }
  public isBgmEnabled(): boolean { return this.bgmEnabled; }
  public getMixer(): Record<CueId, CueSetting> { return { ...this.mixer }; }
  public getMixerSettings(): Record<CueId, CueSetting> { return { ...this.mixer }; }
  public setMixer(c: CueId, enabled: boolean, vol: number): void { this.mixer[c] = { enabled, volume: Math.max(0, Math.min(1, vol)) }; saveMixerStorage(this.mixer); }
  public setCueEnabled(c: CueId, e: boolean): void { this.mixer[c] = { ...this.mixer[c], enabled: e }; saveMixerStorage(this.mixer); }
  public setCueVolume(c: CueId, v: number): void { this.mixer[c] = { ...this.mixer[c], volume: Math.max(0, Math.min(1, v)) }; saveMixerStorage(this.mixer); }
  public resetMixer(): void { this.mixer = loadDefaultMixer(); saveMixerStorage(this.mixer); }
}

export const soundEngine = new SoundEngine();
