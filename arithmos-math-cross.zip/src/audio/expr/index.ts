import { tokenize } from './tokenizer';
import { parse } from './parser';
import { compileAst, AudioExprFn } from './compile';

export type { AudioExprFn };

export function compileExpression(formula: string): AudioExprFn | null {
  try {
    if (!formula || typeof formula !== 'string') return null;
    const tokens = tokenize(formula);
    const ast = parse(tokens);
    const fn = compileAst(ast);
    const testVal = fn(0.01, 44100, 440, 2 * Math.PI);
    if (typeof testVal !== 'number' || isNaN(testVal) || !isFinite(testVal)) return null;
    return fn;
  } catch {
    return null;
  }
}

export function validateExpression(formula: string): boolean {
  return compileExpression(formula) !== null;
}
