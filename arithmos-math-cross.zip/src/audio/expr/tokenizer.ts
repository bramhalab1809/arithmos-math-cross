export type TokenType =
  | 'NUM'
  | 'IDENT'
  | 'OP'
  | 'LPAREN'
  | 'RPAREN'
  | 'COMMA'
  | 'DOT'
  | 'QUESTION'
  | 'COLON'
  | 'EOF';

export interface Token {
  type: TokenType;
  val: string;
  num?: number;
  pos: number;
}

const BANNED_PATTERNS = [
  /[[\]{}`;\\'"\`]/,
  /\b(constructor|prototype|__proto__|this|window|document|fetch|eval|Function|localStorage|sessionStorage|globalThis|import|export|var|let|const|return|throw|new|delete|typeof|void|yield|await|async|class|function)\b/i,
];

export function tokenize(source: string): Token[] {
  if (source.length > 800) throw new Error('Formula exceeds maximum length of 800 characters');

  // Strip single-line and multi-line comments
  const clean = source
    .replace(/\/\*[\s\S]*?\*\//g, ' ')
    .replace(/\/\/.*/g, ' ')
    .trim();

  for (const pat of BANNED_PATTERNS) {
    if (pat.test(clean)) throw new Error('Disallowed syntax or keyword in audio formula');
  }

  const tokens: Token[] = [];
  let i = 0;
  const n = clean.length;

  while (i < n) {
    const ch = clean[i];
    if (/\s/.test(ch)) { i++; continue; }

    if (/[0-9]/.test(ch) || (ch === '.' && /[0-9]/.test(clean[i + 1] ?? ''))) {
      const start = i;
      let hasDot = ch === '.';
      let hasExp = false;
      i++;
      while (i < n) {
        const c = clean[i];
        if (/[0-9]/.test(c)) { i++; }
        else if (c === '.' && !hasDot && !hasExp) { hasDot = true; i++; }
        else if ((c === 'e' || c === 'E') && !hasExp) {
          hasExp = true;
          i++;
          if (clean[i] === '+' || clean[i] === '-') i++;
        } else break;
      }
      const raw = clean.slice(start, i);
      const val = parseFloat(raw);
      if (isNaN(val)) throw new Error(`Invalid number at position ${start}`);
      tokens.push({ type: 'NUM', val: raw, num: val, pos: start });
      continue;
    }

    if (/[a-zA-Z_$]/.test(ch)) {
      const start = i;
      while (i < n && /[a-zA-Z0-9_$]/.test(clean[i])) i++;
      const id = clean.slice(start, i);
      tokens.push({ type: 'IDENT', val: id, pos: start });
      continue;
    }

    if (ch === '(') { tokens.push({ type: 'LPAREN', val: '(', pos: i++ }); continue; }
    if (ch === ')') { tokens.push({ type: 'RPAREN', val: ')', pos: i++ }); continue; }
    if (ch === ',') { tokens.push({ type: 'COMMA', val: ',', pos: i++ }); continue; }
    if (ch === '.') { tokens.push({ type: 'DOT', val: '.', pos: i++ }); continue; }
    if (ch === '?') { tokens.push({ type: 'QUESTION', val: '?', pos: i++ }); continue; }
    if (ch === ':') { tokens.push({ type: 'COLON', val: ':', pos: i++ }); continue; }

    // Multi-char operators
    const two = clean.slice(i, i + 2);
    if (two === '**' || two === '<=' || two === '>=' || two === '==' || two === '!=' || two === '&&' || two === '||') {
      tokens.push({ type: 'OP', val: two, pos: i });
      i += 2;
      continue;
    }

    if ('+-*/%<>!'.includes(ch)) {
      tokens.push({ type: 'OP', val: ch, pos: i++ });
      continue;
    }

    throw new Error(`Unexpected character '${ch}' at position ${i}`);
  }

  tokens.push({ type: 'EOF', val: '', pos: i });
  return tokens;
}
