import { compileExpression, validateExpression } from './index';

const VALID_CASES: string[] = [
  'Math.sin(pi2 * freq * t)',
  'sin(2 * 3.14159 * 440 * t) * exp(-t * 10)',
  '(t < 0.1) ? 1 : 0',
  'abs(cos(pi2 * 110 * t)) * 0.5',
  '0.5 * sin(pi2 * 440 * t) + 0.25 * sin(pi2 * 880 * t)',
  '(t > 0.05 && t < 0.2) ? 0.8 : 0.1',
  'Math.pow(2, -t * 5) * sin(pi2 * 220 * t)',
  'max(0, min(1, sin(pi2 * t)))',
  '(sin(pi2 * t) > 0) ? 0.5 : -0.5',
  'exp(-t * 20) * (sin(pi2 * 300 * t) + 0.5 * sin(pi2 * 600 * t))',
  'Math.PI * t * freq / sr',
  '1 - t / 0.5',
];

const HOSTILE_CASES: string[] = [
  "[].constructor.constructor('return typeof process')()",
  "this['loca' + 'lStorage']",
  "window.location = 'http://evil.com'",
  'document.cookie',
  "fetch('http://evil.com')",
  "eval('1+1')",
  "new Function('return 1')()",
  'alert(1)',
  'globalThis.alert(1)',
  '(() => 1)()',
  'let x = 1; x',
  'a = 5',
  "import('fs')",
  "'a'.toString()",
];

export function runExprSelfTest(): boolean {
  for (let i = 0; i < VALID_CASES.length; i++) {
    const f = VALID_CASES[i];
    const fn = compileExpression(f);
    if (!fn) {
      console.error(`[ExprSelfTest] Valid case #${i + 1} failed compilation: ${f}`);
      return false;
    }
    const val = fn(0.02, 44100, 440, 2 * Math.PI);
    if (typeof val !== 'number' || isNaN(val) || !isFinite(val)) {
      console.error(`[ExprSelfTest] Valid case #${i + 1} produced non-finite output: ${val}`);
      return false;
    }
  }

  for (let i = 0; i < HOSTILE_CASES.length; i++) {
    const h = HOSTILE_CASES[i];
    if (validateExpression(h)) {
      console.error(`[ExprSelfTest] Hostile case #${i + 1} was NOT rejected: ${h}`);
      return false;
    }
  }

  return true;
}
