import { Token, TokenType } from './tokenizer';

export type AstNode =
  | { type: 'num'; val: number }
  | { type: 'var'; name: 't' | 'sr' | 'freq' | 'pi2' }
  | { type: 'unary'; op: '+' | '-' | '!'; arg: AstNode }
  | { type: 'binary'; op: string; left: AstNode; right: AstNode }
  | { type: 'ternary'; cond: AstNode; then: AstNode; elseNode: AstNode }
  | { type: 'call'; fn: string; args: AstNode[] };

const ALLOWED_FNS = new Set([
  'sin', 'cos', 'tan', 'exp', 'log', 'abs', 'floor',
  'ceil', 'round', 'min', 'max', 'pow', 'sqrt', 'sign', 'random'
]);

export function parse(tokens: Token[]): AstNode {
  let idx = 0;
  let nodeCount = 0;
  const maxNodes = 400;
  const maxDepth = 32;

  function countNode(depth: number) {
    if (++nodeCount > maxNodes) throw new Error('Expression exceeds maximum AST node limit (400)');
    if (depth > maxDepth) throw new Error('Expression exceeds maximum depth limit (32)');
  }

  function peek(): Token { return tokens[idx] ?? { type: 'EOF', val: '', pos: 0 }; }
  function consume(type?: TokenType): Token {
    const t = peek();
    if (type && t.type !== type) throw new Error(`Expected token ${type} but found ${t.type} (${t.val})`);
    idx++;
    return t;
  }

  function parseExpression(depth = 0): AstNode {
    return parseTernary(depth);
  }

  function parseTernary(depth: number): AstNode {
    const cond = parseLogicalOr(depth);
    if (peek().type === 'QUESTION') {
      consume('QUESTION');
      const then = parseExpression(depth + 1);
      consume('COLON');
      const elseNode = parseTernary(depth + 1);
      countNode(depth);
      return { type: 'ternary', cond, then, elseNode };
    }
    return cond;
  }

  function parseLogicalOr(depth: number): AstNode {
    let left = parseLogicalAnd(depth);
    while (peek().val === '||') {
      const op = consume().val;
      const right = parseLogicalAnd(depth + 1);
      countNode(depth);
      left = { type: 'binary', op, left, right };
    }
    return left;
  }

  function parseLogicalAnd(depth: number): AstNode {
    let left = parseEquality(depth);
    while (peek().val === '&&') {
      const op = consume().val;
      const right = parseEquality(depth + 1);
      countNode(depth);
      left = { type: 'binary', op, left, right };
    }
    return left;
  }

  function parseEquality(depth: number): AstNode {
    let left = parseComparison(depth);
    while (peek().val === '==' || peek().val === '!=') {
      const op = consume().val;
      const right = parseComparison(depth + 1);
      countNode(depth);
      left = { type: 'binary', op, left, right };
    }
    return left;
  }

  function parseComparison(depth: number): AstNode {
    let left = parseAdditive(depth);
    while (['<', '<=', '>', '>='].includes(peek().val)) {
      const op = consume().val;
      const right = parseAdditive(depth + 1);
      countNode(depth);
      left = { type: 'binary', op, left, right };
    }
    return left;
  }

  function parseAdditive(depth: number): AstNode {
    let left = parseMultiplicative(depth);
    while (peek().val === '+' || peek().val === '-') {
      const op = consume().val;
      const right = parseMultiplicative(depth + 1);
      countNode(depth);
      left = { type: 'binary', op, left, right };
    }
    return left;
  }

  function parseMultiplicative(depth: number): AstNode {
    let left = parsePower(depth);
    while (peek().val === '*' || peek().val === '/' || peek().val === '%') {
      const op = consume().val;
      const right = parsePower(depth + 1);
      countNode(depth);
      left = { type: 'binary', op, left, right };
    }
    return left;
  }

  function parsePower(depth: number): AstNode {
    const left = parseUnary(depth);
    if (peek().val === '**') {
      consume();
      const right = parsePower(depth + 1);
      countNode(depth);
      return { type: 'binary', op: '**', left, right };
    }
    return left;
  }

  function parseUnary(depth: number): AstNode {
    if (peek().val === '+' || peek().val === '-' || peek().val === '!') {
      const op = consume().val as '+' | '-' | '!';
      const arg = parseUnary(depth + 1);
      countNode(depth);
      return { type: 'unary', op, arg };
    }
    return parsePrimary(depth);
  }

  function parsePrimary(depth: number): AstNode {
    const t = peek();
    if (t.type === 'NUM') {
      consume('NUM');
      countNode(depth);
      return { type: 'num', val: t.num ?? 0 };
    }

    if (t.type === 'LPAREN') {
      consume('LPAREN');
      const expr = parseExpression(depth + 1);
      consume('RPAREN');
      return expr;
    }

    if (t.type === 'IDENT') {
      const ident = consume('IDENT').val;
      if (ident === 'Math') {
        consume('DOT');
        const prop = consume('IDENT').val;
        if (prop === 'PI') {
          countNode(depth);
          return { type: 'num', val: Math.PI };
        }
        if (prop === 'E') {
          countNode(depth);
          return { type: 'num', val: Math.E };
        }
        if (ALLOWED_FNS.has(prop)) {
          return parseCall(prop, depth + 1);
        }
        throw new Error(`Unknown or disallowed Math property: Math.${prop}`);
      }

      if (['t', 'sr', 'freq', 'pi2'].includes(ident)) {
        countNode(depth);
        return { type: 'var', name: ident as 't' | 'sr' | 'freq' | 'pi2' };
      }
      if (ident === 'PI') {
        countNode(depth);
        return { type: 'num', val: Math.PI };
      }
      if (ALLOWED_FNS.has(ident)) {
        return parseCall(ident, depth + 1);
      }
      throw new Error(`Unknown variable or function: ${ident}`);
    }

    throw new Error(`Unexpected token at position ${t.pos}: ${t.val}`);
  }

  function parseCall(fn: string, depth: number): AstNode {
    consume('LPAREN');
    const args: AstNode[] = [];
    if (peek().type !== 'RPAREN') {
      args.push(parseExpression(depth + 1));
      while (peek().type === 'COMMA') {
        consume('COMMA');
        args.push(parseExpression(depth + 1));
      }
    }
    consume('RPAREN');
    countNode(depth);
    return { type: 'call', fn, args };
  }

  const root = parseExpression(0);
  if (peek().type !== 'EOF') throw new Error(`Unexpected trailing token: ${peek().val}`);
  return root;
}
