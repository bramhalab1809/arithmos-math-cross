import { AstNode } from './parser';

export type AudioExprFn = (t: number, sr: number, freq: number, pi2: number) => number;

type MathFn = (...args: number[]) => number;

const MATH_FNS: Record<string, MathFn> = {
  sin: Math.sin,
  cos: Math.cos,
  tan: Math.tan,
  exp: Math.exp,
  log: Math.log,
  abs: Math.abs,
  floor: Math.floor,
  ceil: Math.ceil,
  round: Math.round,
  min: Math.min,
  max: Math.max,
  pow: Math.pow,
  sqrt: Math.sqrt,
  sign: Math.sign,
  random: Math.random,
};

function sanitize(val: number): number {
  if (typeof val !== 'number' || isNaN(val) || !isFinite(val)) return 0;
  return val;
}

export function compileAst(node: AstNode): AudioExprFn {
  switch (node.type) {
    case 'num': {
      const v = sanitize(node.val);
      return () => v;
    }
    case 'var': {
      const name = node.name;
      if (name === 't') return (t) => t;
      if (name === 'sr') return (_t, sr) => sr;
      if (name === 'freq') return (_t, _sr, freq) => freq;
      if (name === 'pi2') return (_t, _sr, _freq, pi2) => pi2;
      return () => 0;
    }
    case 'unary': {
      const argFn = compileAst(node.arg);
      if (node.op === '-') return (t, sr, f, p) => -sanitize(argFn(t, sr, f, p));
      if (node.op === '+') return (t, sr, f, p) => sanitize(argFn(t, sr, f, p));
      if (node.op === '!') return (t, sr, f, p) => (sanitize(argFn(t, sr, f, p)) ? 0 : 1);
      return () => 0;
    }
    case 'binary': {
      const leftFn = compileAst(node.left);
      const rightFn = compileAst(node.right);
      const op = node.op;

      switch (op) {
        case '+': return (t, sr, f, p) => sanitize(leftFn(t, sr, f, p) + rightFn(t, sr, f, p));
        case '-': return (t, sr, f, p) => sanitize(leftFn(t, sr, f, p) - rightFn(t, sr, f, p));
        case '*': return (t, sr, f, p) => sanitize(leftFn(t, sr, f, p) * rightFn(t, sr, f, p));
        case '/': return (t, sr, f, p) => {
          const r = rightFn(t, sr, f, p);
          if (r === 0) return 0;
          return sanitize(leftFn(t, sr, f, p) / r);
        };
        case '%': return (t, sr, f, p) => {
          const r = rightFn(t, sr, f, p);
          if (r === 0) return 0;
          return sanitize(leftFn(t, sr, f, p) % r);
        };
        case '**': return (t, sr, f, p) => sanitize(Math.pow(leftFn(t, sr, f, p), rightFn(t, sr, f, p)));
        case '<': return (t, sr, f, p) => (leftFn(t, sr, f, p) < rightFn(t, sr, f, p) ? 1 : 0);
        case '<=': return (t, sr, f, p) => (leftFn(t, sr, f, p) <= rightFn(t, sr, f, p) ? 1 : 0);
        case '>': return (t, sr, f, p) => (leftFn(t, sr, f, p) > rightFn(t, sr, f, p) ? 1 : 0);
        case '>=': return (t, sr, f, p) => (leftFn(t, sr, f, p) >= rightFn(t, sr, f, p) ? 1 : 0);
        case '==': return (t, sr, f, p) => (leftFn(t, sr, f, p) === rightFn(t, sr, f, p) ? 1 : 0);
        case '!=': return (t, sr, f, p) => (leftFn(t, sr, f, p) !== rightFn(t, sr, f, p) ? 1 : 0);
        case '&&': return (t, sr, f, p) => (leftFn(t, sr, f, p) && rightFn(t, sr, f, p) ? 1 : 0);
        case '||': return (t, sr, f, p) => (leftFn(t, sr, f, p) || rightFn(t, sr, f, p) ? 1 : 0);
        default: return () => 0;
      }
    }
    case 'ternary': {
      const condFn = compileAst(node.cond);
      const thenFn = compileAst(node.then);
      const elseFn = compileAst(node.elseNode);
      return (t, sr, f, p) => (condFn(t, sr, f, p) ? thenFn(t, sr, f, p) : elseFn(t, sr, f, p));
    }
    case 'call': {
      const fn = MATH_FNS[node.fn];
      if (!fn) return () => 0;
      const compiledArgs = node.args.map(compileAst);
      return (t, sr, f, p) => {
        const evaluatedArgs = compiledArgs.map((a) => a(t, sr, f, p));
        return sanitize(fn(...evaluatedArgs));
      };
    }
    default:
      return () => 0;
  }
}
