/**
 * 100% Offline Procedural Web Audio Synthesizer.
 * Peak-normalized (0.92) PCM synthesis with zero click/pop fade envelopes.
 */

export type CueId =
  | 'tick'
  | 'equationSolved'
  | 'starEarned'
  | 'hint'
  | 'error'
  | 'heartLost'
  | 'alert30s'
  | 'timeWarning'
  | 'timeUp'
  | 'victory';

export function makePcm(
  ctx: AudioContext,
  durationSec: number,
  synth: (t: number, sampleRate: number) => number
): AudioBuffer {
  const sr = ctx.sampleRate;
  const len = Math.max(1, Math.floor(durationSec * sr));
  const raw = new Float32Array(len);
  let maxPeak = 0;

  for (let i = 0; i < len; i++) {
    const s = synth(i / sr, sr);
    raw[i] = s;
    const a = Math.abs(s);
    if (a > maxPeak) maxPeak = a;
  }

  const norm = maxPeak > 0.001 ? 0.92 / maxPeak : 1;
  const buf = ctx.createBuffer(1, len, sr);
  const data = buf.getChannelData(0);
  const inSamples = Math.floor(0.002 * sr);
  const outSamples = Math.floor(0.014 * sr);

  for (let i = 0; i < len; i++) {
    let s = raw[i] * norm;
    if (i < inSamples) s *= i / inSamples;
    const fromEnd = len - 1 - i;
    if (fromEnd < outSamples) s *= fromEnd / outSamples;
    data[i] = Math.max(-1, Math.min(1, s));
  }
  return buf;
}

export function createProceduralBuffers(ctx: AudioContext): Record<CueId, AudioBuffer> {
  const pi2 = 2 * Math.PI;

  return {
    tick: makePcm(ctx, 0.05, (t) => {
      const f = 420 * Math.exp(-t * 26);
      return Math.sin(pi2 * f * t) * Math.exp(-t * 42);
    }),
    equationSolved: makePcm(ctx, 0.28, (t) => {
      const a = Math.sin(pi2 * 587.33 * t) * 0.6;
      const b = Math.sin(pi2 * 880 * t) * 0.4;
      const c = Math.sin(pi2 * 1174.66 * t) * 0.2;
      return (a + b + c) * Math.exp(-t * 8);
    }),
    starEarned: makePcm(ctx, 0.36, (t) => {
      const f = t < 0.08 ? 523.25 : t < 0.16 ? 659.25 : t < 0.24 ? 783.99 : 1046.5;
      const chime = Math.sin(pi2 * f * t) + 0.35 * Math.sin(pi2 * f * 2 * t);
      return chime * Math.exp(-t * 7);
    }),
    hint: makePcm(ctx, 0.22, (t) => {
      const f = t < 0.09 ? 587.33 : 880;
      return Math.sin(pi2 * f * t) * Math.exp(-t * 9);
    }),
    error: makePcm(ctx, 0.18, (t) => {
      const f = Math.max(55, 145 - t * 280);
      const sub = Math.sin(pi2 * f * t);
      const buzz = Math.sin(pi2 * (f * 1.5) * t) * 0.3;
      return (sub + buzz) * Math.exp(-t * 11);
    }),
    heartLost: makePcm(ctx, 0.25, (t) => {
      const wobble = 1 + 0.15 * Math.sin(pi2 * 18 * t);
      const f = (380 * Math.exp(-t * 4.2)) * wobble;
      return Math.sin(pi2 * f * t) * Math.exp(-t * 6.5);
    }),
    alert30s: makePcm(ctx, 0.28, (t) => {
      const pulse = (t < 0.11 || (t > 0.15 && t < 0.26)) ? 1 : 0;
      return Math.sin(pi2 * 293.66 * t) * pulse * Math.exp(-(t % 0.13) * 12);
    }),
    timeWarning: makePcm(ctx, 0.08, (t) => {
      return Math.sin(pi2 * 880 * t) * Math.exp(-t * 16);
    }),
    timeUp: makePcm(ctx, 0.34, (t) => {
      const f = t < 0.1 ? 329.63 : t < 0.2 ? 261.63 : 196;
      return (Math.sin(pi2 * f * t) + 0.4 * Math.sin(pi2 * (f * 0.5) * t)) * Math.exp(-t * 5.5);
    }),
    victory: makePcm(ctx, 0.55, (t) => {
      const f = t < 0.1 ? 523.25 : t < 0.2 ? 659.25 : t < 0.3 ? 783.99 : 1046.5;
      const sub = Math.sin(pi2 * f * t) * 0.7;
      const fifth = Math.sin(pi2 * (f * 1.5) * t) * 0.3;
      return (sub + fifth) * Math.exp(-t * 4.5);
    }),
  };
}

export const createFallbackBuffers = createProceduralBuffers;
