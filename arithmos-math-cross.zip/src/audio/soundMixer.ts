import { CueId } from './audioBuffers';
import { ALL_SFX_CUES } from './customAudioSynth';

export const SFX_MIXER_KEY = 'arithmos_sfx_mixer_v2';
export const BGM_STORAGE_KEY = 'arithmos_bgm_v1';

export interface CueSetting {
  enabled: boolean;
  volume: number;
}

const DEFAULT_ENABLED_CUES: Set<CueId> = new Set(['tick', 'timeUp', 'victory']);

export function loadDefaultMixer(): Record<CueId, CueSetting> {
  const d = ALL_SFX_CUES.reduce((acc, c) => {
    acc[c.id] = { enabled: DEFAULT_ENABLED_CUES.has(c.id), volume: 1.0 };
    return acc;
  }, {} as Record<CueId, CueSetting>);

  if (typeof window === 'undefined') return d;
  try {
    const raw = localStorage.getItem(SFX_MIXER_KEY);
    if (raw) return { ...d, ...JSON.parse(raw) };
  } catch {}
  return d;
}

export function saveMixerStorage(mixer: Record<CueId, CueSetting>): void {
  try {
    localStorage.setItem(SFX_MIXER_KEY, JSON.stringify(mixer));
  } catch {}
}

export function loadBgmStorage(): { enabled: boolean; volume: number } {
  let enabled = true;
  let volume = 0.5;
  if (typeof window === 'undefined') return { enabled, volume };
  try {
    const p = JSON.parse(localStorage.getItem(BGM_STORAGE_KEY) || '{}');
    if (typeof p.enabled === 'boolean') enabled = p.enabled;
    if (typeof p.volume === 'number') volume = p.volume;
  } catch {}
  return { enabled, volume };
}

export function saveBgmStorage(enabled: boolean, volume: number): void {
  try {
    localStorage.setItem(BGM_STORAGE_KEY, JSON.stringify({ enabled, volume }));
  } catch {}
}
