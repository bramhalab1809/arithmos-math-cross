export class BgmPlayer {
  private bgmAudio: HTMLAudioElement | null = null;
  private fallbackIdx = 0;

  public init(): void {
    if (typeof window === 'undefined') return;
    try {
      const base = import.meta.env.BASE_URL || './';
      const cleanBase = base.endsWith('/') ? base : `${base}/`;
      const candidates = [
        `${cleanBase}audio/ambient-loop.mp3`,
        './audio/ambient-loop.mp3',
        'audio/ambient-loop.mp3',
        `${cleanBase}ambient-loop.mp3`,
        './ambient-loop.mp3',
      ];
      this.fallbackIdx = 0;
      this.bgmAudio = new Audio(candidates[0]);
      this.bgmAudio.loop = true;
      this.bgmAudio.preload = 'auto';
      this.bgmAudio.addEventListener('loadedmetadata', () => {
        if (this.bgmAudio && this.bgmAudio.currentTime < 2.2) {
          try { this.bgmAudio.currentTime = 2.5; } catch { /* ignore */ }
        }
      });
      this.bgmAudio.addEventListener('error', () => {
        this.fallbackIdx += 1;
        if (this.bgmAudio && this.fallbackIdx < candidates.length) {
          this.bgmAudio.src = candidates[this.fallbackIdx];
        }
      });
    } catch { /* ignore */ }
  }

  public update(muted: boolean, masterVolume: number, bgmEnabled: boolean, bgmVolume: number): void {
    if (!this.bgmAudio) this.init();
    if (!this.bgmAudio) return;
    if (muted || masterVolume <= 0 || !bgmEnabled || bgmVolume <= 0) {
      this.bgmAudio.pause();
      return;
    }
    this.bgmAudio.volume = Math.max(0, Math.min(1, masterVolume * bgmVolume));
    if (this.bgmAudio.paused) {
      if (this.bgmAudio.currentTime < 2.2 && this.bgmAudio.readyState >= 1) {
        try { this.bgmAudio.currentTime = 2.5; } catch { /* ignore */ }
      }
      this.bgmAudio.play().catch(() => {});
    }
  }

  public pauseAll(): void { this.bgmAudio?.pause(); }
  public isPlaying(): boolean { return Boolean(this.bgmAudio && !this.bgmAudio.paused); }
  public getCurrentTime(): number { return this.bgmAudio?.currentTime ?? 0; }
}
