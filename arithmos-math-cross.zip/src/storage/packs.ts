import { LabLevel, LabPack } from '../features/lab/schema/packTypes';
import { validatePackJson } from '../features/lab/schema/packValidator';

export const LAB_PACKS_KEY = 'arithmos_packs_v1';
export const LAB_PROGRESS_KEY = 'arithmos_pack_progress_v1';
export const LAB_PACK_LIMIT = 20;

export interface LabLevelProgress {
  bestTimeSec: number;
  solvedAt: number;
}

let activeLabContext: { packId: string; levelIndex: number } | null = null;

export function setActiveLabContext(ctx: { packId: string; levelIndex: number } | null): void {
  activeLabContext = ctx;
}

export function getActiveLabContext(): { packId: string; levelIndex: number } | null {
  return activeLabContext;
}

export const DEFAULT_STARTER_PACK: LabPack = {
  id: 'starter_alchemist',
  title: "The Alchemist's Trial",
  author: 'Arithmos Lab',
  description: 'Handcrafted mathematical trials demonstrating Level Lab capabilities.',
  difficulty: 'normal',
  gridType: '3x3',
  version: 1,
  createdAt: '2025-01-01T00:00:00.000Z',
  levels: [
    {
      kind: 'grid',
      title: 'Initiate Formula',
      author: 'Arithmos Lab',
      size: 3,
      cells: [
        [{ solution: 3, isClue: true }, { solution: 4, isClue: false, hasStar: true }, { solution: 7, isClue: true }],
        [{ solution: 2, isClue: false }, { solution: 5, isClue: true }, { solution: 7, isClue: true }],
        [{ solution: 5, isClue: true }, { solution: 9, isClue: true }, { solution: 14, isClue: true }],
      ],
      rowOps: [['+'], ['+'], ['+']],
      colOps: [['+', '+', '+']],
      timeLimitSeconds: 120,
    },
    {
      kind: 'grid',
      title: 'Transmutation Cross',
      author: 'Arithmos Lab',
      size: 3,
      cells: [
        [{ solution: 6, isClue: true }, { solution: 2, isClue: false }, { solution: 3, isClue: true }],
        [{ solution: 3, isClue: false, hasStar: true }, { solution: 4, isClue: true }, { solution: 12, isClue: true }],
        [{ solution: 2, isClue: true }, { solution: 8, isClue: true }, { solution: 4, isClue: true }],
      ],
      rowOps: [['/'], ['*'], ['/']],
      colOps: [['/', '*', '/']],
      timeLimitSeconds: 120,
    },
    {
      kind: 'spec',
      title: 'Grand Nexus',
      author: 'Arithmos Lab',
      tier: 'medium',
      size: 3,
      timeLimitSeconds: 180,
    },
  ],
};

export function loadLabPacks(): LabPack[] {
  if (typeof window === 'undefined') return [DEFAULT_STARTER_PACK];
  try {
    const raw = localStorage.getItem(LAB_PACKS_KEY);
    if (!raw) {
      localStorage.setItem(LAB_PACKS_KEY, JSON.stringify([DEFAULT_STARTER_PACK]));
      return [DEFAULT_STARTER_PACK];
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) return parsed;
  } catch {}
  return [DEFAULT_STARTER_PACK];
}

export function saveLabPack(pack: LabPack): { success: boolean; error?: string } {
  const current = loadLabPacks();
  const existingIdx = current.findIndex((p) => p.id === pack.id);

  if (existingIdx === -1 && current.length >= LAB_PACK_LIMIT) {
    return { success: false, error: `Lab quota reached (max ${LAB_PACK_LIMIT} projects). Delete one first.` };
  }

  const updated = existingIdx >= 0
    ? current.map((p, i) => (i === existingIdx ? pack : p))
    : [pack, ...current];

  try {
    localStorage.setItem(LAB_PACKS_KEY, JSON.stringify(updated));
    return { success: true };
  } catch (err) {
    return { success: false, error: (err as Error).message };
  }
}

export function appendLevelsToPack(packId: string, newLevels: LabLevel[]): LabPack | null {
  const current = loadLabPacks();
  const target = current.find((p) => p.id === packId);
  if (!target) return null;
  const combined = [...target.levels, ...newLevels].slice(0, 100);
  const updatedPack: LabPack = { ...target, levels: combined };
  saveLabPack(updatedPack);
  return updatedPack;
}

export function deleteLabPack(packId: string): void {
  const current = loadLabPacks();
  const filtered = current.filter((p) => p.id !== packId);
  try {
    localStorage.setItem(LAB_PACKS_KEY, JSON.stringify(filtered.length > 0 ? filtered : [DEFAULT_STARTER_PACK]));
  } catch {}
}

export function getLabPack(packId: string): LabPack | null {
  return loadLabPacks().find((p) => p.id === packId) || null;
}

export function getLabPackProgress(packId: string): Record<number, LabLevelProgress> {
  if (typeof window === 'undefined') return {};
  try {
    const raw = localStorage.getItem(LAB_PROGRESS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return parsed?.[packId] || {};
    }
  } catch {}
  return {};
}

export function recordLabLevelWin(packId: string, levelIndex: number, timeSec: number): void {
  if (typeof window === 'undefined') return;
  try {
    const raw = localStorage.getItem(LAB_PROGRESS_KEY);
    const store = raw ? JSON.parse(raw) : {};
    const packMap: Record<number, LabLevelProgress> = store[packId] || {};
    const prev = packMap[levelIndex];
    packMap[levelIndex] = {
      bestTimeSec: prev ? Math.min(prev.bestTimeSec, Math.max(1, timeSec)) : Math.max(1, timeSec),
      solvedAt: Date.now(),
    };
    store[packId] = packMap;
    localStorage.setItem(LAB_PROGRESS_KEY, JSON.stringify(store));
  } catch {}
}

export function exportPackToJson(pack: LabPack): string {
  return JSON.stringify(pack, null, 2);
}

export function exportPackToBase64Url(pack: LabPack): string {
  const json = JSON.stringify(pack);
  const utf8 = new TextEncoder().encode(json);
  let binary = '';
  for (let i = 0; i < utf8.length; i++) binary += String.fromCharCode(utf8[i]);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export function importPackFromBase64Url(b64: string): { valid: boolean; pack?: LabPack; errors: string[] } {
  try {
    let base64 = b64.replace(/-/g, '+').replace(/_/g, '/');
    while (base64.length % 4 !== 0) base64 += '=';
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    const json = new TextDecoder().decode(bytes);
    return validatePackJson(json);
  } catch (err) {
    return { valid: false, errors: [`Base64URL decode failed: ${(err as Error).message}`] };
  }
}
