import { loadHistory } from './history';
import { GameMode } from './schema';
import { loadState } from './storage';

export const LEVEL_MAP_KEY = 'arithmos_level_map_v1';
export const CHUNK_SIZE = 10;

export interface LevelMapRecord {
  level: number;
  bestTimeSec: number;
  stars?: 1 | 2 | 3;
  solvedAt: number;
}

type FullMapStore = Record<string, Record<number, LevelMapRecord>>;

export function getLevelMapSlotKey(mode: GameMode, overrideSize?: number | null): string {
  if (mode === 'practice') {
    return overrideSize ? `practice:${overrideSize}` : 'practice:auto';
  }
  return mode;
}

function readRawStore(): FullMapStore {
  if (typeof window === 'undefined') return {};
  try {
    const raw = localStorage.getItem(LEVEL_MAP_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') return parsed;
    }
  } catch {}
  return {};
}

function writeRawStore(store: FullMapStore): void {
  try {
    localStorage.setItem(LEVEL_MAP_KEY, JSON.stringify(store));
  } catch {}
}

export function loadLevelMap(slotKey: string): Record<number, LevelMapRecord> {
  const store = readRawStore();
  const existing = store[slotKey] || {};
  const state = loadState();
  const history = loadHistory();

  let currentSlotLevel = 1;
  let targetMode: GameMode = 'endless';
  let targetGrid: number | null = null;

  if (slotKey === 'endless') {
    currentSlotLevel = state.modes.endless.level;
    targetMode = 'endless';
  } else if (slotKey === 'star') {
    currentSlotLevel = state.modes.star.level;
    targetMode = 'star';
  } else if (slotKey.startsWith('practice:')) {
    targetMode = 'practice';
    const sub = slotKey.split(':')[1] || 'auto';
    targetGrid = sub === 'auto' ? null : Number(sub);
    const pSlot = state.modes.practice?.slots?.[sub as keyof typeof state.modes.practice.slots];
    currentSlotLevel = pSlot?.level ?? 1;
  }

  let dirty = false;
  for (const h of history) {
    if (!h.won || h.mode !== targetMode) continue;
    if (targetMode === 'practice' && targetGrid !== null && h.gridSize !== targetGrid) continue;
    const prev = existing[h.level];
    if (!prev || h.elapsedSeconds < prev.bestTimeSec) {
      existing[h.level] = {
        level: h.level,
        bestTimeSec: Math.max(1, h.elapsedSeconds),
        stars: h.stars,
        solvedAt: h.timestamp,
      };
      dirty = true;
    }
  }

  for (let lvl = 1; lvl < currentSlotLevel; lvl++) {
    if (!existing[lvl]) {
      existing[lvl] = {
        level: lvl,
        bestTimeSec: 25 + (lvl % 15),
        stars: targetMode === 'star' ? 3 : undefined,
        solvedAt: Date.now(),
      };
      dirty = true;
    }
  }

  if (dirty) {
    store[slotKey] = existing;
    writeRawStore(store);
  }

  return existing;
}

export function recordLevelMapWin(
  mode: GameMode,
  overrideSize: number | null,
  level: number,
  timeSec: number,
  stars?: 1 | 2 | 3
): void {
  if (mode !== 'endless' && mode !== 'star' && mode !== 'practice') return;
  const slotKey = getLevelMapSlotKey(mode, overrideSize);
  const store = readRawStore();
  const map = store[slotKey] || {};
  const prev = map[level];
  const bestTimeSec = prev ? Math.min(prev.bestTimeSec, Math.max(1, timeSec)) : Math.max(1, timeSec);
  const bestStars =
    stars && prev?.stars ? (Math.max(stars, prev.stars) as 1 | 2 | 3) : stars ?? prev?.stars;

  map[level] = {
    level,
    bestTimeSec,
    stars: bestStars,
    solvedAt: Date.now(),
  };
  store[slotKey] = map;
  writeRawStore(store);
}

export function getVisibleFogChunkCount(
  solvedRecords: Record<number, LevelMapRecord>,
  highestUnlockedLevel: number
): number {
  const solvedNums = Object.keys(solvedRecords).map(Number);
  const maxSolved = solvedNums.length > 0 ? Math.max(...solvedNums) : 0;
  const effectiveFront = Math.max(highestUnlockedLevel, maxSolved + 1, 1);
  return Math.max(CHUNK_SIZE, Math.ceil(effectiveFront / CHUNK_SIZE) * CHUNK_SIZE);
}
