import { GameMode } from './schema';
import { loadState } from './storage';

export const LEVEL_MAP_KEY = 'arithmos_level_map_v1';
export const CHUNK_SIZE = 10;

export interface LevelMapRecord {
  level: number;
  bestTimeSec: number;
  stars?: 1 | 2 | 3;
  solvedAt: number;
}

type FullMapStore = Record<string, Record<number, LevelMapRecord>>;

export function getLevelMapSlotKey(mode: GameMode, overrideSize?: number | null): string {
  if (mode === 'practice') {
    return overrideSize ? `practice:${overrideSize}` : 'practice:auto';
  }
  if (mode === 'hardcore') {
    return overrideSize ? `hardcore:${overrideSize}` : 'hardcore:auto';
  }
  return mode;
}

function readRawStore(): FullMapStore {
  if (typeof window === 'undefined') return {};
  try {
    const raw = localStorage.getItem(LEVEL_MAP_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') return parsed;
    }
  } catch {}
  return {};
}

function writeRawStore(store: FullMapStore): void {
  try {
    localStorage.setItem(LEVEL_MAP_KEY, JSON.stringify(store));
  } catch {}
}

export function clearLevelMapForMode(mode: GameMode | 'all'): void {
  if (typeof window === 'undefined') return;
  try {
    if (mode === 'all') {
      localStorage.removeItem(LEVEL_MAP_KEY);
      return;
    }
    const store = readRawStore();
    for (const key of Object.keys(store)) {
      if (key === mode || key.startsWith(`${mode}:`)) {
        delete store[key];
      }
    }
    writeRawStore(store);
  } catch {}
}

export function loadLevelMap(slotKey: string): Record<number, LevelMapRecord> {
  const store = readRawStore();
  const existing = store[slotKey] || {};
  const state = loadState();

  let currentSlotLevel = 1;
  let targetMode: GameMode = 'endless';

  if (slotKey === 'endless') {
    currentSlotLevel = state.modes.endless.level;
    targetMode = 'endless';
  } else if (slotKey === 'star') {
    currentSlotLevel = state.modes.star.level;
    targetMode = 'star';
  } else if (slotKey.startsWith('practice:') || slotKey.startsWith('hardcore:')) {
    const isHardcore = slotKey.startsWith('hardcore:');
    targetMode = isHardcore ? 'hardcore' : 'practice';
    const sub = slotKey.split(':')[1] || 'auto';
    const container = isHardcore ? state.modes.hardcore : state.modes.practice;
    const pSlot = container?.slots?.[sub as keyof typeof state.modes.practice.slots];
    currentSlotLevel = pSlot?.level ?? 1;
  }

  let dirty = false;
  // Remove any stale records above currentSlotLevel - 1 so unbeaten levels never appear solved
  for (const k of Object.keys(existing)) {
    const lvlNum = Number(k);
    if (lvlNum >= currentSlotLevel) {
      delete existing[lvlNum];
      dirty = true;
    }
  }

  for (let lvl = 1; lvl < currentSlotLevel; lvl++) {
    if (!existing[lvl]) {
      existing[lvl] = {
        level: lvl,
        bestTimeSec: 25 + (lvl % 15),
        stars: targetMode === 'star' || targetMode === 'hardcore' ? 3 : undefined,
        solvedAt: Date.now(),
      };
      dirty = true;
    }
  }

  if (dirty) {
    store[slotKey] = existing;
    writeRawStore(store);
  }

  return existing;
}

export function recordLevelMapWin(
  mode: GameMode,
  overrideSize: number | null,
  level: number,
  timeSec: number,
  stars?: 1 | 2 | 3
): void {
  if (mode !== 'endless' && mode !== 'star' && mode !== 'practice' && mode !== 'hardcore') return;
  const slotKey = getLevelMapSlotKey(mode, overrideSize);
  const store = readRawStore();
  const map = store[slotKey] || {};
  const prev = map[level];
  const bestTimeSec = prev ? Math.min(prev.bestTimeSec, Math.max(1, timeSec)) : Math.max(1, timeSec);
  const bestStars =
    stars && prev?.stars ? (Math.max(stars, prev.stars) as 1 | 2 | 3) : stars ?? prev?.stars;

  map[level] = {
    level,
    bestTimeSec,
    stars: bestStars,
    solvedAt: Date.now(),
  };
  store[slotKey] = map;
  writeRawStore(store);
}

export function getVisibleFogChunkCount(
  _solvedRecords: Record<number, LevelMapRecord>,
  highestUnlockedLevel: number
): number {
  const effectiveFront = Math.max(highestUnlockedLevel, 1);
  return Math.max(CHUNK_SIZE, Math.ceil(effectiveFront / CHUNK_SIZE) * CHUNK_SIZE);
}
