const DB_NAME = 'arithmos_native_db';
const STORE_NAME = 'kv';
const KEY_PREFIX = 'arithmos_';

function openNativeDb(): Promise<IDBDatabase | null> {
  if (typeof window === 'undefined' || !('indexedDB' in window)) {
    return Promise.resolve(null);
  }
  return new Promise((resolve) => {
    try {
      const req = window.indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME);
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

function collectLocalStorageSnapshot(): Record<string, string> {
  const snapshot: Record<string, string> = {};
  if (typeof window === 'undefined') return snapshot;
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k && k.startsWith(KEY_PREFIX)) {
      const v = localStorage.getItem(k);
      if (v !== null) snapshot[k] = v;
    }
  }
  return snapshot;
}

export async function hydrateStorageFromNativeDb(): Promise<void> {
  if (typeof window === 'undefined') return;

  // Tier 1: Windows .exe native file system (%APPDATA%/Arithmos/arithmos-storage.json)
  if (window.arithmosElectron?.readSaveFile) {
    try {
      const diskData = await window.arithmosElectron.readSaveFile();
      if (diskData && typeof diskData === 'object') {
        for (const [k, v] of Object.entries(diskData)) {
          if (k.startsWith(KEY_PREFIX) && typeof v === 'string') {
            if (localStorage.getItem(k) === null) {
              localStorage.setItem(k, v);
            }
          }
        }
      }
    } catch {
      // ignore desktop read errors
    }
  }

  // Tier 2: IndexedDB mirror (Android APK Capacitor WebView & Web)
  const db = await openNativeDb();
  if (!db) return;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const keysReq = store.getAllKeys();
      const valsReq = store.getAll();
      tx.oncomplete = () => {
        const keys = keysReq.result || [];
        const vals = valsReq.result || [];
        for (let i = 0; i < keys.length; i++) {
          const k = String(keys[i]);
          const v = vals[i];
          if (k.startsWith(KEY_PREFIX) && typeof v === 'string') {
            if (localStorage.getItem(k) === null) {
              localStorage.setItem(k, v);
            }
          }
        }
        resolve();
      };
      tx.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

export async function syncStorageToNativeDb(): Promise<void> {
  if (typeof window === 'undefined') return;
  const snapshot = collectLocalStorageSnapshot();

  // Tier 1: Windows .exe native disk write
  if (window.arithmosElectron?.writeSaveFile) {
    try {
      await window.arithmosElectron.writeSaveFile(snapshot);
    } catch {
      // ignore desktop write errors
    }
  }

  // Tier 2: IndexedDB mirror write
  const db = await openNativeDb();
  if (!db) return;
  try {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    for (const [k, v] of Object.entries(snapshot)) {
      store.put(v, k);
    }
  } catch {
    // ignore IndexedDB errors
  }
}

declare global {
  interface Window {
    arithmosElectron?: {
      readSaveFile: () => Promise<Record<string, string> | null>;
      writeSaveFile: (data: Record<string, string>) => Promise<boolean>;
    };
    arithmosStorage?: {
      hydrateStorageFromNativeDb: typeof hydrateStorageFromNativeDb;
      syncStorageToNativeDb: typeof syncStorageToNativeDb;
    };
  }
}

if (typeof window !== 'undefined') {
  window.arithmosStorage = { hydrateStorageFromNativeDb, syncStorageToNativeDb };
}
