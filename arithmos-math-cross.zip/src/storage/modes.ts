import {
  DEFAULT_MODE_SLOT,
  DEFAULT_PRACTICE_STATE,
  DEFAULT_STAR_SLOT,
  GameMode,
  ModeSlot,
  PracticeGridKey,
  StoredStateV3,
} from './schema';
import { getModeRules } from '../features/game/state/modeRules';

export function getModeSlot(
  state: StoredStateV3,
  mode: GameMode,
  gridSize?: number | null,
  isAuto = false
): ModeSlot {
  if (mode === 'endless') {
    return { ...state.modes.endless, easeNext: Boolean(state.modes.endless.easeNext) };
  }
  if (mode === 'star') {
    return { ...state.modes.star, easeNext: Boolean(state.modes.star.easeNext) };
  }

  const pKey: PracticeGridKey = isAuto || !gridSize ? 'auto' : (String(gridSize) as PracticeGridKey);
  const container = mode === 'hardcore' ? (state.modes.hardcore || DEFAULT_PRACTICE_STATE) : (state.modes.practice || DEFAULT_PRACTICE_STATE);
  const pSlot = container.slots?.[pKey] || { rating: 100, level: 1, played: 0, easeNext: false };
  return {
    rating: pSlot.rating,
    level: pSlot.level,
    bestLevel: pSlot.level,
    played: pSlot.played,
    easeNext: Boolean(pSlot.easeNext),
  };
}

export function updateModeSlotOnWin(
  state: StoredStateV3,
  mode: GameMode,
  gridSize: number | null,
  newRating: number,
  starsEarned?: 1 | 2 | 3,
  easeNext = false,
  solvedLevel?: number
): StoredStateV3 {
  if (mode !== 'endless' && mode !== 'star' && mode !== 'practice' && mode !== 'hardcore') return state;

  if (mode === 'endless') {
    const cur = state.modes.endless;
    const nextLevel = Math.max(cur.level, (solvedLevel ?? cur.level) + 1);
    return {
      ...state,
      modes: {
        ...state.modes,
        endless: {
          rating: newRating,
          level: nextLevel,
          bestLevel: Math.max(cur.bestLevel, nextLevel),
          played: cur.played + 1,
          easeNext,
        },
      },
    };
  }

  if (mode === 'star') {
    const cur = state.modes.star;
    const nextLevel = Math.max(cur.level, (solvedLevel ?? cur.level) + 1);
    const stars = starsEarned ?? 1;
    const nextStreak = stars === 3 ? cur.currentStreak + 1 : 0;
    return {
      ...state,
      modes: {
        ...state.modes,
        star: {
          rating: newRating,
          level: nextLevel,
          bestLevel: Math.max(cur.bestLevel, nextLevel),
          played: cur.played + 1,
          totalStars: cur.totalStars + stars,
          currentStreak: nextStreak,
          bestStreak: Math.max(cur.bestStreak, nextStreak),
          easeNext,
        },
      },
    };
  }

  // Practice & Hardcore modes: rating never lowers on win
  const pKey: PracticeGridKey = gridSize === null ? 'auto' : (String(gridSize) as PracticeGridKey);
  const isHardcore = mode === 'hardcore';
  const curPractice = (isHardcore ? state.modes.hardcore : state.modes.practice) || { ...DEFAULT_PRACTICE_STATE };
  const cur = curPractice.slots[pKey] || { rating: 100, level: 1, played: 0, easeNext: false };
  const nextRating = Math.max(cur.rating, newRating);
  const nextLevel = Math.max(cur.level, (solvedLevel ?? cur.level) + 1);

  const updatedContainer = {
    lastGridSize: gridSize === null ? 'auto' : (gridSize as 3 | 4 | 5 | 6 | 7),
    slots: {
      ...curPractice.slots,
      [pKey]: { rating: nextRating, level: nextLevel, played: cur.played + 1, easeNext },
    },
  };

  return {
    ...state,
    modes: {
      ...state.modes,
      [isHardcore ? 'hardcore' : 'practice']: updatedContainer,
    },
  };
}

export function updateModeSlotOnLoss(
  state: StoredStateV3,
  mode: GameMode,
  _gridSize: number | null,
  newRating: number,
  easeNext = true
): StoredStateV3 {
  if (!getModeRules(mode).hasTimer) return state;
  if (mode === 'endless') {
    return {
      ...state,
      modes: {
        ...state.modes,
        endless: {
          ...state.modes.endless,
          rating: newRating,
          played: state.modes.endless.played + 1,
          easeNext,
        },
      },
    };
  }
  if (mode === 'star') {
    return {
      ...state,
      modes: {
        ...state.modes,
        star: {
          ...state.modes.star,
          rating: newRating,
          played: state.modes.star.played + 1,
          currentStreak: 0,
          easeNext,
        },
      },
    };
  }
  return state;
}

export function clearSlotEaseNext(
  state: StoredStateV3,
  mode: GameMode,
  gridSize: number | null
): StoredStateV3 {
  if (mode === 'endless') {
    return { ...state, modes: { ...state.modes, endless: { ...state.modes.endless, easeNext: false } } };
  }
  if (mode === 'star') {
    return { ...state, modes: { ...state.modes, star: { ...state.modes.star, easeNext: false } } };
  }
  const isHardcore = mode === 'hardcore';
  const pKey: PracticeGridKey = gridSize === null ? 'auto' : (String(gridSize) as PracticeGridKey);
  const curPractice = (isHardcore ? state.modes.hardcore : state.modes.practice) || { ...DEFAULT_PRACTICE_STATE };
  const cur = curPractice.slots[pKey] || { rating: 100, level: 1, played: 0, easeNext: false };
  return {
    ...state,
    modes: {
      ...state.modes,
      [isHardcore ? 'hardcore' : 'practice']: {
        ...curPractice,
        slots: {
          ...curPractice.slots,
          [pKey]: { ...cur, easeNext: false },
        },
      },
    },
  };
}

export function resetMode(
  state: StoredStateV3,
  mode: GameMode,
  gridSize?: number | null
): StoredStateV3 {
  if (mode === 'endless') {
    return { ...state, modes: { ...state.modes, endless: { ...DEFAULT_MODE_SLOT } } };
  }
  if (mode === 'star') {
    return { ...state, modes: { ...state.modes, star: { ...DEFAULT_STAR_SLOT } } };
  }
  if (mode === 'practice' || mode === 'hardcore') {
    const isHardcore = mode === 'hardcore';
    const targetKey = isHardcore ? 'hardcore' : 'practice';
    if (gridSize !== undefined) {
      const pKey: PracticeGridKey = gridSize === null ? 'auto' : (String(gridSize) as PracticeGridKey);
      const curPractice = state.modes[targetKey] || { ...DEFAULT_PRACTICE_STATE };
      return {
        ...state,
        modes: {
          ...state.modes,
          [targetKey]: {
            ...curPractice,
            slots: { ...curPractice.slots, [pKey]: { rating: 100, level: 1, played: 0, easeNext: false } },
          },
        },
      };
    }
    return { ...state, modes: { ...state.modes, [targetKey]: { ...DEFAULT_PRACTICE_STATE } } };
  }
  return state;
}
