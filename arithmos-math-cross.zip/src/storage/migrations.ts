import {
  DEFAULT_STORED_STATE_V3,
  LEGACY_MUTED_KEY,
  LEGACY_PROGRESS_KEY_V1,
  STORAGE_KEY_V2,
  STORAGE_KEY_V3,
  StoredStateV3,
  sanitizeSettings,
  sanitizeStoredState,
} from './schema';

/**
 * Migrates data from legacy V1 and V2 to V3 if arithmos_v3 does not yet exist.
 * Preserves legacy keys to avoid destructive data loss.
 */
export function migrateFromLegacyIfNeeded(): StoredStateV3 | null {
  try {
    const existingV3 = localStorage.getItem(STORAGE_KEY_V3);
    if (existingV3 !== null) {
      return null;
    }

    // 1. Try migrating from V2
    const rawV2 = localStorage.getItem(STORAGE_KEY_V2);
    if (rawV2) {
      try {
        const v2 = JSON.parse(rawV2);
        if (v2 && typeof v2 === 'object') {
          const rating =
            typeof v2.rating === 'number' && Number.isFinite(v2.rating) && v2.rating >= 100
              ? v2.rating
              : DEFAULT_STORED_STATE_V3.modes.endless.rating;
          const level =
            typeof v2.level === 'number' && Number.isFinite(v2.level) && v2.level >= 1
              ? v2.level
              : DEFAULT_STORED_STATE_V3.modes.endless.level;

          const migrated: StoredStateV3 = {
            version: 3,
            settings: sanitizeSettings({
              darkMode: typeof v2.darkMode === 'boolean' ? v2.darkMode : DEFAULT_STORED_STATE_V3.settings.darkMode,
              themeMode: v2.themeMode || (v2.darkMode ? 'dark' : 'light'),
              muted: typeof v2.muted === 'boolean' ? v2.muted : DEFAULT_STORED_STATE_V3.settings.muted,
              volume: typeof v2.volume === 'number' ? v2.volume : DEFAULT_STORED_STATE_V3.settings.volume,
              autoAdvance: typeof v2.autoAdvance === 'boolean' ? v2.autoAdvance : DEFAULT_STORED_STATE_V3.settings.autoAdvance,
              showKeyHints: typeof v2.showKeyHints === 'boolean' ? v2.showKeyHints : DEFAULT_STORED_STATE_V3.settings.showKeyHints,
              controls: v2.controls,
            }),
            modes: {
              ...DEFAULT_STORED_STATE_V3.modes,
              endless: {
                rating,
                level,
                bestLevel: level,
                played: Math.max(0, level - 1),
              },
            },
          };

          const sanitized = sanitizeStoredState(migrated);
          try {
            localStorage.setItem(STORAGE_KEY_V3, JSON.stringify(sanitized));
          } catch {
            // Ignore storage write errors
          }
          return sanitized;
        }
      } catch {
        // Fall through to V1
      }
    }

    // 2. Try migrating from V1
    let rating = DEFAULT_STORED_STATE_V3.modes.endless.rating;
    let level = DEFAULT_STORED_STATE_V3.modes.endless.level;
    let darkMode = DEFAULT_STORED_STATE_V3.settings.darkMode;
    let muted = DEFAULT_STORED_STATE_V3.settings.muted;

    const rawV1 = localStorage.getItem(LEGACY_PROGRESS_KEY_V1);
    if (rawV1) {
      try {
        const parsed = JSON.parse(rawV1);
        if (parsed && typeof parsed === 'object') {
          if (typeof parsed.rating === 'number' && Number.isFinite(parsed.rating) && parsed.rating >= 100) {
            rating = parsed.rating;
          }
          if (typeof parsed.level === 'number' && Number.isFinite(parsed.level) && parsed.level >= 1) {
            level = parsed.level;
          }
          if (typeof parsed.darkMode === 'boolean') {
            darkMode = parsed.darkMode;
          }
        }
      } catch {
        // Ignore JSON error
      }
    }

    const rawMuted = localStorage.getItem(LEGACY_MUTED_KEY);
    if (rawMuted !== null) {
      muted = rawMuted === 'true';
    }

    const migrated: StoredStateV3 = {
      version: 3,
      settings: sanitizeSettings({
        ...DEFAULT_STORED_STATE_V3.settings,
        darkMode,
        muted,
      }),
      modes: {
        ...DEFAULT_STORED_STATE_V3.modes,
        endless: {
          rating,
          level,
          bestLevel: level,
          played: Math.max(0, level - 1),
        },
      },
    };

    const sanitized = sanitizeStoredState(migrated);
    try {
      localStorage.setItem(STORAGE_KEY_V3, JSON.stringify(sanitized));
    } catch {
      // Ignore storage write errors
    }

    return sanitized;
  } catch {
    return { ...DEFAULT_STORED_STATE_V3 };
  }
}
