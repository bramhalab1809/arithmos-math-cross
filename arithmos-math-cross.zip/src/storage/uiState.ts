import { UI_SCREEN_STORAGE_KEY } from './schema';

export type UiScreen =
  | 'home'
  | 'levelMap'
  | 'game'
  | 'analytics'
  | 'lab'
  | 'mistakes';

const VALID_SCREENS = new Set<UiScreen>([
  'home',
  'levelMap',
  'game',
  'analytics',
  'lab',
  'mistakes',
]);

export interface StoredUiState {
  screen: UiScreen;
  savedAt: number;
}

export function loadUiState(): StoredUiState {
  try {
    const raw = localStorage.getItem(UI_SCREEN_STORAGE_KEY);
    if (!raw) return { screen: 'home', savedAt: Date.now() };
    const parsed = JSON.parse(raw);
    if (parsed && VALID_SCREENS.has(parsed.screen)) {
      return {
        screen: parsed.screen,
        savedAt: typeof parsed.savedAt === 'number' ? parsed.savedAt : Date.now(),
      };
    }
  } catch {}
  return { screen: 'home', savedAt: Date.now() };
}

export function saveUiScreen(screen: UiScreen): void {
  try {
    localStorage.setItem(
      UI_SCREEN_STORAGE_KEY,
      JSON.stringify({ screen, savedAt: Date.now() })
    );
  } catch {}
}
