import {
  DEFAULT_STORED_STATE_V3,
  STORAGE_KEY_V3,
  StoredSettings,
  StoredStateV3,
  sanitizeStoredState,
} from './schema';
import { migrateFromLegacyIfNeeded } from './migrations';

export function loadState(): StoredStateV3 {
  try {
    const migrated = migrateFromLegacyIfNeeded();
    if (migrated) {
      return migrated;
    }

    const raw = localStorage.getItem(STORAGE_KEY_V3);
    if (!raw) {
      return { ...DEFAULT_STORED_STATE_V3 };
    }

    const parsed = JSON.parse(raw);
    return sanitizeStoredState(parsed);
  } catch {
    return { ...DEFAULT_STORED_STATE_V3 };
  }
}

export function saveState(
  updater:
    | Partial<StoredStateV3>
    | Partial<StoredSettings>
    | ((prev: StoredStateV3) => StoredStateV3)
): StoredStateV3 {
  const current = loadState();
  let nextState: StoredStateV3;

  if (typeof updater === 'function') {
    nextState = updater(current);
  } else if ('modes' in updater || 'settings' in updater || 'version' in updater) {
    nextState = {
      ...current,
      ...(updater as Partial<StoredStateV3>),
      version: 3,
    };
  } else {
    nextState = {
      ...current,
      settings: {
        ...current.settings,
        ...(updater as Partial<StoredSettings>),
      },
      version: 3,
    };
  }

  const sanitized = sanitizeStoredState(nextState);
  try {
    localStorage.setItem(STORAGE_KEY_V3, JSON.stringify(sanitized));
  } catch {
    // Ignore storage write errors
  }

  return sanitized;
}
