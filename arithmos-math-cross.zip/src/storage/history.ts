import { GameMode } from './schema';

export interface HistoryRecord {
  id: string;
  timestamp: number;
  mode: GameMode;
  gridSize: number;
  level: number;
  ratingBefore: number;
  ratingAfter: number;
  ratingDelta: number;
  won: boolean;
  stars?: 1 | 2 | 3;
  elapsedSeconds: number;
  timeLimitSeconds: number;
  hintsUsed: number;
  calculatorUses?: number;
  mistakes: number;
  starReason?: string;
  relief?: boolean;
  domino?: boolean;
  firstMoves?: number;
  easeApplied?: boolean;
  paced?: number;
  operatorMistakes?: { '+': number; '-': number; '*': number; '/': number };
  operatorExposure?: { '+': number; '-': number; '*': number; '/': number };
  cellSolveSec?: Record<string, number>;
  rowSolveSec?: Record<string, number>;
  firstInputSec?: number;
  longGaps?: number;
  pauseCount?: number;
  undoCount?: number;
  editCount?: number;
  inputKind?: 'touch' | 'keyboard';
  sessionId?: string;
}

export type HistoryEntry = HistoryRecord;

export const HISTORY_STORAGE_KEY = 'arithmos_history_v1';
export const MAX_HISTORY_PER_MODE = 500;

export function estimateHistoryBytes(): number {
  try {
    const raw = localStorage.getItem(HISTORY_STORAGE_KEY);
    return raw ? new Blob([raw]).size : 0;
  } catch {
    return 0;
  }
}

function safeSaveHistory(records: HistoryRecord[]): void {
  try {
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(records));
  } catch {
    // Quota reached: auto-trim oldest 25% records and retry
    try {
      const trimmed = records.slice(0, Math.max(1, Math.floor(records.length * 0.75)));
      localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(trimmed));
    } catch {
      // Ignore fallback write error
    }
  }
}

export function loadHistory(): HistoryRecord[] {
  try {
    const raw = localStorage.getItem(HISTORY_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed.filter(
        (item): item is HistoryRecord =>
          item &&
          typeof item === 'object' &&
          typeof item.id === 'string' &&
          (item.mode === 'endless' ||
            item.mode === 'star' ||
            item.mode === 'practice' ||
            item.mode === 'hardcore' ||
            item.mode === 'lab' ||
            item.mode === 'repair' ||
            item.mode === 'multiplayer')
      );
    }
    return [];
  } catch {
    return [];
  }
}

export function appendHistory(
  entry: Omit<HistoryRecord, 'id' | 'timestamp'>
): HistoryRecord {
  const all = loadHistory();
  const record: HistoryRecord = {
    ...entry,
    id: `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
    timestamp: Date.now(),
  };

  const updated = [record, ...all];

  // Cap at 500 entries per mode
  const modeCounts: Record<GameMode, number> = {
    endless: 0,
    star: 0,
    practice: 0,
    hardcore: 0,
    lab: 0,
    repair: 0,
    multiplayer: 0,
  };

  const capped = updated.filter((item) => {
    const count = modeCounts[item.mode] || 0;
    if (count < MAX_HISTORY_PER_MODE) {
      modeCounts[item.mode] = count + 1;
      return true;
    }
    return false;
  });

  safeSaveHistory(capped);
  return record;
}

export function clearHistory(mode?: GameMode): void {
  try {
    if (!mode) {
      localStorage.removeItem(HISTORY_STORAGE_KEY);
      return;
    }
    const all = loadHistory();
    const filtered = all.filter((item) => item.mode !== mode);
    safeSaveHistory(filtered);
  } catch {}
}

export function importHistory(records: unknown): boolean {
  if (!Array.isArray(records)) return false;
  try {
    const valid = records.filter(
      (item): item is HistoryRecord =>
        item &&
        typeof item === 'object' &&
        typeof item.id === 'string' &&
        (item.mode === 'endless' ||
          item.mode === 'star' ||
          item.mode === 'practice' ||
          item.mode === 'hardcore' ||
          item.mode === 'lab' ||
          item.mode === 'repair')
    );
    safeSaveHistory(valid);
    return true;
  } catch {
    return false;
  }
}
