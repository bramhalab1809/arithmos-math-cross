import { MathCrosswordPuzzle, MathOperator } from '../engine';
import { loadHistory } from './history';
import { GameMode } from './schema';

export const MISTAKES_STORAGE_KEY = 'arithmos_mistakes_v1';
const MAX_MISTAKES = 100;

export interface MistakeRecord {
  id: string;
  mode: 'endless' | 'star' | 'practice' | 'hardcore';
  operator: MathOperator;
  gridSize: number;
  level: number;
  failedEquation?: string;
  createdAt: number;
  repaired: boolean;
  repairTimeSec?: number;
}

export type MistakeEntry = MistakeRecord;

let activeMistakeId: string | null = null;

export function setActiveMistakeId(id: string | null): void {
  activeMistakeId = id;
}

export function getActiveMistakeId(): string | null {
  return activeMistakeId;
}

function saveMistakes(list: MistakeRecord[]): void {
  try {
    localStorage.setItem(MISTAKES_STORAGE_KEY, JSON.stringify(list.slice(0, MAX_MISTAKES)));
  } catch {}
}

function synthesizeFromHistory(): MistakeRecord[] {
  const history = loadHistory();
  const synthesized: MistakeRecord[] = [];
  for (const h of history) {
    if (h.mode !== 'endless' && h.mode !== 'star' && h.mode !== 'practice' && h.mode !== 'hardcore') continue;
    if (h.mistakes <= 0 && h.won) continue;
    const ops: MathOperator[] = [];
    if (h.operatorMistakes) {
      (['+', '-', '*', '/'] as MathOperator[]).forEach((op) => {
        if ((h.operatorMistakes?.[op] ?? 0) > 0) ops.push(op);
      });
    }
    if (ops.length === 0) ops.push('+');
    for (const op of ops) {
      synthesized.push({
        id: `hist_${h.id}_${op}`,
        mode: h.mode,
        operator: op,
        gridSize: Math.max(3, Math.min(7, h.gridSize || 3)),
        level: h.level || 1,
        failedEquation: `L${h.level} (${h.gridSize}x${h.gridSize})`,
        createdAt: h.timestamp || Date.now(),
        repaired: false,
      });
      if (synthesized.length >= 40) break;
    }
    if (synthesized.length >= 40) break;
  }
  return synthesized;
}

export function loadMistakes(): MistakeRecord[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(MISTAKES_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  const fromHistory = synthesizeFromHistory();
  if (fromHistory.length > 0) {
    saveMistakes(fromHistory);
  }
  return fromHistory;
}

export function recordMistakeFromGame(
  mode: GameMode,
  puzzle: MathCrosswordPuzzle,
  row: number,
  col: number
): void {
  if (mode !== 'endless' && mode !== 'star' && mode !== 'practice' && mode !== 'hardcore') return;
  let allOps: MathOperator[] = [];
  if (puzzle.equations && puzzle.equations.length > 0) {
    for (const eq of puzzle.equations) {
      const touchesCell =
        (eq.resultCell.row === row && eq.resultCell.col === col) ||
        eq.operandCells.some((p) => p.row === row && p.col === col);
      if (touchesCell) {
        allOps.push(...eq.ops);
      }
    }
  }
  if (allOps.length === 0) {
    const rOps = puzzle.rowOps?.[row] ?? [];
    const cOps = puzzle.colOps ? puzzle.colOps.map((arr) => arr[col]).filter(Boolean) : [];
    allOps = [...rOps, ...cOps];
  }
  const priorityOrder: MathOperator[] = ['/', '*', '-', '+'];
  const primaryOp = priorityOrder.find((op) => allOps.includes(op)) || allOps[0] || '+';

  const current = loadMistakes();
  const recentDuplicate = current.find(
    (m) =>
      !m.repaired &&
      m.mode === mode &&
      m.level === puzzle.level &&
      m.operator === primaryOp &&
      Date.now() - m.createdAt < 15000
  );
  if (recentDuplicate) return;

  const newRec: MistakeRecord = {
    id: `m_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    mode,
    operator: primaryOp,
    gridSize: puzzle.size,
    level: puzzle.level,
    failedEquation: `R${row + 1}C${col + 1} (${puzzle.size}x${puzzle.size})`,
    createdAt: Date.now(),
    repaired: false,
  };

  saveMistakes([newRec, ...current]);
}

export function createManualMistakeDrill(
  mode: 'endless' | 'star' | 'practice' | 'hardcore',
  operator: MathOperator,
  gridSize = 3
): MistakeRecord {
  const current = loadMistakes();
  const newRec: MistakeRecord = {
    id: `drill_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
    mode,
    operator,
    gridSize,
    level: current.length + 1,
    failedEquation: `${operator} Operator Clinic (${gridSize}x${gridSize})`,
    createdAt: Date.now(),
    repaired: false,
  };
  saveMistakes([newRec, ...current]);
  return newRec;
}

export function clearRepairedMistakes(): void {
  const current = loadMistakes().filter((m) => !m.repaired);
  saveMistakes(current);
}

export function markMistakeRepaired(mistakeId: string, solveTimeSec: number): void {
  const current = loadMistakes();
  const updated = current.map((m) =>
    m.id === mistakeId
      ? {
          ...m,
          repaired: true,
          repairTimeSec: m.repairTimeSec ? Math.min(m.repairTimeSec, solveTimeSec) : solveTimeSec,
        }
      : m
  );
  saveMistakes(updated);
}
