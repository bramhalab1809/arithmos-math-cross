import {
  ACTIVE_SESSION_KEY_V2,
  ActivePuzzleSession,
  GameMode,
  SESSIONS_STORAGE_KEY,
} from './schema';
import { getModeRules } from '../features/game/state/modeRules';

export type SessionKey =
  | 'endless'
  | 'star'
  | 'practice:auto'
  | 'practice:3'
  | 'practice:4'
  | 'practice:5'
  | 'practice:6'
  | 'practice:7';

export function sessionKeyFor(
  mode: GameMode,
  overrideSize: number | null,
  isAuto = false
): SessionKey {
  if (mode === 'endless') return 'endless';
  if (mode === 'star') return 'star';
  if (isAuto || overrideSize === null) return 'practice:auto';
  const size = overrideSize >= 3 && overrideSize <= 7 ? overrideSize : 'auto';
  return `practice:${size}` as SessionKey;
}

function isValidPuzzleObject(p: unknown): boolean {
  if (!p || typeof p !== 'object') return false;
  const o = p as Record<string, unknown>;
  return (
    typeof o.id === 'string' &&
    typeof o.size === 'number' &&
    o.size >= 3 &&
    o.size <= 7 &&
    Array.isArray(o.cells) &&
    Array.isArray(o.rowOps) &&
    Array.isArray(o.colOps) &&
    typeof o.profile === 'object' &&
    o.profile !== null
  );
}

function sanitizeSession(parsed: unknown): ActivePuzzleSession | null {
  if (!parsed || typeof parsed !== 'object') return null;
  const o = parsed as Record<string, unknown>;
  if (!isValidPuzzleObject(o.puzzle)) return null;
  if (typeof o.level !== 'number' || o.level < 1) return null;

  // Silently drop custom sessions
  if (o.mode === 'custom') return null;

  const validModes: GameMode[] = ['endless', 'star', 'practice'];
  const mode: GameMode = validModes.includes(o.mode as GameMode) ? (o.mode as GameMode) : 'endless';
  const rules = getModeRules(mode);
  const timeLimit = typeof o.timeLimitSeconds === 'number' && o.timeLimitSeconds > 0 ? o.timeLimitSeconds : 300;
  const elapsed = typeof o.elapsedSeconds === 'number' && o.elapsedSeconds >= 0 ? o.elapsedSeconds : 0;

  return {
    version: 2,
    mode,
    puzzle: o.puzzle as ActivePuzzleSession['puzzle'],
    level: o.level,
    rating: typeof o.rating === 'number' && o.rating >= 100 ? o.rating : 100,
    overrideSize:
      typeof o.overrideSize === 'number' && o.overrideSize >= 3 && o.overrideSize <= 7
        ? o.overrideSize
        : null,
    elapsedSeconds: rules.hasTimer ? Math.min(elapsed, timeLimit) : elapsed,
    timeLimitSeconds: timeLimit,
    hintsUsed: typeof o.hintsUsed === 'number' && o.hintsUsed >= 0 ? o.hintsUsed : 0,
    checksUsed: typeof o.checksUsed === 'number' && o.checksUsed >= 0 ? o.checksUsed : 0,
    calculatorUses: typeof o.calculatorUses === 'number' && o.calculatorUses >= 0 ? o.calculatorUses : 0,
    heartsLeft: typeof o.heartsLeft === 'number' && o.heartsLeft >= 0 && o.heartsLeft <= 3 ? o.heartsLeft : 3,
    errorsMade: typeof o.errorsMade === 'number' && o.errorsMade >= 0 ? o.errorsMade : 0,
    mistakeCellKeys: Array.isArray(o.mistakeCellKeys) ? o.mistakeCellKeys.filter((k): k is string => typeof k === 'string') : [],
    direction: o.direction === 'col' ? 'col' : 'row',
    focusedPos: (o.focusedPos && typeof o.focusedPos === 'object') ? (o.focusedPos as { row: number; col: number }) : null,
    savedAt: typeof o.savedAt === 'number' ? o.savedAt : Date.now(),
    operatorMistakes: o.operatorMistakes as any,
    operatorExposure: o.operatorExposure as any,
    cellSolveSec: (o.cellSolveSec && typeof o.cellSolveSec === 'object') ? o.cellSolveSec as Record<string, number> : undefined,
    rowSolveSec: (o.rowSolveSec && typeof o.rowSolveSec === 'object') ? o.rowSolveSec as Record<string, number> : undefined,
    firstInputSec: typeof o.firstInputSec === 'number' ? o.firstInputSec : undefined,
    longGaps: typeof o.longGaps === 'number' ? o.longGaps : undefined,
    pauseCount: typeof o.pauseCount === 'number' ? o.pauseCount : undefined,
    undoCount: typeof o.undoCount === 'number' ? o.undoCount : undefined,
    editCount: typeof o.editCount === 'number' ? o.editCount : undefined,
    inputKind: (o.inputKind === 'touch' || o.inputKind === 'keyboard') ? o.inputKind : undefined,
    lastInputAt: typeof o.lastInputAt === 'number' ? o.lastInputAt : undefined,
    sessionId: typeof o.sessionId === 'string' ? o.sessionId : undefined,
  };
}

let migrated = false;
function ensureMigrated(): void {
  if (migrated) return;
  migrated = true;
  try {
    const rawSessions = localStorage.getItem(SESSIONS_STORAGE_KEY);
    if (!rawSessions) {
      const oldRaw = localStorage.getItem(ACTIVE_SESSION_KEY_V2);
      if (oldRaw) {
        const session = sanitizeSession(JSON.parse(oldRaw));
        if (session && session.mode !== ('custom' as any)) {
          const key = sessionKeyFor(session.mode ?? 'endless', session.overrideSize);
          const map: Record<string, ActivePuzzleSession> = { [key]: session };
          localStorage.setItem(SESSIONS_STORAGE_KEY, JSON.stringify(map));
        }
      }
    }
  } catch {
    // Ignore migration errors
  }
}

export function listSessions(): Record<string, ActivePuzzleSession> {
  ensureMigrated();
  try {
    const raw = localStorage.getItem(SESSIONS_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return {};
    const res: Record<string, ActivePuzzleSession> = {};
    for (const [k, v] of Object.entries(parsed as Record<string, unknown>)) {
      if (k.startsWith('custom:')) continue;
      const sanitized = sanitizeSession(v);
      if (sanitized && sanitized.mode !== ('custom' as any)) {
        res[k] = sanitized;
      }
    }
    return res;
  } catch {
    return {};
  }
}

export function loadSession(key: SessionKey): ActivePuzzleSession | null {
  const sessions = listSessions();
  const session = sessions[key] ?? null;
  if (!session) return null;
  const rules = getModeRules(session.mode ?? 'endless');
  if (rules.hasTimer && session.elapsedSeconds >= session.timeLimitSeconds) {
    return null;
  }
  return session;
}

export function saveSession(session: ActivePuzzleSession): void {
  if (session.mode === ('custom' as any)) return;
  ensureMigrated();
  try {
    const key = sessionKeyFor(session.mode ?? 'endless', session.overrideSize);
    const sessions = listSessions();
    sessions[key] = { ...session, savedAt: Date.now() };
    localStorage.setItem(SESSIONS_STORAGE_KEY, JSON.stringify(sessions));
  } catch {
    // Ignore write errors
  }
}

export function clearSession(key: SessionKey): void {
  ensureMigrated();
  try {
    const sessions = listSessions();
    if (sessions[key]) {
      delete sessions[key];
      localStorage.setItem(SESSIONS_STORAGE_KEY, JSON.stringify(sessions));
    }
  } catch {
    // Ignore write errors
  }
}

export function clearAllSessions(): void {
  try {
    localStorage.removeItem(SESSIONS_STORAGE_KEY);
    localStorage.removeItem(ACTIVE_SESSION_KEY_V2);
  } catch {}
}

export function clearSessionsForMode(mode: GameMode): void {
  ensureMigrated();
  try {
    const sessions = listSessions();
    let changed = false;
    for (const [k, s] of Object.entries(sessions)) {
      if (s.mode === mode) {
        delete sessions[k];
        changed = true;
      }
    }
    if (changed) localStorage.setItem(SESSIONS_STORAGE_KEY, JSON.stringify(sessions));
  } catch {}
}

export function loadMostRecentSession(): ActivePuzzleSession | null {
  const sessions = listSessions();
  const list = Object.values(sessions).filter((s) => {
    if (!s || s.mode === ('custom' as any)) return false;
    const rules = getModeRules(s.mode ?? 'endless');
    return rules.hasTimer ? s.elapsedSeconds < s.timeLimitSeconds : true;
  });
  if (list.length === 0) return null;
  list.sort((a, b) => (b.savedAt ?? 0) - (a.savedAt ?? 0));
  return list[0];
}

export function loadActiveSession(key?: SessionKey): ActivePuzzleSession | null {
  return key ? loadSession(key) : loadMostRecentSession();
}

export function saveActiveSession(session: ActivePuzzleSession): void {
  saveSession(session);
}

export function clearActiveSession(key?: SessionKey): void {
  if (key) {
    clearSession(key);
  } else {
    const recent = loadMostRecentSession();
    if (recent) clearSession(sessionKeyFor(recent.mode ?? 'endless', recent.overrideSize));
  }
}
