import { MathCrosswordPuzzle } from '../engine';

export type ThemeMode = 'light' | 'dark' | 'system';
export type GameMode = 'endless' | 'star' | 'practice' | 'lab' | 'repair' | 'multiplayer';
export type PracticeGridKey = 'auto' | '3' | '4' | '5' | '6' | '7';

export interface ModeControls {
  numpad: boolean;
  equations: boolean;
  undoRedo: boolean;
  hint: boolean;
  check: boolean;
  retry: boolean;
  swap: boolean;
  calculator: boolean;
  timer: boolean;
  hearts: boolean;
  keyHints: boolean;
  timeGlow: boolean;
  autoAdvance: boolean;
  levelInfo: boolean;
}

export interface StoredSettings {
  darkMode: boolean;
  themeMode: ThemeMode;
  muted: boolean;
  volume: number;
  autoAdvance: boolean;
  showKeyHints: boolean;
  controls: Record<GameMode, ModeControls>;
  soundTheme?: string;
  soundKeyIndex?: number;
  soundScale?: string;
  duckingEnabled?: boolean;
  pressureFilterEnabled?: boolean;
}

export interface ModeSlot {
  rating: number;
  level: number;
  bestLevel: number;
  played: number;
  easeNext?: boolean;
}

export interface StarModeSlot extends ModeSlot {
  totalStars: number;
  bestStreak: number;
  currentStreak: number;
}

export interface PracticeSlot {
  rating: number;
  level: number;
  played: number;
  easeNext?: boolean;
}

export interface PracticeModeState {
  lastGridSize: 'auto' | 3 | 4 | 5 | 6 | 7;
  slots: Record<PracticeGridKey, PracticeSlot>;
}

export interface StoredStateV3 {
  version: 3;
  settings: StoredSettings;
  modes: {
    endless: ModeSlot;
    star: StarModeSlot;
    practice: PracticeModeState;
  };
}

export interface ActivePuzzleSessionV2 {
  version: 2;
  mode?: GameMode;
  puzzle: MathCrosswordPuzzle;
  level: number;
  rating: number;
  overrideSize: number | null;
  elapsedSeconds: number;
  timeLimitSeconds: number;
  hintsUsed: number;
  checksUsed: number;
  calculatorUses?: number;
  heartsLeft: number;
  errorsMade: number;
  mistakeCellKeys: string[];
  direction: 'row' | 'col';
  focusedPos: { row: number; col: number } | null;
  savedAt: number;
  operatorMistakes?: { '+': number; '-': number; '*': number; '/': number };
  operatorExposure?: { '+': number; '-': number; '*': number; '/': number };
  cellSolveSec?: Record<string, number>;
  rowSolveSec?: Record<string, number>;
  firstInputSec?: number;
  longGaps?: number;
  pauseCount?: number;
  undoCount?: number;
  editCount?: number;
  inputKind?: 'touch' | 'keyboard';
  lastInputAt?: number;
  sessionId?: string;
}

export type ActivePuzzleSession = ActivePuzzleSessionV2;

export const STORAGE_KEY_V3 = 'arithmos_v3';
export const STORAGE_KEY_V2 = 'arithmos_v2';
export const LEGACY_PROGRESS_KEY_V1 = 'arithmos_save';
export const LEGACY_MUTED_KEY = 'arithmos_muted';
export const ACTIVE_SESSION_KEY_V2 = 'arithmos_active_session_v2';
export const SESSIONS_STORAGE_KEY = 'arithmos_sessions_v1';
export const UI_SCREEN_STORAGE_KEY = 'arithmos_ui_v1';

export const DEFAULT_MODE_CONTROLS: ModeControls = {
  numpad: true,
  equations: true,
  undoRedo: true,
  hint: true,
  check: true,
  retry: true,
  swap: true,
  calculator: true,
  timer: true,
  hearts: true,
  keyHints: false,
  timeGlow: true,
  autoAdvance: true,
  levelInfo: true,
};

export const DEFAULT_SETTINGS: StoredSettings = {
  darkMode: true,
  themeMode: 'system',
  muted: false,
  volume: 0.7,
  autoAdvance: true,
  showKeyHints: false,
  controls: {
    endless: { ...DEFAULT_MODE_CONTROLS },
    star: { ...DEFAULT_MODE_CONTROLS },
    practice: { ...DEFAULT_MODE_CONTROLS },
    lab: { ...DEFAULT_MODE_CONTROLS },
    repair: { ...DEFAULT_MODE_CONTROLS },
    multiplayer: { ...DEFAULT_MODE_CONTROLS },
  },
  soundTheme: 'dreamBox',
  soundKeyIndex: 5,
  soundScale: 'pentatonicMajor',
  duckingEnabled: true,
  pressureFilterEnabled: true,
};

export const DEFAULT_MODE_SLOT: ModeSlot = { rating: 100, level: 1, bestLevel: 1, played: 0, easeNext: false };
export const DEFAULT_STAR_SLOT: StarModeSlot = { ...DEFAULT_MODE_SLOT, totalStars: 0, bestStreak: 0, currentStreak: 0 };
export const DEFAULT_PRACTICE_STATE: PracticeModeState = {
  lastGridSize: 'auto',
  slots: {
    auto: { rating: 100, level: 1, played: 0, easeNext: false },
    '3': { rating: 100, level: 1, played: 0, easeNext: false },
    '4': { rating: 100, level: 1, played: 0, easeNext: false },
    '5': { rating: 100, level: 1, played: 0, easeNext: false },
    '6': { rating: 100, level: 1, played: 0, easeNext: false },
    '7': { rating: 100, level: 1, played: 0, easeNext: false },
  },
};

export const DEFAULT_STORED_STATE_V3: StoredStateV3 = {
  version: 3,
  settings: { ...DEFAULT_SETTINGS },
  modes: {
    endless: { ...DEFAULT_MODE_SLOT },
    star: { ...DEFAULT_STAR_SLOT },
    practice: { ...DEFAULT_PRACTICE_STATE },
  },
};

export {
  sanitizeSlot,
  sanitizeStarSlot,
  sanitizePractice,
  sanitizeModeControls,
  sanitizeSettings,
  sanitizeStoredState,
} from './sanitizers';

