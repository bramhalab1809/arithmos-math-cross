import {
  DEFAULT_MODE_CONTROLS,
  DEFAULT_MODE_SLOT,
  DEFAULT_PRACTICE_STATE,
  DEFAULT_SETTINGS,
  DEFAULT_STAR_SLOT,
  DEFAULT_STORED_STATE_V3,
  ModeControls,
  ModeSlot,
  PracticeGridKey,
  PracticeModeState,
  PracticeSlot,
  StarModeSlot,
  StoredSettings,
  StoredStateV3,
} from './schema';

export function sanitizeSlot(raw: unknown): ModeSlot {
  if (!raw || typeof raw !== 'object') return { ...DEFAULT_MODE_SLOT };
  const o = raw as Record<string, unknown>;
  const num = (v: unknown, fb: number) => (typeof v === 'number' && Number.isFinite(v) && v >= 1 ? v : fb);
  const rating = num(o.rating, 100);
  const level = num(o.level, 1);
  return {
    rating,
    level,
    bestLevel: Math.max(level, num(o.bestLevel, level)),
    played: typeof o.played === 'number' ? Math.max(0, o.played) : 0,
    easeNext: Boolean(o.easeNext),
  };
}

export function sanitizeStarSlot(raw: unknown): StarModeSlot {
  const base = sanitizeSlot(raw);
  if (!raw || typeof raw !== 'object') return { ...base, totalStars: 0, bestStreak: 0, currentStreak: 0 };
  const o = raw as Record<string, unknown>;
  const num = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) && v >= 0 ? v : 0);
  const currentStreak = num(o.currentStreak);
  return { ...base, totalStars: num(o.totalStars), currentStreak, bestStreak: Math.max(num(o.bestStreak), currentStreak) };
}

export function sanitizePractice(raw: unknown): PracticeModeState {
  if (!raw || typeof raw !== 'object') return { ...DEFAULT_PRACTICE_STATE };
  const o = raw as Record<string, unknown>;
  const validSizes: Array<'auto' | 3 | 4 | 5 | 6 | 7> = ['auto', 3, 4, 5, 6, 7];
  const lastGridSize = validSizes.includes(o.lastGridSize as any) ? (o.lastGridSize as any) : 'auto';
  const sl = (o.slots && typeof o.slots === 'object' ? o.slots : {}) as Record<string, unknown>;
  const parseP = (v: unknown): PracticeSlot => {
    if (!v || typeof v !== 'object') return { rating: 100, level: 1, played: 0, easeNext: false };
    const p = v as Record<string, unknown>;
    return {
      rating: typeof p.rating === 'number' && p.rating >= 100 ? p.rating : 100,
      level: typeof p.level === 'number' && p.level >= 1 ? p.level : 1,
      played: typeof p.played === 'number' && p.played >= 0 ? p.played : 0,
      easeNext: Boolean(p.easeNext),
    };
  };
  return {
    lastGridSize,
    slots: {
      auto: parseP(sl.auto),
      '3': parseP(sl['3']),
      '4': parseP(sl['4']),
      '5': parseP(sl['5']),
      '6': parseP(sl['6']),
      '7': parseP(sl['7']),
    },
  };
}

export function sanitizeModeControls(raw: unknown, fbAdv: boolean, fbKey: boolean): ModeControls {
  if (!raw || typeof raw !== 'object') return { ...DEFAULT_MODE_CONTROLS, autoAdvance: fbAdv, keyHints: fbKey };
  const o = raw as Record<string, unknown>;
  const b = (k: keyof ModeControls, def: boolean) => (typeof o[k] === 'boolean' ? (o[k] as boolean) : def);
  return {
    numpad: b('numpad', true),
    equations: b('equations', true),
    undoRedo: b('undoRedo', true),
    hint: b('hint', true),
    check: b('check', true),
    retry: b('retry', true),
    swap: b('swap', true),
    calculator: b('calculator', true),
    timer: b('timer', true),
    hearts: b('hearts', true),
    keyHints: b('keyHints', fbKey),
    timeGlow: b('timeGlow', true),
    autoAdvance: b('autoAdvance', fbAdv),
    levelInfo: b('levelInfo', true),
  };
}

export function sanitizeSettings(raw: unknown): StoredSettings {
  if (!raw || typeof raw !== 'object') return { ...DEFAULT_SETTINGS };
  const o = raw as Record<string, unknown>;
  const themeMode = (o.themeMode === 'light' || o.themeMode === 'dark' || o.themeMode === 'system')
    ? o.themeMode
    : (o.darkMode ? 'dark' : 'light');
  const volume = typeof o.volume === 'number' && Number.isFinite(o.volume) ? Math.max(0, Math.min(1, o.volume)) : DEFAULT_SETTINGS.volume;
  const autoAdvance = typeof o.autoAdvance === 'boolean' ? o.autoAdvance : DEFAULT_SETTINGS.autoAdvance;
  const showKeyHints = typeof o.showKeyHints === 'boolean' ? o.showKeyHints : DEFAULT_SETTINGS.showKeyHints;
  const rawControls = (o.controls && typeof o.controls === 'object' ? o.controls : {}) as Record<string, unknown>;

  return {
    darkMode: typeof o.darkMode === 'boolean' ? o.darkMode : DEFAULT_SETTINGS.darkMode,
    themeMode,
    muted: typeof o.muted === 'boolean' ? o.muted : DEFAULT_SETTINGS.muted,
    volume,
    autoAdvance,
    showKeyHints,
    controls: {
      endless: sanitizeModeControls(rawControls.endless, autoAdvance, showKeyHints),
      star: sanitizeModeControls(rawControls.star, autoAdvance, showKeyHints),
      practice: sanitizeModeControls(rawControls.practice, autoAdvance, showKeyHints),
      lab: sanitizeModeControls(rawControls.lab, autoAdvance, showKeyHints),
      repair: sanitizeModeControls(rawControls.repair, autoAdvance, showKeyHints),
      multiplayer: sanitizeModeControls(rawControls.multiplayer, autoAdvance, showKeyHints),
    },
    soundTheme: typeof o.soundTheme === 'string' ? o.soundTheme : DEFAULT_SETTINGS.soundTheme,
    soundKeyIndex: typeof o.soundKeyIndex === 'number' ? o.soundKeyIndex : DEFAULT_SETTINGS.soundKeyIndex,
    soundScale: typeof o.soundScale === 'string' ? o.soundScale : DEFAULT_SETTINGS.soundScale,
    duckingEnabled: typeof o.duckingEnabled === 'boolean' ? o.duckingEnabled : DEFAULT_SETTINGS.duckingEnabled,
    pressureFilterEnabled: typeof o.pressureFilterEnabled === 'boolean' ? o.pressureFilterEnabled : DEFAULT_SETTINGS.pressureFilterEnabled,
  };
}

export function sanitizeStoredState(raw: unknown): StoredStateV3 {
  if (!raw || typeof raw !== 'object') return { ...DEFAULT_STORED_STATE_V3 };
  const o = raw as Record<string, unknown>;
  const rawModes = (o.modes && typeof o.modes === 'object' ? o.modes : {}) as Record<string, unknown>;
  return {
    version: 3,
    settings: sanitizeSettings(o.settings || o),
    modes: {
      endless: sanitizeSlot(rawModes.endless || { rating: o.rating, level: o.level }),
      star: sanitizeStarSlot(rawModes.star),
      practice: sanitizePractice(rawModes.practice),
    },
  };
}
