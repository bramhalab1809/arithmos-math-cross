import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './styles/index.css';
import { runExprSelfTest } from './audio/expr/selfTest';
import { hydrateStorageFromNativeDb, syncStorageToNativeDb } from './storage/nativeBridge';

if (import.meta.env.DEV) {
  runExprSelfTest();
}

async function bootApp() {
  await Promise.race([
    hydrateStorageFromNativeDb(),
    new Promise((resolve) => setTimeout(resolve, 120)),
  ]);
  window.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') void syncStorageToNativeDb();
  });
  window.addEventListener('beforeunload', () => {
    void syncStorageToNativeDb();
  });
  createRoot(document.getElementById('root')!).render(<App />);
}

void bootApp();
