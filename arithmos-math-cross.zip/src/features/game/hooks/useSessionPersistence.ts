import { useEffect, useRef } from 'react';
import { GameSessionState, GameState } from '../state/gameTypes';
import { clearSession, saveSession, sessionKeyFor } from '../../../storage/sessionStorage';
import { saveUiScreen } from '../../../storage/uiState';

export function useSessionPersistence(
  state: GameSessionState,
  getTelemetrySnapshot?: () => Partial<import('../../../storage/history').HistoryRecord>
): void {
  const latestStateRef = useRef<GameSessionState>(state);
  latestStateRef.current = state;

  const prevGameStateRef = useRef<GameState>(state.gameState);
  const lastSavedElapsedRef = useRef<number>(state.elapsedSeconds);
  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const saveCurrentSession = (overrideState?: GameSessionState) => {
    const s = overrideState ?? latestStateRef.current;
    if (s.puzzle && (s.gameState === 'PLAYING' || s.gameState === 'PAUSED' || s.gameState === 'TITLE_MENU')) {
      const snap = getTelemetrySnapshot?.();
      saveSession({
        version: 2,
        mode: s.mode,
        puzzle: s.puzzle,
        level: s.level,
        rating: s.rating,
        overrideSize: s.overrideSize,
        elapsedSeconds: s.elapsedSeconds,
        timeLimitSeconds: s.timeLimitSeconds,
        hintsUsed: s.hintsUsed,
        checksUsed: s.checksUsed,
        calculatorUses: s.calculatorUses,
        heartsLeft: s.heartsLeft,
        errorsMade: s.errorsMade,
        mistakeCellKeys: s.mistakeCellKeys,
        direction: s.direction,
        focusedPos: s.focusedPos,
        savedAt: Date.now(),
        operatorMistakes: snap?.operatorMistakes,
        operatorExposure: snap?.operatorExposure,
        firstInputSec: snap?.firstInputSec,
        longGaps: snap?.longGaps,
        pauseCount: snap?.pauseCount,
        undoCount: snap?.undoCount,
        editCount: snap?.editCount,
        inputKind: snap?.inputKind,
        sessionId: snap?.sessionId,
      });
      lastSavedElapsedRef.current = s.elapsedSeconds;
    }
  };

  // Immediate save on Pause, transitions, and write last UI screen
  useEffect(() => {
    const prev = prevGameStateRef.current;
    prevGameStateRef.current = state.gameState;

    if (state.gameState === 'PLAYING' || state.gameState === 'PAUSED') {
      saveUiScreen('game');
    } else if (state.gameState === 'TITLE_MENU' || state.gameState === 'ROUND_SUMMARY' || state.gameState === 'TIME_UP') {
      saveUiScreen('home');
    }

    if (state.gameState === 'PAUSED') {
      saveCurrentSession(state);
    } else if (prev === 'PLAYING' && state.gameState === 'TITLE_MENU') {
      saveCurrentSession(state);
    } else if (state.gameState === 'ROUND_SUMMARY' || state.gameState === 'TIME_UP') {
      clearSession(sessionKeyFor(state.mode, state.overrideSize));
    }
  }, [state.gameState, state.mode, state.overrideSize]);

  // Flush save on tab hidden or beforeunload
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        saveCurrentSession();
      }
    };
    const handleFlush = () => saveCurrentSession();

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('beforeunload', handleFlush);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('beforeunload', handleFlush);
    };
  }, []);

  // Save elapsedSeconds at most every 5 seconds during PLAYING
  useEffect(() => {
    if (state.gameState !== 'PLAYING') return;
    if (Math.abs(state.elapsedSeconds - lastSavedElapsedRef.current) >= 5) {
      saveCurrentSession();
    }
  }, [state.gameState, state.elapsedSeconds]);

  // Debounce structural changes
  useEffect(() => {
    if (state.gameState !== 'PLAYING' && state.gameState !== 'PAUSED') return;

    if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
    debounceTimerRef.current = setTimeout(() => {
      saveCurrentSession();
    }, 150);

    return () => {
      if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
    };
  }, [
    state.puzzle.cells,
    state.hintsUsed,
    state.checksUsed,
    state.calculatorUses,
    state.heartsLeft,
    state.errorsMade,
    state.mistakeCellKeys,
  ]);
}
