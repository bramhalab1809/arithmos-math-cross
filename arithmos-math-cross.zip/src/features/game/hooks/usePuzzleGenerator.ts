import { useRef, useCallback, useEffect } from 'react';
import {
  calculatePuzzleTimeLimit,
  findBestStartCell,
  generatePuzzleAsync,
  isReliefLevel,
} from '../../../engine';
import { ActivePuzzleSession, GameMode } from '../../../storage/schema';
import { clearSession, loadSession, sessionKeyFor } from '../../../storage/sessionStorage';
import { loadState, saveState } from '../../../storage/storage';
import { getModeSlot, clearSlotEaseNext } from '../../../storage/modes';
import { soundEngine } from '../../../audio/soundEngine';
import { GameAction, GameSessionState } from '../state/gameTypes';
import { getModeRules } from '../state/modeRules';
import { assignStarCells } from '../state/starCells';

interface UsePuzzleGeneratorProps {
  state: GameSessionState;
  dispatch: React.Dispatch<GameAction>;
  focusDomInput: (row: number, col: number, delay?: number) => void;
  resumeSavedSession: (session?: ActivePuzzleSession) => void;
}

export function usePuzzleGenerator({
  state,
  dispatch,
  focusDomInput,
  resumeSavedSession,
}: UsePuzzleGeneratorProps) {
  const activeRequestIdRef = useRef<number>(0);
  const isGeneratingRef = useRef<boolean>(false);
  const loadingTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const clearLoadingTimer = useCallback(() => {
    if (loadingTimerRef.current) {
      clearTimeout(loadingTimerRef.current);
      loadingTimerRef.current = null;
    }
  }, []);

  const cancelGeneration = useCallback(() => {
    activeRequestIdRef.current++;
    isGeneratingRef.current = false;
    clearLoadingTimer();
    dispatch({ type: 'SET_GENERATING', isGenerating: false });
  }, [clearLoadingTimer, dispatch]);

  useEffect(() => {
    return () => {
      clearLoadingTimer();
    };
  }, [clearLoadingTimer]);

  const startPuzzleLevel = useCallback(
    (
      targetMode: GameMode = state.mode,
      targetRating: number = state.rating,
      targetLevel: number = state.level,
      sizeOverride: number | null = state.overrideSize,
      forceNew = false
    ) => {
      if (isGeneratingRef.current) return;

      const key = sessionKeyFor(targetMode, sizeOverride);
      if (!forceNew) {
        const savedSession = loadSession(key);
        if (savedSession) {
          const rules = getModeRules(savedSession.mode ?? targetMode);
          if (!rules.hasTimer || savedSession.elapsedSeconds < savedSession.timeLimitSeconds) {
            resumeSavedSession(savedSession);
            return;
          }
        }
      }

      clearSession(key);
      const reqId = ++activeRequestIdRef.current;
      isGeneratingRef.current = true;
      clearLoadingTimer();
      loadingTimerRef.current = setTimeout(() => {
        dispatch({ type: 'SET_GENERATING', isGenerating: true });
      }, 120);

      const currentStorage = loadState();
      const slot = getModeSlot(currentStorage, targetMode, sizeOverride);
      const easeActive = Boolean(slot.easeNext);
      const isRelief = isReliefLevel(targetLevel);
      const blanksScale = isRelief ? 0.75 : easeActive ? 0.85 : 1.0;
      const easeApplied = easeActive;

      if (easeActive) {
        saveState((prev) => clearSlotEaseNext(prev, targetMode, sizeOverride));
      }

      generatePuzzleAsync(targetRating, targetLevel, sizeOverride, { blanksScale, easeApplied })
        .then((genPuzzle) => {
          clearLoadingTimer();
          if (reqId !== activeRequestIdRef.current) return;
          isGeneratingRef.current = false;
          dispatch({ type: 'SET_GENERATING', isGenerating: false });

          const newPuzzle = assignStarCells(genPuzzle, targetMode === 'star');
          const timeLimitSeconds = calculatePuzzleTimeLimit(newPuzzle, targetLevel);
          const startCell = findBestStartCell(newPuzzle);
          const firstCell = { row: startCell.row, col: startCell.col };

          dispatch({
            type: 'START_PUZZLE',
            mode: targetMode,
            puzzle: newPuzzle,
            timeLimitSeconds,
            firstCell,
            direction: startCell.direction,
            showOnboarding: targetLevel === 1 && !sizeOverride && targetMode === 'endless',
            rating: targetRating,
            level: targetLevel,
            overrideSize: sizeOverride,
            resetHearts: true,
          });

          focusDomInput(firstCell.row, firstCell.col, 20);
        })
        .catch(() => {
          clearLoadingTimer();
          if (reqId !== activeRequestIdRef.current) return;
          isGeneratingRef.current = false;
          dispatch({ type: 'SET_GENERATING', isGenerating: false });
        });
    },
    [
      state.mode,
      state.rating,
      state.level,
      state.overrideSize,
      clearLoadingTimer,
      dispatch,
      resumeSavedSession,
      focusDomInput,
    ]
  );

  const handleSwapPuzzle = useCallback(() => {
    if (state.gameState !== 'PLAYING' || isGeneratingRef.current) return;
    const rules = getModeRules(state.mode);
    if (rules.hasHearts && state.heartsLeft <= 0) {
      soundEngine.playError();
      dispatch({
        type: 'SET_BANNER',
        banner: { type: 'error', message: 'No hearts left to swap puzzle.' },
      });
      return;
    }

    if (rules.hasHearts) {
      soundEngine.playHeartLost();
    } else {
      soundEngine.playTick(1);
    }

    const reqId = ++activeRequestIdRef.current;
    isGeneratingRef.current = true;
    clearLoadingTimer();
    loadingTimerRef.current = setTimeout(() => {
      dispatch({ type: 'SET_GENERATING', isGenerating: true });
    }, 120);

    const currentStorage = loadState();
    const slot = getModeSlot(currentStorage, state.mode, state.overrideSize);
    const easeActive = Boolean(slot.easeNext);
    const isRelief = isReliefLevel(state.level);
    const blanksScale = isRelief ? 0.75 : easeActive ? 0.85 : 1.0;
    const easeApplied = easeActive;

    if (easeActive) {
      saveState((prev) => clearSlotEaseNext(prev, state.mode, state.overrideSize));
    }

    generatePuzzleAsync(state.rating, state.level, state.overrideSize, { blanksScale, easeApplied })
      .then((genPuzzle) => {
        clearLoadingTimer();
        if (reqId !== activeRequestIdRef.current) return;
        isGeneratingRef.current = false;
        dispatch({ type: 'SET_GENERATING', isGenerating: false });

        const newPuzzle = assignStarCells(genPuzzle, state.mode === 'star');
        const timeLimitSeconds = calculatePuzzleTimeLimit(newPuzzle, state.level);
        const startCell = findBestStartCell(newPuzzle);
        const firstCell = { row: startCell.row, col: startCell.col };

        dispatch({
          type: 'SWAP_NEW_PUZZLE',
          puzzle: newPuzzle,
          timeLimitSeconds,
          firstCell,
          direction: startCell.direction,
        });

        focusDomInput(firstCell.row, firstCell.col, 10);
      })
      .catch(() => {
        clearLoadingTimer();
        if (reqId !== activeRequestIdRef.current) return;
        isGeneratingRef.current = false;
        dispatch({ type: 'SET_GENERATING', isGenerating: false });
      });
  }, [
    state.gameState,
    state.mode,
    state.heartsLeft,
    state.rating,
    state.level,
    state.overrideSize,
    clearLoadingTimer,
    dispatch,
    focusDomInput,
  ]);

  return {
    startPuzzleLevel,
    handleSwapPuzzle,
    cancelGeneration,
    isGeneratingRef,
  };
}
