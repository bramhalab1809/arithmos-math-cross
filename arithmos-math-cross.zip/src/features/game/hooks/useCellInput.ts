import { useCallback, useEffect, useRef } from 'react';
import { MathCrosswordPuzzle, getCellMaxValue, isCompleteLineValid } from '../../../engine';
import { soundEngine } from '../../../audio/soundEngine';
import { recordMistakeFromGame } from '../../../storage/mistakes';
import { CellEdit, GameAction, GameSessionState } from '../state/gameTypes';
import { findNextEmptyEditableCell, findPreviousEditableCell } from '../state/navigation';
import { checkAndHandleVictory } from '../state/recordOutcome';
import { collectLineMistakes } from '../state/mistakeTracker';
import { useCellKeyboard } from './useCellKeyboard';

export interface CellInputTelemetry {
  recordEdit?: (isTouch?: boolean) => void;
  recordUndo?: () => void;
  recordProgressTiming?: (puzzle: MathCrosswordPuzzle, row: number, col: number) => void;
  getSnapshot?: () => Partial<import('../../../storage/history').HistoryRecord>;
}

function isCellInInvalidCompletedLine(puzzle: MathCrosswordPuzzle, row: number, col: number): boolean {
  const rowCells = puzzle.cells[row];
  if (rowCells && rowCells.every((c) => c.isClue || c.userValue.trim() !== '')) {
    const rVals = rowCells.map((c) => (c.isClue ? c.solution : parseInt(c.userValue, 10)));
    if (puzzle.rowOps?.[row] && !isCompleteLineValid(rVals, puzzle.rowOps[row])) return true;
  }
  if (puzzle.cells.every((r) => r[col]?.isClue || r[col]?.userValue.trim() !== '')) {
    const cVals = puzzle.cells.map((r) => (r[col].isClue ? r[col].solution : parseInt(r[col].userValue, 10)));
    const cOps = puzzle.colOps ? puzzle.colOps.map((rOps) => rOps[col]) : [];
    if (cOps.length === puzzle.size - 2 && !isCompleteLineValid(cVals, cOps)) return true;
  }
  return false;
}

export function useCellInput(
  state: GameSessionState,
  dispatch: React.Dispatch<GameAction>,
  focusCell: (row: number, col: number) => void,
  autoAdvance = true,
  telemetry?: CellInputTelemetry
) {
  const freshFocusRef = useRef<boolean>(true);
  const lastDigitAtRef = useRef<number>(0);
  const autoAdvanceTimerRef = useRef<number | null>(null);
  const focusedRow = state.focusedPos?.row ?? -1;
  const focusedCol = state.focusedPos?.col ?? -1;

  const clearAdvanceTimer = useCallback(() => {
    if (autoAdvanceTimerRef.current !== null) {
      window.clearTimeout(autoAdvanceTimerRef.current);
      autoAdvanceTimerRef.current = null;
    }
  }, []);

  const resetCellAppendWindow = useCallback(() => {
    clearAdvanceTimer();
    freshFocusRef.current = true;
    lastDigitAtRef.current = 0;
  }, [clearAdvanceTimer]);

  useEffect(() => {
    resetCellAppendWindow();
    return () => clearAdvanceTimer();
  }, [focusedRow, focusedCol, state.puzzle.id, resetCellAppendWindow, clearAdvanceTimer]);

  const checkVictory = useCallback(
    (updatedPuzzle: MathCrosswordPuzzle, currentHints: number, currentErrors: number): boolean =>
      checkAndHandleVictory(state, updatedPuzzle, currentHints, currentErrors, dispatch, telemetry?.getSnapshot?.()),
    [state, dispatch, telemetry]
  );

  const applyCellValue = useCallback(
    (row: number, col: number, nextVal: string, isFromUndoRedo = false, isTouch = false) => {
      if (state.gameState !== 'PLAYING') return;
      clearAdvanceTimer();
      const cell = state.puzzle.cells[row]?.[col];
      if (!cell || cell.isClue || cell.isHinted) return;

      const sanitized = nextVal.replace(/[^0-9]/g, '');
      if (cell.userValue === sanitized) return;
      if (!isFromUndoRedo) telemetry?.recordEdit?.(isTouch);

      const edit: CellEdit | undefined = isFromUndoRedo ? undefined : { row, col, prev: cell.userValue, next: sanitized };
      const nextCells = state.puzzle.cells.map((rArr, r) =>
        rArr.map((cObj, c) => (r === row && c === col ? { ...cObj, userValue: sanitized, isError: false } : cObj))
      );
      const updatedPuzzle: MathCrosswordPuzzle = { ...state.puzzle, cells: nextCells };
      telemetry?.recordProgressTiming?.(updatedPuzzle, row, col);

      let currentMistakeKeys = state.mistakeCellKeys || [];
      let totalAddedErrors = 0;
      let hasError = false;
      let hasStarSolved = false;
      let hasEquationSolved = false;

      if (sanitized !== '') {
        const lineRes = collectLineMistakes(updatedPuzzle, row, col, currentMistakeKeys);
        currentMistakeKeys = lineRes.newKeys;
        totalAddedErrors = lineRes.addedCount;
        if (lineRes.addedCount > 0) {
          hasError = true;
          recordMistakeFromGame(state.mode, updatedPuzzle, row, col);
        }

        if (updatedPuzzle.cells[row].every((cl) => cl.isClue || cl.userValue.trim() !== '')) {
          const rVals = updatedPuzzle.cells[row].map((cl) => (cl.isClue ? cl.solution : parseInt(cl.userValue, 10)));
          if (updatedPuzzle.rowOps?.[row] && isCompleteLineValid(rVals, updatedPuzzle.rowOps[row])) hasEquationSolved = true;
        }
        if (updatedPuzzle.cells.every((r) => r[col].isClue || r[col].userValue.trim() !== '')) {
          const cVals = updatedPuzzle.cells.map((r) => (r[col].isClue ? r[col].solution : parseInt(r[col].userValue, 10)));
          const cOps = updatedPuzzle.colOps ? updatedPuzzle.colOps.map((rOps) => rOps[col]) : [];
          if (cOps.length === updatedPuzzle.size - 2 && isCompleteLineValid(cVals, cOps)) hasEquationSolved = true;
        }
        if (cell.hasStar && !cell.isHinted && !hasError && (parseInt(sanitized, 10) === cell.solution || hasEquationSolved)) {
          hasStarSolved = true;
        }
      }

      if (checkVictory(updatedPuzzle, state.hintsUsed, state.errorsMade + totalAddedErrors)) return;

      if (hasError) {
        freshFocusRef.current = true;
        lastDigitAtRef.current = 0;
      } else if (sanitized !== '' && autoAdvance && !isFromUndoRedo) {
        const maxVal = Math.max(99, getCellMaxValue(updatedPuzzle, row, col));
        const maxDigits = Math.max(2, String(maxVal).length);
        const delayMs = hasEquationSolved ? 400 : sanitized.length >= maxDigits ? 320 : 0;
        if (delayMs > 0) {
          autoAdvanceTimerRef.current = window.setTimeout(() => {
            const nextTarget = findNextEmptyEditableCell(updatedPuzzle, row, col, state.direction);
            if (nextTarget) focusCell(nextTarget.row, nextTarget.col);
          }, delayMs);
        }
      }

      if (hasError) soundEngine.playError();
      else if (hasStarSolved) soundEngine.playStarEarned(35);
      else if (hasEquationSolved) soundEngine.playEquationSolved(35);
      else if (sanitized !== '') soundEngine.playTick((parseInt(sanitized.slice(-1), 10) || 0) % 7);

      dispatch({
        type: 'SET_CELL_VALUE', puzzle: updatedPuzzle, edit,
        dismissOnboarding: state.showOnboarding && (parseInt(sanitized, 10) === cell.solution || hasEquationSolved),
        errorsAdded: totalAddedErrors, mistakeCellKeys: currentMistakeKeys,
      });
    },
    [state, autoAdvance, checkVictory, clearAdvanceTimer, dispatch, focusCell, telemetry]
  );

  const handleDigitInput = useCallback(
    (digit: string) => {
      if (state.gameState !== 'PLAYING' || !state.focusedPos) return;
      clearAdvanceTimer();
      const { row, col } = state.focusedPos;
      const cell = state.puzzle.cells[row]?.[col];
      if (!cell || cell.isClue || cell.isHinted) return;

      const now = performance.now();
      const elapsedMs = now - lastDigitAtRef.current;
      const maxVal = Math.max(99, getCellMaxValue(state.puzzle, row, col));
      const maxDigits = Math.max(2, String(maxVal).length);
      const curVal = cell.userValue.trim();
      const lineInvalid = isCellInInvalidCompletedLine(state.puzzle, row, col);
      const canAppend = !freshFocusRef.current && curVal.length > 0 && curVal.length < maxDigits && elapsedMs <= 1450 && !cell.isError && !lineInvalid;

      if (digit === '0') {
        if (canAppend && parseInt(curVal + '0', 10) <= maxVal) {
          freshFocusRef.current = false; lastDigitAtRef.current = now;
          applyCellValue(row, col, curVal + '0');
          return;
        }
        freshFocusRef.current = true; lastDigitAtRef.current = 0;
        soundEngine.playTick(0);
        applyCellValue(row, col, '');
        return;
      }

      let nextVal = canAppend ? curVal + digit : digit;
      if (parseInt(nextVal, 10) > maxVal) nextVal = digit;
      freshFocusRef.current = false; lastDigitAtRef.current = now;
      applyCellValue(row, col, nextVal);
    },
    [state.gameState, state.focusedPos, state.puzzle, applyCellValue, clearAdvanceTimer]
  );

  const handleBackspace = useCallback(() => {
    if (state.gameState !== 'PLAYING' || !state.focusedPos) return;
    clearAdvanceTimer();
    const { row, col } = state.focusedPos;
    const cell = state.puzzle.cells[row]?.[col];
    if (!cell || cell.isClue || cell.isHinted) return;
    if (cell.userValue === '') {
      const prev = findPreviousEditableCell(state.puzzle, row, col, state.direction);
      if (prev) focusCell(prev.row, prev.col);
      return;
    }
    freshFocusRef.current = false; lastDigitAtRef.current = performance.now();
    soundEngine.playTick(0);
    applyCellValue(row, col, cell.userValue.slice(0, -1));
  }, [state.gameState, state.focusedPos, state.puzzle, state.direction, applyCellValue, clearAdvanceTimer, focusCell]);

  const handleDelete = useCallback(() => {
    if (state.gameState !== 'PLAYING' || !state.focusedPos) return;
    clearAdvanceTimer();
    const cell = state.puzzle.cells[state.focusedPos.row]?.[state.focusedPos.col];
    if (!cell || cell.isClue || cell.isHinted) return;
    freshFocusRef.current = true; lastDigitAtRef.current = 0;
    soundEngine.playTick(0);
    applyCellValue(state.focusedPos.row, state.focusedPos.col, '');
  }, [state.gameState, state.focusedPos, state.puzzle, applyCellValue, clearAdvanceTimer]);

  const handleUndo = useCallback(() => {
    if (state.gameState !== 'PLAYING' || !state.history.past.some((e) => !state.puzzle.cells[e.row]?.[e.col]?.isHinted)) return;
    resetCellAppendWindow(); telemetry?.recordUndo?.(); soundEngine.playTick(1); dispatch({ type: 'UNDO' });
  }, [state.gameState, state.history.past, state.puzzle.cells, resetCellAppendWindow, dispatch, telemetry]);

  const handleRedo = useCallback(() => {
    if (state.gameState !== 'PLAYING' || !state.history.future.some((e) => !state.puzzle.cells[e.row]?.[e.col]?.isHinted)) return;
    resetCellAppendWindow(); soundEngine.playTick(1); dispatch({ type: 'REDO' });
  }, [state.gameState, state.history.future, state.puzzle.cells, resetCellAppendWindow, dispatch]);

  const handleCellKeyDown = useCellKeyboard({
    gameState: state.gameState, puzzle: state.puzzle, direction: state.direction,
    handleUndo, handleRedo, handleBackspace, handleDelete, handleDigitInput, focusCell, dispatch,
  });

  return { handleDigitInput, handleBackspace, handleDelete, handleUndo, handleRedo, handleCellKeyDown, applyCellValue, resetCellAppendWindow };
}
