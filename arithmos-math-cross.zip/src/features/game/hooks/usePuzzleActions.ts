import React, { useCallback } from 'react';
import { GameAction, GameSessionState } from '../state/gameTypes';
import { useCellInput } from './useCellInput';
import { usePuzzleTools } from './usePuzzleTools';

export function usePuzzleActions(
  state: GameSessionState,
  dispatch: React.Dispatch<GameAction>,
  focusCell: (row: number, col: number) => void,
  focusDomInput: (row: number, col: number, delay?: number) => void,
  autoAdvance: boolean = true,
  telemetry?: {
    recordEdit: (isTouch?: boolean) => void;
    recordUndo: () => void;
    recordProgressTiming?: (updatedPuzzle: import('../../../engine').MathCrosswordPuzzle, row: number, col: number) => void;
    getSnapshot: () => Partial<import('../../../storage/history').HistoryRecord>;
  }
) {
  const cellInput = useCellInput(state, dispatch, focusCell, autoAdvance, telemetry);
  const puzzleTools = usePuzzleTools(state, dispatch, focusDomInput, telemetry?.getSnapshot, telemetry?.recordProgressTiming);

  const handleCellKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLInputElement>, row: number, col: number) => {
      if (state.gameState !== 'PLAYING') return;

      // Single-letter tool triggers with confirmation guards
      if (!e.ctrlKey && !e.metaKey && !e.altKey) {
        if (e.key === 'h' || e.key === 'H') {
          e.preventDefault();
          puzzleTools.handleTriggerHint(true);
          return;
        }
        if (e.key === 'c' || e.key === 'C') {
          e.preventDefault();
          puzzleTools.handleValidateBoard(true);
          return;
        }
      }

      cellInput.handleCellKeyDown(e, row, col);
    },
    [state.gameState, puzzleTools, cellInput]
  );

  const handleNumpadPress = useCallback(
    (digit: string) => {
      if (digit === 'BACKSPACE') {
        cellInput.handleBackspace();
      } else {
        cellInput.handleDigitInput(digit);
      }
    },
    [cellInput]
  );

  return {
    handleCellInputChange: cellInput.applyCellValue,
    handleDigitInput: cellInput.handleDigitInput,
    handleBackspace: cellInput.handleBackspace,
    handleDelete: cellInput.handleDelete,
    handleUndo: cellInput.handleUndo,
    handleRedo: cellInput.handleRedo,
    handleCellKeyDown,
    handleNumpadPress,
    resetCellAppendWindow: cellInput.resetCellAppendWindow,
    handleTriggerHint: () => puzzleTools.handleTriggerHint(false),
    handleValidateBoard: () => puzzleTools.handleValidateBoard(false),
  };
}
