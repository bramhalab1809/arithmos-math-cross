import { useCallback, useEffect, useRef } from 'react';
import { MathCrosswordPuzzle, MathOperator, isCompleteLineValid } from '../../../engine';
import { HistoryRecord } from '../../../storage/history';
import { ActivePuzzleSession } from '../../../storage/schema';
import { GameSessionState } from '../state/gameTypes';

const APP_SESSION_ID = `sess_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 7)}`;

export function computeOperatorExposure(puzzle: MathCrosswordPuzzle): Record<MathOperator, number> {
  const exposure: Record<MathOperator, number> = { '+': 0, '-': 0, '*': 0, '/': 0 };
  if (!puzzle.rowOps || !puzzle.colOps) return exposure;
  for (const rOps of puzzle.rowOps) {
    for (const op of rOps) {
      if (exposure[op] !== undefined) exposure[op]++;
    }
  }
  for (const cOps of puzzle.colOps) {
    for (const op of cOps) {
      if (exposure[op] !== undefined) exposure[op]++;
    }
  }
  return exposure;
}

export function computeOperatorMistakes(
  puzzle: MathCrosswordPuzzle,
  mistakeKeys: string[]
): Record<MathOperator, number> {
  const mistakes: Record<MathOperator, number> = { '+': 0, '-': 0, '*': 0, '/': 0 };
  const size = puzzle.size;
  const opCount = size - 2;

  for (const key of mistakeKeys) {
    const parts = key.split(',');
    const r = parseInt(parts[0], 10);
    const c = parseInt(parts[1], 10);
    if (isNaN(r) || isNaN(c)) continue;

    if (c > 0 && c - 1 < opCount && puzzle.rowOps?.[r]?.[c - 1]) {
      mistakes[puzzle.rowOps[r][c - 1]]++;
    }
    if (c < opCount && puzzle.rowOps?.[r]?.[c]) {
      mistakes[puzzle.rowOps[r][c]]++;
    }
    if (r > 0 && r - 1 < opCount && puzzle.colOps?.[r - 1]?.[c]) {
      mistakes[puzzle.colOps[r - 1][c]]++;
    }
    if (r < opCount && puzzle.colOps?.[r]?.[c]) {
      mistakes[puzzle.colOps[r][c]]++;
    }
  }
  return mistakes;
}

export function usePuzzleTelemetry(state: GameSessionState) {
  const firstInputSecRef = useRef<number | undefined>(undefined);
  const lastInputSecRef = useRef<number | undefined>(undefined);
  const longGapsRef = useRef<number>(0);
  const pauseCountRef = useRef<number>(0);
  const undoCountRef = useRef<number>(0);
  const editCountRef = useRef<number>(0);
  const inputKindRef = useRef<'touch' | 'keyboard'>('keyboard');
  const currentPuzzleIdRef = useRef<string>(state.puzzle?.id ?? '');
  const cellSolveSecRef = useRef<Record<string, number>>({});
  const rowSolveSecRef = useRef<Record<string, number>>({});
  const lastSolveElapsedRef = useRef<number>(0);

  // Detect coarse pointer as default input kind
  useEffect(() => {
    if (typeof window !== 'undefined' && window.matchMedia?.('(pointer: coarse)').matches) {
      inputKindRef.current = 'touch';
    }
  }, []);

  // Reset counters when puzzle ID changes (new puzzle or swap) or on retry
  useEffect(() => {
    currentPuzzleIdRef.current = state.puzzle?.id ?? '';
    firstInputSecRef.current = undefined;
    lastInputSecRef.current = undefined;
    longGapsRef.current = 0;
    pauseCountRef.current = 0;
    undoCountRef.current = 0;
    editCountRef.current = 0;
    cellSolveSecRef.current = {};
    rowSolveSecRef.current = {};
    lastSolveElapsedRef.current = 0;
  }, [state.puzzle?.id, state.retriesCount]);

  const recordEdit = useCallback((isTouch = false) => {
    if (isTouch) inputKindRef.current = 'touch';
    editCountRef.current += 1;

    const currentElapsed = state.elapsedSeconds;
    if (firstInputSecRef.current === undefined) {
      firstInputSecRef.current = currentElapsed;
    }

    if (lastInputSecRef.current !== undefined) {
      const gap = currentElapsed - lastInputSecRef.current;
      if (gap >= 15) {
        longGapsRef.current += 1;
      }
    }
    lastInputSecRef.current = currentElapsed;
  }, [state.elapsedSeconds]);

  const recordUndo = useCallback(() => {
    undoCountRef.current += 1;
  }, []);

  const recordPause = useCallback(() => {
    pauseCountRef.current += 1;
  }, []);

  const setInputKind = useCallback((kind: 'touch' | 'keyboard') => {
    inputKindRef.current = kind;
  }, []);

  const recordProgressTiming = useCallback(
    (updatedPuzzle: MathCrosswordPuzzle, row: number, col: number) => {
      const cell = updatedPuzzle.cells[row]?.[col];
      if (cell && parseInt(cell.userValue, 10) === cell.solution) {
        const key = `${row},${col}`;
        if (cellSolveSecRef.current[key] === undefined) {
          const delta = Math.max(1, state.elapsedSeconds - lastSolveElapsedRef.current);
          cellSolveSecRef.current[key] = delta;
          lastSolveElapsedRef.current = state.elapsedSeconds;
        }
      }

      for (let r = 0; r < updatedPuzzle.size; r++) {
        if (rowSolveSecRef.current[String(r)] !== undefined) continue;
        const rowFilled = updatedPuzzle.cells[r].every((cl) => cl.isClue || cl.userValue.trim() !== '');
        if (rowFilled) {
          const rVals = updatedPuzzle.cells[r].map((cl) => (cl.isClue ? cl.solution : parseInt(cl.userValue, 10)));
          if (isCompleteLineValid(rVals, updatedPuzzle.rowOps[r])) {
            let rowSum = 0;
            for (let c = 0; c < updatedPuzzle.size; c++) {
              if (!updatedPuzzle.cells[r][c].isClue) {
                rowSum += cellSolveSecRef.current[`${r},${c}`] || 1;
              }
            }
            rowSolveSecRef.current[String(r)] = Math.max(1, rowSum);
          }
        }
      }
    },
    [state.elapsedSeconds]
  );

  const restoreFromSession = useCallback((session?: ActivePuzzleSession) => {
    if (!session) return;
    if (typeof session.firstInputSec === 'number') firstInputSecRef.current = session.firstInputSec;
    if (typeof session.longGaps === 'number') longGapsRef.current = session.longGaps;
    if (typeof session.pauseCount === 'number') pauseCountRef.current = session.pauseCount;
    if (typeof session.undoCount === 'number') undoCountRef.current = session.undoCount;
    if (typeof session.editCount === 'number') editCountRef.current = session.editCount;
    if (session.inputKind) inputKindRef.current = session.inputKind;
    if (typeof session.lastInputAt === 'number') lastInputSecRef.current = session.lastInputAt;
    if (session.cellSolveSec) cellSolveSecRef.current = { ...session.cellSolveSec };
    if (session.rowSolveSec) rowSolveSecRef.current = { ...session.rowSolveSec };
    if (typeof session.elapsedSeconds === 'number') lastSolveElapsedRef.current = session.elapsedSeconds;
  }, []);

  const getSnapshot = useCallback((): Partial<HistoryRecord> => {
    const exposure = computeOperatorExposure(state.puzzle);
    const opMistakes = computeOperatorMistakes(state.puzzle, state.mistakeCellKeys);

    return {
      operatorMistakes: opMistakes,
      operatorExposure: exposure,
      cellSolveSec: { ...cellSolveSecRef.current },
      rowSolveSec: { ...rowSolveSecRef.current },
      firstInputSec: firstInputSecRef.current ?? state.elapsedSeconds,
      longGaps: longGapsRef.current,
      pauseCount: pauseCountRef.current,
      undoCount: undoCountRef.current,
      editCount: editCountRef.current,
      inputKind: inputKindRef.current,
      sessionId: APP_SESSION_ID,
    };
  }, [state.puzzle, state.mistakeCellKeys, state.elapsedSeconds]);

  return {
    recordEdit,
    recordUndo,
    recordPause,
    setInputKind,
    recordProgressTiming,
    restoreFromSession,
    getSnapshot,
  };
}
