import { useReducer, useEffect, useRef, useCallback } from 'react';
import { calculateTimeUpPenalty, findBestStartCell } from '../../../engine';
import { clearSession, sessionKeyFor } from '../../../storage/sessionStorage';
import { ActivePuzzleSession, GameMode, ModeControls } from '../../../storage/schema';
import { soundEngine } from '../../../audio/soundEngine';
import { createInitialGameSessionState, gameReducer } from '../state/gameReducer';
import { findFirstEditableCell } from '../state/navigation';
import { recordLossOutcome } from '../state/recordOutcome';
import { getModeRules } from '../state/modeRules';
import { collectAllBoardMistakes } from '../state/mistakeTracker';
import { launchLabLevel } from '../../lab/startLab';
import { LabPack } from '../../lab/schema/packTypes';
import { useCountdown } from './useCountdown';
import { useAutoPause } from './useAutoPause';
import { useSessionPersistence } from './useSessionPersistence';
import { usePuzzleActions } from './usePuzzleActions';
import { usePuzzleGenerator } from './usePuzzleGenerator';
import { usePuzzleTelemetry } from './usePuzzleTelemetry';
import { useResultAudio } from './useResultAudio';

interface GameSessionOptions {
  controls?: Record<GameMode, ModeControls>;
  darkMode?: boolean;
  muted?: boolean;
  isSettingsOpen?: boolean;
}

export function useGameSession(options: GameSessionOptions = {}) {
  const [state, dispatch] = useReducer(gameReducer, undefined, createInitialGameSessionState);
  const inputRefs = useRef<(HTMLInputElement | null)[][]>([]);
  const telemetry = usePuzzleTelemetry(state);

  // Synchronize resolved dark mode from settings
  useEffect(() => {
    if (options.darkMode !== undefined && state.darkMode !== options.darkMode) {
      dispatch({ type: 'TOGGLE_DARK' });
    }
  }, [options.darkMode, state.darkMode]);

  // Synchronize mute state
  useEffect(() => {
    if (options.muted !== undefined && state.muted !== options.muted) {
      dispatch({ type: 'TOGGLE_MUTE', muted: options.muted });
    }
  }, [options.muted, state.muted]);

  // Record pauses for telemetry
  useEffect(() => {
    if (state.gameState === 'PAUSED') {
      telemetry.recordPause();
    }
  }, [state.gameState, telemetry]);

  // Throttled mid-puzzle session persistence
  useSessionPersistence(state, telemetry.getSnapshot);

  // Play outcome audio safely guarded against duplicates
  useResultAudio(state.gameState, state.puzzle.id, state.retriesCount);

  const focusDomInput = useCallback((row: number, col: number, delay = 0) => {
    if (delay > 0) {
      setTimeout(() => inputRefs.current[row]?.[col]?.focus(), delay);
    } else {
      inputRefs.current[row]?.[col]?.focus();
    }
  }, []);

  const focusCell = useCallback((row: number, col: number) => {
    dispatch({ type: 'SET_FOCUS', pos: { row, col } });
  }, []);

  const handleResumeFocus = useCallback(() => {
    const pos = state.focusedPos ?? findFirstEditableCell(state.puzzle);
    if (pos) focusDomInput(pos.row, pos.col, 0);
  }, [state.focusedPos, state.puzzle, focusDomInput]);

  useAutoPause(state.gameState, dispatch, handleResumeFocus, options.isSettingsOpen);

  const handleTimeUp = useCallback(() => {
    clearSession(sessionKeyFor(state.mode, state.overrideSize));
    const penalty = calculateTimeUpPenalty(state.rating);
    const mistakesResult = collectAllBoardMistakes(state.puzzle, state.mistakeCellKeys);
    const finalMistakes = state.errorsMade + mistakesResult.addedCount;
    recordLossOutcome({
      mode: state.mode,
      ratingBefore: state.rating,
      level: state.level,
      overrideSize: state.overrideSize,
      gridSize: state.puzzle.size,
      timeLimitSeconds: state.timeLimitSeconds,
      hintsUsed: state.hintsUsed,
      mistakes: finalMistakes,
      ratingResult: penalty,
      puzzle: state.puzzle,
      telemetry: telemetry.getSnapshot(),
    });
    dispatch({
      type: 'TIME_UP',
      ratingResult: penalty,
      errorsMade: finalMistakes,
      mistakeCellKeys: mistakesResult.newKeys,
    });
  }, [
    state.mode,
    state.rating,
    state.level,
    state.overrideSize,
    state.puzzle,
    state.timeLimitSeconds,
    state.hintsUsed,
    state.errorsMade,
    state.mistakeCellKeys,
    telemetry,
  ]);

  const currentRules = getModeRules(state.mode);

  useCountdown(
    state.gameState,
    state.elapsedSeconds,
    state.timeLimitSeconds,
    dispatch,
    handleTimeUp,
    currentRules.hasTimer
  );

  const resumeSavedSession = useCallback(
    (session?: ActivePuzzleSession) => {
      telemetry.restoreFromSession(session);
      dispatch({ type: 'RESUME_SAVED_SESSION', session });
      const targetPuzzle = session?.puzzle ?? state.puzzle;
      const targetFocus = (session ? session.focusedPos : state.focusedPos) ?? findFirstEditableCell(targetPuzzle);
      if (targetFocus) focusDomInput(targetFocus.row, targetFocus.col, 20);
    },
    [state.puzzle, state.focusedPos, focusDomInput, telemetry]
  );

  const {
    startPuzzleLevel,
    handleSwapPuzzle,
    cancelGeneration,
  } = usePuzzleGenerator({
    state,
    dispatch,
    focusDomInput,
    resumeSavedSession,
  });

  const handleRetryPuzzle = useCallback(() => {
    soundEngine.playTick(0);
    const startCell = findBestStartCell(state.puzzle);
    dispatch({
      type: 'RETRY_SAME_PUZZLE',
      firstCell: { row: startCell.row, col: startCell.col },
      direction: startCell.direction,
    });
    focusDomInput(startCell.row, startCell.col, 10);
  }, [state.puzzle, focusDomInput]);

  const startLabLevel = useCallback(
    (pack: LabPack, levelIndex: number) => {
      launchLabLevel(pack, levelIndex, dispatch, cancelGeneration, focusDomInput);
    },
    [cancelGeneration, dispatch, focusDomInput]
  );

  const puzzleActions = usePuzzleActions(
    state,
    dispatch,
    focusCell,
    focusDomInput,
    options.controls ? (options.controls[state.mode]?.autoAdvance ?? true) : true,
    telemetry
  );

  return {
    state,
    dispatch,
    inputRefs,
    focusCell,
    focusDomInput,
    resumeSavedSession,
    startPuzzleLevel,
    startLabLevel,
    handleRetryPuzzle,
    handleSwapPuzzle,
    cancelGeneration,
    ...puzzleActions,
  };
}
