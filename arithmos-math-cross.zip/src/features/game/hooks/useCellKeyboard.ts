import React, { useCallback } from 'react';
import { MathCrosswordPuzzle } from '../../../engine';
import { soundEngine } from '../../../audio/soundEngine';
import { GameAction } from '../state/gameTypes';
import {
  findLineBoundaryCell,
  findNextEmptyEditableCell,
  findSpatialNextCell,
  isCellEditable,
} from '../state/navigation';

interface CellKeyboardParams {
  gameState: string;
  puzzle: MathCrosswordPuzzle;
  direction: 'row' | 'col';
  isCalculatorOpen?: boolean;
  handleUndo: () => void;
  handleRedo: () => void;
  handleBackspace: () => void;
  handleDelete: () => void;
  handleDigitInput: (digit: string) => void;
  focusCell: (row: number, col: number) => void;
  dispatch: React.Dispatch<GameAction>;
}

const SPATIAL_DELTAS: Record<string, [number, number, 'row' | 'col']> = {
  ArrowRight: [0, 1, 'row'],
  ArrowLeft: [0, -1, 'row'],
  ArrowDown: [1, 0, 'col'],
  ArrowUp: [-1, 0, 'col'],
};

export function useCellKeyboard({
  gameState,
  puzzle,
  direction,
  isCalculatorOpen = false,
  handleUndo,
  handleRedo,
  handleBackspace,
  handleDelete,
  handleDigitInput,
  focusCell,
  dispatch,
}: CellKeyboardParams) {
  return useCallback(
    (e: React.KeyboardEvent<HTMLInputElement>, row: number, col: number) => {
      if (gameState !== 'PLAYING' || isCalculatorOpen) return;

      const cell = puzzle.cells[row]?.[col];
      const canEdit = isCellEditable(cell);

      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) handleRedo();
        else handleUndo();
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        handleRedo();
        return;
      }
      if (e.key === 'Home') {
        e.preventDefault();
        const target = findLineBoundaryCell(puzzle, row, col, direction, 'first');
        if (target) focusCell(target.row, target.col);
        return;
      }
      if (e.key === 'End') {
        e.preventDefault();
        const target = findLineBoundaryCell(puzzle, row, col, direction, 'last');
        if (target) focusCell(target.row, target.col);
        return;
      }
      if (e.key === 'Enter') {
        e.preventDefault();
        const next = findNextEmptyEditableCell(puzzle, row, col, direction);
        if (next) focusCell(next.row, next.col);
        return;
      }
      if (e.key === 'Backspace') {
        e.preventDefault();
        if (canEdit) handleBackspace();
        return;
      }
      if (e.key === 'Delete') {
        e.preventDefault();
        if (canEdit) handleDelete();
        return;
      }
      if (e.key === 'd' || e.key === 'D') {
        e.preventDefault();
        dispatch({ type: 'TOGGLE_DIRECTION' });
        soundEngine.playTick(1);
        return;
      }

      const delta = SPATIAL_DELTAS[e.key];
      if (delta) {
        e.preventDefault();
        dispatch({ type: 'SET_DIRECTION', direction: delta[2] });
        const next = findSpatialNextCell(puzzle, row, col, delta[0], delta[1]);
        if (next) focusCell(next.row, next.col);
        return;
      }

      if (/^[0-9]$/.test(e.key)) {
        e.preventDefault();
        if (canEdit) handleDigitInput(e.key);
      }
    },
    [
      gameState,
      puzzle,
      direction,
      isCalculatorOpen,
      handleUndo,
      handleRedo,
      handleBackspace,
      handleDelete,
      handleDigitInput,
      focusCell,
      dispatch,
    ]
  );
}
