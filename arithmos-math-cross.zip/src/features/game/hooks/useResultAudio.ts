import { useEffect, useRef } from 'react';
import { soundEngine } from '../../../audio/soundEngine';
import { GameState } from '../state/gameTypes';

export function useResultAudio(gameState: GameState, puzzleId: string, attemptCount = 0): void {
  const lastPlayedKeyRef = useRef<string | null>(null);

  useEffect(() => {
    const key = `${puzzleId}-${attemptCount}`;
    if (gameState === 'ROUND_SUMMARY') {
      const victoryKey = `win-${key}`;
      if (lastPlayedKeyRef.current !== victoryKey) {
        lastPlayedKeyRef.current = victoryKey;
        soundEngine.playVictory();
      }
    } else if (gameState === 'TIME_UP') {
      const timeUpKey = `loss-${key}`;
      if (lastPlayedKeyRef.current !== timeUpKey) {
        lastPlayedKeyRef.current = timeUpKey;
        soundEngine.playTimeUp();
      }
    } else if (gameState === 'PLAYING') {
      if (lastPlayedKeyRef.current && lastPlayedKeyRef.current.endsWith(key)) {
        lastPlayedKeyRef.current = null;
      }
    }
  }, [gameState, puzzleId, attemptCount]);
}
