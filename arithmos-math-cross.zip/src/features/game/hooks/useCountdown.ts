import { useEffect, useRef } from 'react';
import { soundEngine } from '../../../audio/soundEngine';
import { GameAction, GameState } from '../state/gameTypes';

export function useCountdown(
  gameState: GameState,
  elapsedSeconds: number,
  timeLimitSeconds: number,
  dispatch: React.Dispatch<GameAction>,
  onTimeUp: () => void,
  hasTimer = true
): void {
  const lastTickRef = useRef<number>(Date.now());
  const lastBeepSecondRef = useRef<number | null>(null);
  const timeUpFiredRef = useRef<boolean>(false);
  const alert30FiredRef = useRef<boolean>(false);
  const isInitialMountRef = useRef<boolean>(true);

  // Initial mount check for restored sessions
  useEffect(() => {
    if (isInitialMountRef.current) {
      isInitialMountRef.current = false;
      const initialRemaining = timeLimitSeconds - elapsedSeconds;
      if (initialRemaining <= 30) {
        alert30FiredRef.current = true;
      }
      if (initialRemaining <= 10) {
        lastBeepSecondRef.current = initialRemaining;
      }
    }
  }, [timeLimitSeconds, elapsedSeconds]);

  // Reset guards when timer resets or advances past 30s
  useEffect(() => {
    if (elapsedSeconds < timeLimitSeconds) {
      timeUpFiredRef.current = false;
    }
    if (elapsedSeconds === 0 || timeLimitSeconds - elapsedSeconds > 30) {
      alert30FiredRef.current = false;
      lastBeepSecondRef.current = null;
    }
  }, [elapsedSeconds, timeLimitSeconds]);

  // Play 30s alert, warning beeps in final 10s, or trigger time-up at 0
  useEffect(() => {
    if (!hasTimer || gameState !== 'PLAYING') return;
    const remaining = timeLimitSeconds - elapsedSeconds;

    if (remaining <= 0) {
      if (!timeUpFiredRef.current) {
        timeUpFiredRef.current = true;
        onTimeUp();
      }
      return;
    }

    if (remaining <= 30 && remaining > 0 && !alert30FiredRef.current) {
      alert30FiredRef.current = true;
      soundEngine.playAlert30s();
    }

    if (remaining <= 10 && remaining > 0) {
      if (lastBeepSecondRef.current === null) {
        lastBeepSecondRef.current = remaining;
        soundEngine.playTimeWarning();
      } else if (lastBeepSecondRef.current > remaining) {
        // Catch-up missed seconds up to 1 sound per frame
        lastBeepSecondRef.current = remaining;
        soundEngine.playTimeWarning();
      }
    }
  }, [gameState, elapsedSeconds, timeLimitSeconds, onTimeUp, hasTimer]);

  // Drift-free Date.now() delta interval while PLAYING
  useEffect(() => {
    if (gameState !== 'PLAYING') return;
    lastTickRef.current = Date.now();

    const interval = setInterval(() => {
      const now = Date.now();
      const deltaMs = now - lastTickRef.current;
      if (deltaMs >= 1000) {
        const wholeSeconds = Math.floor(deltaMs / 1000);
        lastTickRef.current += wholeSeconds * 1000;
        dispatch({ type: 'TICK', seconds: wholeSeconds });
      }
    }, 200);

    return () => clearInterval(interval);
  }, [gameState, dispatch]);
}
