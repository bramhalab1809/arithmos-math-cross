import React, { useEffect } from 'react';
import { GameAction, GameState } from '../state/gameTypes';

export function useAutoPause(
  gameState: GameState,
  dispatch: React.Dispatch<GameAction>,
  onResumeFocus?: () => void,
  isSettingsOpen = false
): void {
  // Automatically pause when user switches browser tabs or minimizes window
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden' && gameState === 'PLAYING') {
        dispatch({ type: 'PAUSE' });
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, [gameState, dispatch]);

  // Global Escape key listener to pause/resume even when board inputs are unmounted
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if (isSettingsOpen) return;
      if (e.key === 'Escape' && (gameState === 'PLAYING' || gameState === 'PAUSED')) {
        e.preventDefault();
        const wasPaused = gameState === 'PAUSED';
        dispatch({ type: 'TOGGLE_PAUSE' });
        if (wasPaused && onResumeFocus) {
          onResumeFocus();
        }
      }
    };
    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [gameState, dispatch, onResumeFocus, isSettingsOpen]);
}
