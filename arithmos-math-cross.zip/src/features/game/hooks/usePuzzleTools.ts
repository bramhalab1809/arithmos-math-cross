import React, { useCallback, useRef } from 'react';
import { MathCrosswordPuzzle, findLogicalDeductionHint, isCompleteLineValid } from '../../../engine';
import { soundEngine } from '../../../audio/soundEngine';
import { getModeRules } from '../state/modeRules';
import { checkAndHandleVictory } from '../state/recordOutcome';
import { findNextEmptyEditableCell } from '../state/navigation';
import {
  GameAction,
  GameSessionState,
  MAX_CHECKS_PER_PUZZLE,
  MAX_HINTS_PER_PUZZLE,
  StatusBanner,
} from '../state/gameTypes';
import { isPartialMultiDigitPrefix } from '../state/mistakeTracker';

export function usePuzzleTools(
  state: GameSessionState,
  dispatch: React.Dispatch<GameAction>,
  focusDomInput: (row: number, col: number, delay?: number) => void,
  getSnapshot?: () => Partial<import('../../../storage/history').HistoryRecord>,
  recordProgressTiming?: (updatedPuzzle: MathCrosswordPuzzle, row: number, col: number) => void
) {
  const lastHintKeyTimeRef = useRef<number>(0);
  const lastCheckKeyTimeRef = useRef<number>(0);
  const rules = getModeRules(state.mode);

  const checkVictoryIfComplete = useCallback(
    (updatedPuzzle: MathCrosswordPuzzle, currentHints: number, currentErrors: number): boolean => {
      return checkAndHandleVictory(state, updatedPuzzle, currentHints, currentErrors, dispatch, getSnapshot?.());
    },
    [state, dispatch, getSnapshot]
  );

  const handleTriggerHint = useCallback(
    (isFromKeyboard = false) => {
      if (state.gameState !== 'PLAYING' || !rules.hasHints) return;

      const hintsLeft = MAX_HINTS_PER_PUZZLE - state.hintsUsed;
      if (hintsLeft <= 0) {
        soundEngine.playError();
        const message = `No hints remaining (${MAX_HINTS_PER_PUZZLE}/${MAX_HINTS_PER_PUZZLE} used).`;
        dispatch({ type: 'SET_BANNER', banner: { type: 'info', message } });
        return;
      }

      if (isFromKeyboard) {
        const now = Date.now();
        if (now - lastHintKeyTimeRef.current > 2000) {
          lastHintKeyTimeRef.current = now;
          soundEngine.playTick(1);
          dispatch({
            type: 'SET_BANNER',
            banner: { type: 'info', message: `Press H again to use a hint (${hintsLeft} left).` },
          });
          return;
        }
        lastHintKeyTimeRef.current = 0;
      }

      const deduction = findLogicalDeductionHint(state.puzzle, state.focusedPos);
      if (!deduction) return;

      soundEngine.playHint();
      const newHintsUsed = state.hintsUsed + 1;
      const nextCells = state.puzzle.cells.map((rArr, rIdx) =>
        rArr.map((cObj, cIdx) =>
          rIdx === deduction.row && cIdx === deduction.col
            ? { ...cObj, userValue: String(deduction.value), isHinted: true, isError: false }
            : cObj
        )
      );
      const updatedPuzzle: MathCrosswordPuzzle = { ...state.puzzle, cells: nextCells };
      recordProgressTiming?.(updatedPuzzle, deduction.row, deduction.col);
      const banner: StatusBanner = { type: 'info', message: deduction.explanation };
      if (checkVictoryIfComplete(updatedPuzzle, newHintsUsed, state.errorsMade)) {
        dispatch({ type: 'SET_BANNER', banner });
        return;
      }

      const nextTarget = findNextEmptyEditableCell(updatedPuzzle, deduction.row, deduction.col, state.direction);
      const targetPos = nextTarget
        ? { row: nextTarget.row, col: nextTarget.col }
        : { row: deduction.row, col: deduction.col };
      dispatch({ type: 'APPLY_HINT', puzzle: updatedPuzzle, hintsUsed: newHintsUsed, banner, nextFocus: targetPos });
      focusDomInput(targetPos.row, targetPos.col, 10);
    },
    [state, rules.hasHints, checkVictoryIfComplete, focusDomInput, dispatch]
  );

  const handleValidateBoard = useCallback(
    (isFromKeyboard = false) => {
      if (state.gameState !== 'PLAYING') return;

      if (!rules.unlimitedChecks) {
        const checksLeft = MAX_CHECKS_PER_PUZZLE - state.checksUsed;
        if (checksLeft <= 0) {
          soundEngine.playError();
          const message = `No checks remaining (${MAX_CHECKS_PER_PUZZLE}/${MAX_CHECKS_PER_PUZZLE} used).`;
          dispatch({ type: 'SET_BANNER', banner: { type: 'info', message } });
          return;
        }

        if (isFromKeyboard) {
          const now = Date.now();
          if (now - lastCheckKeyTimeRef.current > 2000) {
            lastCheckKeyTimeRef.current = now;
            soundEngine.playTick(1);
            dispatch({
              type: 'SET_BANNER',
              banner: { type: 'info', message: `Press C again to check board (${checksLeft} left).` },
            });
            return;
          }
          lastCheckKeyTimeRef.current = 0;
        }
      }

      let errorCount = 0;
      let emptyCount = 0;
      let newDistinctMistakes = 0;
      const updatedMistakeKeys = [...state.mistakeCellKeys];

      const nextCells = state.puzzle.cells.map((rArr, r) =>
        rArr.map((cell, c) => {
          if (cell.isClue || cell.isHinted) return cell;
          if (isPartialMultiDigitPrefix(cell)) {
            emptyCount++;
            return { ...cell, isError: false };
          }
          const trimmed = cell.userValue.trim();
          if (trimmed === '') {
            emptyCount++;
            return { ...cell, isError: false };
          }
          const val = parseInt(trimmed, 10);
          let wrong = false;
          if (!Number.isInteger(val) || val < 1) {
            wrong = true;
          } else if (val !== cell.solution) {
            const rVals = state.puzzle.cells[r].map((cl, i) => (i === c ? val : (cl.isClue ? cl.solution : parseInt(cl.userValue, 10))));
            const rFull = rVals.every((v) => Number.isInteger(v) && v >= 1);
            const rInvalid = rFull && !isCompleteLineValid(rVals, state.puzzle.rowOps[r]);

            const cVals = state.puzzle.cells.map((rowArr, i) => (i === r ? val : (rowArr[c].isClue ? rowArr[c].solution : parseInt(rowArr[c].userValue, 10))));
            const cFull = cVals.every((v) => Number.isInteger(v) && v >= 1);
            const cOps = state.puzzle.colOps ? state.puzzle.colOps.map((rOps) => rOps[c]) : [];
            const cInvalid = cFull && !isCompleteLineValid(cVals, cOps);

            wrong = rInvalid || cInvalid;
          }
          if (wrong) {
            errorCount++;
            const mistakeKey = `${r},${c}:${trimmed}`;
            if (!updatedMistakeKeys.includes(mistakeKey)) {
              updatedMistakeKeys.push(mistakeKey);
              newDistinctMistakes++;
            }
          }
          return { ...cell, isError: wrong };
        })
      );
      const updatedPuzzle = { ...state.puzzle, cells: nextCells };
      const nextChecksUsed = state.checksUsed + 1;

      if (errorCount > 0) {
        soundEngine.playError();
        const message = `${errorCount} cell${errorCount > 1 ? 's' : ''} highlighted in red do not satisfy equations.`;
        dispatch({
          type: 'VALIDATE_BOARD',
          puzzle: updatedPuzzle,
          checksUsed: nextChecksUsed,
          errorsAdded: newDistinctMistakes,
          mistakeCellKeys: updatedMistakeKeys,
          banner: { type: 'error', message },
        });
      } else if (emptyCount > 0) {
        soundEngine.playTick(2);
        const message = `All entered digits are accurate so far. ${emptyCount} remaining.`;
        dispatch({
          type: 'VALIDATE_BOARD',
          puzzle: updatedPuzzle,
          checksUsed: nextChecksUsed,
          errorsAdded: 0,
          mistakeCellKeys: updatedMistakeKeys,
          banner: { type: 'info', message },
        });
      } else {
        dispatch({
          type: 'VALIDATE_BOARD',
          puzzle: updatedPuzzle,
          checksUsed: nextChecksUsed,
          errorsAdded: 0,
          mistakeCellKeys: updatedMistakeKeys,
          banner: null,
        });
        checkVictoryIfComplete(updatedPuzzle, state.hintsUsed, state.errorsMade);
      }
    },
    [state, rules.unlimitedChecks, checkVictoryIfComplete, dispatch]
  );

  return { handleTriggerHint, handleValidateBoard };
}
