import React from 'react';
import { AlertTriangle, CheckCircle2, Lock, Star } from '../../../icons';
import { CellData } from '../../../engine';

interface CellProps {
  cell: CellData;
  row: number;
  col: number;
  fontSizeClass?: string;
  minSizeClass?: string;
  darkMode: boolean;
  isFocused: boolean;
  isLineHighlighted: boolean;
  isResultCell: boolean;
  lineCompleteValid: boolean;
  lineCompleteInvalid: boolean;
  isCalculatorOpen?: boolean;
  inputRefCallback: (el: HTMLInputElement | null) => void;
  onFocusPos: (row: number, col: number) => void;
  onChangeValue: (row: number, col: number, value: string) => void;
  onKeyDownCell: (e: React.KeyboardEvent<HTMLInputElement>, row: number, col: number) => void;
}

export const Cell: React.FC<CellProps> = React.memo(
  ({
    cell,
    row,
    col,
    fontSizeClass = 'text-base font-bold',
    minSizeClass = 'min-w-0 min-h-0',
    darkMode,
    isFocused,
    isLineHighlighted,
    isResultCell,
    lineCompleteValid,
    lineCompleteInvalid,
    isCalculatorOpen = false,
    inputRefCallback,
    onFocusPos,
    onChangeValue,
    onKeyDownCell,
  }) => {
    if (cell.isVoid) {
      return (
        <div
          className={`w-full h-full ${minSizeClass} pointer-events-none select-none`}
          aria-hidden="true"
        />
      );
    }

    const isErrorState = cell.isError || lineCompleteInvalid;
    const isStarSolved = Boolean(
      cell.hasStar &&
        !cell.isHinted &&
        cell.userValue !== '' &&
        (parseInt(cell.userValue, 10) === cell.solution || lineCompleteValid)
    );
    const isReadOnly = Boolean(cell.isClue || cell.isHinted);
    const displayVal = cell.isClue ? String(cell.solution) : cell.userValue;
    const dynamicFont = displayVal.length >= 3 ? 'text-xs sm:text-sm font-bold tracking-tight' : fontSizeClass;
    const hubClass =
      cell.isHub && !isFocused
        ? 'ring-2 ring-amber-500/70 shadow-[0_0_12px_rgba(245,158,11,0.22)]'
        : '';

    return (
      <div
        data-bird-perch={`cell-${row}-${col}`}
        className="relative w-full h-full flex items-center justify-center"
      >
        <input
          ref={inputRefCallback}
          type="text"
          inputMode="none"
          enterKeyHint="next"
          pattern="[0-9]*"
          maxLength={3}
          readOnly={isReadOnly || isCalculatorOpen}
          aria-readonly={isReadOnly || isCalculatorOpen}
          value={displayVal}
          aria-label={`Row ${row + 1} Column ${col + 1} ${
            cell.isClue ? 'clue (read-only)' : cell.isHinted ? 'input (locked hint)' : 'input'
          }`}
          onFocus={() => {
            if (isCalculatorOpen) return;
            onFocusPos(row, col);
          }}
          onClick={() => {
            if (!isCalculatorOpen) onFocusPos(row, col);
          }}
          onChange={(e) => {
            if (!isReadOnly && !isCalculatorOpen) {
              const digits = e.target.value.replace(/[^0-9]/g, '').slice(0, 3);
              if (digits !== cell.userValue) onChangeValue(row, col, digits);
            }
          }}
          onKeyDown={(e) => {
            if (!isCalculatorOpen) onKeyDownCell(e, row, col);
          }}
          className={`w-full h-full ${minSizeClass} ${dynamicFont} ${hubClass} rounded-xl font-mono tabular-nums text-center outline-none ${
            cell.isClue && !isFocused ? 'border' : 'border-2'
          } transition-all duration-150 select-none selection:bg-transparent ${
            cell.isClue
              ? isFocused
                ? darkMode
                  ? '!bg-orange-400/30 !border-orange-400 !text-orange-100 ring-4 ring-orange-400/50 shadow-md scale-[1.04] z-10 cursor-default'
                  : '!bg-orange-100 !border-orange-500 !text-orange-950 ring-4 ring-orange-400/50 shadow-md scale-[1.04] z-10 cursor-default'
                : isResultCell
                ? darkMode
                  ? 'bg-slate-900/95 border-slate-700/80 text-amber-300/90 cursor-default'
                  : 'bg-slate-100 border-slate-300 text-slate-800 cursor-default'
                : darkMode
                ? 'bg-slate-900/75 border-slate-800 text-slate-300 cursor-default'
                : 'bg-slate-100/80 border-slate-200 text-slate-700 cursor-default'
              : cell.isHinted
              ? isFocused
                ? darkMode
                  ? '!bg-orange-400/30 !border-orange-400 !text-orange-100 ring-4 ring-orange-400/50 shadow-md scale-[1.04] z-10 cursor-default'
                  : '!bg-orange-100 !border-orange-500 !text-orange-950 ring-4 ring-orange-400/50 shadow-md scale-[1.04] z-10 cursor-default'
                : darkMode
                ? 'bg-amber-950/30 border-amber-500/50 text-amber-300 cursor-default'
                : 'bg-amber-50/80 border-amber-400 text-amber-900 cursor-default'
              : isErrorState
              ? darkMode
                ? 'bg-red-950/60 border-dashed border-red-500 text-red-200 cursor-pointer'
                : 'bg-red-50 border-dashed border-red-500 text-red-700 cursor-pointer'
              : isFocused
              ? darkMode
                ? 'bg-amber-500/20 border-amber-400 text-white ring-4 ring-amber-400/40 shadow-md scale-[1.04] z-10 cursor-pointer'
                : 'bg-blue-50 border-blue-600 text-blue-950 ring-4 ring-blue-500/35 shadow-md scale-[1.04] z-10 cursor-pointer'
              : lineCompleteValid
              ? darkMode
                ? 'bg-emerald-950/35 border-emerald-500/50 text-emerald-300 cursor-pointer'
                : 'bg-emerald-50/70 border-emerald-400 text-emerald-900 cursor-pointer'
              : isLineHighlighted && cell.userValue === ''
              ? darkMode
                ? 'bg-amber-500/10 border-slate-700 text-slate-100 cursor-pointer'
                : 'bg-blue-50/50 border-slate-300 text-slate-900 cursor-pointer'
              : cell.hasStar
              ? darkMode
                ? 'bg-[#0B0F17] border-amber-400/40 text-slate-100 hover:border-amber-400/60 cursor-pointer'
                : 'bg-white border-amber-300 text-slate-900 hover:border-amber-400 cursor-pointer'
              : darkMode
              ? 'bg-[#0B0F17] border-slate-700 text-slate-100 hover:border-slate-500 cursor-pointer'
              : 'bg-white border-slate-300 text-slate-900 hover:border-slate-400 cursor-pointer'
          }`}
        />

        {isErrorState && !cell.isClue && (
          <span
            className="absolute top-1 left-1 inline-flex items-center text-red-500 pointer-events-none"
            title="Incorrect value"
          >
            <AlertTriangle className="w-2.5 h-2.5" />
          </span>
        )}

        {lineCompleteValid && isResultCell && !isErrorState && (
          <span
            className="absolute top-1 left-1 inline-flex items-center text-emerald-500 pointer-events-none"
            title="Line balanced"
          >
            <CheckCircle2 className="w-2.5 h-2.5" />
          </span>
        )}

        {cell.hasStar && (
          <span
            className={`absolute top-1 right-1 inline-flex items-center pointer-events-none transition-all ${
              cell.isHinted
                ? 'text-slate-400 dark:text-slate-500'
                : isStarSolved
                ? 'text-amber-400 fill-amber-400 drop-shadow-[0_0_4px_rgba(251,191,36,0.7)] scale-110'
                : 'text-amber-400/50 dark:text-amber-400/40'
            }`}
            title={
              cell.isHinted
                ? 'Hinted star (invalidated)'
                : isStarSolved
                ? 'Star collected'
                : 'Star cell'
            }
          >
            <Star className="w-2.5 h-2.5" />
          </span>
        )}

        {cell.isHinted && !cell.hasStar && (
          <span
            className="absolute top-1 right-1 inline-flex items-center text-amber-400 pointer-events-none"
            title="Revealed via Hint (Locked)"
          >
            <Lock className="w-2.5 h-2.5" />
          </span>
        )}

        {cell.isHinted && cell.hasStar && !isErrorState && (
          <span
            className="absolute top-1 left-1 inline-flex items-center text-amber-400 pointer-events-none"
            title="Revealed via Hint (Locked)"
          >
            <Lock className="w-2.5 h-2.5" />
          </span>
        )}
      </div>
    );
  }
);
