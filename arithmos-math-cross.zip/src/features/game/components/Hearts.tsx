import React from 'react';
import { Heart } from '../../../icons';
import { MAX_HEARTS_PER_LEVEL } from '../state/gameTypes';

interface HeartsProps {
  heartsLeft: number;
  darkMode: boolean;
}

export const Hearts: React.FC<HeartsProps> = ({ heartsLeft, darkMode }) => {
  return (
    <div
      className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border ${
        darkMode
          ? 'bg-slate-900 border-slate-800'
          : 'bg-slate-100 border-slate-200'
      }`}
      role="status"
      aria-label={`${heartsLeft} of ${MAX_HEARTS_PER_LEVEL} hearts remaining`}
      title={`${heartsLeft} of ${MAX_HEARTS_PER_LEVEL} hearts remaining (used to swap puzzles)`}
    >
      {Array.from({ length: MAX_HEARTS_PER_LEVEL }, (_, idx) => {
        const filled = idx < heartsLeft;
        return (
          <Heart
            key={idx}
            className={`w-3.5 h-3.5 transition-all duration-150 ${
              filled
                ? 'text-rose-500 fill-rose-500'
                : darkMode
                ? 'text-slate-700'
                : 'text-slate-300'
            }`}
          />
        );
      })}
    </div>
  );
};
