import React, { useEffect, useRef } from 'react';
import { ArrowRight, Flame, Home, Infinity, Lightbulb, Star, Timer, TrendingUp, X } from '../../../icons';
import { MathCrosswordPuzzle, RatingAdjustmentResult } from '../../../engine';
import { GameMode } from '../../../storage/schema';
import { getModeRules } from '../state/modeRules';
import { formatTime } from './TimerBar';
import { LevelMiniAnalytics } from './LevelMiniAnalytics';

export interface SummaryModalProps {
  puzzle: MathCrosswordPuzzle;
  level: number;
  completedLevel: number | null;
  elapsedSeconds: number;
  timeLimitSeconds: number;
  hintsUsed: number;
  errorsMade?: number;
  calculatorUses?: number;
  mistakeCellKeys?: string[];
  lastRatingResult: RatingAdjustmentResult;
  darkMode: boolean;
  mode?: GameMode;
  starsEarned?: 1 | 2 | 3;
  starReason?: string;
  onNextLevel: () => void;
  onReturnHome: () => void;
}

export const SummaryModal: React.FC<SummaryModalProps> = ({
  puzzle, level, completedLevel, elapsedSeconds, timeLimitSeconds,
  hintsUsed, errorsMade = 0, calculatorUses = 0, mistakeCellKeys = [],
  lastRatingResult, darkMode, mode = 'endless', starsEarned, onNextLevel, onReturnHome,
}) => {
  const nextBtnRef = useRef<HTMLButtonElement>(null);
  const solvedLevelNum = completedLevel ?? Math.max(1, level - 1);
  const rules = getModeRules(mode);
  const isStarMode = rules.hasStars || starsEarned !== undefined;
  const delta = lastRatingResult.delta;

  const starCellsTotal = puzzle.cells.flat().filter((c) => c.hasStar).length;
  const starCellsSolved = puzzle.cells.flat().filter((c) => c.hasStar && parseInt(c.userValue, 10) === c.solution).length;

  useEffect(() => {
    nextBtnRef.current?.focus();
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      e.preventDefault();
      onReturnHome();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      onNextLevel();
    }
  };

  const renderModeIcon = () => {
    if (mode === 'star') {
      return (
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-2 ${darkMode ? 'bg-yellow-400/15 border border-yellow-400/30' : 'bg-yellow-50 border border-yellow-200'}`}>
          <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
        </div>
      );
    }
    if (mode === 'practice') {
      return (
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-2 ${darkMode ? 'bg-emerald-500/15 border border-emerald-500/30' : 'bg-emerald-50 border border-emerald-200'}`}>
          <Infinity className="w-5 h-5 text-emerald-500" />
        </div>
      );
    }
    return (
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-2 ${darkMode ? 'bg-amber-500/15 border border-amber-500/30' : 'bg-amber-50 border border-amber-200'}`}>
        <Flame className="w-5 h-5 text-amber-500" />
      </div>
    );
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 px-4"
      role="dialog"
      aria-modal="true"
      aria-label="Level clear"
      tabIndex={-1}
      onKeyDown={handleKeyDown}
    >
      <div
        className={`w-full max-w-md max-h-[92dvh] overflow-y-auto no-scrollbar rounded-2xl border p-4 sm:p-5 shadow-2xl flex flex-col items-center text-center ${
          darkMode ? 'bg-[#131B2E] border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {renderModeIcon()}

        <h2 className="font-display text-2xl font-bold tracking-tight mb-2">
          Level <span className="text-emerald-500 dark:text-emerald-400">{solvedLevelNum}</span>
        </h2>

        {isStarMode && (
          <div
            className={`w-full py-1.5 px-3 rounded-xl border mb-2 flex items-center justify-center gap-3 text-center ${
              darkMode ? 'bg-amber-500/10 border-amber-500/30 text-amber-300' : 'bg-amber-50 border-amber-200 text-amber-800'
            }`}
          >
            <div className="flex items-center gap-1.5">
              {[1, 2, 3].map((starIndex) => (
                <Star
                  key={starIndex}
                  className={`w-5 h-5 transition-all ${
                    starIndex <= (starsEarned ?? 1)
                      ? 'text-amber-400 fill-amber-400 filter drop-shadow-[0_0_6px_rgba(251,191,36,0.5)]'
                      : darkMode ? 'text-slate-700' : 'text-slate-300'
                  }`}
                />
              ))}
            </div>
            {starCellsTotal > 0 && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-400/20 border border-amber-400/40 text-amber-500 dark:text-amber-400">
                <Star className="w-2.5 h-2.5 fill-current" /> {starCellsSolved}/{starCellsTotal}
              </span>
            )}
          </div>
        )}

        <div className="grid grid-cols-4 gap-1.5 sm:gap-2 w-full mb-1.5 font-mono text-xs tabular-nums">
          <div
            className={`py-1.5 px-2 rounded-xl border flex flex-col items-center justify-center gap-0.5 ${
              darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
            title={`Solve time: ${formatTime(elapsedSeconds)}`}
          >
            <Timer className="w-3.5 h-3.5 text-slate-400" />
            <span className="font-bold">{formatTime(elapsedSeconds)}</span>
          </div>

          <div
            className={`py-1.5 px-2 rounded-xl border flex flex-col items-center justify-center gap-0.5 ${
              darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
            title={`Hints used: ${hintsUsed}`}
          >
            <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-bold">{hintsUsed}</span>
          </div>

          <div
            className={`py-1.5 px-2 rounded-xl border flex flex-col items-center justify-center gap-0.5 ${
              darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
            title={`Mistakes made: ${errorsMade}`}
          >
            <X className="w-3.5 h-3.5 text-red-400" />
            <span className="font-bold">{errorsMade}</span>
          </div>

          <div
            className={`py-1.5 px-2 rounded-xl border flex flex-col items-center justify-center gap-0.5 ${
              darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
            title={`Rating: ${lastRatingResult.newRating} (${delta >= 0 ? `+${delta}` : delta})`}
          >
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-bold text-emerald-400">{delta >= 0 ? `+${delta}` : delta}</span>
          </div>
        </div>

        <LevelMiniAnalytics
          puzzle={puzzle}
          mode={mode}
          won={true}
          elapsedSeconds={elapsedSeconds}
          timeLimitSeconds={timeLimitSeconds}
          hintsUsed={hintsUsed}
          errorsMade={errorsMade}
          calculatorUses={calculatorUses}
          mistakeCellKeys={mistakeCellKeys}
          darkMode={darkMode}
        />

        <div className="flex items-center justify-center gap-4 mt-2.5">
          <button
            ref={nextBtnRef}
            type="button"
            onClick={onNextLevel}
            aria-label="Next Level"
            title="Next Level (Enter)"
            className={`w-12 h-12 min-w-[48px] min-h-[48px] rounded-full flex items-center justify-center transition-all cursor-pointer shadow-md ${
              darkMode
                ? 'bg-amber-500 text-slate-950 hover:bg-amber-400 ring-4 ring-amber-500/20'
                : 'bg-blue-600 text-white hover:bg-blue-500 ring-4 ring-blue-500/20'
            }`}
          >
            <ArrowRight className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={onReturnHome}
            aria-label="Home"
            title="Home (Esc)"
            className={`w-12 h-12 min-w-[48px] min-h-[48px] rounded-full flex items-center justify-center border transition-all cursor-pointer ${
              darkMode
                ? 'border-slate-800 bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-white'
                : 'border-slate-200 bg-slate-100 text-slate-700 hover:bg-slate-200 hover:text-slate-900'
            }`}
          >
            <Home className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
