import React from 'react';
import { GameAction, GameSessionState } from '../state/gameTypes';
import { GameMode } from '../../../storage/schema';
import { Loader2 } from '../../../icons';
import { PauseModal } from './PauseModal';
import { SummaryModal } from './SummaryModal';
import { TimeUpModal } from './TimeUpModal';

interface GameModalsProps {
  state: GameSessionState;
  dispatch: React.Dispatch<GameAction>;
  startPuzzleLevel: (
    targetMode: GameMode,
    targetRating: number,
    targetLevel: number,
    sizeOverride: number | null,
    forceNew?: boolean
  ) => void;
  handleRetryPuzzle: () => void;
  onOpenSettings: () => void;
  onNextCustomAction?: () => boolean;
  onExitToHub?: () => void;
}

export const GameModals: React.FC<GameModalsProps> = ({
  state,
  dispatch,
  startPuzzleLevel,
  handleRetryPuzzle,
  onOpenSettings,
  onNextCustomAction,
  onExitToHub,
}) => {
  const handleExit = () => {
    if (onExitToHub) onExitToHub();
    else dispatch({ type: 'GO_TO_TITLE' });
  };
  const {
    gameState,
    mode,
    level,
    completedLevel,
    darkMode,
    overrideSize,
    elapsedSeconds,
    timeLimitSeconds,
    hintsUsed,
    errorsMade,
    calculatorUses,
    mistakeCellKeys,
    lastRatingResult,
    starsEarned,
    starReason,
    isGenerating,
    puzzle,
  } = state;

  return (
    <>
      {isGenerating && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs">
          <div
            className={`flex items-center gap-3 px-6 py-4 rounded-2xl shadow-xl border ${
              darkMode ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
            }`}
          >
            <Loader2 className="w-5 h-5 animate-spin motion-reduce:animate-none text-amber-500" />
            <span className="text-sm font-semibold tracking-wide">Preparing puzzle</span>
          </div>
        </div>
      )}

      {gameState === 'PAUSED' && (
        <PauseModal
          darkMode={darkMode}
          onResume={() => dispatch({ type: 'RESUME' })}
          onRetrySamePuzzle={handleRetryPuzzle}
          onOpenSettings={onOpenSettings}
          onGoToHome={handleExit}
        />
      )}

      {gameState === 'ROUND_SUMMARY' && lastRatingResult && (
        <SummaryModal
          puzzle={puzzle}
          level={level}
          completedLevel={completedLevel}
          elapsedSeconds={elapsedSeconds}
          timeLimitSeconds={timeLimitSeconds}
          hintsUsed={hintsUsed}
          errorsMade={errorsMade}
          calculatorUses={calculatorUses}
          mistakeCellKeys={mistakeCellKeys}
          lastRatingResult={lastRatingResult}
          darkMode={darkMode}
          mode={mode}
          starsEarned={starsEarned}
          starReason={starReason}
          onNextLevel={() => {
            if (onNextCustomAction && onNextCustomAction()) return;
            startPuzzleLevel(mode, lastRatingResult.newRating, level, overrideSize, true);
          }}
          onReturnHome={handleExit}
        />
      )}

      {gameState === 'TIME_UP' && (
        <TimeUpModal
          puzzle={puzzle}
          level={level}
          timeLimitSeconds={timeLimitSeconds}
          hintsUsed={hintsUsed}
          errorsMade={errorsMade}
          calculatorUses={calculatorUses}
          mistakeCellKeys={mistakeCellKeys}
          lastRatingResult={lastRatingResult}
          darkMode={darkMode}
          mode={mode}
          onRetrySamePuzzle={handleRetryPuzzle}
          onReturnHome={handleExit}
        />
      )}
    </>
  );
};
