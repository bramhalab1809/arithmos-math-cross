import React from 'react';
import { Pause } from '../../../icons';

interface PausedPlaceholderProps {
  darkMode: boolean;
}

export const PausedPlaceholder: React.FC<PausedPlaceholderProps> = ({ darkMode }) => {
  return (
    <div
      className={`w-full max-w-md max-h-full aspect-square rounded-3xl border flex items-center justify-center select-none ${
        darkMode
          ? 'bg-[#131B2E]/60 border-slate-800 text-slate-600'
          : 'bg-white/80 border-slate-200 text-slate-300'
      }`}
      aria-hidden="true"
    >
      <Pause className="w-16 h-16 opacity-40" />
    </div>
  );
};
