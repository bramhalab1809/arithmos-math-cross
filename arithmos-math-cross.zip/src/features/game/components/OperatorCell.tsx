import React from 'react';
import { MathOperator } from '../../../engine';

export function displayOperatorSymbol(op: MathOperator): string {
  switch (op) {
    case '+':
      return '+';
    case '-':
      return '−';
    case '*':
      return '×';
    case '/':
      return '÷';
  }
}

interface OperatorCellProps {
  symbol: string;
  lineStatus: 'incomplete' | 'valid' | 'invalid';
  isLineFocused: boolean;
  darkMode: boolean;
  fontSizeClass?: string;
}

export const OperatorCell = React.memo<OperatorCellProps>(function OperatorCell({
  symbol,
  lineStatus,
  isLineFocused,
  darkMode,
  fontSizeClass = 'text-xs sm:text-sm font-bold',
}) {
  return (
    <div
      className={`w-full h-full flex items-center justify-center font-mono select-none transition-colors ${fontSizeClass} ${
        symbol === '='
          ? lineStatus === 'valid'
            ? 'text-emerald-500 font-extrabold'
            : lineStatus === 'invalid'
            ? 'text-rose-500 font-extrabold'
            : darkMode
            ? 'text-amber-400 font-extrabold'
            : 'text-blue-600 font-extrabold'
          : isLineFocused
          ? darkMode
            ? 'text-amber-300 font-bold'
            : 'text-blue-600 font-bold'
          : darkMode
          ? 'text-slate-400'
          : 'text-slate-500'
      }`}
    >
      {symbol}
    </div>
  );
});
