import React from 'react';
import { MathOperator } from '../../../engine';

interface OperatorCellProps {
  symbol: string;
  axis: 'h' | 'v';
  lineStatus: 'incomplete' | 'valid' | 'invalid';
  isLineFocused: boolean;
  darkMode: boolean;
  fontSizeClass?: string;
}

export const OperatorCell: React.FC<OperatorCellProps> = React.memo(
  ({ symbol, lineStatus, isLineFocused, darkMode, fontSizeClass = 'text-base font-bold' }) => {
    const renderedSymbol = symbol === '||' ? '=' : symbol;

    if (!renderedSymbol) {
      return <div className="w-full h-full pointer-events-none select-none" aria-hidden="true" />;
    }

    const isEquals = renderedSymbol === '=';

    return (
      <div
        className={`w-full h-full flex items-center justify-center font-mono select-none transition-colors ${fontSizeClass} ${
          isEquals ? 'font-extrabold' : ''
        } ${
          lineStatus === 'valid'
            ? 'text-emerald-500 dark:text-emerald-400'
            : lineStatus === 'invalid'
            ? 'text-rose-500 dark:text-rose-400'
            : isEquals
            ? darkMode
              ? 'text-amber-400'
              : 'text-blue-600'
            : isLineFocused
            ? darkMode
              ? 'text-amber-300'
              : 'text-blue-700'
            : darkMode
            ? 'text-slate-400'
            : 'text-slate-600'
        }`}
        aria-hidden="true"
      >
        {renderedSymbol}
      </div>
    );
  }
);

export function displayOperatorSymbol(op: MathOperator): string {
  switch (op) {
    case '*':
      return '×';
    case '/':
      return '÷';
    case '-':
      return '−';
    default:
      return '+';
  }
}
