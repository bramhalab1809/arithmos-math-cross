import React from 'react';

interface IconButtonProps {
  icon: React.ReactNode;
  badge?: number | string | null;
  badgeColor?: 'amber' | 'emerald' | 'rose' | 'blue' | 'slate' | 'indigo';
  label: string;
  title: string;
  disabled?: boolean;
  darkMode: boolean;
  onClick: () => void;
  className?: string;
}

export const IconButton: React.FC<IconButtonProps> = ({
  icon,
  badge,
  badgeColor = 'amber',
  label,
  title,
  disabled = false,
  darkMode,
  onClick,
  className = '',
}) => {
  const badgeColors = {
    amber: darkMode ? 'bg-amber-500 text-slate-950' : 'bg-amber-500 text-white',
    emerald: darkMode ? 'bg-emerald-500 text-slate-950' : 'bg-emerald-600 text-white',
    rose: darkMode ? 'bg-rose-500 text-white' : 'bg-rose-500 text-white',
    blue: darkMode ? 'bg-blue-500 text-white' : 'bg-blue-600 text-white',
    slate: darkMode ? 'bg-slate-700 text-slate-200' : 'bg-slate-200 text-slate-700',
    indigo: darkMode ? 'bg-indigo-500 text-white' : 'bg-indigo-600 text-white',
  };

  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      aria-label={label}
      title={title}
      data-bird-perch={label ? `btn-${label.toLowerCase()}` : undefined}
      className={`relative w-12 h-12 min-w-[44px] min-h-[44px] rounded-xl flex items-center justify-center border transition-all duration-100 active:scale-95 focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 select-none ${
        disabled
          ? darkMode
            ? 'border-slate-800/40 bg-slate-900/30 text-slate-600 cursor-not-allowed opacity-40'
            : 'border-slate-200/50 bg-slate-100/50 text-slate-400 cursor-not-allowed opacity-40'
          : darkMode
          ? 'border-slate-800 bg-slate-900 text-slate-200 hover:bg-slate-800 hover:text-white cursor-pointer hover:border-slate-700'
          : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-100 hover:text-slate-900 cursor-pointer shadow-2xs hover:border-slate-300'
      } ${className}`}
    >
      <div className="w-5 h-5 flex items-center justify-center">{icon}</div>

      {badge !== undefined && badge !== null && (
        <span
          className={`absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] px-1 rounded-full text-[10px] font-mono font-bold flex items-center justify-center shadow-xs ${
            badgeColors[badgeColor]
          }`}
        >
          {badge}
        </span>
      )}
    </button>
  );
};
