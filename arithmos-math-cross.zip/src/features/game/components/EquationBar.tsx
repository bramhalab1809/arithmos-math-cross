import React, { useMemo } from 'react';
import { ArrowRight, ArrowDown } from '../../../icons';
import {
  MathCrosswordPuzzle,
  formatPuzzleEquationPreview,
  getPuzzleEquations,
} from '../../../engine';
import { GridPosition, StatusBanner } from '../state/gameTypes';

interface EquationBarProps {
  puzzle: MathCrosswordPuzzle;
  focusedPos: GridPosition | null;
  direction: 'row' | 'col';
  darkMode: boolean;
  statusBanner: StatusBanner | null;
  onSelectDirection: (dir: 'row' | 'col') => void;
  onDismissBanner: () => void;
}

export const EquationBar: React.FC<EquationBarProps> = ({
  puzzle,
  focusedPos,
  direction,
  darkMode,
  statusBanner,
  onSelectDirection,
  onDismissBanner,
}) => {
  const activeEquations = useMemo(() => {
    const pos = focusedPos || { row: 0, col: 0 };
    const r = Math.min(pos.row, puzzle.size - 1);
    const c = Math.min(pos.col, puzzle.size - 1);

    const equations = getPuzzleEquations(puzzle);
    const rowEqs = equations.filter((eq) => {
      const allPts = [...eq.operandCells, eq.resultCell];
      return allPts.some((p) => p.row === r && p.col === c) && eq.axis === 'row';
    });
    const colEqs = equations.filter((eq) => {
      const allPts = [...eq.operandCells, eq.resultCell];
      return allPts.some((p) => p.row === r && p.col === c) && eq.axis === 'col';
    });

    const primaryRow = rowEqs[0] || equations.find((eq) => eq.axis === 'row') || equations[0];
    const primaryCol = colEqs[0] || equations.find((eq) => eq.axis === 'col') || equations[0];

    const rowLabel = primaryRow?.label || `R${r + 1}`;
    const colLabel = primaryCol?.label || `C${c + 1}`;
    const rowString = primaryRow ? formatPuzzleEquationPreview(puzzle, primaryRow) : '';
    const colString = primaryCol ? formatPuzzleEquationPreview(puzzle, primaryCol) : '';

    return {
      rowLabel,
      colLabel,
      rowString,
      colString,
    };
  }, [focusedPos, puzzle]);

  return (
    <div className="w-full shrink-0 flex flex-col gap-1.5">
      {/* Dual Stacked Equation Inspector Card (~70px height) */}
      <div
        className={`w-full rounded-xl border p-1 sm:p-1.5 flex flex-col gap-1 text-xs font-mono tabular-nums select-none ${
          darkMode
            ? 'bg-[#111827] border-slate-800'
            : 'bg-white border-slate-200 shadow-2xs'
        }`}
      >
        {/* Row Equation Line */}
        <button
          type="button"
          onClick={() => onSelectDirection('row')}
          className={`w-full h-6 sm:h-7 px-2.5 rounded-lg flex items-center gap-2 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden whitespace-nowrap transition-colors cursor-pointer text-left ${
            direction === 'row'
              ? darkMode
                ? 'bg-blue-950/60 text-blue-300 font-semibold border border-blue-500/30'
                : 'bg-blue-50 text-blue-700 font-semibold border border-blue-200'
              : darkMode
              ? 'text-slate-400 hover:bg-slate-800/50 border border-transparent'
              : 'text-slate-600 hover:bg-slate-50 border border-transparent'
          }`}
          title="Focus Row traversal (D / Tab)"
        >
          <ArrowRight className="w-3.5 h-3.5 shrink-0" />
          <span className="shrink-0 font-bold">{activeEquations.rowLabel}:</span>
          <span className="tracking-wide">{activeEquations.rowString}</span>
        </button>

        {/* Column Equation Line */}
        <button
          type="button"
          onClick={() => onSelectDirection('col')}
          className={`w-full h-6 sm:h-7 px-2.5 rounded-lg flex items-center gap-2 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden whitespace-nowrap transition-colors cursor-pointer text-left ${
            direction === 'col'
              ? darkMode
                ? 'bg-emerald-950/60 text-emerald-300 font-semibold border border-emerald-500/30'
                : 'bg-emerald-50 text-emerald-700 font-semibold border border-emerald-200'
              : darkMode
              ? 'text-slate-400 hover:bg-slate-800/50 border border-transparent'
              : 'text-slate-600 hover:bg-slate-50 border border-transparent'
          }`}
          title="Focus Column traversal (D / Tab)"
        >
          <ArrowDown className="w-3.5 h-3.5 shrink-0" />
          <span className="shrink-0 font-bold">{activeEquations.colLabel}:</span>
          <span className="tracking-wide">{activeEquations.colString}</span>
        </button>
      </div>

      {/* Optional Status / Feedback Banner */}
      {statusBanner && (
        <div
          className={`w-full px-3 py-1.5 rounded-lg border text-xs font-mono flex items-center justify-between shrink-0 ${
            statusBanner.type === 'error'
              ? darkMode
                ? 'bg-red-950/60 border-red-500/40 text-red-300'
                : 'bg-red-50 border-red-200 text-red-800'
              : darkMode
              ? 'bg-amber-950/40 border-amber-500/30 text-amber-200'
              : 'bg-blue-50 border-blue-200 text-blue-800'
          }`}
        >
          <span className="truncate">{statusBanner.message}</span>
          <button
            type="button"
            onClick={onDismissBanner}
            className="ml-3 underline opacity-75 hover:opacity-100 cursor-pointer text-[11px] shrink-0"
          >
            Dismiss
          </button>
        </div>
      )}
    </div>
  );
};
