import React from 'react';
import { Clock, Zap } from '../../../icons';

export interface LevelTimingPillsProps {
  cellSolveSec?: Record<string, number>;
  rowSolveSec?: Record<string, number>;
  gridSize?: number;
  darkMode?: boolean;
}

export const LevelTimingPills: React.FC<LevelTimingPillsProps> = ({
  cellSolveSec,
  rowSolveSec,
  darkMode = false,
}) => {
  const rowEntries = Object.entries(rowSolveSec || {})
    .map(([rStr, sec]) => ({ r: Number(rStr), sec }))
    .sort((a, b) => a.r - b.r);

  const cellEntries = Object.entries(cellSolveSec || {})
    .map(([key, sec]) => {
      const parts = key.split(',').map(Number);
      return { r: parts[0], c: parts[1], sec };
    })
    .sort((a, b) => a.r - b.r || a.c - b.c);

  if (rowEntries.length === 0 && cellEntries.length === 0) return null;

  const minSec = cellEntries.length > 0 ? Math.min(...cellEntries.map((e) => e.sec)) : -1;

  return (
    <div className="w-full space-y-1.5 pt-1.5 border-t border-slate-200/60 dark:border-slate-800/60 text-left">
      {/* Row Completion Times */}
      {rowEntries.length > 0 && (
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] font-mono uppercase tracking-wider text-slate-500 dark:text-slate-400 font-semibold bg-slate-200/50 dark:bg-slate-800/50">
            <Clock className="w-3 h-3 text-slate-400 shrink-0" />
            Rows
          </span>
          {rowEntries.map(({ r, sec }) => (
            <span
              key={r}
              className={`inline-flex items-center px-1.5 py-0.5 rounded-md border text-[10px] font-mono tabular-nums ${
                darkMode
                  ? 'bg-slate-900/80 border-slate-800 text-slate-300'
                  : 'bg-slate-100 border-slate-200 text-slate-700'
              }`}
            >
              <span className="font-semibold text-slate-400 dark:text-slate-500 mr-1">
                R{r + 1}
              </span>
              {sec}s
            </span>
          ))}
        </div>
      )}

      {/* Per-Box Solve Times */}
      {cellEntries.length > 0 && (
        <div className="flex flex-wrap items-center gap-1 max-h-16 overflow-y-auto no-scrollbar">
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] font-mono uppercase tracking-wider text-slate-500 dark:text-slate-400 font-semibold bg-slate-200/50 dark:bg-slate-800/50">
            <Zap className="w-3 h-3 text-amber-500 shrink-0" />
            Cells
          </span>
          {cellEntries.map(({ r, c, sec }) => {
            const isFastest = sec === minSec && minSec > 0;
            let badgeStyle = darkMode
              ? 'bg-slate-900/80 border-slate-800 text-slate-300'
              : 'bg-slate-100 border-slate-200 text-slate-700';

            if (sec <= 4) {
              badgeStyle = darkMode
                ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-300'
                : 'bg-emerald-50 border-emerald-200 text-emerald-700';
            } else if (sec > 10) {
              badgeStyle = darkMode
                ? 'bg-amber-950/40 border-amber-800/60 text-amber-300'
                : 'bg-amber-50 border-amber-200 text-amber-700';
            }

            return (
              <span
                key={`${r},${c}`}
                className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md border text-[10px] font-mono tabular-nums ${badgeStyle}`}
                title={`Row ${r + 1}, Col ${c + 1}: ${sec}s`}
              >
                {isFastest && (
                  <Zap className="w-2.5 h-2.5 text-amber-400 fill-amber-400 shrink-0" />
                )}
                <span>R{r + 1}C{c + 1}:</span>
                <span className="font-bold">{sec}s</span>
              </span>
            );
          })}
        </div>
      )}
    </div>
  );
};
