import React from 'react';
import {
  Lightbulb,
  CheckCircle2,
  RotateCcw,
  Shuffle,
  Calculator,
} from '../../../icons';
import { GameMode, ModeControls } from '../../../storage/schema';
import { getModeRules } from '../state/modeRules';
import {
  MAX_CHECKS_PER_PUZZLE,
  MAX_HINTS_PER_PUZZLE,
} from '../state/gameTypes';
import { IconButton } from './IconButton';

interface BottomToolbarProps {
  mode: GameMode;
  hintsUsed: number;
  checksUsed: number;
  heartsLeft: number;
  calculatorUses: number;
  controls: ModeControls;
  darkMode: boolean;
  onOpenCalculator?: () => void;
  onTriggerHint: () => void;
  onValidateBoard: () => void;
  onRetrySamePuzzle: () => void;
  onSwapNewPuzzle: () => void;
}

export const BottomToolbar: React.FC<BottomToolbarProps> = ({
  mode,
  hintsUsed,
  checksUsed,
  heartsLeft,
  calculatorUses,
  controls,
  darkMode,
  onOpenCalculator,
  onTriggerHint,
  onValidateBoard,
  onRetrySamePuzzle,
  onSwapNewPuzzle,
}) => {
  const rules = getModeRules(mode);
  const hintsRemaining = Math.max(0, MAX_HINTS_PER_PUZZLE - hintsUsed);
  const checksRemaining = Math.max(0, MAX_CHECKS_PER_PUZZLE - checksUsed);

  const calcUsesRemaining =
    rules.calculatorLimit === Infinity
      ? Infinity
      : Math.max(0, rules.calculatorLimit - calculatorUses);

  const isCalcDisabled =
    rules.calculatorLimit !== Infinity && calcUsesRemaining <= 0;

  return (
    <div
      className="flex items-center justify-center gap-1.5 sm:gap-3 shrink-0 py-0.5"
      role="toolbar"
      aria-label="Puzzle actions"
    >
      {rules.hasHints && controls.hint && (
        <IconButton
          icon={<Lightbulb className="w-5 h-5 text-amber-500" />}
          badge={hintsRemaining}
          badgeColor="amber"
          label="Hint"
          title="Hint (H twice)"
          disabled={hintsRemaining <= 0}
          darkMode={darkMode}
          onClick={onTriggerHint}
        />
      )}

      {controls.calculator && onOpenCalculator && (
        <IconButton
          icon={<Calculator className="w-5 h-5 text-indigo-500" />}
          badge={rules.calculatorLimit === Infinity ? undefined : calcUsesRemaining}
          badgeColor="indigo"
          label="Calc"
          title={isCalcDisabled ? 'No calculator uses left' : 'Chain Calculator (K)'}
          disabled={isCalcDisabled}
          darkMode={darkMode}
          onClick={onOpenCalculator}
        />
      )}

      {controls.check && (
        <IconButton
          icon={<CheckCircle2 className="w-5 h-5 text-emerald-500" />}
          badge={rules.unlimitedChecks ? undefined : checksRemaining}
          badgeColor="emerald"
          label="Check"
          title={rules.unlimitedChecks ? 'Check solutions (C)' : 'Check (C twice)'}
          disabled={!rules.unlimitedChecks && checksRemaining <= 0}
          darkMode={darkMode}
          onClick={onValidateBoard}
        />
      )}

      {controls.retry && (
        <IconButton
          icon={<RotateCcw className="w-5 h-5" />}
          label="Retry"
          title="Retry same puzzle"
          darkMode={darkMode}
          onClick={onRetrySamePuzzle}
        />
      )}

      {controls.swap && (
        <IconButton
          icon={<Shuffle className="w-5 h-5 text-rose-500" />}
          badge={rules.unlimitedSwaps ? undefined : heartsLeft}
          badgeColor="rose"
          label="Swap"
          title={rules.hasHearts ? 'Swap for a new puzzle (costs 1 heart)' : 'Swap for a new puzzle'}
          disabled={rules.hasHearts && heartsLeft <= 0}
          darkMode={darkMode}
          onClick={onSwapNewPuzzle}
        />
      )}
    </div>
  );
};
