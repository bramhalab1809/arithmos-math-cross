import React from 'react';
import { GameMode, ModeControls } from '../../../storage/schema';
import { BottomToolbar } from './BottomToolbar';
import { Numpad } from './Numpad';

export interface ControlsColumnProps {
  eqBar: React.ReactNode;
  mode: GameMode;
  hintsUsed: number;
  checksUsed: number;
  heartsLeft: number;
  calculatorUses: number;
  controls: ModeControls;
  darkMode: boolean;
  canUndo: boolean;
  canRedo: boolean;
  showNumpad: boolean;
  onOpenCalculator: () => void;
  onTriggerHint: () => void;
  onValidateBoard: () => void;
  onRetrySamePuzzle: () => void;
  onSwapNewPuzzle: () => void;
  onNumpadPress: (digit: string) => void;
  onUndo: () => void;
  onRedo: () => void;
}

export const ControlsColumn: React.FC<ControlsColumnProps> = ({
  eqBar,
  mode,
  hintsUsed,
  checksUsed,
  heartsLeft,
  calculatorUses,
  controls,
  darkMode,
  canUndo,
  canRedo,
  showNumpad,
  onOpenCalculator,
  onTriggerHint,
  onValidateBoard,
  onRetrySamePuzzle,
  onSwapNewPuzzle,
  onNumpadPress,
  onUndo,
  onRedo,
}) => {
  return (
    <div className="w-full shrink-0 flex flex-col justify-center gap-2">
      <div className="hidden wide:block">{eqBar}</div>
      <BottomToolbar
        mode={mode}
        hintsUsed={hintsUsed}
        checksUsed={checksUsed}
        heartsLeft={heartsLeft}
        calculatorUses={calculatorUses}
        controls={controls}
        darkMode={darkMode}
        onOpenCalculator={onOpenCalculator}
        onTriggerHint={onTriggerHint}
        onValidateBoard={onValidateBoard}
        onRetrySamePuzzle={onRetrySamePuzzle}
        onSwapNewPuzzle={onSwapNewPuzzle}
      />
      {showNumpad && (
        <Numpad
          darkMode={darkMode}
          onPress={onNumpadPress}
          canUndo={controls.undoRedo && canUndo}
          canRedo={controls.undoRedo && canRedo}
          onUndo={onUndo}
          onRedo={onRedo}
        />
      )}
      {controls.keyHints && (
        <p className="hidden wide:block hide-short text-[11px] font-mono text-center text-slate-500 leading-tight max-w-[380px] mx-auto select-none mt-1">
          0–9 Digits · Arrows Move · Enter Next · K Calc · C Check · Ctrl+Z Undo
        </p>
      )}
    </div>
  );
};
