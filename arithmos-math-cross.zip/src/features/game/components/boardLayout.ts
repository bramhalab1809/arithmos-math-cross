import { MathCrosswordPuzzle, evaluateEquationStatus, getPuzzleEquations } from '../../../engine';

export function getMinCellSizeClass(_N: number): string {
  return 'min-w-0 min-h-0';
}

export function getCellFontSizeClass(N: number): string {
  if (N === 3) return 'text-xl sm:text-2xl font-bold';
  if (N === 4) return 'text-lg sm:text-xl font-bold';
  if (N === 5) return 'text-base sm:text-lg font-bold';
  if (N === 6) return 'text-sm sm:text-base font-semibold';
  return 'text-xs sm:text-sm font-semibold';
}

export interface BoardEquationStatuses {
  rowValid: ('incomplete' | 'valid' | 'invalid')[];
  colValid: ('incomplete' | 'valid' | 'invalid')[];
  cellStatus: ('incomplete' | 'valid' | 'invalid')[][];
  hConnectorStatus: ('incomplete' | 'valid' | 'invalid')[][];
  vConnectorStatus: ('incomplete' | 'valid' | 'invalid')[][];
}

function mergeStatus(
  prev: 'incomplete' | 'valid' | 'invalid',
  next: 'incomplete' | 'valid' | 'invalid'
): 'incomplete' | 'valid' | 'invalid' {
  if (prev === 'invalid' || next === 'invalid') return 'invalid';
  if (prev === 'valid' || next === 'valid') return 'valid';
  return 'incomplete';
}

export function computeBoardEquationStatuses(puzzle: MathCrosswordPuzzle): BoardEquationStatuses {
  const N = puzzle.size;
  const rowValid: ('incomplete' | 'valid' | 'invalid')[] = new Array(N).fill('incomplete');
  const colValid: ('incomplete' | 'valid' | 'invalid')[] = new Array(N).fill('incomplete');
  const cellStatus: ('incomplete' | 'valid' | 'invalid')[][] = Array.from({ length: N }, () => new Array(N).fill('incomplete'));
  const hConnectorStatus: ('incomplete' | 'valid' | 'invalid')[][] = Array.from({ length: N }, () => new Array(Math.max(0, N - 1)).fill('incomplete'));
  const vConnectorStatus: ('incomplete' | 'valid' | 'invalid')[][] = Array.from({ length: Math.max(0, N - 1) }, () => new Array(N).fill('incomplete'));

  const equations = getPuzzleEquations(puzzle);

  for (const eq of equations) {
    const status = evaluateEquationStatus(puzzle, eq);

    if (!puzzle.equations || puzzle.equations.length === 0) {
      if (eq.axis === 'row' && typeof eq.label === 'string' && eq.label.startsWith('R')) {
        const rIdx = parseInt(eq.label.slice(1), 10) - 1;
        if (rIdx >= 0 && rIdx < N) rowValid[rIdx] = status;
      } else if (eq.axis === 'col' && typeof eq.label === 'string' && eq.label.startsWith('C')) {
        const cIdx = parseInt(eq.label.slice(1), 10) - 1;
        if (cIdx >= 0 && cIdx < N) colValid[cIdx] = status;
      }
    }

    for (let i = 0; i < eq.operandCells.length - 1; i++) {
      const a = eq.operandCells[i];
      const b = eq.operandCells[i + 1];
      if (eq.axis === 'row' && a.row === b.row && Math.abs(a.col - b.col) === 1) {
        const cIdx = Math.min(a.col, b.col);
        if (hConnectorStatus[a.row] && hConnectorStatus[a.row][cIdx] !== undefined) {
          hConnectorStatus[a.row][cIdx] = mergeStatus(hConnectorStatus[a.row][cIdx], status);
        }
      } else if (eq.axis === 'col' && a.col === b.col && Math.abs(a.row - b.row) === 1) {
        const rIdx = Math.min(a.row, b.row);
        if (vConnectorStatus[rIdx] && vConnectorStatus[rIdx][a.col] !== undefined) {
          vConnectorStatus[rIdx][a.col] = mergeStatus(vConnectorStatus[rIdx][a.col], status);
        }
      }
    }

    if (eq.equalsConnector) {
      const { type, row, col } = eq.equalsConnector;
      if (type === 'h' && hConnectorStatus[row] && hConnectorStatus[row][col] !== undefined) {
        hConnectorStatus[row][col] = mergeStatus(hConnectorStatus[row][col], status);
      } else if (type === 'v' && vConnectorStatus[row] && vConnectorStatus[row][col] !== undefined) {
        vConnectorStatus[row][col] = mergeStatus(vConnectorStatus[row][col], status);
      }
    }

    const allPts = [...eq.operandCells, eq.resultCell];
    for (const p of allPts) {
      if (cellStatus[p.row] && cellStatus[p.row][p.col] !== undefined) {
        cellStatus[p.row][p.col] = mergeStatus(cellStatus[p.row][p.col], status);
      }
    }
  }

  return { rowValid, colValid, cellStatus, hConnectorStatus, vConnectorStatus };
}

export const computeLineStatuses = computeBoardEquationStatuses;
