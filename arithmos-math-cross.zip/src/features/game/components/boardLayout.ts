import { MathCrosswordPuzzle, evaluateEquationStatus, getPuzzleEquations } from '../../../engine';

export function getMinCellSizeClass(N: number): string {
  if (N <= 5) return 'min-w-[44px] min-h-[44px]';
  return 'min-w-[32px] min-h-[32px]';
}

export function getCellFontSizeClass(N: number): string {
  if (N === 3) return 'text-xl sm:text-2xl font-bold';
  if (N === 4) return 'text-lg sm:text-xl font-bold';
  if (N === 5) return 'text-base sm:text-lg font-bold';
  if (N === 6) return 'text-sm sm:text-base font-semibold';
  return 'text-xs sm:text-sm font-semibold';
}

export interface BoardEquationStatuses {
  rowValid: ('incomplete' | 'valid' | 'invalid')[];
  colValid: ('incomplete' | 'valid' | 'invalid')[];
  cellStatus: ('incomplete' | 'valid' | 'invalid')[][];
  hConnectorStatus: ('incomplete' | 'valid' | 'invalid')[][];
  vConnectorStatus: ('incomplete' | 'valid' | 'invalid')[][];
}

export function computeBoardEquationStatuses(puzzle: MathCrosswordPuzzle): BoardEquationStatuses {
  const N = puzzle.size;
  const rowValid: ('incomplete' | 'valid' | 'invalid')[] = new Array(N).fill('incomplete');
  const colValid: ('incomplete' | 'valid' | 'invalid')[] = new Array(N).fill('incomplete');
  const cellStatus: ('incomplete' | 'valid' | 'invalid')[][] = Array.from({ length: N }, () => new Array(N).fill('incomplete'));
  const hConnectorStatus: ('incomplete' | 'valid' | 'invalid')[][] = Array.from({ length: N }, () => new Array(Math.max(0, N - 1)).fill('incomplete'));
  const vConnectorStatus: ('incomplete' | 'valid' | 'invalid')[][] = Array.from({ length: Math.max(0, N - 1) }, () => new Array(N).fill('incomplete'));

  const equations = getPuzzleEquations(puzzle);

  for (const eq of equations) {
    const status = evaluateEquationStatus(puzzle, eq);

    if (eq.axis === 'row' && typeof eq.label === 'string' && eq.label.startsWith('R')) {
      const rIdx = parseInt(eq.label.slice(1), 10) - 1;
      if (rIdx >= 0 && rIdx < N) rowValid[rIdx] = status;
    } else if (eq.axis === 'col' && typeof eq.label === 'string' && eq.label.startsWith('C')) {
      const cIdx = parseInt(eq.label.slice(1), 10) - 1;
      if (cIdx >= 0 && cIdx < N) colValid[cIdx] = status;
    }

    if (eq.equalsConnector) {
      const { type, row, col } = eq.equalsConnector;
      if (type === 'h' && hConnectorStatus[row] && hConnectorStatus[row][col] !== undefined) {
        if (status === 'invalid' || (status === 'valid' && hConnectorStatus[row][col] !== 'invalid')) {
          hConnectorStatus[row][col] = status;
        }
      } else if (type === 'v' && vConnectorStatus[row] && vConnectorStatus[row][col] !== undefined) {
        if (status === 'invalid' || (status === 'valid' && vConnectorStatus[row][col] !== 'invalid')) {
          vConnectorStatus[row][col] = status;
        }
      }
    }

    const allPts = [...eq.operandCells, eq.resultCell];
    for (const p of allPts) {
      if (cellStatus[p.row] && cellStatus[p.row][p.col] !== undefined) {
        if (status === 'invalid') {
          cellStatus[p.row][p.col] = 'invalid';
        } else if (status === 'valid' && cellStatus[p.row][p.col] !== 'invalid') {
          cellStatus[p.row][p.col] = 'valid';
        }
      }
    }
  }

  return { rowValid, colValid, cellStatus, hConnectorStatus, vConnectorStatus };
}

export const computeLineStatuses = computeBoardEquationStatuses;
