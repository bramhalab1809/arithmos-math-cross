import { MathCrosswordPuzzle, MathOperator, isCompleteLineValid } from '../../../engine';

export function getMinCellSizeClass(N: number): string {
  if (N <= 5) return 'min-w-[44px] min-h-[44px]';
  return 'min-w-[32px] min-h-[32px]';
}

export function getCellFontSizeClass(N: number): string {
  if (N === 3) return 'text-xl sm:text-2xl font-bold';
  if (N === 4) return 'text-lg sm:text-xl font-bold';
  if (N === 5) return 'text-base sm:text-lg font-bold';
  if (N === 6) return 'text-sm sm:text-base font-semibold';
  return 'text-xs sm:text-sm font-semibold';
}

export function computeLineStatuses(puzzle: MathCrosswordPuzzle): {
  rowValid: ('incomplete' | 'valid' | 'invalid')[];
  colValid: ('incomplete' | 'valid' | 'invalid')[];
} {
  const N = puzzle.size;
  const rowValid: ('incomplete' | 'valid' | 'invalid')[] = new Array(N).fill('incomplete');
  const colValid: ('incomplete' | 'valid' | 'invalid')[] = new Array(N).fill('incomplete');

  for (let r = 0; r < N; r++) {
    const vals: number[] = [];
    let complete = true;
    for (let c = 0; c < N; c++) {
      const cell = puzzle.cells[r][c];
      if (!cell.isClue) {
        const trimmed = cell.userValue.trim();
        const solStr = String(cell.solution);
        if (trimmed !== '' && solStr.length > trimmed.length && solStr.startsWith(trimmed)) {
          complete = false;
          break;
        }
      }
      const raw = cell.isClue ? cell.solution : parseInt(cell.userValue, 10);
      if (!Number.isInteger(raw) || raw < 1) {
        complete = false;
        break;
      }
      vals.push(raw);
    }
    if (complete) {
      rowValid[r] = isCompleteLineValid(vals, puzzle.rowOps[r]) ? 'valid' : 'invalid';
    }
  }

  for (let c = 0; c < N; c++) {
    const vals: number[] = [];
    let complete = true;
    for (let r = 0; r < N; r++) {
      const cell = puzzle.cells[r][c];
      if (!cell.isClue) {
        const trimmed = cell.userValue.trim();
        const solStr = String(cell.solution);
        if (trimmed !== '' && solStr.length > trimmed.length && solStr.startsWith(trimmed)) {
          complete = false;
          break;
        }
      }
      const raw = cell.isClue ? cell.solution : parseInt(cell.userValue, 10);
      if (!Number.isInteger(raw) || raw < 1) {
        complete = false;
        break;
      }
      vals.push(raw);
    }
    if (complete) {
      const cOps: MathOperator[] = [];
      for (let r = 0; r < N - 2; r++) cOps.push(puzzle.colOps[r][c]);
      colValid[c] = isCompleteLineValid(vals, cOps) ? 'valid' : 'invalid';
    }
  }

  return { rowValid, colValid };
}
