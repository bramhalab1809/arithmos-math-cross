import React from 'react';
import { AlertTriangle, Clock } from '../../../icons';

export function formatTime(secs: number): string {
  const safe = Math.max(0, Math.floor(secs));
  const mins = Math.floor(safe / 60);
  const rem = safe % 60;
  return `${String(mins).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
}

interface TimerBarProps {
  elapsedSeconds: number;
  timeLimitSeconds: number;
  darkMode: boolean;
  hasTimer?: boolean;
}

export const TimerBar: React.FC<TimerBarProps> = ({
  elapsedSeconds,
  timeLimitSeconds,
  darkMode,
  hasTimer = true,
}) => {
  if (!hasTimer) {
    return (
      <div
        className={`px-3 py-1.5 rounded-lg border font-mono text-xs sm:text-sm font-semibold tabular-nums flex items-center gap-1.5 ${
          darkMode
            ? 'bg-slate-900 border-slate-800 text-slate-300'
            : 'bg-slate-100 border-slate-200 text-slate-700'
        }`}
        role="timer"
        aria-label={`Elapsed time ${formatTime(elapsedSeconds)}`}
      >
        <Clock className="w-3.5 h-3.5 opacity-70 shrink-0" />
        <span>{formatTime(elapsedSeconds)}</span>
      </div>
    );
  }

  const safeLimit = Math.max(1, timeLimitSeconds);
  const remainingSeconds = Math.max(0, safeLimit - elapsedSeconds);
  const ratioRemaining = Math.max(0, Math.min(1, remainingSeconds / safeLimit));
  const isUrgent = remainingSeconds <= Math.ceil(safeLimit * 0.2);

  return (
    <div
      data-bird-perch="timer-bar"
      data-remaining-seconds={remainingSeconds}
      className={`px-3 py-1.5 rounded-lg border font-mono text-xs sm:text-sm font-semibold tabular-nums flex items-center gap-2 transition-colors ${
        isUrgent
          ? darkMode
            ? 'bg-red-950/70 border-red-500/60 text-red-200'
            : 'bg-red-50 border-red-400 text-red-800'
          : darkMode
          ? 'bg-slate-900 border-slate-800 text-slate-200'
          : 'bg-slate-100 border-slate-200 text-slate-800'
      }`}
      role="timer"
      aria-label={`Time remaining ${formatTime(remainingSeconds)}${isUrgent ? ', low time warning' : ''}`}
    >
      {isUrgent ? (
        <AlertTriangle className="w-3.5 h-3.5 text-red-400 animate-pulse shrink-0" />
      ) : (
        <Clock className="w-3.5 h-3.5 opacity-70 shrink-0" />
      )}

      <span>{formatTime(remainingSeconds)}</span>

      {isUrgent && (
        <span
          className={`px-1.5 py-0.5 rounded text-[10px] font-bold tracking-wider uppercase animate-pulse ${
            darkMode ? 'bg-red-500/30 text-red-200' : 'bg-red-200 text-red-900'
          }`}
        >
          LOW TIME
        </span>
      )}

      <div
        className={`hidden md:block w-14 h-1.5 rounded-full overflow-hidden ${
          darkMode ? 'bg-slate-800' : 'bg-slate-300'
        }`}
        aria-hidden="true"
      >
        <div
          className={`h-full transition-all duration-300 ${
            isUrgent ? 'bg-red-500' : darkMode ? 'bg-amber-400' : 'bg-blue-600'
          }`}
          style={{ width: `${Math.round(ratioRemaining * 100)}%` }}
        />
      </div>
    </div>
  );
};
