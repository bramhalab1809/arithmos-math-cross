import React, { useLayoutEffect, useMemo } from 'react';
import { MathCrosswordPuzzle } from '../../../engine';
import { GridPosition } from '../state/gameTypes';
import { Cell } from './Cell';
import { OperatorCell, displayOperatorSymbol } from './OperatorCell';
import {
  computeBoardEquationStatuses,
  getCellFontSizeClass,
  getMinCellSizeClass,
} from './boardLayout';

interface BoardProps {
  puzzle: MathCrosswordPuzzle;
  focusedPos: GridPosition | null;
  darkMode: boolean;
  showOnboarding: boolean;
  onboardingStep: number;
  isCalculatorOpen?: boolean;
  inputRefs: React.MutableRefObject<(HTMLInputElement | null)[][]>;
  onFocusPos: (row: number, col: number) => void;
  onChangeValue: (row: number, col: number, value: string) => void;
  onKeyDownCell: (e: React.KeyboardEvent<HTMLInputElement>, row: number, col: number) => void;
}

export const Board: React.FC<BoardProps> = ({
  puzzle,
  focusedPos,
  darkMode,
  showOnboarding,
  onboardingStep,
  isCalculatorOpen = false,
  inputRefs,
  onFocusPos,
  onChangeValue,
  onKeyDownCell,
}) => {
  const N = puzzle.size;

  useLayoutEffect(() => {
    if (!isCalculatorOpen && focusedPos && inputRefs.current[focusedPos.row]?.[focusedPos.col]) {
      const el = inputRefs.current[focusedPos.row][focusedPos.col];
      if (el && document.activeElement !== el) {
        el.focus();
      }
    }
  }, [focusedPos, inputRefs, isCalculatorOpen]);

  const eqStatuses = useMemo(() => computeBoardEquationStatuses(puzzle), [puzzle]);
  const fontSizeClass = useMemo(() => getCellFontSizeClass(N), [N]);
  const minSizeClass = useMemo(() => getMinCellSizeClass(N), [N]);

  return (
    <div
      className={`w-[min(100cqw,100cqh)] h-[min(100cqw,100cqh)] aspect-square max-h-full max-w-full p-2 sm:p-3.5 rounded-2xl border transition-colors flex flex-col justify-between ${
        darkMode
          ? 'bg-[#131B2E] border-slate-800 shadow-xl shadow-black/40'
          : 'bg-white border-slate-200 shadow-md shadow-slate-200/50'
      }`}
    >
      {/* Top Column Coordinate Header (C1..CN) */}
      <div className="flex items-center justify-between min-h-0 w-full gap-1 mb-1">
        <div className="w-5 sm:w-6 shrink-0" aria-hidden="true" />
        {puzzle.cells[0].map((_, c) => {
          const isColFocused = focusedPos?.col === c;
          return (
            <React.Fragment key={`col-hdr-${c}`}>
              <div
                className={`flex-2 min-w-0 text-center font-mono text-[9px] sm:text-[11px] font-semibold select-none transition-colors ${
                  isColFocused
                    ? darkMode ? 'text-amber-400 font-bold' : 'text-blue-600 font-bold'
                    : darkMode ? 'text-slate-500' : 'text-slate-400'
                }`}
              >
                C{c + 1}
              </div>
              {c < N - 1 && <div className="flex-1 min-w-0" aria-hidden="true" />}
            </React.Fragment>
          );
        })}
      </div>

      {puzzle.cells.map((rowCells, r) => {
        const isRowFocused =
          focusedPos?.row === r &&
          (!showOnboarding || onboardingStep === 0 || onboardingStep === 2);
        const rowStatus = eqStatuses.rowValid[r] || 'incomplete';

        return (
          <React.Fragment key={`row-group-${r}`}>
            {/* Number + Horizontal Operator Row with Left Row Coordinate R1..RN */}
            <div className="flex items-center justify-between flex-2 min-h-0 w-full gap-1">
              <div
                className={`w-5 sm:w-6 shrink-0 flex items-center justify-center font-mono text-[9px] sm:text-[11px] font-semibold select-none transition-colors ${
                  isRowFocused
                    ? darkMode ? 'text-amber-400 font-bold' : 'text-blue-600 font-bold'
                    : darkMode ? 'text-slate-500' : 'text-slate-400'
                }`}
              >
                R{r + 1}
              </div>

              {rowCells.map((cell, c) => {
                const isFocused = focusedPos?.row === r && focusedPos?.col === c;
                const isColFocused =
                  focusedPos?.col === c &&
                  (!showOnboarding || onboardingStep === 1 || onboardingStep === 2);
                const isLineHighlighted = isRowFocused || isColFocused;
                const isResultCell = r === N - 1 || c === N - 1;
                const colStatus = eqStatuses.colValid[c] || 'incomplete';

                const cellEqStatus = eqStatuses.cellStatus[r]?.[c] || 'incomplete';
                const lineCompleteValid = cellEqStatus === 'valid' || rowStatus === 'valid' || colStatus === 'valid';
                const lineCompleteInvalid = cellEqStatus === 'invalid' || rowStatus === 'invalid' || colStatus === 'invalid';

                const hasRightOp = c < N - 1;
                let rightSymbol = '';
                if (puzzle.hConnectors && puzzle.hConnectors[r]) {
                  const raw = puzzle.hConnectors[r][c] ?? '';
                  rightSymbol = raw === '=' || raw === '' ? raw : displayOperatorSymbol(raw as any);
                } else {
                  rightSymbol = c < N - 2 ? displayOperatorSymbol(puzzle.rowOps[r][c]) : '=';
                }
                const rightStatus = eqStatuses.hConnectorStatus[r]?.[c] ?? rowStatus;

                return (
                  <React.Fragment key={`cell-${r}-${c}`}>
                    <div className="flex-2 min-w-0 h-full flex items-center justify-center">
                      <Cell
                        cell={cell}
                        row={r}
                        col={c}
                        fontSizeClass={fontSizeClass}
                        minSizeClass={minSizeClass}
                        darkMode={darkMode}
                        isFocused={isFocused}
                        isLineHighlighted={isLineHighlighted}
                        isResultCell={isResultCell}
                        lineCompleteValid={lineCompleteValid}
                        lineCompleteInvalid={lineCompleteInvalid}
                        isCalculatorOpen={isCalculatorOpen}
                        inputRefCallback={(el) => {
                          if (!inputRefs.current[r]) inputRefs.current[r] = [];
                          inputRefs.current[r][c] = el;
                        }}
                        onFocusPos={onFocusPos}
                        onChangeValue={onChangeValue}
                        onKeyDownCell={onKeyDownCell}
                      />
                    </div>

                    {hasRightOp && (
                      <div className="flex-1 min-w-0 h-full flex items-center justify-center">
                        <OperatorCell
                          symbol={rightSymbol}
                          axis="h"
                          lineStatus={rightStatus}
                          isLineFocused={isRowFocused}
                          darkMode={darkMode}
                          fontSizeClass={fontSizeClass}
                        />
                      </div>
                    )}
                  </React.Fragment>
                );
              })}
            </div>

            {/* Vertical Operator Connector Row between r and r + 1 */}
            {r < N - 1 && (
              <div className="flex items-center justify-between flex-1 min-h-0 w-full gap-1">
                <div className="w-5 sm:w-6 shrink-0" aria-hidden="true" />
                {rowCells.map((_, c) => {
                  const isColFocused =
                    focusedPos?.col === c &&
                    (!showOnboarding || onboardingStep === 1 || onboardingStep === 2);
                  const colStatus = eqStatuses.colValid[c] || 'incomplete';

                  let downSymbol = '';
                  if (puzzle.vConnectors && puzzle.vConnectors[r]) {
                    const raw = puzzle.vConnectors[r][c] ?? '';
                    downSymbol = raw === '=' || raw === '' ? raw : displayOperatorSymbol(raw as any);
                  } else {
                    downSymbol = r < N - 2 ? displayOperatorSymbol(puzzle.colOps[r][c]) : '=';
                  }
                  const downStatus = eqStatuses.vConnectorStatus[r]?.[c] ?? colStatus;

                  return (
                    <React.Fragment key={`vop-${r}-${c}`}>
                      <div className="flex-2 min-w-0 h-full flex items-center justify-center">
                        <OperatorCell
                          symbol={downSymbol}
                          axis="v"
                          lineStatus={downStatus}
                          isLineFocused={isColFocused}
                          darkMode={darkMode}
                          fontSizeClass={fontSizeClass}
                        />
                      </div>
                      {c < N - 1 && <div className="flex-1 min-w-0 h-full" aria-hidden="true" />}
                    </React.Fragment>
                  );
                })}
              </div>
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
};
