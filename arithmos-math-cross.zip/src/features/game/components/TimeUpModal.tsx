import React, { useEffect, useRef } from 'react';
import { AlertTriangle, Eye, EyeOff, Home, Lightbulb, RotateCcw, Timer, TrendingDown, X } from '../../../icons';
import { MathCrosswordPuzzle, RatingAdjustmentResult } from '../../../engine';
import { GameMode } from '../../../storage/schema';
import { formatTime } from './TimerBar';
import { LevelMiniAnalytics } from './LevelMiniAnalytics';

export interface TimeUpModalProps {
  puzzle: MathCrosswordPuzzle;
  level: number;
  timeLimitSeconds: number;
  hintsUsed: number;
  errorsMade: number;
  calculatorUses?: number;
  mistakeCellKeys?: string[];
  lastRatingResult: RatingAdjustmentResult | null;
  darkMode: boolean;
  mode?: GameMode;
  onRetrySamePuzzle: () => void;
  onReturnHome: () => void;
}

export const TimeUpModal: React.FC<TimeUpModalProps> = ({
  puzzle, level, timeLimitSeconds, hintsUsed, errorsMade,
  calculatorUses = 0, mistakeCellKeys = [], lastRatingResult,
  darkMode, mode = 'endless', onRetrySamePuzzle, onReturnHome,
}) => {
  const retryBtnRef = useRef<HTMLButtonElement>(null);
  const [isReviewingBoard, setIsReviewingBoard] = React.useState(false);
  const delta = lastRatingResult?.delta ?? -8;

  useEffect(() => {
    retryBtnRef.current?.focus();
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      e.preventDefault();
      onReturnHome();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      onRetrySamePuzzle();
    }
  };

  if (isReviewingBoard) {
    return (
      <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 px-3 w-full max-w-md pointer-events-auto">
        <div
          className={`flex items-center justify-between gap-2 px-4 py-2.5 rounded-2xl border shadow-2xl backdrop-blur-md ${
            darkMode
              ? 'bg-[#131B2E]/95 border-red-500/40 text-slate-100'
              : 'bg-white/95 border-red-500/40 text-slate-900'
          }`}
        >
          <div className="flex items-center gap-2 text-xs font-mono font-bold">
            <span className="text-red-400">Level {level} · Time Up</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsReviewingBoard(false)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border cursor-pointer ${
                darkMode
                  ? 'border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700'
                  : 'border-slate-200 bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <EyeOff className="w-3.5 h-3.5" /> Summary
            </button>
            <button
              type="button"
              onClick={onRetrySamePuzzle}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer ${
                darkMode
                  ? 'bg-amber-500 text-slate-950 hover:bg-amber-400'
                  : 'bg-blue-600 text-white hover:bg-blue-500'
              }`}
            >
              Retry <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 px-4"
      role="dialog"
      aria-modal="true"
      aria-label="Time up"
      tabIndex={-1}
      onKeyDown={handleKeyDown}
    >
      <div
        className={`w-full max-w-md max-h-[92dvh] overflow-y-auto no-scrollbar rounded-2xl border p-4 sm:p-5 shadow-2xl flex flex-col items-center text-center ${
          darkMode ? 'bg-[#131B2E] border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        <div
          className={`w-10 h-10 rounded-xl flex items-center justify-center mb-2 ${
            darkMode ? 'bg-red-500/15 text-red-400 border border-red-500/30' : 'bg-red-50 text-red-600 border border-red-200'
          }`}
        >
          <AlertTriangle className="w-5 h-5" />
        </div>

        <h2 className="font-display text-2xl font-bold tracking-tight mb-2">
          Level <span className="text-red-500 dark:text-red-400">{level}</span>{' '}
          <span className="text-base font-sans font-medium text-slate-400">· Time up</span>
        </h2>

        <div className="grid grid-cols-4 gap-1.5 sm:gap-2 w-full mb-1.5 font-mono text-xs tabular-nums">
          <div
            className={`py-1.5 px-2 rounded-xl border flex flex-col items-center justify-center gap-0.5 ${
              darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
            title={`Time limit: ${formatTime(timeLimitSeconds)}`}
          >
            <Timer className="w-3.5 h-3.5 text-slate-400" />
            <span className="font-bold">{formatTime(timeLimitSeconds)}</span>
          </div>

          <div
            className={`py-1.5 px-2 rounded-xl border flex flex-col items-center justify-center gap-0.5 ${
              darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
            title={`Hints used: ${hintsUsed}`}
          >
            <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-bold">{hintsUsed}</span>
          </div>

          <div
            className={`py-1.5 px-2 rounded-xl border flex flex-col items-center justify-center gap-0.5 ${
              darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
            title={`Mistakes made: ${errorsMade}`}
          >
            <X className="w-3.5 h-3.5 text-red-400" />
            <span className="font-bold">{errorsMade}</span>
          </div>

          <div
            className={`py-1.5 px-2 rounded-xl border flex flex-col items-center justify-center gap-0.5 ${
              darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
            title={`Rating delta: ${delta}`}
          >
            <TrendingDown className="w-3.5 h-3.5 text-red-400" />
            <span className="font-bold text-red-400">{delta}</span>
          </div>
        </div>

        <LevelMiniAnalytics
          puzzle={puzzle}
          mode={mode}
          won={false}
          elapsedSeconds={timeLimitSeconds}
          timeLimitSeconds={timeLimitSeconds}
          hintsUsed={hintsUsed}
          errorsMade={errorsMade}
          calculatorUses={calculatorUses}
          mistakeCellKeys={mistakeCellKeys}
          darkMode={darkMode}
        />

        <div className="flex items-center justify-center gap-4 mt-2.5">
          <button
            type="button"
            onClick={() => setIsReviewingBoard(true)}
            aria-label="Inspect Board"
            title="Inspect Board"
            className={`w-12 h-12 min-w-[48px] min-h-[48px] rounded-full flex items-center justify-center border transition-all cursor-pointer ${
              darkMode
                ? 'border-slate-800 bg-slate-900 text-amber-400 hover:bg-slate-800'
                : 'border-slate-200 bg-slate-100 text-blue-600 hover:bg-slate-200'
            }`}
          >
            <Eye className="w-5 h-5" />
          </button>

          <button
            ref={retryBtnRef}
            type="button"
            onClick={onRetrySamePuzzle}
            aria-label="Retry"
            title="Retry (Enter)"
            className={`w-12 h-12 min-w-[48px] min-h-[48px] rounded-full flex items-center justify-center transition-all cursor-pointer shadow-md ${
              darkMode
                ? 'bg-amber-500 text-slate-950 hover:bg-amber-400 ring-4 ring-amber-500/20'
                : 'bg-blue-600 text-white hover:bg-blue-500 ring-4 ring-blue-500/20'
            }`}
          >
            <RotateCcw className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={onReturnHome}
            aria-label="Home"
            title="Home (Esc)"
            className={`w-12 h-12 min-w-[48px] min-h-[48px] rounded-full flex items-center justify-center border transition-all cursor-pointer ${
              darkMode
                ? 'border-slate-800 bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-white'
                : 'border-slate-200 bg-slate-100 text-slate-700 hover:bg-slate-200 hover:text-slate-900'
            }`}
          >
            <Home className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
