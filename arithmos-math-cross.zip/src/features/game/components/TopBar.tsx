import React from 'react';
import { Flame, Grid, Infinity as InfinityIcon, Pause, ShieldCheck, Star, TrendingUp } from '../../../icons';
import { GameMode, ModeControls } from '../../../storage/schema';
import { MathCrosswordPuzzle } from '../../../engine';
import { countCollectedStarCells, countTotalStarCells } from '../state/starCells';
import { getModeRules } from '../state/modeRules';
import { Hearts } from './Hearts';
import { TimerBar, formatTime } from './TimerBar';

export { formatTime };

interface TopBarProps {
  mode: GameMode;
  level: number;
  elapsedSeconds: number;
  timeLimitSeconds: number;
  heartsLeft: number;
  darkMode: boolean;
  controls: ModeControls;
  onPause: () => void;
  rating?: number;
  gridSize?: number;
  tierName?: string;
  puzzle?: MathCrosswordPuzzle;
}

export const TopBar: React.FC<TopBarProps> = ({
  mode,
  level,
  elapsedSeconds,
  timeLimitSeconds,
  heartsLeft,
  darkMode,
  controls,
  onPause,
  rating,
  gridSize,
  tierName,
  puzzle,
}) => {
  const rules = getModeRules(mode);
  const collectedStars = puzzle ? countCollectedStarCells(puzzle) : 0;
  const totalStars = puzzle ? countTotalStarCells(puzzle) : 3;

  const renderModeIcon = () => {
    if (rules.hasStars) {
      return <Star className="w-4 h-4 text-amber-400 fill-amber-400" />;
    }
    if (!rules.hasTimer) {
      return <InfinityIcon className="w-4 h-4 text-emerald-500" />;
    }
    return <Flame className="w-4 h-4 text-amber-500" />;
  };

  return (
    <header
      className={`w-full h-11 short-h:h-11 sm:h-12 shrink-0 border-b px-3 sm:px-6 transition-colors flex items-center justify-between select-none ${
        darkMode
          ? 'bg-[#0F1624]/95 border-slate-800/80 text-slate-100'
          : 'bg-white/95 border-slate-200 text-slate-900'
      }`}
    >
      <div className="w-full max-w-7xl mx-auto flex items-center justify-between gap-2">
        {/* Left: Mode icon + Level N + optional Level Info chips */}
        <div className="flex items-center gap-2 min-w-0 flex-shrink overflow-hidden">
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <div
              className={`p-1.5 rounded-lg border flex items-center justify-center ${
                darkMode ? 'bg-slate-900 border-slate-800' : 'bg-slate-100 border-slate-200'
              }`}
              title={`${mode.charAt(0).toUpperCase() + mode.slice(1)} Mode`}
            >
              {renderModeIcon()}
            </div>
            <span className="font-mono text-xs sm:text-sm font-bold tracking-tight shrink-0">
              Level {level}
            </span>
            {rules.hasStars && (
              <div
                className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-mono font-bold border shrink-0 ${
                  darkMode
                    ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                    : 'bg-amber-50 border-amber-200 text-amber-800'
                }`}
                title={`Stars collected: ${collectedStars}/${totalStars}`}
              >
                <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                <span>{collectedStars}/{totalStars}</span>
              </div>
            )}
          </div>

          {/* Level Info Chips (up to 3) */}
          {controls.levelInfo && (
            <div className="flex items-center gap-1 sm:gap-1.5 min-w-0 flex-shrink whitespace-nowrap overflow-hidden">
              {/* Chip 1: Grid & Tier */}
              {gridSize && (
                <div
                  className={`hidden sm:flex short-h:hidden items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-mono font-medium border shrink-0 ${
                    darkMode
                      ? 'bg-slate-900/80 border-slate-800 text-slate-300'
                      : 'bg-slate-100 border-slate-200 text-slate-700'
                  }`}
                  title={`Grid: ${gridSize}×${gridSize}${tierName ? ` · Tier: ${tierName}` : ''}`}
                >
                  <Grid className="w-3 h-3 text-slate-400" />
                  <span>{gridSize}×{gridSize}</span>
                  {tierName && <span className="text-slate-400 font-normal">{tierName}</span>}
                </div>
              )}
              {gridSize && (
                <div
                  className={`flex sm:hidden short-h:hidden items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-mono font-medium border shrink-0 ${
                    darkMode
                      ? 'bg-slate-900/80 border-slate-800 text-slate-300'
                      : 'bg-slate-100 border-slate-200 text-slate-700'
                  }`}
                  title={`${gridSize}×${gridSize}${tierName ? ` · ${tierName}` : ''}`}
                >
                  <Grid className="w-2.5 h-2.5 text-slate-400" />
                  <span>{gridSize}×{gridSize}</span>
                </div>
              )}

              {/* Chip 2: Rating (screens >= 640px, hidden on short-h <480px) */}
              {rating !== undefined && (
                <div
                  className={`hidden sm:flex short-h:hidden items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-mono font-medium border shrink-0 ${
                    darkMode
                      ? 'bg-slate-900/80 border-slate-800 text-slate-300'
                      : 'bg-slate-100 border-slate-200 text-slate-700'
                  }`}
                  title={`Rating: ${rating}`}
                >
                  <TrendingUp className="w-3 h-3 text-emerald-400" />
                  <span>{rating}</span>
                </div>
              )}

              {/* Chip 3: Unique solution verified (ShieldCheck icon ONLY) */}
              <div
                className={`flex items-center justify-center p-1 rounded-full border shrink-0 ${
                  darkMode
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-600'
                }`}
                title="Unique solution verified"
                aria-label="Unique solution verified"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
              </div>
            </div>
          )}
        </div>

        {/* Right: Hearts, Countdown/Elapsed, Pause */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {rules.hasHearts && controls.hearts && (
            <Hearts heartsLeft={heartsLeft} darkMode={darkMode} />
          )}

          {controls.timer && (
            <TimerBar
              elapsedSeconds={elapsedSeconds}
              timeLimitSeconds={timeLimitSeconds}
              darkMode={darkMode}
              hasTimer={rules.hasTimer}
            />
          )}

          <button
            type="button"
            onClick={onPause}
            className={`p-1.5 sm:p-2 rounded-xl border transition-colors cursor-pointer ${
              darkMode
                ? 'border-slate-800 bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-white'
                : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-100'
            }`}
            title="Pause (Esc)"
            aria-label="Pause"
          >
            <Pause className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
