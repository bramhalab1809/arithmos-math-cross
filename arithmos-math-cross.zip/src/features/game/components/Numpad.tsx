import React from 'react';
import { Delete, Undo2, Redo2 } from '../../../icons';

interface NumpadProps {
  darkMode: boolean;
  onPress: (digit: string) => void;
  canUndo?: boolean;
  canRedo?: boolean;
  onUndo?: () => void;
  onRedo?: () => void;
}

const ROW_ONE = ['1', '2', '3', '4', '5'];
const ROW_TWO = ['6', '7', '8', '9', '0'];

export const Numpad: React.FC<NumpadProps> = ({
  darkMode,
  onPress,
  canUndo = false,
  canRedo = false,
  onUndo,
  onRedo,
}) => {
  const baseKeyClass = `h-9 sm:h-11 min-h-[36px] sm:min-h-[44px] rounded-xl flex items-center justify-center border font-mono text-base font-bold select-none transition-all duration-100 active:scale-95 focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-blue-500`;

  const numberKeyClass = `${baseKeyClass} cursor-pointer ${
    darkMode
      ? 'bg-slate-900 border-slate-800 text-slate-200 hover:bg-slate-800 hover:border-slate-700'
      : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-100 shadow-2xs hover:border-slate-300'
  }`;

  const preventBlur = (e: React.SyntheticEvent) => e.preventDefault();

  return (
    <div
      className="grid grid-cols-5 gap-1 sm:gap-2 max-w-[340px] sm:max-w-[380px] w-full mx-auto select-none shrink-0"
      role="group"
      aria-label="Numeric keypad"
    >
      {ROW_ONE.map((digit) => (
        <button
          key={digit}
          type="button"
          onPointerDown={preventBlur}
          onMouseDown={preventBlur}
          onClick={() => onPress(digit)}
          className={numberKeyClass}
          aria-label={`Digit ${digit}`}
        >
          {digit}
        </button>
      ))}

      {ROW_TWO.map((digit) => (
        <button
          key={digit}
          type="button"
          onPointerDown={preventBlur}
          onMouseDown={preventBlur}
          onClick={() => onPress(digit)}
          className={numberKeyClass}
          aria-label={`Digit ${digit}`}
        >
          {digit}
        </button>
      ))}

      <button
        type="button"
        disabled={!canUndo}
        onPointerDown={preventBlur}
        onMouseDown={preventBlur}
        onClick={onUndo}
        className={`${baseKeyClass} ${
          !canUndo
            ? 'opacity-35 cursor-not-allowed border-transparent text-slate-500'
            : darkMode
            ? 'bg-slate-900 border-slate-800 text-slate-200 hover:bg-slate-800 cursor-pointer'
            : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-100 shadow-2xs cursor-pointer'
        }`}
        title="Undo (Ctrl+Z)"
        aria-label="Undo"
      >
        <Undo2 className="w-4 h-4" />
      </button>

      <button
        type="button"
        disabled={!canRedo}
        onPointerDown={preventBlur}
        onMouseDown={preventBlur}
        onClick={onRedo}
        className={`${baseKeyClass} ${
          !canRedo
            ? 'opacity-35 cursor-not-allowed border-transparent text-slate-500'
            : darkMode
            ? 'bg-slate-900 border-slate-800 text-slate-200 hover:bg-slate-800 cursor-pointer'
            : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-100 shadow-2xs cursor-pointer'
        }`}
        title="Redo (Ctrl+Shift+Z / Ctrl+Y)"
        aria-label="Redo"
      >
        <Redo2 className="w-4 h-4" />
      </button>

      <button
        type="button"
        onPointerDown={preventBlur}
        onMouseDown={preventBlur}
        onClick={() => onPress('BACKSPACE')}
        className={`col-span-3 ${baseKeyClass} cursor-pointer ${
          darkMode
            ? 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100 shadow-2xs'
        }`}
        title="Erase cell value (Backspace / 0)"
        aria-label="Erase"
      >
        <Delete className="w-4 h-4" />
      </button>
    </div>
  );
};
