import React from 'react';
import { MathCrosswordPuzzle, MathOperator } from '../../../engine';
import { GameMode } from '../../../storage/schema';
import { loadHistory } from '../../../storage/history';
import { getModeRules } from '../state/modeRules';
import { computeOperatorExposure, computeOperatorMistakes } from '../hooks/usePuzzleTelemetry';
import { formatTime } from './TimerBar';
import { LevelTimingPills } from './LevelTimingPills';
import { AlertTriangle, Calculator, Check, Lightbulb, Sparkles, Star, Timer, Trophy, X } from '../../../icons';

export interface LevelMiniAnalyticsProps {
  puzzle: MathCrosswordPuzzle;
  mode: GameMode;
  won: boolean;
  elapsedSeconds: number;
  timeLimitSeconds: number;
  hintsUsed: number;
  errorsMade: number;
  calculatorUses: number;
  mistakeCellKeys: string[];
  darkMode: boolean;
  cellSolveSec?: Record<string, number>;
  rowSolveSec?: Record<string, number>;
}

const OP_SYMBOLS: Record<MathOperator, string> = {
  '+': '+',
  '-': '−',
  '*': '×',
  '/': '÷',
};

export const LevelMiniAnalytics: React.FC<LevelMiniAnalyticsProps> = ({
  puzzle,
  mode,
  won,
  elapsedSeconds,
  timeLimitSeconds,
  hintsUsed,
  errorsMade,
  calculatorUses,
  mistakeCellKeys,
  darkMode,
  cellSolveSec,
  rowSolveSec,
}) => {
  const rules = getModeRules(mode);
  const timePct = Math.min(100, Math.round((elapsedSeconds / Math.max(1, timeLimitSeconds)) * 100));

  const exposure = computeOperatorExposure(puzzle);
  const mistakes = computeOperatorMistakes(puzzle, mistakeCellKeys);
  const activeOps = (['+', '-', '*', '/'] as MathOperator[]).filter((op) => exposure[op] > 0);

  // Fallback timing lookup if not directly passed
  const latestHist = typeof window !== 'undefined' ? loadHistory()[0] : undefined;
  const timingCells = cellSolveSec || (latestHist?.level === puzzle.level ? latestHist.cellSolveSec : undefined);
  const timingRows = rowSolveSec || (latestHist?.level === puzzle.level ? latestHist.rowSolveSec : undefined);

  // Micro-badges
  const isFlawless = won && errorsMade === 0 && hintsUsed === 0;
  const historyForGrid = typeof window !== 'undefined'
    ? loadHistory().filter((h) => h.gridSize === puzzle.size && h.won && h.mode === mode)
    : [];
  const isNewBest = won && historyForGrid.length > 0 && elapsedSeconds <= Math.min(...historyForGrid.map((h) => h.elapsedSeconds));

  // Star mode board stars
  const starCellsTotal = puzzle.cells.flat().filter((c) => c.hasStar).length;
  const starCellsSolved = puzzle.cells.flat().filter((c) => c.hasStar && (won || parseInt(c.userValue, 10) === c.solution)).length;

  const starChecks = [
    { icon: Timer, label: '≤60%', pass: elapsedSeconds <= 0.6 * timeLimitSeconds },
    { icon: Lightbulb, label: '0', pass: hintsUsed === 0 },
    { icon: AlertTriangle, label: '≤1', pass: errorsMade <= 1 },
    { icon: Calculator, label: '0', pass: calculatorUses === 0 },
  ];

  return (
    <div className="w-full space-y-1.5 my-0.5 pt-2 border-t border-slate-200/80 dark:border-slate-800/80">
      {/* Time vs Limit Bar */}
      {rules.hasTimer && (
        <div className="w-full space-y-1">
          <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 dark:text-slate-400 tabular-nums">
            <span className="flex items-center gap-1 font-sans">
              <Timer className="w-3 h-3 text-slate-400" />
              Pace
            </span>
            <span>
              {formatTime(elapsedSeconds)} / {formatTime(timeLimitSeconds)} ({timePct}%)
            </span>
          </div>
          <div className="relative w-full h-1.5 rounded-full overflow-hidden bg-slate-200 dark:bg-slate-800">
            <div
              className={`h-full rounded-full transition-all ${
                won ? (mode === 'star' && timePct <= 60 ? 'bg-amber-400' : 'bg-emerald-500') : 'bg-red-500'
              }`}
              style={{ width: `${timePct}%` }}
            />
            {mode === 'star' && (
              <>
                <div
                  className="absolute top-0 bottom-0 left-[60%] w-[1px] bg-amber-400/80 dark:bg-amber-500"
                  title="60% (3-Star)"
                />
                <div
                  className="absolute top-0 bottom-0 left-[85%] w-[1px] bg-slate-400/80 dark:bg-slate-600"
                  title="85% (2-Star)"
                />
              </>
            )}
          </div>
        </div>
      )}

      {/* Micro-Badges & Operator Accuracy Pills on one flex-wrap row (Only when won) */}
      {won && (isFlawless || isNewBest || activeOps.length > 0) && (
        <div className="flex items-center justify-center gap-1.5 flex-wrap w-full text-[10px] font-mono">
          {isFlawless && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full border bg-emerald-500/10 border-emerald-500/30 text-emerald-500 dark:text-emerald-400 font-semibold">
              <Sparkles className="w-2.5 h-2.5" /> Flawless
            </span>
          )}
          {isNewBest && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full border bg-amber-500/10 border-amber-500/30 text-amber-600 dark:text-amber-400 font-semibold">
              <Trophy className="w-2.5 h-2.5" /> New Best ({puzzle.size}×{puzzle.size})
            </span>
          )}
          {activeOps.map((op) => {
            const errs = mistakes[op] || 0;
            return (
              <div
                key={op}
                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg border text-xs font-mono font-semibold tabular-nums ${
                  errs === 0
                    ? darkMode
                      ? 'bg-slate-900/80 border-slate-800 text-slate-200'
                      : 'bg-slate-50 border-slate-200 text-slate-800'
                    : darkMode
                    ? 'bg-rose-950/30 border-rose-900/50 text-rose-300'
                    : 'bg-rose-50 border-rose-200 text-rose-700'
                }`}
              >
                <span className="font-bold">{OP_SYMBOLS[op]}</span>
                {errs === 0 ? (
                  <Check className="w-3 h-3 text-emerald-500" />
                ) : (
                  <span className="text-red-500 font-bold inline-flex items-center gap-0.5">{errs}<X className="w-2.5 h-2.5" /></span>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Per-Cell & Per-Row Timing Breakdown */}
      <LevelTimingPills
        cellSolveSec={timingCells}
        rowSolveSec={timingRows}
        gridSize={puzzle.size}
        darkMode={darkMode}
      />

      {/* Star Mode 3-Star Checklist Pills */}
      {mode === 'star' && won && (
        <div className="grid grid-cols-4 gap-1.5 w-full">
          {starChecks.map((check, idx) => (
            <div
              key={idx}
              className={`flex items-center justify-center gap-1 py-1 px-1 rounded-lg border text-[11px] font-mono tabular-nums ${
                check.pass
                  ? darkMode
                    ? 'bg-emerald-950/30 border-emerald-800/50 text-emerald-300'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-700'
                  : darkMode
                  ? 'bg-rose-950/20 border-rose-900/40 text-rose-400'
                  : 'bg-rose-50 border-rose-200 text-rose-600'
              }`}
            >
              <check.icon className="w-3 h-3 shrink-0" />
              <span className="font-semibold">{check.label}</span>
              {check.pass ? (
                <Check className="w-2.5 h-2.5 text-emerald-500 shrink-0" />
              ) : (
                <X className="w-2.5 h-2.5 text-rose-400 shrink-0" />
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
