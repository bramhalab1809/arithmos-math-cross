import React from 'react';
import { Home, Play, RotateCcw, Settings } from '../../../icons';

interface PauseModalProps {
  darkMode: boolean;
  onResume: () => void;
  onRetrySamePuzzle: () => void;
  onOpenSettings: () => void;
  onGoToHome: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  darkMode,
  onResume,
  onRetrySamePuzzle,
  onOpenSettings,
  onGoToHome,
}) => {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 px-4 select-none"
      role="dialog"
      aria-modal="true"
      aria-label="Paused"
    >
      <div
        className={`w-full max-w-xs rounded-3xl border p-6 shadow-2xl flex flex-col items-center gap-5 ${
          darkMode
            ? 'bg-[#131B2E] border-slate-800 text-slate-100'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        <h2 className="text-sm font-bold tracking-widest uppercase opacity-75">
          Paused
        </h2>

        <div className="grid grid-cols-4 gap-2.5 w-full">
          {/* Resume */}
          <button
            type="button"
            onClick={onResume}
            className={`h-16 rounded-2xl flex flex-col items-center justify-center transition-all cursor-pointer shadow-md ${
              darkMode
                ? 'bg-amber-500 text-slate-950 hover:bg-amber-400 active:scale-95'
                : 'bg-blue-600 text-white hover:bg-blue-500 active:scale-95'
            }`}
            title="Resume (Esc)"
            aria-label="Resume"
          >
            <Play className="w-5 h-5 fill-current" />
            <span className="text-[10px] font-semibold mt-1">Resume</span>
          </button>

          {/* Retry */}
          <button
            type="button"
            onClick={onRetrySamePuzzle}
            className={`h-16 rounded-2xl border flex flex-col items-center justify-center transition-all cursor-pointer ${
              darkMode
                ? 'border-slate-700 bg-slate-900 text-slate-200 hover:bg-slate-800 active:scale-95'
                : 'border-slate-200 bg-slate-100 text-slate-700 hover:bg-slate-200 active:scale-95'
            }`}
            title="Retry same puzzle"
            aria-label="Retry same puzzle"
          >
            <RotateCcw className="w-5 h-5" />
            <span className="text-[10px] font-semibold mt-1">Retry</span>
          </button>

          {/* Settings */}
          <button
            type="button"
            onClick={onOpenSettings}
            className={`h-16 rounded-2xl border flex flex-col items-center justify-center transition-all cursor-pointer ${
              darkMode
                ? 'border-slate-700 bg-slate-900 text-slate-200 hover:bg-slate-800 active:scale-95'
                : 'border-slate-200 bg-slate-100 text-slate-700 hover:bg-slate-200 active:scale-95'
            }`}
            title="Settings"
            aria-label="Settings"
          >
            <Settings className="w-5 h-5" />
            <span className="text-[10px] font-semibold mt-1">Settings</span>
          </button>

          {/* Home */}
          <button
            type="button"
            onClick={onGoToHome}
            className={`h-16 rounded-2xl border flex flex-col items-center justify-center transition-all cursor-pointer ${
              darkMode
                ? 'border-slate-700 bg-slate-900 text-slate-200 hover:bg-slate-800 active:scale-95'
                : 'border-slate-200 bg-slate-100 text-slate-700 hover:bg-slate-200 active:scale-95'
            }`}
            title="Home"
            aria-label="Home"
          >
            <Home className="w-5 h-5" />
            <span className="text-[10px] font-semibold mt-1">Home</span>
          </button>
        </div>
      </div>
    </div>
  );
};
