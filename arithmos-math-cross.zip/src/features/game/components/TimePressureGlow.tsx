import React from 'react';

interface TimePressureGlowProps {
  remainingSeconds: number;
  isActive: boolean;
}

export const TimePressureGlow: React.FC<TimePressureGlowProps> = ({
  remainingSeconds,
  isActive,
}) => {
  if (!isActive || remainingSeconds > 30 || remainingSeconds <= 0) {
    return null;
  }

  let pulseClass = 'time-glow-slow';
  if (remainingSeconds <= 5) {
    pulseClass = 'time-glow-fast';
  } else if (remainingSeconds <= 10) {
    pulseClass = 'time-glow-medium';
  }

  return (
    <div
      className={`fixed inset-0 pointer-events-none z-30 time-glow-overlay ${pulseClass}`}
      aria-hidden="true"
    />
  );
};
