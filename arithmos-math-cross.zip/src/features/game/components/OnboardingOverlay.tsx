import React from 'react';
import { ArrowRight, ArrowDown, Check, X } from '../../../icons';
import { MathCrosswordPuzzle, formatLinearEquationString } from '../../../engine';

interface OnboardingOverlayProps {
  puzzle: MathCrosswordPuzzle;
  targetPos: { row: number; col: number };
  step: number; // 0: Row highlight, 1: Col highlight, 2: Intersection solve
  darkMode: boolean;
  onNextStep: () => void;
  onDismiss: () => void;
  onApplyTutorialDigit: (digit: string) => void;
}

export const OnboardingOverlay: React.FC<OnboardingOverlayProps> = ({
  puzzle,
  targetPos,
  step,
  darkMode,
  onNextStep,
  onDismiss,
  onApplyTutorialDigit,
}) => {
  const { row, col } = targetPos;
  const targetCell = puzzle.cells[row]?.[col];
  if (!targetCell) return null;

  const rowValues = puzzle.cells[row].map((c, idx) =>
    idx === col ? '?' : c.isClue ? c.solution : c.userValue || '?'
  );
  const rowEqText = formatLinearEquationString(rowValues, puzzle.rowOps[row]);

  const colOpsForCol = puzzle.colOps.map((r) => r[col]);
  const colValues = puzzle.cells.map((r, idx) =>
    idx === row ? '?' : r[col].isClue ? r[col].solution : r[col].userValue || '?'
  );
  const colEqText = formatLinearEquationString(colValues, colOpsForCol);

  return (
    <div
      className={`w-full max-w-2xl mx-auto mb-2 shrink-0 rounded-xl border px-3 py-2 transition-all duration-150 ${
        darkMode
          ? 'bg-slate-900/95 border-amber-500/40 text-slate-100 shadow-lg shadow-black/40'
          : 'bg-white border-blue-500/40 text-slate-900 shadow-md shadow-slate-200/70'
      }`}
      role="region"
      aria-label="Interactive Level 1 Guide"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2.5 min-w-0">
          <div
            className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 font-mono text-xs font-bold ${
              step === 0
                ? darkMode
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'bg-blue-50 text-blue-700 border border-blue-200'
                : step === 1
                ? darkMode
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                : darkMode
                ? 'bg-amber-500 text-slate-950'
                : 'bg-blue-600 text-white'
            }`}
          >
            {step === 0 ? (
              <ArrowRight className="w-3.5 h-3.5" />
            ) : step === 1 ? (
              <ArrowDown className="w-3.5 h-3.5" />
            ) : (
              <span>{targetCell.solution}</span>
            )}
          </div>

          <div className="text-left min-w-0">
            <div className="flex items-center gap-1.5 text-[11px] font-mono">
              <span className={darkMode ? 'text-amber-400 font-semibold' : 'text-blue-600 font-semibold'}>
                Guide ({step + 1}/3)
              </span>
              <span className={darkMode ? 'text-slate-600' : 'text-slate-300'}>·</span>
              <span className="text-slate-500 truncate">
                {step === 0
                  ? `Row ${row + 1} (Left→Right)`
                  : step === 1
                  ? `Col ${col + 1} (Top→Bottom)`
                  : `Row ${row + 1} ∩ Col ${col + 1}`}
              </span>
            </div>

            <p className="text-xs font-medium truncate">
              {step === 0 && (
                <>
                  Row {row + 1}: <span className="font-mono font-bold">{rowEqText}</span>
                </>
              )}
              {step === 1 && (
                <>
                  Col {col + 1}: <span className="font-mono font-bold">{colEqText}</span>
                </>
              )}
              {step === 2 && (
                <>
                  Intersect. Enter{' '}
                  <span className="font-mono font-bold underline">{targetCell.solution}</span>.
                </>
              )}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 self-end sm:self-center shrink-0">
          {step < 2 ? (
            <button
              type="button"
              onClick={onNextStep}
              className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
                darkMode
                  ? 'bg-amber-500 text-slate-950 hover:bg-amber-400'
                  : 'bg-blue-600 text-white hover:bg-blue-500'
              }`}
            >
              <span>Next</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                onApplyTutorialDigit(String(targetCell.solution));
                onDismiss();
              }}
              className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
                darkMode
                  ? 'bg-emerald-500 text-slate-950 hover:bg-emerald-400'
                  : 'bg-emerald-600 text-white hover:bg-emerald-500'
              }`}
            >
              <Check className="w-3 h-3" />
              <span>Fill {targetCell.solution}</span>
            </button>
          )}

          <button
            type="button"
            onClick={onDismiss}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-200 cursor-pointer"
            aria-label="Dismiss guide"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
