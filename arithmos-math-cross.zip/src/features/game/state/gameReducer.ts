import {
  GameAction,
  GameSessionState,
  MAX_HEARTS_PER_LEVEL,
  MAX_HISTORY_LENGTH,
} from './gameTypes';
import { createInitialGameSessionState, resumeSessionState } from './sessionHelpers';
import { applyUndo, applyRedo } from './historyHelpers';
import { getModeRules } from './modeRules';

export { createInitialGameSessionState };

export function gameReducer(state: GameSessionState, action: GameAction): GameSessionState {
  switch (action.type) {
    case 'START_PUZZLE':
      return {
        ...state,
        mode: action.mode !== undefined ? action.mode : state.mode,
        rating: action.rating !== undefined ? action.rating : state.rating,
        level: action.level !== undefined ? action.level : state.level,
        completedLevel: null,
        overrideSize: action.overrideSize !== undefined ? action.overrideSize : state.overrideSize,
        puzzle: action.puzzle,
        elapsedSeconds: 0,
        timeLimitSeconds: action.timeLimitSeconds,
        hintsUsed: 0,
        checksUsed: 0,
        calculatorUses: 0,
        heartsLeft: action.resetHearts !== false ? MAX_HEARTS_PER_LEVEL : state.heartsLeft,
        errorsMade: 0,
        mistakeCellKeys: [],
        retriesCount: 0,
        history: { past: [], future: [] },
        statusBanner: null,
        lastRatingResult: null,
        starsEarned: undefined,
        starReason: undefined,
        direction: action.direction ?? 'row',
        focusedPos: action.firstCell,
        showOnboarding: action.showOnboarding,
        onboardingStep: action.showOnboarding ? 0 : state.onboardingStep,
        isGenerating: false,
        gameState: 'PLAYING',
      };

    case 'RESUME_SAVED_SESSION':
      return resumeSessionState(state, action.session, 'PLAYING');

    case 'RETRY_SAME_PUZZLE': {
      const clearedCells = state.puzzle.cells.map((r) => r.map((c) => (c.isClue || c.isHinted ? { ...c, isError: false } : { ...c, userValue: '', isError: false })));
      return {
        ...state,
        puzzle: { ...state.puzzle, cells: clearedCells },
        elapsedSeconds: 0,
        errorsMade: 0,
        mistakeCellKeys: [],
        retriesCount: state.retriesCount + 1,
        history: { past: [], future: [] },
        statusBanner: null,
        lastRatingResult: null,
        direction: action.direction ?? state.direction,
        focusedPos: action.firstCell,
        gameState: 'PLAYING',
      };
    }

    case 'SWAP_NEW_PUZZLE': {
      const rules = getModeRules(state.mode);
      if (rules.hasHearts && state.heartsLeft <= 0) return state;
      return {
        ...state,
        heartsLeft: rules.hasHearts ? Math.max(0, state.heartsLeft - 1) : state.heartsLeft,
        puzzle: action.puzzle,
        timeLimitSeconds: action.timeLimitSeconds,
        elapsedSeconds: 0,
        hintsUsed: 0,
        checksUsed: 0,
        calculatorUses: 0,
        mistakeCellKeys: [],
        history: { past: [], future: [] },
        statusBanner: null,
        lastRatingResult: null,
        direction: action.direction ?? 'row',
        focusedPos: action.firstCell,
        isGenerating: false,
        gameState: 'PLAYING',
      };
    }

    case 'CONSUME_CALCULATOR_USE':
      return { ...state, calculatorUses: state.calculatorUses + 1 };

    case 'SET_CELL_VALUE': {
      const nextHistory = action.edit
        ? {
            past: [...state.history.past, action.edit].slice(-MAX_HISTORY_LENGTH),
            future: [],
          }
        : state.history;

      return {
        ...state,
        puzzle: action.puzzle,
        history: nextHistory,
        statusBanner: null,
        showOnboarding: action.dismissOnboarding ? false : state.showOnboarding,
        direction: action.nextDirection ?? state.direction,
        focusedPos: action.nextFocus ?? state.focusedPos,
        errorsMade: action.errorsAdded ? state.errorsMade + action.errorsAdded : state.errorsMade,
        mistakeCellKeys: action.mistakeCellKeys ?? state.mistakeCellKeys,
      };
    }

    case 'UNDO':
      return applyUndo(state);

    case 'REDO':
      return applyRedo(state);

    case 'APPLY_HINT': {
      const filteredPast = state.history.past.filter(
        (e) => !action.puzzle.cells[e.row]?.[e.col]?.isHinted
      );
      const filteredFuture = state.history.future.filter(
        (e) => !action.puzzle.cells[e.row]?.[e.col]?.isHinted
      );

      return {
        ...state,
        puzzle: action.puzzle,
        hintsUsed: action.hintsUsed,
        history: { past: filteredPast, future: filteredFuture },
        statusBanner: action.banner,
        focusedPos: action.nextFocus ?? state.focusedPos,
      };
    }

    case 'VALIDATE_BOARD':
      return {
        ...state,
        puzzle: action.puzzle,
        checksUsed: action.checksUsed,
        errorsMade: state.errorsMade + action.errorsAdded,
        mistakeCellKeys: action.mistakeCellKeys,
        statusBanner: action.banner,
      };

    case 'SET_FOCUS':
      if (state.focusedPos?.row === action.pos?.row && state.focusedPos?.col === action.pos?.col) return state;
      return { ...state, focusedPos: action.pos };
    case 'SET_DIRECTION':
      return { ...state, direction: action.direction };
    case 'TOGGLE_DIRECTION':
      return { ...state, direction: state.direction === 'row' ? 'col' : 'row' };

    case 'TICK': {
      if (state.gameState !== 'PLAYING') return state;
      const step = action.seconds ?? 1;
      const rules = getModeRules(state.mode);
      const nextElapsed = rules.hasTimer
        ? Math.min(state.timeLimitSeconds, state.elapsedSeconds + step)
        : state.elapsedSeconds + step;
      return {
        ...state,
        elapsedSeconds: nextElapsed,
      };
    }

    case 'PAUSE':
      return state.gameState === 'PLAYING' ? { ...state, gameState: 'PAUSED' } : state;
    case 'RESUME':
      return state.gameState === 'PAUSED' ? { ...state, gameState: 'PLAYING' } : state;
    case 'TOGGLE_PAUSE':
      if (state.gameState !== 'PLAYING' && state.gameState !== 'PAUSED') return state;
      return { ...state, gameState: state.gameState === 'PLAYING' ? 'PAUSED' : 'PLAYING' };

    case 'WIN':
      return {
        ...state,
        puzzle: action.puzzle,
        hintsUsed: action.hintsUsed,
        statusBanner: null,
        lastRatingResult: action.ratingResult,
        rating: action.ratingResult.newRating,
        completedLevel: state.level,
        level: state.level + 1,
        starsEarned: action.starsEarned,
        starReason: action.starReason,
        showOnboarding: false,
        gameState: 'ROUND_SUMMARY',
      };

    case 'TIME_UP':
      return {
        ...state,
        rating: action.ratingResult.newRating,
        lastRatingResult: action.ratingResult,
        statusBanner: null,
        showOnboarding: false,
        gameState: 'TIME_UP',
        errorsMade: action.errorsMade ?? state.errorsMade,
        mistakeCellKeys: action.mistakeCellKeys ?? state.mistakeCellKeys,
      };

    case 'GO_TO_TITLE':
      return { ...state, gameState: 'TITLE_MENU', isGenerating: false };
    case 'SET_OVERRIDE_SIZE':
      return { ...state, overrideSize: action.size };
    case 'TOGGLE_DARK':
      return { ...state, darkMode: !state.darkMode };
    case 'TOGGLE_MUTE':
      return { ...state, muted: action.muted };
    case 'SET_BANNER':
      return { ...state, statusBanner: action.banner };
    case 'TOGGLE_ONBOARDING':
      return { ...state, showOnboarding: !state.showOnboarding, onboardingStep: 0 };
    case 'ONBOARDING_NEXT':
      return { ...state, onboardingStep: Math.min(2, state.onboardingStep + 1) };
    case 'ONBOARDING_DISMISS':
      return { ...state, showOnboarding: false };
    case 'GENERATING':
      return { ...state, isGenerating: true };
    case 'SET_GENERATING':
      return { ...state, isGenerating: action.isGenerating };
    default:
      return state;
  }
}
