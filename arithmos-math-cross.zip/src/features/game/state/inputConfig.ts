/**
 * Global input configuration.
 * P4 settings sheet can toggle these preferences.
 */
export const AUTO_ADVANCE_ENABLED = true;
