import { GameSessionState, MAX_HISTORY_LENGTH } from './gameTypes';

export function applyUndo(state: GameSessionState): GameSessionState {
  if (state.gameState !== 'PLAYING') return state;
  let editIndex = -1;
  for (let i = state.history.past.length - 1; i >= 0; i--) {
    const e = state.history.past[i];
    if (!state.puzzle.cells[e.row]?.[e.col]?.isHinted) {
      editIndex = i;
      break;
    }
  }
  if (editIndex === -1) return state;

  const lastEdit = state.history.past[editIndex];
  const nextPast = state.history.past.filter(
    (e, idx) => idx !== editIndex && !state.puzzle.cells[e.row]?.[e.col]?.isHinted
  );
  const nextFuture = [
    lastEdit,
    ...state.history.future.filter((e) => !state.puzzle.cells[e.row]?.[e.col]?.isHinted),
  ].slice(0, MAX_HISTORY_LENGTH);

  const nextCells = state.puzzle.cells.map((rArr, r) =>
    rArr.map((cell, c) =>
      r === lastEdit.row && c === lastEdit.col ? { ...cell, userValue: lastEdit.prev, isError: false } : cell
    )
  );

  return {
    ...state,
    puzzle: { ...state.puzzle, cells: nextCells },
    history: { past: nextPast, future: nextFuture },
    focusedPos: { row: lastEdit.row, col: lastEdit.col },
  };
}

export function applyRedo(state: GameSessionState): GameSessionState {
  if (state.gameState !== 'PLAYING') return state;
  let editIndex = -1;
  for (let i = 0; i < state.history.future.length; i++) {
    const e = state.history.future[i];
    if (!state.puzzle.cells[e.row]?.[e.col]?.isHinted) {
      editIndex = i;
      break;
    }
  }
  if (editIndex === -1) return state;

  const nextEdit = state.history.future[editIndex];
  const nextFuture = state.history.future.filter(
    (e, idx) => idx !== editIndex && !state.puzzle.cells[e.row]?.[e.col]?.isHinted
  );
  const nextPast = [
    ...state.history.past.filter((e) => !state.puzzle.cells[e.row]?.[e.col]?.isHinted),
    nextEdit,
  ].slice(-MAX_HISTORY_LENGTH);

  const nextCells = state.puzzle.cells.map((rArr, r) =>
    rArr.map((cell, c) =>
      r === nextEdit.row && c === nextEdit.col ? { ...cell, userValue: nextEdit.next, isError: false } : cell
    )
  );

  return {
    ...state,
    puzzle: { ...state.puzzle, cells: nextCells },
    history: { past: nextPast, future: nextFuture },
    focusedPos: { row: nextEdit.row, col: nextEdit.col },
  };
}
