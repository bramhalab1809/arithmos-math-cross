import {
  calculateRatingAdjustment,
  calculateStars,
  scaleRatingDelta,
  scaleRatingGain,
  MathCrosswordPuzzle,
  RatingAdjustmentResult,
} from '../../../engine';
import { saveState } from '../../../storage/storage';
import { updateModeSlotOnWin, updateModeSlotOnLoss } from '../../../storage/modes';
import { appendHistory } from '../../../storage/history';
import { recordLevelMapWin } from '../../../storage/levelMap';
import { getActiveMistakeId, markMistakeRepaired, setActiveMistakeId } from '../../../storage/mistakes';
import { getActiveLabContext, recordLabLevelWin } from '../../../storage/packs';
import { GameMode } from '../../../storage/schema';
import { clearSession, sessionKeyFor } from '../../../storage/sessionStorage';
import { syncStorageToNativeDb } from '../../../storage/nativeBridge';
import { getModeRules } from './modeRules';
import { isBoardCompletelySolved } from './winCheck';
import { countCollectedStarCells } from './starCells';
import { GameAction, GameSessionState, MAX_HEARTS_PER_LEVEL } from './gameTypes';

export interface WinOutcomeInput {
  mode: GameMode;
  ratingBefore: number;
  level: number;
  overrideSize: number | null;
  gridSize: number;
  elapsedSeconds: number;
  timeLimitSeconds: number;
  hintsUsed: number;
  calculatorUses?: number;
  mistakes: number;
  ratingResult: RatingAdjustmentResult;
  starsEarned?: 1 | 2 | 3;
  starReason?: string;
  easeNext?: boolean;
  puzzle?: MathCrosswordPuzzle;
  telemetry?: Partial<import('../../../storage/history').HistoryRecord>;
}

export function recordWinOutcome(input: WinOutcomeInput) {
  let starsEarned = input.starsEarned;
  let starReason = input.starReason;

  const rules = getModeRules(input.mode);
  if (rules.hasStars && !starsEarned) {
    const res = calculateStars({
      hintsUsed: input.hintsUsed,
      mistakes: input.mistakes,
      elapsedSeconds: input.elapsedSeconds,
      timeLimitSeconds: input.timeLimitSeconds,
      calculatorUses: input.calculatorUses,
    });
    const boardStars = input.puzzle ? countCollectedStarCells(input.puzzle) : 3;
    starsEarned = Math.max(1, Math.min(res.stars, boardStars)) as 1 | 2 | 3;
    starReason = res.reason;
  }

  const activeMistake = getActiveMistakeId();
  if (activeMistake) {
    markMistakeRepaired(activeMistake, input.elapsedSeconds);
    setActiveMistakeId(null);
  } else if (input.mode === 'lab') {
    const labCtx = getActiveLabContext();
    if (labCtx) recordLabLevelWin(labCtx.packId, labCtx.levelIndex, input.elapsedSeconds);
  } else if (input.mode === 'endless' || input.mode === 'star' || input.mode === 'practice') {
    recordLevelMapWin(input.mode, input.overrideSize, input.level, input.elapsedSeconds, starsEarned);
    saveState((prev) =>
      updateModeSlotOnWin(
        prev,
        input.mode,
        input.overrideSize,
        input.ratingResult.newRating,
        starsEarned,
        input.easeNext,
        input.level
      )
    );
  }

  appendHistory({
    mode: input.mode,
    gridSize: input.gridSize,
    level: input.level,
    ratingBefore: input.ratingBefore,
    ratingAfter: input.ratingResult.newRating,
    ratingDelta: input.ratingResult.delta,
    won: true,
    stars: starsEarned,
    elapsedSeconds: input.elapsedSeconds,
    timeLimitSeconds: input.timeLimitSeconds,
    hintsUsed: input.hintsUsed,
    calculatorUses: input.calculatorUses,
    mistakes: input.mistakes,
    starReason,
    relief: input.puzzle?.flow?.relief,
    domino: input.puzzle?.flow?.domino,
    firstMoves: input.puzzle?.flow?.firstMoves,
    easeApplied: input.puzzle?.flow?.easeApplied,
    paced: input.puzzle?.flow?.paced,
    ...input.telemetry,
  });
  void syncStorageToNativeDb();

  return { starsEarned, starReason };
}

export function checkAndHandleVictory(
  state: GameSessionState,
  updatedPuzzle: MathCrosswordPuzzle,
  currentHints: number,
  currentErrors: number,
  dispatch: (action: GameAction) => void,
  telemetry?: Partial<import('../../../storage/history').HistoryRecord>
): boolean {
  if (!isBoardCompletelySolved(updatedPuzzle)) return false;
  clearSession(sessionKeyFor(state.mode, state.overrideSize));

  const rules = getModeRules(state.mode);
  let starsEarned: (1 | 2 | 3) | undefined;
  let starReason: string | undefined;

  if (rules.hasStars) {
    const res = calculateStars({
      hintsUsed: currentHints,
      mistakes: currentErrors,
      elapsedSeconds: state.elapsedSeconds,
      timeLimitSeconds: state.timeLimitSeconds,
      calculatorUses: state.calculatorUses,
    });
    const boardStars = countCollectedStarCells(updatedPuzzle);
    starsEarned = Math.max(1, Math.min(res.stars, boardStars)) as 1 | 2 | 3;
    starReason = res.reason;
  }

  const rawRatingAdj = calculateRatingAdjustment(
    state.rating,
    state.elapsedSeconds,
    state.timeLimitSeconds,
    currentHints,
    currentErrors
  );

  let delta = rules.hasTimer ? rawRatingAdj.delta : Math.max(0, rawRatingAdj.delta);
  if (delta > 0) {
    delta = scaleRatingGain(delta);
    delta = state.mode === 'star' && starsEarned ? Math.min(25, scaleRatingDelta(delta, starsEarned)) : Math.min(20, delta);
  }

  const ratingAdj: RatingAdjustmentResult = {
    ...rawRatingAdj,
    delta,
    newRating: state.rating + delta,
    performanceLabel: !rules.hasTimer && rawRatingAdj.delta <= 0 ? 'Practice Complete' : rawRatingAdj.performanceLabel,
  };

  const heartsUsed = rules.hasHearts ? Math.max(0, MAX_HEARTS_PER_LEVEL - state.heartsLeft) : 0;
  const easeNext = currentHints >= 2 || heartsUsed >= 2;

  recordWinOutcome({
    mode: state.mode, ratingBefore: state.rating, level: state.level, overrideSize: state.overrideSize,
    gridSize: updatedPuzzle.size, elapsedSeconds: state.elapsedSeconds, timeLimitSeconds: state.timeLimitSeconds,
    hintsUsed: currentHints, calculatorUses: state.calculatorUses, mistakes: currentErrors,
    ratingResult: ratingAdj, starsEarned, starReason, easeNext, puzzle: updatedPuzzle, telemetry,
  });

  dispatch({
    type: 'WIN', puzzle: updatedPuzzle, hintsUsed: currentHints,
    ratingResult: ratingAdj, starsEarned, starReason,
  });
  return true;
}

export interface LossOutcomeInput {
  mode: GameMode;
  ratingBefore: number;
  level: number;
  overrideSize: number | null;
  gridSize: number;
  timeLimitSeconds: number;
  hintsUsed: number;
  mistakes: number;
  ratingResult: RatingAdjustmentResult;
  puzzle?: MathCrosswordPuzzle;
  telemetry?: Partial<import('../../../storage/history').HistoryRecord>;
}

export function recordLossOutcome(input: LossOutcomeInput) {
  clearSession(sessionKeyFor(input.mode, input.overrideSize));
  saveState((prev) => updateModeSlotOnLoss(prev, input.mode, input.overrideSize, input.ratingResult.newRating, true));
  appendHistory({
    mode: input.mode, gridSize: input.gridSize, level: input.level,
    ratingBefore: input.ratingBefore, ratingAfter: input.ratingResult.newRating, ratingDelta: input.ratingResult.delta,
    won: false, elapsedSeconds: input.timeLimitSeconds, timeLimitSeconds: input.timeLimitSeconds,
    hintsUsed: input.hintsUsed, mistakes: input.mistakes,
    relief: input.puzzle?.flow?.relief, domino: input.puzzle?.flow?.domino,
    firstMoves: input.puzzle?.flow?.firstMoves, easeApplied: input.puzzle?.flow?.easeApplied,
    paced: input.puzzle?.flow?.paced, ...input.telemetry,
  });
  void syncStorageToNativeDb();
}
