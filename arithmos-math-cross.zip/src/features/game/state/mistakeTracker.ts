import { MathCrosswordPuzzle, MathOperator, isCompleteLineValid } from '../../../engine';

export interface MistakeResult {
  newKeys: string[];
  addedCount: number;
}

export function isPartialMultiDigitPrefix(_cell: { isClue: boolean; userValue: string; solution: number }): boolean {
  return false;
}

function isRowFilled(puzzle: MathCrosswordPuzzle, r: number): boolean {
  return puzzle.cells[r].every((c) => {
    const v = c.isClue ? c.solution : parseInt(c.userValue, 10);
    return Number.isInteger(v) && v >= 1;
  });
}

function isColFilled(puzzle: MathCrosswordPuzzle, c: number): boolean {
  return puzzle.cells.every((row) => {
    const cell = row[c];
    const v = cell.isClue ? cell.solution : parseInt(cell.userValue, 10);
    return Number.isInteger(v) && v >= 1;
  });
}

export function collectLineMistakes(
  puzzle: MathCrosswordPuzzle,
  row: number,
  col: number,
  existingKeys: string[]
): MistakeResult {
  const keysSet = new Set(existingKeys);
  const initialSize = keysSet.size;
  const N = puzzle.size;

  if (isRowFilled(puzzle, row)) {
    const vals = puzzle.cells[row].map((c) => (c.isClue ? c.solution : parseInt(c.userValue, 10)));
    if (!isCompleteLineValid(vals, puzzle.rowOps[row])) {
      for (let c = 0; c < N; c++) {
        const cell = puzzle.cells[row][c];
        const trimmed = cell.userValue.trim();
        if (!cell.isClue && trimmed !== '') {
          keysSet.add(`${row},${c}:${trimmed}`);
        }
      }
    }
  }

  if (isColFilled(puzzle, col)) {
    const vals = puzzle.cells.map((r) => (r[col].isClue ? r[col].solution : parseInt(r[col].userValue, 10)));
    const cOps: MathOperator[] = [];
    for (let r = 0; r < N - 2; r++) cOps.push(puzzle.colOps[r][col]);
    if (!isCompleteLineValid(vals, cOps)) {
      for (let r = 0; r < N; r++) {
        const cell = puzzle.cells[r][col];
        const trimmed = cell.userValue.trim();
        if (!cell.isClue && trimmed !== '') {
          keysSet.add(`${r},${col}:${trimmed}`);
        }
      }
    }
  }

  const newKeys = Array.from(keysSet);
  return { newKeys, addedCount: newKeys.length - initialSize };
}

export function collectSingleCellMistake(
  _puzzle: MathCrosswordPuzzle,
  _row: number,
  _col: number,
  existingKeys: string[]
): MistakeResult {
  return { newKeys: existingKeys, addedCount: 0 };
}

export function collectAllBoardMistakes(
  puzzle: MathCrosswordPuzzle,
  existingKeys: string[]
): MistakeResult {
  const keysSet = new Set(existingKeys);
  const initialSize = keysSet.size;
  const N = puzzle.size;

  for (let r = 0; r < N; r++) {
    if (isRowFilled(puzzle, r)) {
      const vals = puzzle.cells[r].map((c) => (c.isClue ? c.solution : parseInt(c.userValue, 10)));
      if (!isCompleteLineValid(vals, puzzle.rowOps[r])) {
        for (let c = 0; c < N; c++) {
          const cell = puzzle.cells[r][c];
          if (!cell.isClue && cell.userValue.trim() !== '') {
            keysSet.add(`${r},${c}:${cell.userValue.trim()}`);
          }
        }
      }
    }
  }

  for (let c = 0; c < N; c++) {
    if (isColFilled(puzzle, c)) {
      const vals = puzzle.cells.map((r) => (r[c].isClue ? r[c].solution : parseInt(r[c].userValue, 10)));
      const cOps: MathOperator[] = [];
      for (let r = 0; r < N - 2; r++) cOps.push(puzzle.colOps[r][c]);
      if (!isCompleteLineValid(vals, cOps)) {
        for (let r = 0; r < N; r++) {
          const cell = puzzle.cells[r][c];
          if (!cell.isClue && cell.userValue.trim() !== '') {
            keysSet.add(`${r},${c}:${cell.userValue.trim()}`);
          }
        }
      }
    }
  }

  const newKeys = Array.from(keysSet);
  return { newKeys, addedCount: newKeys.length - initialSize };
}
