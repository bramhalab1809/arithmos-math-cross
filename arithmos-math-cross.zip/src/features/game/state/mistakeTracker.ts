import {
  MathCrosswordPuzzle,
  evaluateEquationStatus,
  getPuzzleEquations,
  isCellAwaitingMoreDigits,
} from '../../../engine';

export interface MistakeResult {
  newKeys: string[];
  addedCount: number;
}

export function isPartialMultiDigitPrefix(
  cell: { isClue: boolean; userValue: string; solution: number },
  puzzle?: MathCrosswordPuzzle,
  row?: number,
  col?: number
): boolean {
  if (cell.isClue) return false;
  const trimmed = cell.userValue.trim();
  if (trimmed === '' || trimmed.length >= 3) return false;
  const solStr = String(cell.solution);
  if (solStr.length > trimmed.length && solStr.startsWith(trimmed)) return true;
  if (puzzle && row !== undefined && col !== undefined) {
    return isCellAwaitingMoreDigits(puzzle, row, col);
  }
  return false;
}

export function collectLineMistakes(
  puzzle: MathCrosswordPuzzle,
  row: number,
  col: number,
  existingKeys: string[]
): MistakeResult {
  if (isCellAwaitingMoreDigits(puzzle, row, col)) {
    return { newKeys: existingKeys, addedCount: 0 };
  }

  const keysSet = new Set(existingKeys);
  const initialSize = keysSet.size;
  const equations = getPuzzleEquations(puzzle);

  for (const eq of equations) {
    const allPts = [...eq.operandCells, eq.resultCell];
    const touchesCell = allPts.some((p) => p.row === row && p.col === col);
    if (!touchesCell) continue;

    if (evaluateEquationStatus(puzzle, eq) === 'invalid') {
      for (const p of allPts) {
        const cell = puzzle.cells[p.row]?.[p.col];
        if (cell && !cell.isVoid && !cell.isClue && cell.userValue.trim() !== '') {
          keysSet.add(`${p.row},${p.col}:${cell.userValue.trim()}`);
        }
      }
    }
  }

  const newKeys = Array.from(keysSet);
  return { newKeys, addedCount: newKeys.length - initialSize };
}

export function collectSingleCellMistake(
  _puzzle: MathCrosswordPuzzle,
  _row: number,
  _col: number,
  existingKeys: string[]
): MistakeResult {
  return { newKeys: existingKeys, addedCount: 0 };
}

export function collectAllBoardMistakes(
  puzzle: MathCrosswordPuzzle,
  existingKeys: string[]
): MistakeResult {
  const keysSet = new Set(existingKeys);
  const initialSize = keysSet.size;
  const equations = getPuzzleEquations(puzzle);

  for (const eq of equations) {
    if (evaluateEquationStatus(puzzle, eq) === 'invalid') {
      const allPts = [...eq.operandCells, eq.resultCell];
      for (const p of allPts) {
        const cell = puzzle.cells[p.row]?.[p.col];
        if (cell && !cell.isVoid && !cell.isClue && cell.userValue.trim() !== '') {
          keysSet.add(`${p.row},${p.col}:${cell.userValue.trim()}`);
        }
      }
    }
  }

  const newKeys = Array.from(keysSet);
  return { newKeys, addedCount: newKeys.length - initialSize };
}
