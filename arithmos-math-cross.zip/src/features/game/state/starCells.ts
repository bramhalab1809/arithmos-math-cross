import { CellData, MathCrosswordPuzzle, MathOperator, isCompleteLineValid } from '../../../engine';

export function isStarCellCollected(
  cell: CellData,
  puzzle?: MathCrosswordPuzzle,
  row?: number,
  col?: number
): boolean {
  if (!cell.hasStar || cell.isHinted) return false;
  const trimmed = cell.userValue.trim();
  if (trimmed === '') return false;
  const val = parseInt(trimmed, 10);
  if (!Number.isInteger(val) || val < 1) return false;
  if (val === cell.solution) return true;

  if (puzzle && typeof row === 'number' && typeof col === 'number') {
    const N = puzzle.size;
    const rVals = puzzle.cells[row].map((c) => (c.isClue ? c.solution : parseInt(c.userValue, 10)));
    if (rVals.every((v) => Number.isInteger(v) && v >= 1) && isCompleteLineValid(rVals, puzzle.rowOps[row])) {
      return true;
    }

    const cVals = puzzle.cells.map((rArr) => (rArr[col].isClue ? rArr[col].solution : parseInt(rArr[col].userValue, 10)));
    const cOps: MathOperator[] = [];
    for (let r = 0; r < N - 2; r++) cOps.push(puzzle.colOps[r][col]);
    if (cVals.every((v) => Number.isInteger(v) && v >= 1) && isCompleteLineValid(cVals, cOps)) {
      return true;
    }
  }
  return false;
}

export function countCollectedStarCells(puzzle: MathCrosswordPuzzle): number {
  let count = 0;
  puzzle.cells.forEach((row, r) => {
    row.forEach((cell, c) => {
      if (isStarCellCollected(cell, puzzle, r, c)) count++;
    });
  });
  return count;
}

export function countTotalStarCells(puzzle: MathCrosswordPuzzle): number {
  let count = 0;
  for (const row of puzzle.cells) {
    for (const cell of row) {
      if (cell.hasStar) count++;
    }
  }
  return count;
}

export function assignStarCells(
  puzzle: MathCrosswordPuzzle,
  isStarMode: boolean
): MathCrosswordPuzzle {
  if (!isStarMode) {
    const nextCells = puzzle.cells.map((row) =>
      row.map((cell) => (cell.hasStar ? { ...cell, hasStar: false } : cell))
    );
    return { ...puzzle, cells: nextCells };
  }

  if (countTotalStarCells(puzzle) > 0) return puzzle;

  const editableCoords: { r: number; c: number }[] = [];
  for (let r = 0; r < puzzle.size; r++) {
    for (let c = 0; c < puzzle.size; c++) {
      if (!puzzle.cells[r][c].isClue) {
        editableCoords.push({ r, c });
      }
    }
  }

  const selectedIndices = new Set<number>();
  const totalAvailable = editableCoords.length;

  if (totalAvailable <= 3) {
    editableCoords.forEach((_, idx) => selectedIndices.add(idx));
  } else {
    selectedIndices.add(0);
    selectedIndices.add(Math.floor(totalAvailable / 2));
    selectedIndices.add(totalAvailable - 1);
  }

  const starCoordSet = new Set(
    Array.from(selectedIndices).map((idx) => `${editableCoords[idx].r},${editableCoords[idx].c}`)
  );

  const nextCells = puzzle.cells.map((row, r) =>
    row.map((cell, c) => ({
      ...cell,
      hasStar: starCoordSet.has(`${r},${c}`),
    }))
  );

  return { ...puzzle, cells: nextCells };
}
