import {
  CellData,
  MathCrosswordPuzzle,
  evaluateEquationStatus,
  getPuzzleEquations,
} from '../../../engine';

export function isStarCellCollected(
  cell: CellData,
  puzzle?: MathCrosswordPuzzle,
  row?: number,
  col?: number
): boolean {
  if (!cell.hasStar || cell.isHinted || cell.isVoid) return false;
  const trimmed = cell.userValue.trim();
  if (trimmed === '') return false;
  const val = parseInt(trimmed, 10);
  if (!Number.isInteger(val) || val < 1) return false;
  if (val === cell.solution) return true;

  if (puzzle && typeof row === 'number' && typeof col === 'number') {
    const equations = getPuzzleEquations(puzzle);
    for (const eq of equations) {
      const touchesCell =
        (eq.resultCell.row === row && eq.resultCell.col === col) ||
        eq.operandCells.some((p) => p.row === row && p.col === col);
      if (touchesCell && evaluateEquationStatus(puzzle, eq) === 'valid') {
        return true;
      }
    }
  }
  return false;
}

export function countCollectedStarCells(puzzle: MathCrosswordPuzzle): number {
  let count = 0;
  puzzle.cells.forEach((row, r) => {
    row.forEach((cell, c) => {
      if (isStarCellCollected(cell, puzzle, r, c)) count++;
    });
  });
  return count;
}

export function countTotalStarCells(puzzle: MathCrosswordPuzzle): number {
  let count = 0;
  for (const row of puzzle.cells) {
    for (const cell of row) {
      if (cell.hasStar && !cell.isVoid) count++;
    }
  }
  return count;
}

export function assignStarCells(
  puzzle: MathCrosswordPuzzle,
  isStarMode: boolean
): MathCrosswordPuzzle {
  if (!isStarMode) {
    const nextCells = puzzle.cells.map((row) =>
      row.map((cell) => (cell.hasStar ? { ...cell, hasStar: false } : cell))
    );
    return { ...puzzle, cells: nextCells };
  }

  if (countTotalStarCells(puzzle) > 0) return puzzle;

  const editableCoords: { r: number; c: number }[] = [];
  for (let r = 0; r < puzzle.size; r++) {
    for (let c = 0; c < puzzle.size; c++) {
      const cell = puzzle.cells[r][c];
      if (!cell.isVoid && !cell.isClue) {
        editableCoords.push({ r, c });
      }
    }
  }

  const selectedIndices = new Set<number>();
  const totalAvailable = editableCoords.length;

  if (totalAvailable <= 3) {
    editableCoords.forEach((_, idx) => selectedIndices.add(idx));
  } else {
    selectedIndices.add(0);
    selectedIndices.add(Math.floor(totalAvailable / 2));
    selectedIndices.add(totalAvailable - 1);
  }

  const starCoordSet = new Set(
    Array.from(selectedIndices).map((idx) => `${editableCoords[idx].r},${editableCoords[idx].c}`)
  );

  const nextCells = puzzle.cells.map((row, r) =>
    row.map((cell, c) => ({
      ...cell,
      hasStar: !cell.isVoid && starCoordSet.has(`${r},${c}`),
    }))
  );

  return { ...puzzle, cells: nextCells };
}
