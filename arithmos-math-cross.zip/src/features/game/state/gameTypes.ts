import {
  MathCrosswordPuzzle,
  RatingAdjustmentResult,
} from '../../../engine';
import { GameMode } from '../../../storage/schema';

export type GameState =
  | 'TITLE_MENU'
  | 'PLAYING'
  | 'PAUSED'
  | 'ROUND_SUMMARY'
  | 'TIME_UP';

export const MAX_HINTS_PER_PUZZLE = 3;
export const MAX_CHECKS_PER_PUZZLE = 3;
export const MAX_HEARTS_PER_LEVEL = 3;
export const MAX_HISTORY_LENGTH = 50;

export interface StatusBanner {
  type: 'info' | 'error' | 'success';
  message: string;
}

export interface GridPosition {
  row: number;
  col: number;
}

export interface CellEdit {
  row: number;
  col: number;
  prev: string;
  next: string;
}

export interface EditHistory {
  past: CellEdit[];
  future: CellEdit[];
}

export interface GameSessionState {
  gameState: GameState;
  mode: GameMode;
  rating: number;
  level: number;
  completedLevel: number | null;
  darkMode: boolean;
  muted: boolean;
  overrideSize: number | null;
  puzzle: MathCrosswordPuzzle;
  focusedPos: GridPosition | null;
  direction: 'row' | 'col';
  elapsedSeconds: number;
  timeLimitSeconds: number;
  hintsUsed: number;
  checksUsed: number;
  calculatorUses: number;
  heartsLeft: number;
  errorsMade: number;
  mistakeCellKeys: string[];
  retriesCount: number;
  history: EditHistory;
  statusBanner: StatusBanner | null;
  lastRatingResult: RatingAdjustmentResult | null;
  starsEarned?: 1 | 2 | 3;
  starReason?: string;
  showOnboarding: boolean;
  onboardingStep: number;
  isGenerating?: boolean;
}

export type GameAction =
  | {
      type: 'START_PUZZLE';
      puzzle: MathCrosswordPuzzle;
      timeLimitSeconds: number;
      firstCell: GridPosition | null;
      showOnboarding: boolean;
      direction?: 'row' | 'col';
      mode?: GameMode;
      rating?: number;
      level?: number;
      overrideSize?: number | null;
      resetHearts?: boolean;
    }
  | {
      type: 'RESUME_SAVED_SESSION';
      session?: import('../../../storage/schema').ActivePuzzleSession;
    }
  | {
      type: 'RETRY_SAME_PUZZLE';
      firstCell: GridPosition | null;
      direction?: 'row' | 'col';
    }
  | {
      type: 'SWAP_NEW_PUZZLE';
      puzzle: MathCrosswordPuzzle;
      timeLimitSeconds: number;
      firstCell: GridPosition | null;
      direction?: 'row' | 'col';
    }
  | {
      type: 'SET_CELL_VALUE';
      puzzle: MathCrosswordPuzzle;
      edit?: CellEdit;
      dismissOnboarding: boolean;
      nextFocus?: GridPosition;
      nextDirection?: 'row' | 'col';
      errorsAdded?: number;
      mistakeCellKeys?: string[];
    }
  | { type: 'UNDO' }
  | { type: 'REDO' }
  | {
      type: 'APPLY_HINT';
      puzzle: MathCrosswordPuzzle;
      hintsUsed: number;
      banner: StatusBanner;
      nextFocus?: GridPosition;
    }
  | {
      type: 'VALIDATE_BOARD';
      puzzle: MathCrosswordPuzzle;
      checksUsed: number;
      errorsAdded: number;
      mistakeCellKeys: string[];
      banner: StatusBanner | null;
    }
  | { type: 'SET_FOCUS'; pos: GridPosition | null }
  | { type: 'SET_DIRECTION'; direction: 'row' | 'col' }
  | { type: 'TOGGLE_DIRECTION' }
  | { type: 'TICK'; seconds?: number }
  | { type: 'PAUSE' }
  | { type: 'RESUME' }
  | { type: 'TOGGLE_PAUSE' }
  | { type: 'CONSUME_CALCULATOR_USE' }
  | {
      type: 'WIN';
      puzzle: MathCrosswordPuzzle;
      hintsUsed: number;
      ratingResult: RatingAdjustmentResult;
      starsEarned?: 1 | 2 | 3;
      starReason?: string;
    }
  | {
      type: 'TIME_UP';
      ratingResult: RatingAdjustmentResult;
      errorsMade?: number;
      mistakeCellKeys?: string[];
    }
  | { type: 'GO_TO_TITLE' }
  | { type: 'SET_OVERRIDE_SIZE'; size: number | null }
  | { type: 'TOGGLE_DARK' }
  | { type: 'TOGGLE_MUTE'; muted: boolean }
  | { type: 'SET_BANNER'; banner: StatusBanner | null }
  | { type: 'TOGGLE_ONBOARDING' }
  | { type: 'ONBOARDING_NEXT' }
  | { type: 'ONBOARDING_DISMISS' }
  | { type: 'SET_GENERATING'; isGenerating: boolean }
  | { type: 'GENERATING' };
