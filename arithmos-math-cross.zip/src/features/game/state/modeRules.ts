import { GameMode } from '../../../storage/schema';
import { CALCULATOR_POOL } from '../../calculator/calculatorRules';

export interface ModeRules {
  hasTimer: boolean;
  hasHearts: boolean;
  hasHints: boolean;
  hasStars: boolean;
  unlimitedChecks: boolean;
  unlimitedSwaps: boolean;
  calculatorLimit: number;
}

export function getModeRules(mode: GameMode): ModeRules {
  switch (mode) {
    case 'practice':
      return {
        hasTimer: false,
        hasHearts: false,
        hasHints: false,
        hasStars: false,
        unlimitedChecks: true,
        unlimitedSwaps: true,
        calculatorLimit: Infinity,
      };
    case 'lab':
    case 'repair':
      return {
        hasTimer: false,
        hasHearts: false,
        hasHints: true,
        hasStars: true,
        unlimitedChecks: true,
        unlimitedSwaps: true,
        calculatorLimit: Infinity,
      };
    case 'multiplayer':
      return {
        hasTimer: true,
        hasHearts: false,
        hasHints: true,
        hasStars: false,
        unlimitedChecks: true,
        unlimitedSwaps: true,
        calculatorLimit: Infinity,
      };
    case 'star':
      return {
        hasTimer: true,
        hasHearts: true,
        hasHints: true,
        hasStars: true,
        unlimitedChecks: false,
        unlimitedSwaps: false,
        calculatorLimit: CALCULATOR_POOL,
      };
    case 'endless':
    default:
      return {
        hasTimer: true,
        hasHearts: true,
        hasHints: true,
        hasStars: false,
        unlimitedChecks: false,
        unlimitedSwaps: false,
        calculatorLimit: CALCULATOR_POOL,
      };
  }
}
