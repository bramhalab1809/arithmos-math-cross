import {
  calculatePuzzleTimeLimit,
  generateMathCrossword,
} from '../../../engine';
import { loadState } from '../../../storage/storage';
import { loadActiveSession } from '../../../storage/sessionStorage';
import { loadUiState } from '../../../storage/uiState';
import { ActivePuzzleSession } from '../../../storage/schema';
import { soundEngine } from '../../../audio/soundEngine';
import { getModeRules } from './modeRules';
import { assignStarCells } from './starCells';
import {
  GameSessionState,
  MAX_HEARTS_PER_LEVEL,
} from './gameTypes';
import { findFirstEditableCell } from './navigation';

export function resumeSessionState(
  state: GameSessionState,
  s?: ActivePuzzleSession,
  targetGameState: 'PLAYING' | 'PAUSED' = 'PLAYING'
): GameSessionState {
  if (!s) {
    return { ...state, history: { past: [], future: [] }, statusBanner: null, gameState: targetGameState };
  }
  return {
    ...state,
    mode: s.mode ?? 'endless',
    rating: s.rating,
    level: s.level,
    completedLevel: null,
    overrideSize: s.overrideSize,
    puzzle: assignStarCells(s.puzzle, (s.mode ?? 'endless') === 'star'),
    focusedPos: s.focusedPos ?? findFirstEditableCell(s.puzzle),
    direction: s.direction,
    elapsedSeconds: s.elapsedSeconds,
    timeLimitSeconds: s.timeLimitSeconds,
    hintsUsed: s.hintsUsed,
    checksUsed: s.checksUsed,
    calculatorUses: s.calculatorUses ?? 0,
    heartsLeft: s.heartsLeft,
    errorsMade: s.errorsMade,
    mistakeCellKeys: s.mistakeCellKeys,
    retriesCount: 0,
    history: { past: [], future: [] },
    statusBanner: null,
    lastRatingResult: null,
    starsEarned: undefined,
    starReason: undefined,
    showOnboarding: false,
    isGenerating: false,
    gameState: targetGameState,
  };
}

export function createInitialGameSessionState(): GameSessionState {
  const saved = loadState();
  const uiState = loadUiState();
  const activeSession = loadActiveSession();

  const rules = activeSession?.mode ? getModeRules(activeSession.mode) : null;
  const isValidSession =
    activeSession &&
    (rules ? (rules.hasTimer ? activeSession.elapsedSeconds < activeSession.timeLimitSeconds : true) : true);

  if (uiState.screen === 'game' && activeSession && isValidSession) {
    const dummyState: GameSessionState = {
      gameState: 'PAUSED',
      mode: 'endless',
      rating: 100,
      level: 1,
      completedLevel: null,
      darkMode: saved.settings.darkMode,
      muted: soundEngine.isMuted(),
      overrideSize: null,
      puzzle: assignStarCells(activeSession.puzzle, (activeSession.mode ?? 'endless') === 'star'),
      focusedPos: null,
      direction: 'row',
      elapsedSeconds: 0,
      timeLimitSeconds: 300,
      hintsUsed: 0,
      checksUsed: 0,
      calculatorUses: 0,
      heartsLeft: 3,
      errorsMade: 0,
      mistakeCellKeys: [],
      retriesCount: 0,
      history: { past: [], future: [] },
      statusBanner: null,
      lastRatingResult: null,
      showOnboarding: false,
      onboardingStep: 0,
    };
    return resumeSessionState(dummyState, activeSession, 'PAUSED');
  }

  const endlessSlot = saved.modes.endless;
  const initialPuzzle = generateMathCrossword(endlessSlot.rating, endlessSlot.level, null);
  return {
    gameState: 'TITLE_MENU',
    mode: 'endless',
    rating: endlessSlot.rating,
    level: endlessSlot.level,
    completedLevel: null,
    darkMode: saved.settings.darkMode,
    muted: soundEngine.isMuted(),
    overrideSize: null,
    puzzle: initialPuzzle,
    focusedPos: null,
    direction: 'row',
    elapsedSeconds: 0,
    timeLimitSeconds: calculatePuzzleTimeLimit(initialPuzzle, endlessSlot.level),
    hintsUsed: 0,
    checksUsed: 0,
    calculatorUses: 0,
    heartsLeft: MAX_HEARTS_PER_LEVEL,
    errorsMade: 0,
    mistakeCellKeys: [],
    retriesCount: 0,
    history: { past: [], future: [] },
    statusBanner: null,
    lastRatingResult: null,
    showOnboarding: false,
    onboardingStep: 0,
    isGenerating: false,
  };
}
