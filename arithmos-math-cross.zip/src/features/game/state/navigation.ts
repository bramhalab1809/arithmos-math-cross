import { CellData, MathCrosswordPuzzle } from '../../../engine';
import { GridPosition } from './gameTypes';
export { isBoardCompletelySolved } from './winCheck';

export function isCellNavigable(cell?: Pick<CellData, 'isVoid'> | null): boolean {
  return Boolean(cell && !cell.isVoid);
}

export function isCellEditable(cell?: Pick<CellData, 'isClue' | 'isHinted' | 'isVoid'> | null): boolean {
  if (!cell || cell.isVoid) return false;
  return !cell.isClue && !cell.isHinted;
}

export function findFirstEditableCell(p: MathCrosswordPuzzle): GridPosition | null {
  for (let r = 0; r < p.size; r++) {
    for (let c = 0; c < p.size; c++) {
      if (isCellEditable(p.cells[r][c])) {
        return { row: r, col: c };
      }
    }
  }
  return null;
}

/**
 * Moves across ALL valid non-void number boxes (both empty editable boxes and
 * pre-filled clue/hinted boxes), skipping void cutouts and operator/`=` cells.
 * First checks the exact directional ray; if blocked by void cutouts in custom
 * topologies, falls back to the nearest navigable cell in the requested direction.
 */
export function findSpatialNextCell(
  puzzle: MathCrosswordPuzzle,
  row: number,
  col: number,
  dr: number,
  dc: number
): GridPosition | null {
  const N = puzzle.size;
  let r = row + dr;
  let c = col + dc;
  while (r >= 0 && r < N && c >= 0 && c < N) {
    if (isCellNavigable(puzzle.cells[r]?.[c])) {
      return { row: r, col: c };
    }
    r += dr;
    c += dc;
  }

  // Fallback for custom topologies with void cutouts: find nearest navigable cell in half-plane
  let bestPos: GridPosition | null = null;
  let bestScore = Infinity;

  for (let rr = 0; rr < N; rr++) {
    for (let cc = 0; cc < N; cc++) {
      if (rr === row && cc === col) continue;
      if (!isCellNavigable(puzzle.cells[rr]?.[cc])) continue;

      const dRow = rr - row;
      const dCol = cc - col;
      const primaryDist = dr !== 0 ? dRow * Math.sign(dr) : dCol * Math.sign(dc);
      if (primaryDist <= 0) continue;

      const perpDist = dr !== 0 ? Math.abs(dCol) : Math.abs(dRow);
      const score = primaryDist * 3 + perpDist * 2;
      if (score < bestScore) {
        bestScore = score;
        bestPos = { row: rr, col: cc };
      }
    }
  }

  return bestPos;
}

export function findPreviousEditableCell(
  puzzle: MathCrosswordPuzzle,
  row: number,
  col: number,
  direction: 'row' | 'col'
): GridPosition | null {
  const N = puzzle.size;
  for (let step = 1; step < N * N; step++) {
    let prevR = row;
    let prevC = col;
    if (direction === 'row') {
      const flat = (row * N + col - step + N * N) % (N * N);
      prevR = Math.floor(flat / N);
      prevC = flat % N;
    } else {
      const flat = (col * N + row - step + N * N) % (N * N);
      prevC = Math.floor(flat / N);
      prevR = flat % N;
    }
    if (isCellEditable(puzzle.cells[prevR][prevC])) {
      return { row: prevR, col: prevC };
    }
  }
  return null;
}

export function findNextEmptyEditableCell(
  puzzle: MathCrosswordPuzzle,
  fromRow: number,
  fromCol: number,
  preferredDir: 'row' | 'col'
): { row: number; col: number; newDir?: 'row' | 'col' } | null {
  const N = puzzle.size;
  const isCellEmpty = (r: number, c: number) =>
    isCellEditable(puzzle.cells[r][c]) && puzzle.cells[r][c].userValue.trim() === '';

  if (preferredDir === 'row') {
    for (let offset = 1; offset < N; offset++) {
      const nextC = (fromCol + offset) % N;
      if (isCellEmpty(fromRow, nextC)) return { row: fromRow, col: nextC };
    }
    for (let offset = 1; offset < N; offset++) {
      const nextR = (fromRow + offset) % N;
      if (isCellEmpty(nextR, fromCol)) return { row: nextR, col: fromCol, newDir: 'col' };
    }
  } else {
    for (let offset = 1; offset < N; offset++) {
      const nextR = (fromRow + offset) % N;
      if (isCellEmpty(nextR, fromCol)) return { row: nextR, col: fromCol };
    }
    for (let offset = 1; offset < N; offset++) {
      const nextC = (fromCol + offset) % N;
      if (isCellEmpty(fromRow, nextC)) return { row: fromRow, col: nextC, newDir: 'row' };
    }
  }

  const total = N * N;
  const startIndex = fromRow * N + fromCol;
  for (let i = 1; i < total; i++) {
    const idx = (startIndex + i) % total;
    const r = Math.floor(idx / N);
    const c = idx % N;
    if (isCellEmpty(r, c)) return { row: r, col: c };
  }
  return null;
}

export const findNextEmptyIntersectingCell = findNextEmptyEditableCell;

export function findLineBoundaryCell(
  puzzle: MathCrosswordPuzzle,
  row: number,
  col: number,
  direction: 'row' | 'col',
  target: 'first' | 'last'
): GridPosition | null {
  const N = puzzle.size;
  if (direction === 'row') {
    const cols = target === 'first'
      ? Array.from({ length: N }, (_, i) => i)
      : Array.from({ length: N }, (_, i) => N - 1 - i);
    for (const c of cols) {
      if (isCellNavigable(puzzle.cells[row][c])) return { row, col: c };
    }
  } else {
    const rows = target === 'first'
      ? Array.from({ length: N }, (_, i) => i)
      : Array.from({ length: N }, (_, i) => N - 1 - i);
    for (const r of rows) {
      if (isCellNavigable(puzzle.cells[r][col])) return { row: r, col };
    }
  }
  return null;
}
