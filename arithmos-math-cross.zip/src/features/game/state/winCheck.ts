import {
  MathCrosswordPuzzle,
  MathOperator,
  isCompleteLineValid,
} from '../../../engine';

/**
 * Pure check whether all cells in the puzzle are filled and all row/col equations hold.
 * Accepts the target solution OR any player-constructed mathematically valid solution.
 */
export function isBoardCompletelySolved(updatedPuzzle: MathCrosswordPuzzle): boolean {
  const N = updatedPuzzle.size;

  for (let r = 0; r < N; r++) {
    for (let c = 0; c < N; c++) {
      const cell = updatedPuzzle.cells[r][c];
      if (!cell.isClue) {
        const val = parseInt(cell.userValue, 10);
        if (!Number.isInteger(val) || val < 1) {
          return false;
        }
      }
    }
  }

  for (let r = 0; r < N; r++) {
    const rowVals = updatedPuzzle.cells[r].map((cl) =>
      cl.isClue ? cl.solution : parseInt(cl.userValue, 10)
    );
    if (!isCompleteLineValid(rowVals, updatedPuzzle.rowOps[r])) return false;
  }

  for (let c = 0; c < N; c++) {
    const colVals = updatedPuzzle.cells.map((rowArr) =>
      rowArr[c].isClue ? rowArr[c].solution : parseInt(rowArr[c].userValue, 10)
    );
    const cOps: MathOperator[] = [];
    for (let r = 0; r < N - 2; r++) cOps.push(updatedPuzzle.colOps[r][c]);
    if (!isCompleteLineValid(colVals, cOps)) return false;
  }

  return true;
}
