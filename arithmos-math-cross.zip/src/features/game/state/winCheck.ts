import {
  MathCrosswordPuzzle,
  evaluateEquationStatus,
  getPuzzleEquations,
} from '../../../engine';

export function isBoardCompletelySolved(updatedPuzzle: MathCrosswordPuzzle): boolean {
  const N = updatedPuzzle.size;

  for (let r = 0; r < N; r++) {
    for (let c = 0; c < N; c++) {
      const cell = updatedPuzzle.cells[r][c];
      if (cell.isVoid) continue;
      if (!cell.isClue) {
        const val = parseInt(cell.userValue, 10);
        if (!Number.isInteger(val) || val < 1) {
          return false;
        }
      }
    }
  }

  const equations = getPuzzleEquations(updatedPuzzle);
  for (const eq of equations) {
    if (evaluateEquationStatus(updatedPuzzle, eq) !== 'valid') {
      return false;
    }
  }

  return true;
}
