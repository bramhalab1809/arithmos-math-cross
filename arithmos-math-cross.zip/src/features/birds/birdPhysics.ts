export type BirdSpecies = 'chimni' | 'crow';
export type BirdActionState = 'hidden' | 'entering' | 'perched' | 'exiting';

export interface PerchTarget {
  id: string;
  x: number;
  y: number;
}

export interface BirdEntity {
  id: string;
  species: BirdSpecies;
  state: BirdActionState;
  x: number;
  y: number;
  startX: number;
  startY: number;
  ctrlX: number;
  ctrlY: number;
  targetX: number;
  targetY: number;
  perchId: string | null;
  perchOffsetRatio: number;
  hopsRemaining: number;
  flightProgress: number;
  flightDurationMs: number;
  stateTimerMs: number;
  facing: 1 | -1;
  wingPhase: number;
  headTiltDeg: number;
  callBubble: string | null;
  callBubbleTimerMs: number;
}

export function scanPerchTargets(preferredPrefix?: string): PerchTarget[] {
  if (typeof document === 'undefined') return [];
  const nodes = document.querySelectorAll<HTMLElement>('[data-bird-perch]');
  const targets: PerchTarget[] = [];
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  nodes.forEach((el) => {
    const id = el.getAttribute('data-bird-perch');
    if (!id || (preferredPrefix && !id.startsWith(preferredPrefix))) return;
    const rect = el.getBoundingClientRect();
    if (rect.width < 16 || rect.height < 16) return;
    if (rect.top < 20 || rect.bottom > vh - 10 || rect.left < 8 || rect.right > vw - 8) return;
    targets.push({ id, x: rect.left + rect.width * 0.5, y: rect.top - 2 });
  });
  return targets;
}

export function resolvePerchCoords(perchId: string, offsetRatio: number): { x: number; y: number } | null {
  if (typeof document === 'undefined') return null;
  const el = document.querySelector<HTMLElement>(`[data-bird-perch="${perchId}"]`);
  if (!el) return null;
  const rect = el.getBoundingClientRect();
  if (rect.width < 10 || rect.height < 10) return null;
  return { x: rect.left + rect.width * offsetRatio, y: rect.top - 2 };
}

export function createInitialFlock(): BirdEntity[] {
  const makeBird = (id: string, species: BirdSpecies, ratio: number, delayMs: number): BirdEntity => ({
    id, species, state: 'hidden', x: -120, y: -120, startX: -120, startY: -120, ctrlX: 0, ctrlY: 0,
    targetX: -120, targetY: -120, perchId: null, perchOffsetRatio: ratio, hopsRemaining: 0,
    flightProgress: 0, flightDurationMs: 1600, stateTimerMs: delayMs, facing: 1,
    wingPhase: Math.random() * 3, headTiltDeg: 0, callBubble: null, callBubbleTimerMs: 0,
  });
  return [
    makeBird('chimni-1', 'chimni', 0.34, 1200),
    makeBird('chimni-2', 'chimni', 0.66, 3400),
    makeBird('crow-1', 'crow', 0.5, 22000),
  ];
}

export function spawnBirdFromOffScreen(bird: BirdEntity, target?: PerchTarget | null, bubble?: string): void {
  const vw = typeof window !== 'undefined' ? window.innerWidth : 1024;
  const vh = typeof window !== 'undefined' ? window.innerHeight : 768;
  const fromLeft = Math.random() < 0.5;
  bird.startX = fromLeft ? -90 : vw + 90;
  bird.startY = 35 + Math.random() * Math.max(110, vh * 0.42);
  bird.x = bird.startX;
  bird.y = bird.startY;
  bird.flightProgress = 0;

  if (target) {
    bird.state = 'entering';
    bird.perchId = target.id;
    bird.hopsRemaining = Math.random() < 0.25 ? 1 : 0;
    const destX = target.x + (bird.perchOffsetRatio - 0.5) * 24;
    bird.targetX = destX;
    bird.targetY = target.y;
    bird.ctrlX = (bird.startX + destX) * 0.5;
    bird.ctrlY = Math.min(bird.startY, target.y) - (55 + Math.random() * 65);
    bird.facing = destX >= bird.startX ? 1 : -1;
    bird.flightDurationMs = 1400 + Math.random() * 550;
  } else {
    bird.state = 'exiting';
    bird.perchId = null;
    bird.hopsRemaining = 0;
    bird.targetX = fromLeft ? vw + 95 : -95;
    bird.targetY = 30 + Math.random() * Math.max(110, vh * 0.38);
    bird.ctrlX = vw * (0.3 + Math.random() * 0.4);
    bird.ctrlY = Math.min(bird.startY, bird.targetY) - (60 + Math.random() * 75);
    bird.facing = bird.targetX >= bird.startX ? 1 : -1;
    bird.flightDurationMs = 2300 + Math.random() * 800;
  }

  if (bubble) {
    bird.callBubble = bubble;
    bird.callBubbleTimerMs = 2200;
  }
}

export function launchBirdToTarget(bird: BirdEntity, target: PerchTarget, bubble?: string): void {
  bird.state = 'entering';
  bird.startX = bird.x;
  bird.startY = bird.y;
  bird.perchId = target.id;
  const destX = target.x + (bird.perchOffsetRatio - 0.5) * 24;
  bird.targetX = destX;
  bird.targetY = target.y;
  bird.ctrlX = (bird.startX + destX) * 0.5;
  bird.ctrlY = Math.min(bird.startY, target.y) - (40 + Math.random() * 45);
  bird.facing = destX >= bird.startX ? 1 : -1;
  bird.flightProgress = 0;
  const dist = Math.hypot(destX - bird.startX, target.y - bird.startY);
  bird.flightDurationMs = Math.max(600, Math.min(1500, dist * 2.8));
  if (bubble) {
    bird.callBubble = bubble;
    bird.callBubbleTimerMs = 1800;
  }
}

export function launchBirdOffScreenExit(bird: BirdEntity, bubble?: string): void {
  const vw = typeof window !== 'undefined' ? window.innerWidth : 1024;
  const exitLeft = bird.x < vw * 0.5 ? Math.random() < 0.72 : Math.random() < 0.28;
  bird.state = 'exiting';
  bird.perchId = null;
  bird.hopsRemaining = 0;
  bird.startX = bird.x;
  bird.startY = bird.y;
  bird.targetX = exitLeft ? -95 : vw + 95;
  bird.targetY = Math.max(25, bird.y - (45 + Math.random() * 115));
  bird.ctrlX = (bird.startX + bird.targetX) * 0.5;
  bird.ctrlY = Math.min(bird.startY, bird.targetY) - (55 + Math.random() * 65);
  bird.facing = bird.targetX >= bird.startX ? 1 : -1;
  bird.flightProgress = 0;
  bird.flightDurationMs = 1350 + Math.random() * 500;
  if (bubble) {
    bird.callBubble = bubble;
    bird.callBubbleTimerMs = 1500;
  }
}

export function stepBirdPhysics(bird: BirdEntity, dtMs: number): void {
  if (bird.callBubbleTimerMs > 0) {
    bird.callBubbleTimerMs -= dtMs;
    if (bird.callBubbleTimerMs <= 0) bird.callBubble = null;
  }
  if (bird.state === 'hidden') {
    bird.stateTimerMs -= dtMs;
    return;
  }
  if (bird.state === 'entering' || bird.state === 'exiting') {
    bird.flightProgress = Math.min(1, bird.flightProgress + dtMs / bird.flightDurationMs);
    const t = bird.flightProgress;
    const u = bird.state === 'entering' ? 1 - Math.pow(1 - t, 3) : t * t * (3 - 2 * t);
    const inv = 1 - u;
    bird.x = inv * inv * bird.startX + 2 * inv * u * bird.ctrlX + u * u * bird.targetX;
    bird.y = inv * inv * bird.startY + 2 * inv * u * bird.ctrlY + u * u * bird.targetY;
    bird.wingPhase += dtMs * (bird.species === 'chimni' ? 0.032 : 0.021);
    bird.headTiltDeg = Math.sin(bird.wingPhase * 0.5) * 6;
    if (bird.flightProgress >= 1) {
      if (bird.state === 'entering') {
        bird.state = 'perched';
        bird.stateTimerMs = 3500 + Math.random() * 2000;
        bird.wingPhase = 0;
      } else {
        bird.state = 'hidden';
        bird.x = -120;
        bird.y = -120;
        bird.callBubble = null;
        bird.stateTimerMs = bird.species === 'crow' ? 28000 + Math.random() * 20000 : 18000 + Math.random() * 16000;
      }
    }
    return;
  }
  if (bird.perchId) {
    const live = resolvePerchCoords(bird.perchId, bird.perchOffsetRatio);
    if (live) { bird.x = live.x; bird.y = live.y; }
    else { launchBirdOffScreenExit(bird); return; }
  }
  bird.wingPhase += dtMs * 0.005;
  bird.headTiltDeg = Math.sin(bird.wingPhase * 1.7) * 8;
  bird.stateTimerMs -= dtMs;
}
