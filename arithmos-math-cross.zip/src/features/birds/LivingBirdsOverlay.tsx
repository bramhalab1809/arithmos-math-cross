import React, { useEffect, useRef, useState } from 'react';
import { soundEngine } from '../../audio/soundEngine';
import {
  BirdEntity,
  createInitialFlock,
  launchBirdOffScreenExit,
  launchBirdToTarget,
  scanPerchTargets,
  spawnBirdFromOffScreen,
  stepBirdPhysics,
} from './birdPhysics';

export const LivingBirdsOverlay: React.FC = () => {
  const flockRef = useRef<BirdEntity[]>(createInitialFlock());
  const [, setTick] = useState(0);
  const lastInputAtRef = useRef<number>(Date.now());
  const alerted30Ref = useRef<boolean>(false);
  const alerted10Ref = useRef<boolean>(false);
  const wasAnyVisibleRef = useRef<boolean>(false);

  useEffect(() => {
    const scatterFromTarget = (el: HTMLElement | null) => {
      lastInputAtRef.current = Date.now();
      const perchEl = el?.closest?.('[data-bird-perch]') as HTMLElement | null;
      const clickedPerchId = perchEl?.getAttribute('data-bird-perch');
      if (!clickedPerchId) return;

      flockRef.current.forEach((bird) => {
        if (
          bird.state === 'perched' &&
          (bird.perchId === clickedPerchId || (clickedPerchId.startsWith('cell-') && bird.perchId?.startsWith('cell-')))
        ) {
          launchBirdOffScreenExit(bird, bird.species === 'chimni' ? 'Chi-Chi!' : 'Kav!');
          if (bird.species === 'chimni') soundEngine.playChimniVoice(false);
        }
      });
    };

    const onPointerDown = (e: PointerEvent) => scatterFromTarget(e.target as HTMLElement | null);
    const onKeyDown = () => {
      lastInputAtRef.current = Date.now();
      scatterFromTarget(document.activeElement as HTMLElement | null);
    };

    window.addEventListener('pointerdown', onPointerDown, { passive: true });
    window.addEventListener('keydown', onKeyDown, { passive: true });

    let lastTime = performance.now();
    let rafId = 0;

    const loop = (now: number) => {
      const dt = Math.min(64, now - lastTime);
      lastTime = now;

      const idleMs = Date.now() - lastInputAtRef.current;
      const timerEl = document.querySelector<HTMLElement>('[data-bird-perch="timer-bar"]');
      const remAttr = timerEl?.getAttribute('data-remaining-seconds');
      const remSecs = remAttr ? parseInt(remAttr, 10) : null;

      if (remSecs !== null && remSecs > 32) {
        alerted30Ref.current = false;
        alerted10Ref.current = false;
      }

      // 30s and 10s Time-Pressure Alert: fly in from off-screen, alert, then fly off-screen
      if (remSecs !== null && remSecs <= 30 && remSecs > 10 && !alerted30Ref.current) {
        alerted30Ref.current = true;
        const crow = flockRef.current.find((b) => b.species === 'crow');
        const chimni = flockRef.current.find((b) => b.species === 'chimni');
        const timerTargets = scanPerchTargets('timer-bar');
        const allTargets = scanPerchTargets();
        if (crow) {
          const dest = timerTargets[0] || allTargets[0] || null;
          if (crow.state === 'hidden') spawnBirdFromOffScreen(crow, dest, 'Kav! Kav! 30s!');
          else if (dest) launchBirdToTarget(crow, dest, 'Kav! Kav! 30s!');
          soundEngine.playCrowVoice();
        }
        if (chimni && chimni.state === 'hidden') {
          spawnBirdFromOffScreen(chimni, allTargets[0] || null, 'Chi-Chi! Hurry!');
          soundEngine.playChimniVoice(true);
        }
      } else if (remSecs !== null && remSecs <= 10 && remSecs > 0 && !alerted10Ref.current) {
        alerted10Ref.current = true;
        const crow = flockRef.current.find((b) => b.species === 'crow');
        const timerTargets = scanPerchTargets('timer-bar');
        if (crow) {
          if (crow.state === 'hidden') spawnBirdFromOffScreen(crow, timerTargets[0] || null, 'Kav! Kav! 10s!');
          else {
            crow.callBubble = 'Kav! Kav! 10s!';
            crow.callBubbleTimerMs = 2200;
          }
          soundEngine.playCrowVoice();
        }
      }

      flockRef.current.forEach((bird) => {
        stepBirdPhysics(bird, dt);

        if (bird.state === 'hidden' && bird.stateTimerMs <= 0) {
          const allTargets = scanPerchTargets();
          if (bird.species === 'crow') {
            if (Math.random() < 0.25) spawnBirdFromOffScreen(bird, null);
            else bird.stateTimerMs = 22000 + Math.random() * 15000;
            return;
          }
          if (idleMs >= 14000) {
            const hintBtn = allTargets.find((t) => t.id === 'btn-hint');
            if (hintBtn) {
              spawnBirdFromOffScreen(bird, hintBtn, 'Need a Hint?');
              soundEngine.playChimniVoice(false);
              lastInputAtRef.current = Date.now() - 4000;
              return;
            }
          }
          if (allTargets.length > 0 && Math.random() < 0.65) {
            const chosen = allTargets[Math.floor(Math.random() * allTargets.length)];
            spawnBirdFromOffScreen(bird, chosen);
          } else {
            spawnBirdFromOffScreen(bird, null);
          }
        } else if (bird.state === 'perched' && bird.stateTimerMs <= 0) {
          if (bird.hopsRemaining > 0) {
            bird.hopsRemaining -= 1;
            const others = scanPerchTargets().filter((t) => t.id !== bird.perchId);
            if (others.length > 0) {
              launchBirdToTarget(bird, others[Math.floor(Math.random() * others.length)]);
              return;
            }
          }
          launchBirdOffScreenExit(bird);
        }
      });

      const anyVisible = flockRef.current.some((b) => b.state !== 'hidden');
      if (anyVisible || wasAnyVisibleRef.current) {
        wasAnyVisibleRef.current = anyVisible;
        setTick((v) => (v + 1) % 1000000);
      }

      rafId = window.requestAnimationFrame(loop);
    };

    rafId = window.requestAnimationFrame(loop);
    return () => {
      window.cancelAnimationFrame(rafId);
      window.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('keydown', onKeyDown);
    };
  }, []);

  const visibleBirds = flockRef.current.filter((b) => b.state !== 'hidden');
  if (visibleBirds.length === 0) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-40 overflow-hidden select-none" aria-hidden="true">
      {visibleBirds.map((bird) => {
        const isCrow = bird.species === 'crow';
        const isFlying = bird.state === 'entering' || bird.state === 'exiting';
        const wingScaleY = isFlying ? Math.sin(bird.wingPhase) : 0.25;
        const hopY = bird.state === 'perched' ? Math.abs(Math.sin(bird.wingPhase * 1.4)) * -2.5 : 0;

        return (
          <div
            key={bird.id}
            style={{ transform: `translate3d(${Math.round(bird.x - 16)}px, ${Math.round(bird.y - 24 + hopY)}px, 0)` }}
            className="absolute top-0 left-0 w-8 h-8 transition-none"
          >
            {bird.callBubble && (
              <div
                className={`absolute -top-6 left-1/2 -translate-x-1/2 whitespace-nowrap px-1.5 py-0.5 rounded-full text-[9px] font-mono font-bold border shadow-xs ${
                  isCrow ? 'bg-slate-900/95 border-amber-500/50 text-amber-300' : 'bg-amber-500/95 border-amber-300 text-slate-950'
                }`}
              >
                {bird.callBubble}
              </div>
            )}

            <svg
              viewBox="0 0 36 32"
              className="w-8 h-8 overflow-visible drop-shadow-xs"
              style={{ transform: `scaleX(${bird.facing}) rotate(${Math.round(bird.headTiltDeg)}deg)` }}
            >
              <polygon points="4,18 11,16 10,21" fill={isCrow ? '#1E293B' : '#92400E'} />
              {bird.state === 'perched' && (
                <g stroke={isCrow ? '#475569' : '#D97706'} strokeWidth="1.5" strokeLinecap="round">
                  <line x1="16" y1="23" x2="15" y2="27" />
                  <line x1="20" y1="23" x2="21" y2="27" />
                </g>
              )}
              <ellipse cx="18" cy="18" rx={isCrow ? 8.5 : 7} ry={isCrow ? 6 : 5.2} fill={isCrow ? '#0F172A' : '#B45309'} />
              {!isCrow && <ellipse cx="19" cy="19.5" rx="5" ry="3.2" fill="#FDE68A" />}
              <g style={{ transform: `translate(17px, 16px) scaleY(${wingScaleY.toFixed(2)}) translate(-17px, -16px)` }}>
                <path d="M 12 16 Q 17 4 24 15 Z" fill={isCrow ? '#334155' : '#78350F'} />
              </g>
              <circle cx="25" cy="13" r={isCrow ? 5 : 4.3} fill={isCrow ? '#0F172A' : '#92400E'} />
              <circle cx="26.5" cy="12" r="1.1" fill="#F8FAFC" />
              <polygon points={isCrow ? '29,12 35,14 29,15.5' : '29,12.2 33.5,13.5 29,14.8'} fill={isCrow ? '#64748B' : '#F59E0B'} />
            </svg>
          </div>
        );
      })}
    </div>
  );
};
