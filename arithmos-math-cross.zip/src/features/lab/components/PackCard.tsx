import React, { useState } from 'react';
import { Check, Copy, Download, Play, Plus, Share2, Trash2 } from '../../../icons';
import { LabDifficultyOption, LabLevel, LabPack } from '../schema/packTypes';
import { appendLevelsToPack, exportPackToBase64Url, exportPackToJson, getLabPackProgress } from '../../../storage/packs';
import { validatePackJson } from '../schema/packValidator';
import { formatTime } from '../../game/components/TimerBar';

interface PackCardProps {
  pack: LabPack;
  darkMode: boolean;
  canDelete: boolean;
  onSelectLevel: (pack: LabPack, levelIndex: number) => void;
  onDelete: (packId: string) => void;
  onPacksChanged: () => void;
}

const ADD_COUNTS = [1, 2, 3, 5, 10, 25, 50];

export const PackCard: React.FC<PackCardProps> = ({
  pack,
  darkMode,
  canDelete,
  onSelectLevel,
  onDelete,
  onPacksChanged,
}) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [showAddDrawer, setShowAddDrawer] = useState(false);
  const [addCount, setAddCount] = useState<number>(3);
  const [addGrid, setAddGrid] = useState<'mix' | 3 | 4 | 5 | 6 | 7>('mix');
  const [addDiff, setAddDiff] = useState<LabDifficultyOption>('normal');
  const [pasteJson, setPasteJson] = useState('');
  const [pasteErr, setPasteErr] = useState<string | null>(null);

  const progress = getLabPackProgress(pack.id);
  const solvedCount = Object.keys(progress).length;

  const handleShare = () => {
    navigator.clipboard?.writeText(exportPackToBase64Url(pack));
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 1500);
  };

  const handleDownload = () => {
    const blob = new Blob([exportPackToJson(pack)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${pack.id || 'project'}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleQuickAddLevels = () => {
    const sizes: Array<3 | 4 | 5 | 6 | 7> = [3, 4, 5, 6];
    const diffs: Array<'easy' | 'normal' | 'hard'> = ['easy', 'normal', 'hard'];
    const newLevels: LabLevel[] = [];
    const startNum = pack.levels.length + 1;
    for (let i = 0; i < addCount; i++) {
      const sz: 3 | 4 | 5 | 6 | 7 = addGrid === 'mix' ? sizes[(startNum + i) % sizes.length] : addGrid;
      const tier = addDiff === 'mix' ? diffs[(startNum + i) % diffs.length] : addDiff;
      newLevels.push({ kind: 'spec', title: `Stage ${startNum + i}`, size: sz, tier, timeLimitSeconds: sz * 40 });
    }
    appendLevelsToPack(pack.id, newLevels);
    setShowAddDrawer(false);
    onPacksChanged();
  };

  const handleAppendPastedJson = () => {
    const res = validatePackJson(pasteJson);
    if (!res.valid || !res.pack) {
      setPasteErr(res.errors[0] || 'Invalid JSON');
      return;
    }
    appendLevelsToPack(pack.id, res.pack.levels);
    setPasteJson('');
    setPasteErr(null);
    setShowAddDrawer(false);
    onPacksChanged();
  };

  const btnCls = darkMode ? 'border-slate-800 bg-slate-800/60 text-slate-300' : 'border-slate-200 bg-slate-50 text-slate-600';

  return (
    <div className={`rounded-2xl p-4 border transition-all ${darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200 shadow-xs'}`}>
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="font-bold text-base tracking-tight truncate">{pack.title}</h3>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full border font-semibold uppercase bg-purple-500/15 border-purple-500/30 text-purple-400">
              {pack.difficulty || 'normal'}
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full border font-semibold bg-indigo-500/15 border-indigo-500/30 text-indigo-400">
              {pack.gridType === 'mix' || !pack.gridType ? 'Mix Grids' : String(pack.gridType).includes('x') ? pack.gridType : `${pack.gridType}x${pack.gridType}`}
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full border font-semibold bg-emerald-500/15 border-emerald-500/30 text-emerald-400">
              {solvedCount}/{pack.levels.length} Solved
            </span>
          </div>
          {pack.description && <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-1">{pack.description}</p>}
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => onSelectLevel(pack, Math.min(solvedCount, pack.levels.length - 1))}
            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold cursor-pointer bg-purple-600 text-white hover:bg-purple-500"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Play</span>
          </button>
          <button type="button" onClick={handleShare} className={`p-1.5 rounded-xl border text-xs cursor-pointer ${copiedLink ? 'border-emerald-500 bg-emerald-500/20 text-emerald-400' : btnCls}`} title="Copy Base64 share code">
            {copiedLink ? <Copy className="w-4 h-4" /> : <Share2 className="w-4 h-4" />}
          </button>
          <button type="button" onClick={handleDownload} className={`p-1.5 rounded-xl border text-xs cursor-pointer ${btnCls}`} title="Download Project JSON">
            <Download className="w-4 h-4" />
          </button>
          {canDelete && (
            <button type="button" onClick={() => onDelete(pack.id)} className="p-1.5 rounded-xl border text-xs cursor-pointer border-rose-500/30 bg-rose-500/10 text-rose-400 hover:bg-rose-500/20" title="Delete Project">
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800/80">
        <div className="flex items-start gap-2 flex-wrap">
          {pack.levels.map((lvl, idx) => {
            const rec = progress[idx];
            const isSolved = Boolean(rec);
            return (
              <div key={idx} className="flex flex-col items-center">
                <button
                  type="button"
                  onClick={() => onSelectLevel(pack, idx)}
                  title={`${lvl.title || `Level ${idx + 1}`} (${lvl.size || 3}x${lvl.size || 3})`}
                  className={`w-10 h-10 rounded-xl font-mono font-bold text-sm flex items-center justify-center transition-all cursor-pointer select-none ${
                    isSolved
                      ? 'border-2 border-emerald-500 bg-emerald-500/10 text-emerald-500 dark:text-emerald-300'
                      : darkMode
                      ? 'border border-slate-800 bg-slate-950/70 text-slate-200 hover:border-purple-500/60'
                      : 'border border-slate-200 bg-slate-50 text-slate-700 hover:border-purple-400'
                  }`}
                >
                  {idx + 1}
                </button>
                <span className="h-3.5 mt-0.5 text-[10px] font-mono text-emerald-500 dark:text-emerald-400 font-semibold">
                  {isSolved ? formatTime(rec.bestTimeSec) : ''}
                </span>
              </div>
            );
          })}

          <div className="flex flex-col items-center">
            <button
              type="button"
              onClick={() => setShowAddDrawer((v) => !v)}
              title="Add levels to this Project"
              className={`w-10 h-10 rounded-xl border-2 border-dashed flex items-center justify-center transition-all cursor-pointer ${
                showAddDrawer ? 'border-purple-500 bg-purple-500/20 text-purple-400' : darkMode ? 'border-slate-700 text-slate-400 hover:border-purple-500/60' : 'border-slate-300 text-slate-500 hover:border-purple-400'
              }`}
            >
              <Plus className="w-4 h-4" />
            </button>
            <span className="h-3.5 mt-0.5 text-[9px] font-mono opacity-60">Add</span>
          </div>
        </div>

        {showAddDrawer && (
          <div className={`mt-2 p-3 rounded-xl border space-y-2.5 ${darkMode ? 'bg-slate-950/80 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[11px] font-semibold opacity-75">Add Count:</span>
                {ADD_COUNTS.map((cnt) => (
                  <button key={cnt} type="button" onClick={() => setAddCount(cnt)} className={`px-2 py-0.5 rounded-lg text-xs font-mono font-bold cursor-pointer border ${addCount === cnt ? 'bg-purple-600 text-white border-purple-500' : btnCls}`}>
                    +{cnt}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-1.5 flex-wrap">
                <select
                  value={String(addGrid)}
                  onChange={(e) => setAddGrid(e.target.value === 'mix' ? 'mix' : (Number(e.target.value) as 3 | 4 | 5 | 6 | 7))}
                  className={`text-xs px-2 py-1 rounded-lg border font-mono ${btnCls}`}
                >
                  <option value="mix">Mix Grids</option>
                  <option value="3">3x3 Grid</option>
                  <option value="4">4x4 Grid</option>
                  <option value="5">5x5 Grid</option>
                  <option value="6">6x6 Grid</option>
                  <option value="7">7x7 Grid</option>
                </select>
                <select value={addDiff} onChange={(e) => setAddDiff(e.target.value as LabDifficultyOption)} className={`text-xs px-2 py-1 rounded-lg border font-mono ${btnCls}`}>
                  <option value="easy">Easy</option>
                  <option value="normal">Normal</option>
                  <option value="hard">Hard</option>
                  <option value="mix">Mix Diff</option>
                </select>
                <button type="button" onClick={handleQuickAddLevels} className="inline-flex items-center gap-1 px-3 py-1 rounded-lg text-xs font-semibold bg-emerald-600 text-white hover:bg-emerald-500 cursor-pointer">
                  <Check className="w-3.5 h-3.5" />
                  <span>Add +{addCount} Levels</span>
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1 border-t border-slate-200/50 dark:border-slate-800">
              <input
                type="text"
                value={pasteJson}
                onChange={(e) => setPasteJson(e.target.value)}
                placeholder="Or paste AI JSON pack here to append its levels into this Project..."
                className={`flex-1 text-xs font-mono px-2.5 py-1 rounded-lg border ${btnCls}`}
              />
              {pasteJson.trim() && (
                <button type="button" onClick={handleAppendPastedJson} className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-purple-600 text-white cursor-pointer">
                  Append JSON
                </button>
              )}
            </div>
            {pasteErr && <p className="text-[11px] text-rose-400 font-mono">{pasteErr}</p>}
          </div>
        )}
      </div>
    </div>
  );
};
