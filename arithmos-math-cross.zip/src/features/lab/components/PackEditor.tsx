import React, { useState } from 'react';
import { AlertTriangle, Check, Copy, ExternalLink, Plus, Sparkles, Upload } from '../../../icons';
import { generateConversationalLabPrompt } from '../prompt';
import { validatePackJson } from '../schema/packValidator';
import { importPackFromBase64Url, saveLabPack } from '../../../storage/packs';
import { LabDifficultyOption, LabLevel, LabPack } from '../schema/packTypes';

interface PackEditorProps {
  darkMode: boolean;
  onPackSaved: (pack: LabPack) => void;
}

const TEMPLATE_JSON = `{
  "id": "my_custom_pack",
  "title": "Quantum Equations",
  "author": "Creator",
  "description": "A crafted level project for Level Lab.",
  "difficulty": "normal",
  "gridType": "mix",
  "version": 1,
  "levels": [
    {
      "kind": "grid",
      "title": "Dual Addition",
      "size": 3,
      "cells": [
        [{ "solution": 3, "isClue": true }, { "solution": 4, "isClue": false, "hasStar": true }, { "solution": 7, "isClue": true }],
        [{ "solution": 2, "isClue": false }, { "solution": 5, "isClue": true }, { "solution": 7, "isClue": true }],
        [{ "solution": 5, "isClue": true }, { "solution": 9, "isClue": true }, { "solution": 14, "isClue": true }]
      ],
      "rowOps": [["+"], ["+"], ["+"]],
      "colOps": [["+", "+", "+"]],
      "timeLimitSeconds": 120
    },
    { "kind": "spec", "title": "Speed Trial", "size": 4, "tier": "normal", "timeLimitSeconds": 150 }
  ]
}`;

const COUNT_PRESETS = [1, 2, 3, 5, 10, 25, 50];
const GRID_OPTIONS: Array<'mix' | 3 | 4 | 5 | 6 | 7> = ['mix', 3, 4, 5, 6, 7];
const DIFF_OPTIONS: LabDifficultyOption[] = ['easy', 'normal', 'hard', 'mix'];

export const PackEditor: React.FC<PackEditorProps> = ({ darkMode, onPackSaved }) => {
  const [projectTitle, setProjectTitle] = useState('Quantum Matrix Project');
  const [gridType, setGridType] = useState<'mix' | 3 | 4 | 5 | 6 | 7>('mix');
  const [difficulty, setDifficulty] = useState<LabDifficultyOption>('normal');
  const [levelCount, setLevelCount] = useState<number>(5);
  const [inputText, setInputText] = useState(TEMPLATE_JSON);
  const [copiedPrompt, setCopiedPrompt] = useState(false);
  const [saveStatus, setSaveStatus] = useState<string | null>(null);

  const isB64 = inputText.trim().startsWith('eyJ') || (!inputText.trim().includes('{') && inputText.trim().length > 20);
  const validation = isB64 ? importPackFromBase64Url(inputText.trim()) : validatePackJson(inputText);

  const handleCopyPrompt = () => {
    navigator.clipboard?.writeText(generateConversationalLabPrompt({ theme: projectTitle, levelCount, size: gridType, difficulty }));
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 1800);
  };

  const handleBuildProjectNow = () => {
    const cleanCount = Math.max(1, Math.min(100, levelCount || 1));
    const sizes: Array<3 | 4 | 5 | 6 | 7> = [3, 4, 5, 6];
    const diffs: Array<'easy' | 'normal' | 'hard'> = ['easy', 'normal', 'hard'];
    const levels: LabLevel[] = [];
    for (let i = 0; i < cleanCount; i++) {
      const sz: 3 | 4 | 5 | 6 | 7 = gridType === 'mix' ? sizes[i % sizes.length] : gridType;
      const tier = difficulty === 'mix' ? diffs[i % diffs.length] : difficulty;
      levels.push({ kind: 'spec', title: `Level ${i + 1}`, size: sz, tier, timeLimitSeconds: sz * 40 });
    }
    const newPack: LabPack = {
      id: `proj_${Date.now().toString(36)}`,
      title: projectTitle.trim() || 'Custom Project',
      author: 'Level Architect',
      description: `${cleanCount} levels • ${gridType === 'mix' ? 'Mixed Grids' : `${gridType}x${gridType}`} • ${difficulty.toUpperCase()}`,
      difficulty,
      gridType,
      version: 1,
      levels,
    };
    if (saveLabPack(newPack).success) onPackSaved(newPack);
  };

  const handleSaveJson = () => {
    if (!validation.valid || !validation.pack) return;
    const res = saveLabPack(validation.pack);
    if (res.success) {
      setSaveStatus('Project saved!');
      setTimeout(() => setSaveStatus(null), 2000);
      onPackSaved(validation.pack);
    } else setSaveStatus(res.error || 'Failed to save project.');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      if (typeof ev.target?.result === 'string') setInputText(ev.target.result);
    };
    reader.readAsText(file);
  };

  const cardCls = darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200 shadow-xs';
  const inputCls = darkMode ? 'bg-slate-950 border-slate-800 text-slate-100' : 'bg-slate-50 border-slate-200 text-slate-800';

  return (
    <div className="space-y-4">
      <div className={`p-4 rounded-2xl border space-y-3 ${cardCls}`}>
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div>
            <h3 className="font-bold text-sm">1. Instant Project Builder & Interactive AI Prompt</h3>
            <p className="text-xs text-slate-400">Configure a project below or copy the 4-question conversational prompt for Gemini, ChatGPT, or Claude</p>
          </div>
          <button type="button" onClick={handleBuildProjectNow} className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-emerald-600 text-white hover:bg-emerald-500 cursor-pointer shadow-xs">
            <Plus className="w-3.5 h-3.5" />
            <span>Create Project Now ({levelCount} Levels)</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="text-[11px] font-mono uppercase opacity-70 block mb-1">Project Name</label>
            <input type="text" value={projectTitle} onChange={(e) => setProjectTitle(e.target.value)} className={`w-full px-3 py-1.5 rounded-xl border text-xs font-semibold ${inputCls}`} />
          </div>
          <div>
            <label className="text-[11px] font-mono uppercase opacity-70 block mb-1">Number of Levels (1–100)</label>
            <div className="flex items-center gap-1 flex-wrap">
              {COUNT_PRESETS.map((c) => (
                <button key={c} type="button" onClick={() => setLevelCount(c)} className={`px-2 py-1 rounded-lg text-xs font-mono font-bold cursor-pointer border ${levelCount === c ? 'bg-purple-600 text-white border-purple-500' : inputCls}`}>
                  {c}
                </button>
              ))}
              <input type="number" min={1} max={100} value={levelCount} onChange={(e) => setLevelCount(Math.max(1, Math.min(100, Number(e.target.value) || 1)))} className={`w-14 px-2 py-1 rounded-lg border text-xs font-mono text-center ${inputCls}`} />
            </div>
          </div>
          <div>
            <label className="text-[11px] font-mono uppercase opacity-70 block mb-1">Grid Type</label>
            <div className="flex items-center gap-1 flex-wrap">
              {GRID_OPTIONS.map((g) => (
                <button key={String(g)} type="button" onClick={() => setGridType(g)} className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold cursor-pointer border ${gridType === g ? 'bg-indigo-600 text-white border-indigo-500' : inputCls}`}>
                  {g === 'mix' ? 'Mix' : `${g}x${g}`}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-[11px] font-mono uppercase opacity-70 block mb-1">Difficulty</label>
            <div className="flex items-center gap-1 flex-wrap">
              {DIFF_OPTIONS.map((d) => (
                <button key={d} type="button" onClick={() => setDifficulty(d)} className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold uppercase cursor-pointer border ${difficulty === d ? 'bg-purple-600 text-white border-purple-500' : inputCls}`}>
                  {d}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="pt-2 border-t border-slate-200/60 dark:border-slate-800 flex items-center justify-between gap-2 flex-wrap">
          <button type="button" onClick={handleCopyPrompt} className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold cursor-pointer ${darkMode ? 'border-purple-500/40 bg-purple-500/15 text-purple-300' : 'border-purple-300 bg-purple-50 text-purple-700'}`}>
            {copiedPrompt ? <Copy className="w-3.5 h-3.5" /> : <Sparkles className="w-3.5 h-3.5 text-purple-400" />}
            <span>{copiedPrompt ? 'Copied Interactive AI Prompt!' : 'Copy Interactive AI Prompt (Asks 4 Questions)'}</span>
          </button>
          <div className="flex items-center gap-1.5 text-xs">
            <span className="opacity-60 text-[11px]">Open AI:</span>
            <a href="https://gemini.google.com" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-blue-500/30 bg-blue-500/10 text-blue-400 font-semibold"><span>Gemini</span><ExternalLink className="w-3 h-3" /></a>
            <a href="https://chatgpt.com" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 font-semibold"><span>ChatGPT</span><ExternalLink className="w-3 h-3" /></a>
            <a href="https://claude.ai" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-amber-500/30 bg-amber-500/10 text-amber-400 font-semibold"><span>Claude</span><ExternalLink className="w-3 h-3" /></a>
          </div>
        </div>
      </div>

      <div className={`p-4 rounded-2xl border space-y-3 ${cardCls}`}>
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div>
            <h3 className="font-bold text-sm">2. Import AI JSON or Share Code</h3>
            <p className="text-xs text-slate-400">Paste the JSON generated by Gemini / ChatGPT / Claude or upload a .json file</p>
          </div>
          <div className="flex items-center gap-2">
            <label className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold cursor-pointer ${inputCls}`}>
              <Upload className="w-3.5 h-3.5" />
              <span>Upload .json</span>
              <input type="file" accept=".json,application/json" onChange={handleFileUpload} className="hidden" />
            </label>
            <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold border ${validation.valid ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400' : 'bg-rose-500/15 border-rose-500/30 text-rose-400'}`}>
              {validation.valid ? `Valid (${validation.pack?.levels.length} Levels)` : 'Validation Error'}
            </span>
          </div>
        </div>
        <textarea rows={6} value={inputText} onChange={(e) => setInputText(e.target.value)} spellCheck={false} className={`w-full font-mono text-xs p-3 rounded-xl border resize-y focus:outline-hidden ${inputCls}`} />
        {validation.errors.length > 0 && (
          <div className="p-2.5 rounded-xl border text-xs bg-rose-500/10 border-rose-500/30 text-rose-400 space-y-1">
            <div className="font-semibold flex items-center gap-1.5"><AlertTriangle className="w-3.5 h-3.5" /><span>Validation Errors:</span></div>
            <ul className="list-disc list-inside pl-1">{validation.errors.map((err, i) => (<li key={i}>{err}</li>))}</ul>
          </div>
        )}
        {saveStatus && <div className="text-xs font-mono text-center font-bold text-emerald-400">{saveStatus}</div>}
        <div className="flex items-center justify-end gap-2">
          <button type="button" onClick={() => setInputText(TEMPLATE_JSON)} className={`px-3 py-1.5 rounded-xl border text-xs font-semibold cursor-pointer ${inputCls}`}>Reset Template</button>
          <button type="button" onClick={handleSaveJson} disabled={!validation.valid} className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-xs font-semibold cursor-pointer bg-purple-600 text-white hover:bg-purple-500 disabled:opacity-40">
            <Check className="w-3.5 h-3.5" /><span>Save Imported Project</span>
          </button>
        </div>
      </div>
    </div>
  );
};
