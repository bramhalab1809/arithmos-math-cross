import React from 'react';
import { calculatePuzzleTimeLimit, findBestStartCell, generatePuzzleAsync } from '../../engine';
import { assignStarCells } from '../game/state/starCells';
import { convertLabGridToPuzzle } from '../../engine/labGrid';
import { setActiveMistakeId } from '../../storage/mistakes';
import { setActiveLabContext } from '../../storage/packs';
import { LabPack } from './schema/packTypes';
import { GameAction } from '../game/state/gameTypes';

const TIER_RATING: Record<string, number> = {
  easy: 220,
  medium: 850,
  hard: 1450,
  expert: 1900,
};

export function launchLabLevel(
  pack: LabPack,
  levelIndex: number,
  dispatch: React.Dispatch<GameAction>,
  cancelGeneration: () => void,
  focusDomInput: (r: number, c: number, delay?: number) => void
): void {
  cancelGeneration();
  const level = pack.levels[levelIndex] || pack.levels[0];
  if (!level) return;

  setActiveLabContext({ packId: pack.id, levelIndex });
  setActiveMistakeId(null);

  if (level.kind === 'grid') {
    const puzzle = convertLabGridToPuzzle(level, levelIndex + 1);
    const timeLimitSeconds = level.timeLimitSeconds ?? 180;
    const startCell = findBestStartCell(puzzle);
    const firstCell = { row: startCell.row, col: startCell.col };
    dispatch({
      type: 'START_PUZZLE',
      mode: 'lab',
      puzzle,
      timeLimitSeconds,
      firstCell,
      direction: startCell.direction,
      showOnboarding: false,
      rating: 1000,
      level: levelIndex + 1,
      overrideSize: level.size,
      resetHearts: true,
    });
    focusDomInput(firstCell.row, firstCell.col, 20);
  } else {
    const size = level.size || 3;
    const rating = TIER_RATING[level.tier || 'medium'] ?? 850;
    dispatch({ type: 'SET_GENERATING', isGenerating: true });
    generatePuzzleAsync(rating, levelIndex + 1, size, { profileOverride: level.profile })
      .then((gen) => {
        dispatch({ type: 'SET_GENERATING', isGenerating: false });
        const puzzle = assignStarCells(gen, true);
        const timeLimitSeconds = level.timeLimitSeconds ?? calculatePuzzleTimeLimit(puzzle, levelIndex + 1);
        const startCell = findBestStartCell(puzzle);
        const firstCell = { row: startCell.row, col: startCell.col };
        dispatch({
          type: 'START_PUZZLE',
          mode: 'lab',
          puzzle,
          timeLimitSeconds,
          firstCell,
          direction: startCell.direction,
          showOnboarding: false,
          rating,
          level: levelIndex + 1,
          overrideSize: size,
          resetHearts: true,
        });
        focusDomInput(firstCell.row, firstCell.col, 20);
      })
      .catch(() => {
        dispatch({ type: 'SET_GENERATING', isGenerating: false });
      });
  }
}
