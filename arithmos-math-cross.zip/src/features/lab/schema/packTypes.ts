import { DifficultyProfile, MathOperator } from '../../../engine';

export type DifficultyTier = 'easy' | 'normal' | 'medium' | 'hard' | 'expert';
export type LabLevelKind = 'spec' | 'grid';
export type LabDifficultyOption = 'easy' | 'normal' | 'hard' | 'mix';
export type LabGridTypeOption = 'mix' | '3x3' | '4x4' | '5x5' | '6x6' | '7x7' | 3 | 4 | 5 | 6 | 7;

export interface LabSpecLevel {
  kind: 'spec';
  title?: string;
  author?: string;
  tier?: DifficultyTier;
  size?: 3 | 4 | 5 | 6 | 7;
  timeLimitSeconds?: number;
  profile?: Partial<DifficultyProfile>;
}

export interface LabGridLevelCell {
  solution: number;
  isClue: boolean;
  hasStar?: boolean;
}

export interface LabGridLevel {
  kind: 'grid';
  title?: string;
  author?: string;
  size: 3 | 4 | 5 | 6 | 7;
  cells: LabGridLevelCell[][];
  rowOps: MathOperator[][];
  colOps: MathOperator[][];
  timeLimitSeconds?: number;
}

export type LabLevel = LabSpecLevel | LabGridLevel;
export type LabLevelEntry = LabLevel;

export interface LabPack {
  id: string;
  title: string;
  author?: string;
  description?: string;
  difficulty?: LabDifficultyOption;
  gridType?: LabGridTypeOption;
  version?: number;
  createdAt?: string;
  levels: LabLevel[];
}

export interface PackValidationResult {
  valid: boolean;
  pack?: LabPack;
  errors: string[];
}
