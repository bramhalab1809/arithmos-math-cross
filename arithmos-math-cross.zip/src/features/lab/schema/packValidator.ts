import { MathOperator } from '../../../engine';
import { LabDifficultyOption, LabGridLevel, LabGridTypeOption, LabLevel, LabPack, LabSpecLevel, PackValidationResult } from './packTypes';

const MAX_PAYLOAD_BYTES = 120000;
const MAX_ERRORS = 12;
const VALID_OPS: Set<string> = new Set(['+', '-', '*', '/']);
const VALID_SIZES = [3, 4, 5, 6, 7];

function sanitizeString(str: unknown): string {
  if (typeof str !== 'string') return '';
  return str.replace(/</g, '&lt;').replace(/>/g, '&gt;').trim();
}

export function extractJsonFromText(raw: string): string {
  let cleaned = raw.trim();
  const fenceMatch = cleaned.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenceMatch) cleaned = fenceMatch[1].trim();
  const firstBrace = cleaned.indexOf('{');
  const lastBrace = cleaned.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
    cleaned = cleaned.slice(firstBrace, lastBrace + 1);
  }
  return cleaned;
}

export function validatePackJson(rawInput: string): PackValidationResult {
  const errors: string[] = [];
  const addError = (msg: string) => {
    if (errors.length < MAX_ERRORS) errors.push(msg);
  };

  if (!rawInput || typeof rawInput !== 'string') {
    return { valid: false, errors: ['Input is empty.'] };
  }

  const jsonStr = extractJsonFromText(rawInput);
  if (jsonStr.length > MAX_PAYLOAD_BYTES) {
    return { valid: false, errors: [`Payload exceeds limit (${Math.round(jsonStr.length / 1024)}KB).`] };
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(jsonStr);
  } catch (err) {
    return { valid: false, errors: [`JSON parse error: ${(err as Error).message}`] };
  }

  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return { valid: false, errors: ['Root JSON must be an object.'] };
  }

  const rawObj = parsed as Record<string, unknown>;
  const title = sanitizeString(rawObj.title) || 'Untitled Project';
  const author = sanitizeString(rawObj.author) || 'Community';
  const description = sanitizeString(rawObj.description);
  const id = sanitizeString(rawObj.id) || `proj_${Date.now()}`;
  const version = typeof rawObj.version === 'number' ? rawObj.version : 1;
  const difficulty = (['easy', 'normal', 'hard', 'mix'].includes(String(rawObj.difficulty))
    ? String(rawObj.difficulty)
    : 'normal') as LabDifficultyOption;
  const gridType = (['mix', '3x3', '4x4', '5x5', '6x6', '7x7'].includes(String(rawObj.gridType))
    ? String(rawObj.gridType)
    : 'mix') as LabGridTypeOption;

  if (!Array.isArray(rawObj.levels) || rawObj.levels.length === 0) {
    addError('Project must contain a non-empty "levels" array.');
    return { valid: false, errors };
  }

  if (rawObj.levels.length > 100) {
    addError('Project cannot exceed 100 levels.');
  }

  const validatedLevels: LabLevel[] = [];

  rawObj.levels.forEach((lvl, idx) => {
    if (errors.length >= MAX_ERRORS) return;
    if (!lvl || typeof lvl !== 'object') {
      addError(`Level #${idx + 1} must be an object.`);
      return;
    }
    const lObj = lvl as Record<string, unknown>;
    const kind = lObj.kind === 'grid' || Array.isArray(lObj.cells) ? 'grid' : 'spec';

    if (kind === 'spec') {
      const sz = VALID_SIZES.includes(Number(lObj.size))
        ? (Number(lObj.size) as 3 | 4 | 5 | 6 | 7)
        : 3;
      const spec: LabSpecLevel = {
        kind: 'spec',
        title: sanitizeString(lObj.title) || `#${idx + 1}`,
        author: sanitizeString(lObj.author) || author,
        tier: (lObj.tier as LabSpecLevel['tier']) || 'medium',
        size: sz,
        timeLimitSeconds: typeof lObj.timeLimitSeconds === 'number' ? lObj.timeLimitSeconds : undefined,
        profile: lObj.profile && typeof lObj.profile === 'object' ? (lObj.profile as LabSpecLevel['profile']) : undefined,
      };
      validatedLevels.push(spec);
    } else {
      const size = Number(lObj.size);
      if (!VALID_SIZES.includes(size)) {
        addError(`Level #${idx + 1}: size must be 3..7.`);
        return;
      }
      const sz = size as 3 | 4 | 5 | 6 | 7;
      const rawCells = lObj.cells;
      if (!Array.isArray(rawCells) || rawCells.length !== sz) {
        addError(`Level #${idx + 1}: cells must be a ${sz}x${sz} matrix.`);
        return;
      }

      const validatedCells: LabGridLevel['cells'] = [];
      for (let r = 0; r < sz; r++) {
        const row = rawCells[r];
        if (!Array.isArray(row) || row.length !== sz) {
          addError(`Level #${idx + 1}: row ${r + 1} must contain ${sz} cells.`);
          return;
        }
        const cellRow: LabGridLevel['cells'][number] = [];
        for (let c = 0; c < sz; c++) {
          const cellObj = row[c] as Record<string, unknown>;
          const sol = Number(cellObj?.solution ?? cellObj?.value);
          if (!Number.isInteger(sol) || sol < 1) {
            addError(`Level #${idx + 1} cell (${r + 1},${c + 1}) solution must be >= 1.`);
            return;
          }
          cellRow.push({
            solution: sol,
            isClue: Boolean(cellObj?.isClue ?? cellObj?.clue),
            hasStar: Boolean(cellObj?.hasStar ?? cellObj?.star),
          });
        }
        validatedCells.push(cellRow);
      }

      const rowOps = lObj.rowOps as MathOperator[][];
      let colOps = lObj.colOps as MathOperator[][];

      if (!Array.isArray(rowOps) || rowOps.length !== sz) {
        addError(`Level #${idx + 1}: rowOps must have ${sz} rows.`);
        return;
      }
      for (let r = 0; r < sz; r++) {
        if (!Array.isArray(rowOps[r]) || rowOps[r].length !== sz - 2) {
          addError(`Level #${idx + 1}: rowOps[${r}] must have ${sz - 2} operators.`);
          return;
        }
        for (const op of rowOps[r]) {
          if (!VALID_OPS.has(op)) {
            addError(`Level #${idx + 1}: invalid operator "${op}".`);
            return;
          }
        }
      }

      if (
        Array.isArray(colOps) &&
        colOps.length === sz &&
        colOps.every((arr) => Array.isArray(arr) && arr.length === sz - 2)
      ) {
        const transposed: MathOperator[][] = [];
        for (let r = 0; r < sz - 2; r++) {
          const rowArr: MathOperator[] = [];
          for (let c = 0; c < sz; c++) {
            rowArr.push(colOps[c][r] as MathOperator);
          }
          transposed.push(rowArr);
        }
        colOps = transposed;
      }

      if (!Array.isArray(colOps) || colOps.length !== sz - 2) {
        addError(`Level #${idx + 1}: colOps must have ${sz - 2} rows of ${sz} operators.`);
        return;
      }
      for (let r = 0; r < sz - 2; r++) {
        if (!Array.isArray(colOps[r]) || colOps[r].length !== sz) {
          addError(`Level #${idx + 1}: colOps[${r}] must have ${sz} operators.`);
          return;
        }
        for (const op of colOps[r]) {
          if (!VALID_OPS.has(op)) {
            addError(`Level #${idx + 1}: invalid operator "${op}".`);
            return;
          }
        }
      }

      validatedLevels.push({
        kind: 'grid',
        title: sanitizeString(lObj.title) || `#${idx + 1}`,
        author: sanitizeString(lObj.author) || author,
        size: sz,
        cells: validatedCells,
        rowOps,
        colOps,
        timeLimitSeconds: typeof lObj.timeLimitSeconds === 'number' ? lObj.timeLimitSeconds : undefined,
      });
    }
  });

  if (errors.length > 0) return { valid: false, errors };

  const pack: LabPack = {
    id,
    title,
    author,
    description,
    difficulty,
    gridType,
    version,
    createdAt: sanitizeString(rawObj.createdAt) || new Date().toISOString(),
    levels: validatedLevels,
  };

  return { valid: true, pack, errors: [] };
}
