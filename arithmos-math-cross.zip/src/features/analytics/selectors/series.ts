import { HistoryRecord } from '../../../storage/history';

export interface RatingPoint {
  index: number;
  level: number;
  rating: number;
  won: boolean;
}

export interface SolveTimePoint {
  index: number;
  level: number;
  elapsedSec: number;
  parSec: number;
  won: boolean;
}

export interface AccuracyPoint {
  index: number;
  level: number;
  mistakes: number;
  hints: number;
  clean: boolean;
}

export interface SeriesData {
  ratingOverTime: RatingPoint[];
  solveTimeOverTime: SolveTimePoint[];
  accuracyOverTime: AccuracyPoint[];
}

function downsample<T>(items: T[], maxPoints = 120): T[] {
  if (items.length <= maxPoints) return items;
  const stride = Math.ceil(items.length / maxPoints);
  const result: T[] = [];
  for (let i = 0; i < items.length; i += stride) {
    result.push(items[i]);
  }
  // Always include the latest item if not already added
  const last = items[items.length - 1];
  if (result[result.length - 1] !== last) {
    result.push(last);
  }
  return result;
}

export function selectSeries(entries: HistoryRecord[]): SeriesData {
  if (entries.length === 0) {
    return {
      ratingOverTime: [],
      solveTimeOverTime: [],
      accuracyOverTime: [],
    };
  }

  // entries are stored newest first -> reverse for chronological order
  const chronological = [...entries].reverse();

  const fullRating: RatingPoint[] = chronological.map((e, idx) => ({
    index: idx + 1,
    level: e.level,
    rating: e.ratingAfter,
    won: e.won,
  }));

  const fullSolveTime: SolveTimePoint[] = chronological.map((e, idx) => ({
    index: idx + 1,
    level: e.level,
    elapsedSec: e.elapsedSeconds,
    parSec: e.timeLimitSeconds,
    won: e.won,
  }));

  const fullAccuracy: AccuracyPoint[] = chronological.map((e, idx) => ({
    index: idx + 1,
    level: e.level,
    mistakes: e.mistakes || 0,
    hints: e.hintsUsed || 0,
    clean: (e.mistakes || 0) === 0 && (e.hintsUsed || 0) === 0,
  }));

  return {
    ratingOverTime: downsample(fullRating, 120),
    solveTimeOverTime: downsample(fullSolveTime, 120),
    accuracyOverTime: downsample(fullAccuracy, 120),
  };
}
