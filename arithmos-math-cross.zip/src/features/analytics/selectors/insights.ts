import { HistoryRecord } from '../../../storage/history';
import { selectSummary } from './summary';
import { selectOperatorMastery } from './operators';
import { selectGridStats } from './grids';
import { selectActivity } from './activity';

export interface InsightChip {
  id: string;
  text: string;
  type: 'positive' | 'warning' | 'neutral';
}

export function selectInsights(entries: HistoryRecord[]): InsightChip[] {
  if (entries.length < 8) return [];

  const summary = selectSummary(entries);
  const operators = selectOperatorMastery(entries);
  const grids = selectGridStats(entries);
  const activity = selectActivity(entries);

  const chips: InsightChip[] = [];

  // 1. Clean solve rate if high
  if (summary.cleanSolveRate >= 60) {
    chips.push({
      id: 'clean-rate',
      text: `Clean solve rate: ${summary.cleanSolveRate}%`,
      type: 'positive',
    });
  } else if (summary.winRate >= 80) {
    chips.push({
      id: 'win-rate',
      text: `Overall win rate: ${summary.winRate}%`,
      type: 'positive',
    });
  }

  // 2. Weakest or strongest operator
  if (operators.weakest && (operators.weakest.accuracy ?? 100) < 75) {
    chips.push({
      id: 'weakest-op',
      text: `Needs practice: ${operators.weakest.name}`,
      type: 'warning',
    });
  } else if (operators.strongest && (operators.strongest.accuracy ?? 0) >= 90) {
    chips.push({
      id: 'strongest-op',
      text: `Top mastery: ${operators.strongest.name}`,
      type: 'positive',
    });
  }

  // 3. Best grid size
  const playedGrids = grids.filter((g) => g.played >= 3 && g.won > 0);
  if (playedGrids.length > 0) {
    const bestGrid = [...playedGrids].sort((a, b) => b.winRate - a.winRate)[0];
    if (bestGrid && bestGrid.winRate >= 70) {
      chips.push({
        id: 'best-grid',
        text: `Best grid: ${bestGrid.label} (${bestGrid.winRate}% win)`,
        type: 'positive',
      });
    }
  }

  // 4. Streak
  if (chips.length < 3 && activity.currentDayStreak >= 2) {
    chips.push({
      id: 'streak',
      text: `Active streak: ${activity.currentDayStreak} days`,
      type: 'positive',
    });
  }

  // 5. Speed indicator (compare last 4 to previous 4)
  if (chips.length < 3) {
    const recentWins = entries.filter((e) => e.won).slice(0, 4);
    const olderWins = entries.filter((e) => e.won).slice(4, 8);
    if (recentWins.length === 4 && olderWins.length === 4) {
      const avgRecent = recentWins.reduce((s, e) => s + e.elapsedSeconds, 0) / 4;
      const avgOlder = olderWins.reduce((s, e) => s + e.elapsedSeconds, 0) / 4;
      if (avgOlder > 0) {
        const diffPct = Math.round(((avgOlder - avgRecent) / avgOlder) * 100);
        if (diffPct >= 10) {
          chips.push({
            id: 'speed-up',
            text: `Solve speed +${diffPct}% recently`,
            type: 'positive',
          });
        }
      }
    }
  }

  // 6. Fallback if still under 3
  if (chips.length < 3 && summary.bestSolveSec > 0) {
    chips.push({
      id: 'best-time',
      text: `Best time: ${summary.bestSolveSec}s`,
      type: 'neutral',
    });
  }

  return chips.slice(0, 3);
}
