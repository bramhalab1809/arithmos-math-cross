import { MathOperator } from '../../../engine';
import { HistoryRecord } from '../../../storage/history';

export interface OperatorStat {
  operator: MathOperator;
  symbol: string;
  name: string;
  exposure: number;
  mistakes: number;
  accuracy: number | null;
}

export interface OperatorMastery {
  stats: Record<MathOperator, OperatorStat>;
  list: OperatorStat[];
  weakest: OperatorStat | null;
  strongest: OperatorStat | null;
}

const OP_NAMES: Record<MathOperator, string> = {
  '+': 'Addition',
  '-': 'Subtraction',
  '*': 'Multiplication',
  '/': 'Division',
};

export function selectOperatorMastery(entries: HistoryRecord[]): OperatorMastery {
  const operators: MathOperator[] = ['+', '-', '*', '/'];
  const totals: Record<MathOperator, { exposure: number; mistakes: number }> = {
    '+': { exposure: 0, mistakes: 0 },
    '-': { exposure: 0, mistakes: 0 },
    '*': { exposure: 0, mistakes: 0 },
    '/': { exposure: 0, mistakes: 0 },
  };

  for (const entry of entries) {
    if (entry.operatorExposure) {
      for (const op of operators) {
        totals[op].exposure += entry.operatorExposure[op] || 0;
      }
    }
    if (entry.operatorMistakes) {
      for (const op of operators) {
        totals[op].mistakes += entry.operatorMistakes[op] || 0;
      }
    }
  }

  const list: OperatorStat[] = operators.map((op) => {
    const exp = totals[op].exposure;
    const mis = totals[op].mistakes;
    const accuracy =
      exp > 0 ? Math.max(0, Math.min(100, Math.round((1 - mis / Math.max(1, exp)) * 100))) : null;

    return {
      operator: op,
      symbol: op === '*' ? '×' : op === '/' ? '÷' : op,
      name: OP_NAMES[op],
      exposure: exp,
      mistakes: mis,
      accuracy,
    };
  });

  const stats = list.reduce((acc, curr) => {
    acc[curr.operator] = curr;
    return acc;
  }, {} as Record<MathOperator, OperatorStat>);

  const eligible = list.filter((s) => s.exposure >= 10 && s.accuracy !== null);

  let weakest: OperatorStat | null = null;
  let strongest: OperatorStat | null = null;

  if (eligible.length > 0) {
    const sorted = [...eligible].sort((a, b) => (a.accuracy ?? 0) - (b.accuracy ?? 0));
    weakest = sorted[0];
    strongest = sorted[sorted.length - 1];
  }

  return {
    stats,
    list,
    weakest,
    strongest,
  };
}
