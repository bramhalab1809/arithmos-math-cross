import { HistoryRecord } from '../../../storage/history';

export interface SummaryStats {
  totalPlayed: number;
  totalWon: number;
  winRate: number;
  currentRating: number;
  peakRating: number;
  totalStars: number;
  bestStreak: number;
  avgSolveSec: number;
  bestSolveSec: number;
  avgHints: number;
  cleanSolveRate: number;
}

export function selectSummary(entries: HistoryRecord[]): SummaryStats {
  const totalPlayed = entries.length;
  if (totalPlayed === 0) {
    return {
      totalPlayed: 0,
      totalWon: 0,
      winRate: 0,
      currentRating: 100,
      peakRating: 100,
      totalStars: 0,
      bestStreak: 0,
      avgSolveSec: 0,
      bestSolveSec: 0,
      avgHints: 0,
      cleanSolveRate: 0,
    };
  }

  // entries are newest first in storage
  const chronological = [...entries].reverse();

  let totalWon = 0;
  let totalStars = 0;
  let cleanWins = 0;
  let sumWinSeconds = 0;
  let bestSolveSec = Infinity;
  let sumHints = 0;
  let peakRating = 100;
  let currentStreak = 0;
  let bestStreak = 0;

  for (const e of chronological) {
    sumHints += e.hintsUsed || 0;
    if (e.ratingAfter > peakRating) {
      peakRating = e.ratingAfter;
    }

    if (e.won) {
      totalWon++;
      currentStreak++;
      if (currentStreak > bestStreak) bestStreak = currentStreak;
      totalStars += e.stars || 1;
      sumWinSeconds += e.elapsedSeconds;
      if (e.elapsedSeconds < bestSolveSec) {
        bestSolveSec = e.elapsedSeconds;
      }
      if ((e.hintsUsed || 0) === 0 && (e.mistakes || 0) === 0) {
        cleanWins++;
      }
    } else {
      currentStreak = 0;
    }
  }

  const latest = entries[0];
  const currentRating = latest ? latest.ratingAfter : 100;
  const winRate = Math.round((totalWon / totalPlayed) * 100);
  const avgSolveSec = totalWon > 0 ? Math.round(sumWinSeconds / totalWon) : 0;
  const cleanSolveRate = totalWon > 0 ? Math.round((cleanWins / totalWon) * 100) : 0;
  const avgHints = totalPlayed > 0 ? Math.round((sumHints / totalPlayed) * 10) / 10 : 0;

  return {
    totalPlayed,
    totalWon,
    winRate,
    currentRating,
    peakRating,
    totalStars,
    bestStreak,
    avgSolveSec,
    bestSolveSec: bestSolveSec === Infinity ? 0 : Math.round(bestSolveSec),
    avgHints,
    cleanSolveRate,
  };
}
