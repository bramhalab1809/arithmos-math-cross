import { HistoryRecord } from '../../../storage/history';

export interface GridStat {
  size: number;
  label: string;
  played: number;
  won: number;
  winRate: number;
  avgSec: number;
  bestSec: number;
  cleanRate: number;
}

export function selectGridStats(entries: HistoryRecord[]): GridStat[] {
  const sizes = [3, 4, 5, 6, 7];

  return sizes.map((size) => {
    const gridEntries = entries.filter((e) => e.gridSize === size);
    const played = gridEntries.length;
    if (played === 0) {
      return {
        size,
        label: `${size}×${size}`,
        played: 0,
        won: 0,
        winRate: 0,
        avgSec: 0,
        bestSec: 0,
        cleanRate: 0,
      };
    }

    let won = 0;
    let sumWinSeconds = 0;
    let bestSec = Infinity;
    let cleanWins = 0;

    for (const e of gridEntries) {
      if (e.won) {
        won++;
        sumWinSeconds += e.elapsedSeconds;
        if (e.elapsedSeconds < bestSec) {
          bestSec = e.elapsedSeconds;
        }
        if ((e.hintsUsed || 0) === 0 && (e.mistakes || 0) === 0) {
          cleanWins++;
        }
      }
    }

    const winRate = Math.round((won / played) * 100);
    const avgSec = won > 0 ? Math.round(sumWinSeconds / won) : 0;
    const cleanRate = won > 0 ? Math.round((cleanWins / won) * 100) : 0;

    return {
      size,
      label: `${size}×${size}`,
      played,
      won,
      winRate,
      avgSec,
      bestSec: bestSec === Infinity ? 0 : Math.round(bestSec),
      cleanRate,
    };
  });
}
