import { HistoryRecord } from '../../../storage/history';

export interface DayActivity {
  date: string;
  count: number;
  wins: number;
  dayOfWeek: number; // 0 = Sun .. 6 = Sat
}

export interface ActivityData {
  days: DayActivity[];
  currentDayStreak: number;
  longestDayStreak: number;
  totalActiveDays: number;
}

function formatDate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function selectActivity(entries: HistoryRecord[]): ActivityData {
  const dateMap = new Map<string, { count: number; wins: number }>();

  for (const entry of entries) {
    const d = new Date(entry.timestamp);
    const key = formatDate(d);
    const existing = dateMap.get(key) || { count: 0, wins: 0 };
    existing.count += 1;
    if (entry.won) existing.wins += 1;
    dateMap.set(key, existing);
  }

  // 84 days (12 weeks) ending today
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const days: DayActivity[] = [];
  for (let i = 83; i >= 0; i--) {
    const target = new Date(today);
    target.setDate(today.getDate() - i);
    const key = formatDate(target);
    const data = dateMap.get(key) || { count: 0, wins: 0 };
    days.push({
      date: key,
      count: data.count,
      wins: data.wins,
      dayOfWeek: target.getDay(),
    });
  }

  // Calculate day streaks
  let longestStreak = 0;
  let tempStreak = 0;
  const allActiveDates = Array.from(dateMap.keys()).sort();

  if (allActiveDates.length > 0) {
    let prevTime = 0;
    for (const dStr of allActiveDates) {
      const parts = dStr.split('-').map(Number);
      const currTime = new Date(parts[0], parts[1] - 1, parts[2]).getTime();
      const oneDay = 24 * 60 * 60 * 1000;

      if (prevTime === 0) {
        tempStreak = 1;
      } else if (Math.round((currTime - prevTime) / oneDay) === 1) {
        tempStreak++;
      } else {
        tempStreak = 1;
      }
      if (tempStreak > longestStreak) {
        longestStreak = tempStreak;
      }
      prevTime = currTime;
    }
  }

  // Current streak (must include today or yesterday)
  let currentStreak = 0;
  const todayKey = formatDate(today);
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  const yesterdayKey = formatDate(yesterday);

  let checkDate = new Date(today);
  if (!dateMap.has(todayKey) && dateMap.has(yesterdayKey)) {
    checkDate = yesterday;
  }

  if (dateMap.has(formatDate(checkDate))) {
    while (dateMap.has(formatDate(checkDate))) {
      currentStreak++;
      checkDate.setDate(checkDate.getDate() - 1);
    }
  }

  return {
    days,
    currentDayStreak: currentStreak,
    longestDayStreak: Math.max(longestStreak, currentStreak),
    totalActiveDays: dateMap.size,
  };
}
