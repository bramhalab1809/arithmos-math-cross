import { HistoryRecord } from '../../../storage/history';

export interface StarConditionCheck {
  label: string;
  passed: boolean;
  actual: string;
  target: string;
}

export interface EntryStarChecks {
  threeStar: StarConditionCheck[];
  twoStar: StarConditionCheck[];
  starsEarned: 1 | 2 | 3 | 0;
  starReason: string;
}

export function selectStarChecks(entry: HistoryRecord): EntryStarChecks {
  const hints = entry.hintsUsed || 0;
  const mistakes = entry.mistakes || 0;
  const elapsed = entry.elapsedSeconds || 0;
  const limit = Math.max(1, entry.timeLimitSeconds || 300);
  const calc = entry.calculatorUses || 0;
  const elapsedPct = Math.round((elapsed / limit) * 100);

  // 3-Star conditions based on engine/stars.ts:
  // hints === 0, mistakes <= 1, elapsed <= 0.60 * limit, calculator === 0
  const pass3Hints = hints === 0;
  const pass3Mistakes = mistakes <= 1;
  const pass3Time = elapsed <= 0.6 * limit;
  const pass3Calc = calc === 0;

  const threeStar: StarConditionCheck[] = [
    {
      label: 'Zero hints used',
      passed: pass3Hints,
      actual: `${hints}`,
      target: '0',
    },
    {
      label: 'Max 1 mistake',
      passed: pass3Mistakes,
      actual: `${mistakes}`,
      target: '≤ 1',
    },
    {
      label: 'Time under 60%',
      passed: pass3Time,
      actual: `${elapsed}s (${elapsedPct}%)`,
      target: `≤ ${Math.round(0.6 * limit)}s (60%)`,
    },
    {
      label: 'No calculator used',
      passed: pass3Calc,
      actual: `${calc}`,
      target: '0',
    },
  ];

  // 2-Star conditions based on engine/stars.ts:
  // hints <= 1, mistakes <= 3, elapsed <= 0.85 * limit, calculator <= 1
  const pass2Hints = hints <= 1;
  const pass2Mistakes = mistakes <= 3;
  const pass2Time = elapsed <= 0.85 * limit;
  const pass2Calc = calc <= 1;

  const twoStar: StarConditionCheck[] = [
    {
      label: 'Max 1 hint used',
      passed: pass2Hints,
      actual: `${hints}`,
      target: '≤ 1',
    },
    {
      label: 'Max 3 mistakes',
      passed: pass2Mistakes,
      actual: `${mistakes}`,
      target: '≤ 3',
    },
    {
      label: 'Time under 85%',
      passed: pass2Time,
      actual: `${elapsed}s (${elapsedPct}%)`,
      target: `≤ ${Math.round(0.85 * limit)}s (85%)`,
    },
    {
      label: 'Max 1 calculator use',
      passed: pass2Calc,
      actual: `${calc}`,
      target: '≤ 1',
    },
  ];

  return {
    threeStar,
    twoStar,
    starsEarned: entry.stars ?? (entry.won ? 1 : 0),
    starReason: entry.starReason ?? (entry.won ? 'Completed' : 'Time up'),
  };
}
