import React from 'react';
import { SeriesData } from '../selectors/series';
import { GridStat } from '../selectors/grids';
import { OperatorMastery } from '../selectors/operators';
import { ActivityData } from '../selectors/activity';
import { ChartFrame } from '../charts/ChartFrame';
import { LineChart, LineSeries } from '../charts/LineChart';
import { BarChart, BarGroup } from '../charts/BarChart';
import { Heatmap } from '../charts/Heatmap';
import { formatTime } from '../charts/chartUtils';
import { TrendingUp, Clock, Grid, Calendar, Zap } from '../../../icons';

interface ChartsGridProps {
  series: SeriesData;
  grids: GridStat[];
  operators: OperatorMastery;
  activity: ActivityData;
  darkMode?: boolean;
}

export const ChartsGrid: React.FC<ChartsGridProps> = ({
  series,
  grids,
  operators,
  activity,
  darkMode = false,
}) => {
  const ratingSeries: LineSeries[] = [
    {
      id: 'rating',
      name: 'Rating',
      color: darkMode ? '#f59e0b' : '#2563eb',
      shape: 'circle',
      data: series.ratingOverTime.map((p) => ({
        x: p.index,
        y: p.rating,
        label: `Level ${p.level} (${p.won ? 'Win' : 'Loss'})`,
      })),
    },
  ];

  const timeSeries: LineSeries[] = [
    {
      id: 'solve',
      name: 'Solve Time',
      color: darkMode ? '#10b981' : '#059669',
      shape: 'circle',
      data: series.solveTimeOverTime.map((p) => ({
        x: p.index,
        y: p.elapsedSec,
        label: `Level ${p.level}: ${formatTime(p.elapsedSec)}`,
      })),
    },
    {
      id: 'par',
      name: 'Time Limit',
      color: darkMode ? '#94a3b8' : '#64748b',
      dash: '4 4',
      shape: 'square',
      data: series.solveTimeOverTime.map((p) => ({
        x: p.index,
        y: p.parSec,
        label: `Par Limit: ${formatTime(p.parSec)}`,
      })),
    },
  ];

  const gridGroups: BarGroup[] = grids.map((g) => ({
    label: g.label,
    values: [
      { name: 'Played', value: g.played, color: darkMode ? '#475569' : '#94a3b8' },
      { name: 'Won', value: g.won, color: darkMode ? '#10b981' : '#16a34a' },
    ],
  }));

  const operatorGroups: BarGroup[] = operators.list.map((op) => ({
    label: op.symbol,
    values: [
      {
        name: 'Accuracy %',
        value: op.accuracy ?? 0,
        color: (op.accuracy ?? 0) >= 80 ? (darkMode ? '#10b981' : '#16a34a') : (op.accuracy ?? 0) >= 60 ? (darkMode ? '#f59e0b' : '#d97706') : (darkMode ? '#ef4444' : '#dc2626'),
      },
    ],
  }));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      {/* Chart 1: Rating Progression */}
      <ChartFrame
        title="Rating Progression"
        subtitle="Rating change over recent levels"
        icon={<TrendingUp className="w-4 h-4 text-amber-500" />}
        isEmpty={series.ratingOverTime.length === 0}
        tableComponent={
          <table className="w-full text-left font-mono">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-700">
                <th className="p-1">#</th><th className="p-1">Level</th><th className="p-1">Rating</th><th className="p-1">Result</th>
              </tr>
            </thead>
            <tbody>
              {series.ratingOverTime.map((p) => (
                <tr key={p.index} className="border-b border-slate-100 dark:border-slate-800">
                  <td className="p-1">{p.index}</td><td className="p-1">{p.level}</td><td className="p-1">{p.rating}</td><td className="p-1">{p.won ? 'Win' : 'Loss'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        }
      >
        <LineChart series={ratingSeries} darkMode={darkMode} />
      </ChartFrame>

      {/* Chart 2: Solve Time vs Par */}
      <ChartFrame
        title="Solve Time vs Par"
        subtitle="Elapsed seconds compared to par limit"
        icon={<Clock className="w-4 h-4 text-purple-500" />}
        isEmpty={series.solveTimeOverTime.length === 0}
        tableComponent={
          <table className="w-full text-left font-mono">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-700">
                <th className="p-1">Level</th><th className="p-1">Solve</th><th className="p-1">Par</th><th className="p-1">Status</th>
              </tr>
            </thead>
            <tbody>
              {series.solveTimeOverTime.map((p) => (
                <tr key={p.index} className="border-b border-slate-100 dark:border-slate-800">
                  <td className="p-1">{p.level}</td><td className="p-1">{formatTime(p.elapsedSec)}</td><td className="p-1">{formatTime(p.parSec)}</td><td className="p-1">{p.won ? 'Solved' : 'Time Up'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        }
      >
        <LineChart series={timeSeries} yUnit="s" darkMode={darkMode} />
      </ChartFrame>

      {/* Chart 3: Grid Size Performance */}
      <ChartFrame
        title="Grid Size Performance"
        subtitle="Total games played and won per grid"
        icon={<Grid className="w-4 h-4 text-blue-500" />}
        isEmpty={grids.every((g) => g.played === 0)}
        tableComponent={
          <table className="w-full text-left font-mono">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-700">
                <th className="p-1">Grid</th><th className="p-1">Played</th><th className="p-1">Won</th><th className="p-1">Win %</th>
              </tr>
            </thead>
            <tbody>
              {grids.map((g) => (
                <tr key={g.size} className="border-b border-slate-100 dark:border-slate-800">
                  <td className="p-1">{g.label}</td><td className="p-1">{g.played}</td><td className="p-1">{g.won}</td><td className="p-1">{g.winRate}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        }
      >
        <BarChart groups={gridGroups} darkMode={darkMode} />
      </ChartFrame>

      {/* Chart 4: Operator Mastery */}
      <ChartFrame
        title="Operator Mastery"
        subtitle="Deduction accuracy across basic arithmetic"
        icon={<Zap className="w-4 h-4 text-emerald-500" />}
        isEmpty={operators.list.every((op) => op.exposure === 0)}
        tableComponent={
          <table className="w-full text-left font-mono">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-700">
                <th className="p-1">Op</th><th className="p-1">Name</th><th className="p-1">Exposure</th><th className="p-1">Mistakes</th><th className="p-1">Accuracy</th>
              </tr>
            </thead>
            <tbody>
              {operators.list.map((op) => (
                <tr key={op.operator} className="border-b border-slate-100 dark:border-slate-800">
                  <td className="p-1">{op.symbol}</td><td className="p-1">{op.name}</td><td className="p-1">{op.exposure}</td><td className="p-1">{op.mistakes}</td><td className="p-1">{op.accuracy !== null ? `${op.accuracy}%` : '--'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        }
      >
        <BarChart groups={operatorGroups} yUnit="%" darkMode={darkMode} />
      </ChartFrame>

      {/* Chart 5: Activity Heatmap */}
      <div className="lg:col-span-2">
        <ChartFrame
          title="Daily Activity"
          subtitle={`Last 84 days (${activity.totalActiveDays} active days · Streak: ${activity.currentDayStreak}d)`}
          icon={<Calendar className="w-4 h-4 text-orange-500" />}
          isEmpty={activity.days.every((d) => d.count === 0)}
        >
          <Heatmap days={activity.days} darkMode={darkMode} />
        </ChartFrame>
      </div>
    </div>
  );
};
