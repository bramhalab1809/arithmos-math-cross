import React from 'react';
import { GameMode } from '../../../storage/schema';
import { Infinity, Star, Calculator, Zap, Sparkles, AlertTriangle, Layers } from '../../../icons';

export type AnalyticsTabMode = 'all' | Exclude<GameMode, 'multiplayer'>;

interface ModeTabsProps {
  currentMode: AnalyticsTabMode;
  onSelectMode: (mode: AnalyticsTabMode) => void;
  counts: Record<AnalyticsTabMode, number>;
}

export const ModeTabs: React.FC<ModeTabsProps> = ({
  currentMode,
  onSelectMode,
  counts,
}) => {
  const tabs: { mode: AnalyticsTabMode; label: string; icon: React.ReactNode }[] = [
    { mode: 'all', label: 'All Modes', icon: <Layers className="w-3.5 h-3.5" /> },
    { mode: 'endless', label: 'Endless', icon: <Infinity className="w-3.5 h-3.5" /> },
    { mode: 'star', label: 'Star', icon: <Star className="w-3.5 h-3.5" /> },
    { mode: 'hardcore', label: 'Hardcore', icon: <Zap className="w-3.5 h-3.5" /> },
    { mode: 'practice', label: 'Practice', icon: <Calculator className="w-3.5 h-3.5" /> },
    { mode: 'lab', label: 'Level Lab', icon: <Sparkles className="w-3.5 h-3.5" /> },
    { mode: 'repair', label: 'Mistakes', icon: <AlertTriangle className="w-3.5 h-3.5" /> },
  ];

  return (
    <div className="flex items-center gap-1 flex-wrap p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl w-full select-none">
      {tabs.map((tab) => {
        const isActive = currentMode === tab.mode;
        const count = counts[tab.mode] || 0;

        return (
          <button
            key={tab.mode}
            type="button"
            onClick={() => onSelectMode(tab.mode)}
            className={`flex items-center justify-center gap-1.5 py-1.5 px-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              isActive
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <span>{tab.icon}</span>
            <span>{tab.label}</span>
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded-full tabular-nums font-mono ${
                isActive
                  ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                  : 'bg-slate-200/70 dark:bg-slate-700/60 text-slate-500 dark:text-slate-400'
              }`}
            >
              {count}
            </span>
          </button>
        );
      })}
    </div>
  );
};
