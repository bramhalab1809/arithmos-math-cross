import React from 'react';
import { GameMode } from '../../../storage/schema';
import { Infinity, Star, Calculator } from '../../../icons';

interface ModeTabsProps {
  currentMode: GameMode;
  onSelectMode: (mode: GameMode) => void;
  counts: Record<GameMode, number>;
}

export const ModeTabs: React.FC<ModeTabsProps> = ({
  currentMode,
  onSelectMode,
  counts,
}) => {
  const tabs: { mode: GameMode; label: string; icon: React.ReactNode }[] = [
    { mode: 'endless', label: 'Endless', icon: <Infinity className="w-4 h-4" /> },
    { mode: 'star', label: 'Star', icon: <Star className="w-4 h-4" /> },
    { mode: 'practice', label: 'Practice', icon: <Calculator className="w-4 h-4" /> },
  ];

  return (
    <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl max-w-md w-full select-none">
      {tabs.map((tab) => {
        const isActive = currentMode === tab.mode;
        const count = counts[tab.mode] || 0;

        return (
          <button
            key={tab.mode}
            type="button"
            onClick={() => onSelectMode(tab.mode)}
            className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              isActive
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <span>{tab.icon}</span>
            <span>{tab.label}</span>
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded-full tabular-nums font-mono ${
                isActive
                  ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                  : 'bg-slate-200/70 dark:bg-slate-700/60 text-slate-500 dark:text-slate-400'
              }`}
            >
              {count}
            </span>
          </button>
        );
      })}
    </div>
  );
};
