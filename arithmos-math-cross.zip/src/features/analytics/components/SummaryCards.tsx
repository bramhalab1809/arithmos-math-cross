import React from 'react';
import { SummaryStats } from '../selectors/summary';
import { GameMode } from '../../../storage/schema';
import {
  Trophy,
  Target,
  TrendingUp,
  Clock,
  Sparkles,
  Star,
  Flame,
} from '../../../icons';
import { formatTime } from '../charts/chartUtils';

interface SummaryCardsProps {
  stats: SummaryStats;
  mode: GameMode;
}

export const SummaryCards: React.FC<SummaryCardsProps> = ({ stats, mode }) => {
  const isStarMode = mode === 'star';

  const cards = [
    {
      id: 'played',
      label: 'Total Played',
      value: stats.totalPlayed,
      subtext: `${stats.totalWon} won`,
      icon: <Target className="w-4 h-4 text-blue-500 dark:text-blue-400" />,
    },
    {
      id: 'winRate',
      label: 'Win Rate',
      value: `${stats.winRate}%`,
      subtext: stats.totalPlayed > 0 ? `${stats.cleanSolveRate}% clean` : 'No games',
      icon: <Trophy className="w-4 h-4 text-amber-500 dark:text-amber-400" />,
    },
    {
      id: 'rating',
      label: 'Rating',
      value: stats.currentRating,
      subtext: `Peak: ${stats.peakRating}`,
      icon: <TrendingUp className="w-4 h-4 text-emerald-500 dark:text-emerald-400" />,
    },
    {
      id: 'time',
      label: 'Avg Solve',
      value: stats.avgSolveSec > 0 ? formatTime(stats.avgSolveSec) : '--',
      subtext: stats.bestSolveSec > 0 ? `Best: ${formatTime(stats.bestSolveSec)}` : '--',
      icon: <Clock className="w-4 h-4 text-purple-500 dark:text-purple-400" />,
    },
    {
      id: 'clean',
      label: 'Clean Solves',
      value: `${stats.cleanSolveRate}%`,
      subtext: '0 hints, 0 mistakes',
      icon: <Sparkles className="w-4 h-4 text-teal-500 dark:text-teal-400" />,
    },
    isStarMode
      ? {
          id: 'stars',
          label: 'Total Stars',
          value: stats.totalStars,
          subtext: `Best streak: ${stats.bestStreak}`,
          icon: <Star className="w-4 h-4 text-amber-400" />,
        }
      : {
          id: 'streak',
          label: 'Best Streak',
          value: stats.bestStreak,
          subtext: 'Consecutive wins',
          icon: <Flame className="w-4 h-4 text-orange-500 dark:text-orange-400" />,
        },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 select-none">
      {cards.map((card) => (
        <div
          key={card.id}
          className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 sm:p-3.5 shadow-2xs flex flex-col justify-between"
        >
          <div className="flex items-center justify-between gap-1 mb-1.5">
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 truncate">
              {card.label}
            </span>
            <span className="p-1 rounded-md bg-slate-50 dark:bg-slate-800 shrink-0">
              {card.icon}
            </span>
          </div>

          <div>
            <div className="text-xl sm:text-2xl font-bold font-mono text-slate-900 dark:text-slate-100 tabular-nums">
              {card.value}
            </div>
            <div className="text-[10px] text-slate-400 dark:text-slate-500 truncate mt-0.5">
              {card.subtext}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
