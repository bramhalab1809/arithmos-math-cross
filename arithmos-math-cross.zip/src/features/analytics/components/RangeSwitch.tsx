import React from 'react';

export type HistoryRange = 25 | 100 | 'all';

interface RangeSwitchProps {
  currentRange: HistoryRange;
  onSelectRange: (range: HistoryRange) => void;
  totalEntries: number;
}

export const RangeSwitch: React.FC<RangeSwitchProps> = ({
  currentRange,
  onSelectRange,
  totalEntries,
}) => {
  const options: { value: HistoryRange; label: string }[] = [
    { value: 25, label: 'Last 25' },
    { value: 100, label: 'Last 100' },
    { value: 'all', label: `All (${totalEntries})` },
  ];

  return (
    <div className="flex items-center gap-1 p-0.5 bg-slate-100 dark:bg-slate-800/60 rounded-lg text-xs select-none">
      {options.map((opt) => {
        const isActive = currentRange === opt.value;
        return (
          <button
            key={opt.value}
            type="button"
            onClick={() => onSelectRange(opt.value)}
            className={`px-2.5 py-1 rounded-md font-medium transition-all cursor-pointer ${
              isActive
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            {opt.label}
          </button>
        );
      })}
    </div>
  );
};
