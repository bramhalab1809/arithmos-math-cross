import React from 'react';
import { HistoryRecord } from '../../../storage/history';
import { GameMode } from '../../../storage/schema';
import { SeriesData } from '../selectors/series';
import { DonutChart, BarChart, LineChart, ChartFrame } from '../charts';
import { AlertTriangle, Award, Star, TrendingUp } from '../../../icons';

export interface BreakdownChartsGridProps {
  records: HistoryRecord[];
  series: SeriesData;
  mode: GameMode | 'all';
  darkMode?: boolean;
}

export const BreakdownChartsGrid: React.FC<BreakdownChartsGridProps> = ({
  records,
  series,
  mode,
  darkMode = false,
}) => {
  // Chart A: Outcome Breakdown
  const flawlessWins = records.filter((r) => r.won && (r.mistakes || 0) === 0 && (r.hintsUsed || 0) === 0).length;
  const assistedWins = records.filter((r) => r.won && ((r.mistakes || 0) > 0 || (r.hintsUsed || 0) > 0)).length;
  const timeUpCount = records.filter((r) => !r.won).length;

  const outcomeSegments = [
    { label: 'Flawless', value: flawlessWins, color: '#10B981' },
    { label: 'Assisted', value: assistedWins, color: '#3B82F6' },
    { label: 'Time Up', value: timeUpCount, color: '#EF4444' },
  ].filter((s) => s.value > 0);

  // Chart B: Mistakes & Hints per level (recent 15)
  const accuracySlice = series.accuracyOverTime.slice(-15);
  const accuracyGroups = accuracySlice.map((p) => ({
    label: `L${p.level}`,
    values: [
      { name: 'Mistakes', value: p.mistakes, color: '#EF4444' },
      { name: 'Hints', value: p.hints, color: '#F59E0B' },
    ],
  }));

  // Chart C: Star Distribution (Star / Hardcore / All mode) OR Rating Progression
  const isStarMode = mode === 'star' || mode === 'hardcore' || mode === 'all';
  const star1 = records.filter((r) => r.won && (r.stars === 1 || !r.stars)).length;
  const star2 = records.filter((r) => r.won && r.stars === 2).length;
  const star3 = records.filter((r) => r.won && r.stars === 3).length;

  const starGroups = [
    { label: '1 Star', values: [{ name: 'Levels', value: star1, color: '#94A3B8' }] },
    { label: '2 Stars', values: [{ name: 'Levels', value: star2, color: '#FBBF24' }] },
    { label: '3 Stars', values: [{ name: 'Levels', value: star3, color: '#F59E0B' }] },
  ];

  const ratingSlice = series.ratingOverTime.slice(-20);
  const progressionSeries = [
    {
      id: 'rating',
      name: 'Rating',
      color: darkMode ? '#F59E0B' : '#2563EB',
      data: ratingSlice.map((p) => ({
        x: p.index,
        y: p.rating,
        label: `Level ${p.level}`,
        sublabel: `${p.rating} pts`,
      })),
    },
  ];

  if (records.length === 0) return null;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {/* Chart A: Outcome Breakdown */}
      <ChartFrame
        title="Outcome Breakdown"
        subtitle="Flawless vs Assisted vs Time Up"
        icon={<Award className="w-4 h-4 text-emerald-500" />}
        isEmpty={outcomeSegments.length === 0}
      >
        <DonutChart
          segments={outcomeSegments}
          centerLabel={String(records.length)}
          centerSublabel="Games"
          darkMode={darkMode}
        />
      </ChartFrame>

      {/* Chart B: Mistakes & Hints */}
      <ChartFrame
        title="Accuracy Over Time"
        subtitle="Mistakes and hints across recent levels"
        icon={<AlertTriangle className="w-4 h-4 text-amber-500" />}
        isEmpty={accuracyGroups.length === 0}
      >
        <BarChart
          groups={accuracyGroups}
          darkMode={darkMode}
        />
      </ChartFrame>

      {/* Chart C: Star Distribution or Rating Trend */}
      {isStarMode ? (
        <ChartFrame
          title="Star Distribution"
          subtitle="Levels completed by star achievement"
          icon={<Star className="w-4 h-4 text-amber-400 fill-amber-400" />}
          isEmpty={records.filter((r) => r.won).length === 0}
        >
          <BarChart
            groups={starGroups}
            darkMode={darkMode}
          />
        </ChartFrame>
      ) : (
        <ChartFrame
          title="Rating Progression"
          subtitle="Skill rating progression over recent levels"
          icon={<TrendingUp className="w-4 h-4 text-blue-500" />}
          isEmpty={progressionSeries[0].data.length === 0}
        >
          <LineChart
            series={progressionSeries}
            yUnit="pts"
            darkMode={darkMode}
          />
        </ChartFrame>
      )}
    </div>
  );
};
