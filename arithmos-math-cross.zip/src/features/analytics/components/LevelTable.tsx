import React, { useState } from 'react';
import { HistoryRecord } from '../../../storage/history';
import { GameMode } from '../../../storage/schema';
import { ChevronLeft, ChevronRight, Star, TrendingUp, TrendingDown } from '../../../icons';
import { formatTime } from '../charts/chartUtils';

interface LevelTableProps {
  entries: HistoryRecord[];
  mode: GameMode;
  onSelectEntry: (entry: HistoryRecord) => void;
}

const PAGE_SIZE = 25;

export const LevelTable: React.FC<LevelTableProps> = ({
  entries,
  mode,
  onSelectEntry,
}) => {
  const [page, setPage] = useState(0);

  React.useEffect(() => {
    setPage(0);
  }, [mode, entries.length]);

  const totalPages = Math.max(1, Math.ceil(entries.length / PAGE_SIZE));
  const currentEntries = entries.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  const isStarMode = mode === 'star';

  if (entries.length === 0) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center text-slate-400 dark:text-slate-500">
        No level records found for this mode.
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden select-none">
      <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-slate-800 dark:text-slate-100">
            Level History
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Showing {page * PAGE_SIZE + 1}–{Math.min((page + 1) * PAGE_SIZE, entries.length)} of{' '}
            {entries.length} levels
          </p>
        </div>

        {totalPages > 1 && (
          <div className="flex items-center gap-1.5 text-xs">
            <button
              type="button"
              disabled={page === 0}
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-30 disabled:pointer-events-none hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
              title="Previous Page"
            >
              <ChevronLeft className="w-4 h-4 text-slate-600 dark:text-slate-300" />
            </button>
            <span className="font-mono text-slate-600 dark:text-slate-400 px-1">
              {page + 1} / {totalPages}
            </span>
            <button
              type="button"
              disabled={page >= totalPages - 1}
              onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-30 disabled:pointer-events-none hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
              title="Next Page"
            >
              <ChevronRight className="w-4 h-4 text-slate-600 dark:text-slate-300" />
            </button>
          </div>
        )}
      </div>

      <div className="overflow-x-auto overflow-y-auto max-h-[300px] sm:max-h-[360px] custom-scrollbar">
        <table className="w-full text-left text-xs font-sans border-collapse">
          <thead className="sticky top-0 z-10 bg-slate-50 dark:bg-slate-800/95 backdrop-blur-xs shadow-2xs">
            <tr className="text-slate-500 dark:text-slate-400 font-semibold border-b border-slate-200 dark:border-slate-800">
              <th className="py-2.5 px-3">Level</th>
              <th className="py-2.5 px-3">Grid</th>
              <th className="py-2.5 px-3">Result</th>
              <th className="py-2.5 px-3">Time</th>
              <th className="py-2.5 px-3">Hints</th>
              <th className="py-2.5 px-3">Errors</th>
              <th className="py-2.5 px-3">Rating</th>
              {isStarMode && <th className="py-2.5 px-3">Stars</th>}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono">
            {currentEntries.map((e) => {
              const delta = e.ratingDelta || 0;
              const isPositive = delta > 0;
              const isNegative = delta < 0;

              return (
                <tr
                  key={e.id}
                  onClick={() => onSelectEntry(e)}
                  className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors cursor-pointer group"
                >
                  <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-amber-400">
                    L{e.level}
                  </td>
                  <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400 font-sans">
                    {e.gridSize}×{e.gridSize}
                  </td>
                  <td className="py-2.5 px-3 font-sans">
                    <span
                      className={`inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                        e.won
                          ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300'
                          : 'bg-red-50 dark:bg-red-950/50 text-red-700 dark:text-red-300'
                      }`}
                    >
                      {e.won ? 'Win' : 'Time Up'}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300 tabular-nums">
                    {formatTime(e.elapsedSeconds)}{' '}
                    <span className="text-[10px] text-slate-400">/ {formatTime(e.timeLimitSeconds)}</span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">
                    {e.hintsUsed || 0}
                  </td>
                  <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">
                    {e.mistakes || 0}
                  </td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`inline-flex items-center gap-0.5 font-bold ${
                        isPositive
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : isNegative
                          ? 'text-red-500 dark:text-red-400'
                          : 'text-slate-400'
                      }`}
                    >
                      {isPositive ? (
                        <TrendingUp className="w-3 h-3" />
                      ) : isNegative ? (
                        <TrendingDown className="w-3 h-3" />
                      ) : null}
                      {isPositive ? `+${delta}` : delta}
                    </span>
                  </td>
                  {isStarMode && (
                    <td className="py-2.5 px-3">
                      <span className="inline-flex items-center gap-0.5 text-amber-500 font-bold">
                        <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                        {e.stars || (e.won ? 1 : 0)}
                      </span>
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
