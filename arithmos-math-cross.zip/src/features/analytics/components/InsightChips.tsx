import React from 'react';
import { InsightChip } from '../selectors/insights';
import { Zap, AlertTriangle, Sparkles } from '../../../icons';

interface InsightChipsProps {
  chips: InsightChip[];
}

export const InsightChips: React.FC<InsightChipsProps> = ({ chips }) => {
  if (chips.length === 0) return null;

  return (
    <div className="flex flex-wrap items-center gap-2 select-none">
      {chips.map((chip) => {
        const isPositive = chip.type === 'positive';
        const isWarning = chip.type === 'warning';

        return (
          <div
            key={chip.id}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all ${
              isPositive
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300'
                : isWarning
                ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800 text-amber-800 dark:text-amber-300'
                : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            {isPositive ? (
              <Zap className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            ) : isWarning ? (
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
            ) : (
              <Sparkles className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
            )}
            <span>{chip.text}</span>
          </div>
        );
      })}
    </div>
  );
};
