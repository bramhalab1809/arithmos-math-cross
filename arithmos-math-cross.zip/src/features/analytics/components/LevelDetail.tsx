import React from 'react';
import { HistoryRecord } from '../../../storage/history';
import { selectStarChecks } from '../selectors/stars';
import { formatTime } from '../charts/chartUtils';
import { LevelTimingPills } from '../../game/components/LevelTimingPills';
import {
  X,
  ChevronLeft,
  ChevronRight,
  CheckCircle,
  XCircle,
  Play,
  TrendingUp,
  TrendingDown,
  Star,
} from '../../../icons';

interface LevelDetailProps {
  entry: HistoryRecord;
  currentIndex: number;
  totalEntries: number;
  onPrev?: () => void;
  onNext?: () => void;
  onClose: () => void;
  onPlayNext?: (entry: HistoryRecord) => void;
}

export const LevelDetail: React.FC<LevelDetailProps> = ({
  entry,
  currentIndex,
  totalEntries,
  onPrev,
  onNext,
  onClose,
  onPlayNext,
}) => {
  const starData = selectStarChecks(entry);
  const timeLimit = Math.max(1, entry.timeLimitSeconds);
  const timePercent = Math.min(100, Math.round((entry.elapsedSeconds / timeLimit) * 100));

  const delta = entry.ratingDelta || 0;
  const isPositive = delta > 0;
  const dateFormatted = new Date(entry.timestamp).toLocaleString(undefined, {
    dateStyle: 'medium',
    timeStyle: 'short',
  });

  const ops: Array<{ op: '+' | '-' | '*' | '/'; sym: string }> = [
    { op: '+', sym: '+' },
    { op: '-', sym: '-' },
    { op: '*', sym: '×' },
    { op: '/', sym: '÷' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs select-none">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className={`px-2.5 py-1 rounded-lg text-xs font-bold uppercase tracking-wider ${
              entry.won ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300' : 'bg-red-50 dark:bg-red-950/50 text-red-700 dark:text-red-300'
            }`}>
              {entry.won ? 'Solved' : 'Time Up'}
            </span>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-slate-100">
                Level {entry.level} <span className="text-xs text-slate-400 font-normal">({entry.gridSize}×{entry.gridSize})</span>
              </h2>
              <p className="text-[11px] text-slate-400">{dateFormatted}</p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button type="button" disabled={currentIndex >= totalEntries - 1} onClick={onPrev} className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-30 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer" title="Previous Level">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button type="button" disabled={currentIndex <= 0} onClick={onNext} className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-30 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer" title="Next Level">
              <ChevronRight className="w-4 h-4" />
            </button>
            <button type="button" onClick={onClose} className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer ml-1" title="Close">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scrollable content */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 text-xs font-sans">
          {/* Rating & Time Progress */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="text-[11px] text-slate-400">Rating Progression</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-lg font-bold font-mono text-slate-800 dark:text-slate-100">{entry.ratingAfter}</span>
                <span className={`inline-flex items-center text-xs font-bold font-mono ${isPositive ? 'text-emerald-500' : delta < 0 ? 'text-red-500' : 'text-slate-400'}`}>
                  {isPositive ? <TrendingUp className="w-3 h-3 mr-0.5" /> : delta < 0 ? <TrendingDown className="w-3 h-3 mr-0.5" /> : null}
                  {isPositive ? `+${delta}` : delta}
                </span>
              </div>
              <span className="text-[10px] text-slate-400">From {entry.ratingBefore}</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="text-[11px] text-slate-400">Time Usage</span>
              <div className="flex items-baseline gap-1 mt-1 font-mono font-bold text-slate-800 dark:text-slate-100 text-base">
                <span>{formatTime(entry.elapsedSeconds)}</span>
                <span className="text-xs font-normal text-slate-400">/ {formatTime(timeLimit)}</span>
              </div>
              <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden mt-2">
                <div className={`h-full rounded-full ${timePercent <= 60 ? 'bg-emerald-500' : timePercent <= 85 ? 'bg-amber-500' : 'bg-red-500'}`} style={{ width: `${timePercent}%` }} />
              </div>
            </div>
          </div>

          {/* Stats Bar */}
          <div className="grid grid-cols-3 gap-2 text-center p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
            <div>
              <div className="text-[10px] text-slate-400">Hints</div>
              <div className="font-mono font-bold text-slate-700 dark:text-slate-200 mt-0.5">{entry.hintsUsed || 0} / 3</div>
            </div>
            <div>
              <div className="text-[10px] text-slate-400">Mistakes</div>
              <div className="font-mono font-bold text-slate-700 dark:text-slate-200 mt-0.5">{entry.mistakes || 0}</div>
            </div>
            <div>
              <div className="text-[10px] text-slate-400">Calculator</div>
              <div className="font-mono font-bold text-slate-700 dark:text-slate-200 mt-0.5">{entry.calculatorUses || 0}</div>
            </div>
          </div>

          {/* Operator mistakes */}
          <div>
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 block mb-1.5">Operator Breakdown (Mistakes)</span>
            <div className="grid grid-cols-4 gap-2">
              {ops.map(({ op, sym }) => {
                const mis = entry.operatorMistakes?.[op] ?? 0;
                const exp = entry.operatorExposure?.[op] ?? 0;
                return (
                  <div key={op} className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 text-center bg-white dark:bg-slate-900">
                    <span className="font-bold font-mono text-base text-slate-800 dark:text-slate-200">{sym}</span>
                    <div className="text-[10px] text-slate-400 mt-0.5 font-mono">
                      {mis > 0 ? <span className="text-red-500 font-bold">{mis} err</span> : entry.won ? <span className="text-emerald-500 font-medium">Clean</span> : <span className="text-slate-400 font-medium">0 err</span>}
                    </div>
                    {exp > 0 && <span className="text-[9px] text-slate-400 font-mono block">exp: {exp}</span>}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Telemetry Chips */}
          {(entry.firstInputSec !== undefined || entry.longGaps !== undefined || entry.editCount !== undefined) && (
            <div className="flex flex-wrap gap-1.5 pt-1">
              {entry.firstInputSec !== undefined && (
                <span className="px-2 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-[10px] text-slate-600 dark:text-slate-300 font-mono">
                  First input: {entry.firstInputSec}s
                </span>
              )}
              {entry.longGaps !== undefined && (
                <span className="px-2 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-[10px] text-slate-600 dark:text-slate-300 font-mono">
                  Idle gaps ≥15s: {entry.longGaps}
                </span>
              )}
              {entry.editCount !== undefined && (
                <span className="px-2 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-[10px] text-slate-600 dark:text-slate-300 font-mono">
                  Edits: {entry.editCount}
                </span>
              )}
              {entry.inputKind && (
                <span className="px-2 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-[10px] text-slate-600 dark:text-slate-300 font-mono uppercase">
                  Input: {entry.inputKind}
                </span>
              )}
            </div>
          )}

          {/* Row & Cell Timing Breakdown */}
          {(entry.cellSolveSec || entry.rowSolveSec) && (
            <LevelTimingPills
              cellSolveSec={entry.cellSolveSec}
              rowSolveSec={entry.rowSolveSec}
              gridSize={entry.gridSize}
            />
          )}

          {/* Star Checklist */}
          {entry.mode === 'star' && (
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  Star Checklist ({starData.starsEarned} Stars)
                </span>
              </div>
              <div className="space-y-1.5">
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">3-Star Requirements</div>
                <div className="grid grid-cols-2 gap-1.5">
                  {starData.threeStar.map((chk) => (
                    <div key={chk.label} className="flex items-center justify-between p-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800">
                      <span className="text-[10px] text-slate-600 dark:text-slate-300 truncate">{chk.label}</span>
                      {chk.passed ? <CheckCircle className="w-3 h-3 text-emerald-500 shrink-0 ml-1" /> : <XCircle className="w-3 h-3 text-slate-300 dark:text-slate-600 shrink-0 ml-1" />}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2 bg-slate-50/50 dark:bg-slate-900/50">
          <button type="button" onClick={onClose} className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer">
            Close
          </button>
          {onPlayNext && (
            <button type="button" onClick={() => onPlayNext(entry)} className="flex items-center gap-1.5 px-5 py-2 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 dark:bg-amber-500 dark:hover:bg-amber-600 dark:text-slate-950 shadow-sm transition-all cursor-pointer">
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Next Level</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
