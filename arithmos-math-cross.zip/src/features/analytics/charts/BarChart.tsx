import React, { useState } from 'react';
import { scaleLinear } from './chartUtils';

export interface BarGroup {
  label: string;
  values: { name: string; value: number; color: string }[];
}

interface BarChartProps {
  groups: BarGroup[];
  yUnit?: string;
  darkMode?: boolean;
}

export const BarChart: React.FC<BarChartProps> = ({
  groups,
  yUnit = '',
  darkMode = false,
}) => {
  const [activeBar, setActiveBar] = useState<{
    groupLabel: string;
    name: string;
    value: number;
    px: number;
    py: number;
  } | null>(null);

  if (groups.length === 0) return null;

  const width = 460;
  const height = 180;
  const padL = 36;
  const padR = 20;
  const padT = 16;
  const padB = 30;

  const allVals = groups.flatMap((g) => g.values.map((v) => v.value));
  const maxVal = Math.max(1, ...allVals);

  const seriesNames = groups[0]?.values.map((v) => ({ name: v.name, color: v.color })) || [];

  const groupWidth = (width - padL - padR) / groups.length;
  const barCount = seriesNames.length || 1;
  const barWidth = Math.min(22, (groupWidth * 0.7) / barCount);
  const groupInnerWidth = barWidth * barCount + (barCount - 1) * 2;

  const getY = (val: number) => scaleLinear(val, 0, maxVal, height - padB, padT);

  // Y-axis ticks
  const yTicks = [0, Math.round(maxVal / 2), maxVal];

  return (
    <div className="relative w-full select-none">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto overflow-visible font-sans">
        {/* Horizontal grid lines */}
        {yTicks.map((val) => {
          const y = getY(val);
          return (
            <g key={val}>
              <line
                x1={padL}
                y1={y}
                x2={width - padR}
                y2={y}
                stroke={darkMode ? '#334155' : '#e2e8f0'}
                strokeWidth="1"
                strokeDasharray="2 2"
              />
              <text
                x={padL - 6}
                y={y + 3}
                textAnchor="end"
                className="text-[9px] fill-slate-400 dark:fill-slate-500 font-mono"
              >
                {val}
              </text>
            </g>
          );
        })}

        {/* Groups & Bars */}
        {groups.map((grp, gIdx) => {
          const groupCenterX = padL + gIdx * groupWidth + groupWidth / 2;
          const startX = groupCenterX - groupInnerWidth / 2;

          return (
            <g key={grp.label}>
              {/* Group label */}
              <text
                x={groupCenterX}
                y={height - padB + 16}
                textAnchor="middle"
                className="text-[10px] font-medium fill-slate-600 dark:fill-slate-400"
              >
                {grp.label}
              </text>

              {/* Bars */}
              {grp.values.map((v, vIdx) => {
                const barX = startX + vIdx * (barWidth + 2);
                const barY = getY(v.value);
                const barH = Math.max(0, height - padB - barY);

                return (
                  <rect
                    key={v.name}
                    x={barX}
                    y={barY}
                    width={barWidth}
                    height={barH}
                    rx="3"
                    ry="3"
                    fill={v.color}
                    className="cursor-pointer transition-opacity hover:opacity-85"
                    onMouseEnter={() =>
                      setActiveBar({
                        groupLabel: grp.label,
                        name: v.name,
                        value: v.value,
                        px: barX + barWidth / 2,
                        py: barY,
                      })
                    }
                    onMouseLeave={() => setActiveBar(null)}
                  />
                );
              })}
            </g>
          );
        })}

        {/* Tooltip */}
        {activeBar && (
          <g transform={`translate(${Math.min(activeBar.px, width - 70)}, ${Math.max(activeBar.py - 25, 20)})`}>
            <rect
              x="-15"
              y="-14"
              width="90"
              height="28"
              rx="4"
              fill={darkMode ? '#1e293b' : '#0f172a'}
              fillOpacity="0.95"
            />
            <text x="30" y="-2" textAnchor="middle" className="text-[9px] fill-slate-300 font-sans">
              {activeBar.groupLabel} · {activeBar.name}
            </text>
            <text x="30" y="9" textAnchor="middle" className="text-[10px] font-bold fill-amber-300 font-sans">
              {activeBar.value}
              {yUnit}
            </text>
          </g>
        )}
      </svg>

      {/* Legend */}
      <div className="flex flex-wrap items-center justify-center gap-4 mt-2 pt-1 border-t border-slate-100 dark:border-slate-800/60">
        {seriesNames.map((s) => (
          <div key={s.name} className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400">
            <span
              className="inline-block w-2.5 h-2.5 rounded-sm"
              style={{ backgroundColor: s.color }}
            />
            <span>{s.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
