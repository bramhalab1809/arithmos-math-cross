import React, { useState } from 'react';

export interface DonutSegment {
  label: string;
  value: number;
  color: string;
}

interface DonutChartProps {
  segments: DonutSegment[];
  centerLabel?: string;
  centerSublabel?: string;
  darkMode?: boolean;
}

export const DonutChart: React.FC<DonutChartProps> = ({
  segments,
  centerLabel,
  centerSublabel = 'Total',
}) => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  const total = segments.reduce((sum, s) => sum + s.value, 0);
  if (total === 0) return null;

  const size = 160;
  const strokeWidth = 22;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;

  let accumulatedLength = 0;

  return (
    <div className="flex flex-col sm:flex-row items-center justify-center gap-6 py-2 select-none">
      <div className="relative w-[150px] h-[150px] shrink-0">
        <svg viewBox={`0 0 ${size} ${size}`} className="w-full h-full -rotate-90">
          {/* Base track */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="currentColor"
            strokeWidth={strokeWidth}
            className="text-slate-100 dark:text-slate-800"
          />

          {/* Segments */}
          {segments.map((seg, idx) => {
            const fraction = seg.value / total;
            const arcLength = fraction * circumference;
            const strokeOffset = -accumulatedLength;
            accumulatedLength += arcLength;

            const isHovered = hoveredIdx === idx;

            return (
              <circle
                key={seg.label}
                cx={size / 2}
                cy={size / 2}
                r={radius}
                fill="none"
                stroke={seg.color}
                strokeWidth={isHovered ? strokeWidth + 4 : strokeWidth}
                strokeDasharray={`${arcLength} ${circumference - arcLength}`}
                strokeDashoffset={strokeOffset}
                className="transition-all duration-200 cursor-pointer"
                onMouseEnter={() => setHoveredIdx(idx)}
                onMouseLeave={() => setHoveredIdx(null)}
              />
            );
          })}
        </svg>

        {/* Center label */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <span className="text-xl font-bold font-mono text-slate-800 dark:text-slate-100">
            {hoveredIdx !== null ? segments[hoveredIdx].value : centerLabel || total}
          </span>
          <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">
            {hoveredIdx !== null ? segments[hoveredIdx].label : centerSublabel}
          </span>
        </div>
      </div>

      {/* Legend with percentages */}
      <div className="flex flex-col gap-2 min-w-[130px]">
        {segments.map((seg, idx) => {
          const pct = Math.round((seg.value / total) * 100);
          const isHovered = hoveredIdx === idx;

          return (
            <div
              key={seg.label}
              onMouseEnter={() => setHoveredIdx(idx)}
              onMouseLeave={() => setHoveredIdx(null)}
              className={`flex items-center justify-between gap-3 text-xs p-1 rounded-md transition-colors cursor-pointer ${
                isHovered ? 'bg-slate-100 dark:bg-slate-800' : ''
              }`}
            >
              <div className="flex items-center gap-2">
                <span
                  className="w-2.5 h-2.5 rounded-full shrink-0"
                  style={{ backgroundColor: seg.color }}
                />
                <span className="text-slate-700 dark:text-slate-300 font-medium">{seg.label}</span>
              </div>
              <div className="text-slate-500 dark:text-slate-400 font-mono text-right tabular-nums">
                <span>{seg.value}</span>
                <span className="text-[10px] ml-1 opacity-75">({pct}%)</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
