import React, { useState } from 'react';
import { Table, BarChart3, Info } from '../../../icons';

interface ChartFrameProps {
  title: string;
  subtitle?: string;
  icon?: React.ReactNode;
  isEmpty?: boolean;
  emptyMessage?: string;
  tableComponent?: React.ReactNode;
  children: React.ReactNode;
}

export const ChartFrame: React.FC<ChartFrameProps> = ({
  title,
  subtitle,
  icon,
  isEmpty = false,
  emptyMessage = 'No games recorded yet',
  tableComponent,
  children,
}) => {
  const [showTable, setShowTable] = useState(false);

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col justify-between shadow-xs transition-colors">
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-2">
          {icon && <span className="text-slate-500 dark:text-slate-400">{icon}</span>}
          <div>
            <h3 className="text-sm font-semibold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
              {title}
            </h3>
            {subtitle && (
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{subtitle}</p>
            )}
          </div>
        </div>

        {tableComponent && !isEmpty && (
          <button
            type="button"
            onClick={() => setShowTable((prev) => !prev)}
            aria-label={showTable ? 'Switch to chart view' : 'Switch to accessible table view'}
            className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            title={showTable ? 'Show Chart' : 'Show Table'}
          >
            {showTable ? <BarChart3 className="w-4 h-4" /> : <Table className="w-4 h-4" />}
          </button>
        )}
      </div>

      <div className="w-full flex-1 flex flex-col justify-center min-h-[160px]">
        {isEmpty ? (
          <div className="flex flex-col items-center justify-center py-8 text-center text-slate-400 dark:text-slate-500">
            <Info className="w-8 h-8 mb-2 opacity-50" />
            <p className="text-xs">{emptyMessage}</p>
          </div>
        ) : showTable && tableComponent ? (
          <div className="w-full overflow-x-auto max-h-[220px] text-xs py-1">{tableComponent}</div>
        ) : (
          children
        )}
      </div>
    </div>
  );
};
