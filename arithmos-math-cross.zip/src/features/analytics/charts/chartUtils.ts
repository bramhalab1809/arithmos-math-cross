export function scaleLinear(
  value: number,
  domainMin: number,
  domainMax: number,
  rangeMin: number,
  rangeMax: number
): number {
  if (domainMax === domainMin) return (rangeMin + rangeMax) / 2;
  const ratio = (value - domainMin) / (domainMax - domainMin);
  return rangeMin + ratio * (rangeMax - rangeMin);
}

export function formatTime(seconds: number): string {
  const safe = Math.max(0, Math.round(seconds));
  const m = Math.floor(safe / 60);
  const s = safe % 60;
  if (m === 0) return `${s}s`;
  return `${m}m ${s}s`;
}

export function formatNumber(n: number): string {
  return new Intl.NumberFormat('en-US').format(n);
}

export interface MarkerProps {
  x: number;
  y: number;
  shape: 'circle' | 'square' | 'triangle';
  color: string;
  size?: number;
}

export function renderMarkerShape({ x, y, shape, color, size = 6 }: MarkerProps) {
  const half = size / 2;
  if (shape === 'square') {
    return {
      type: 'rect' as const,
      props: {
        x: x - half,
        y: y - half,
        width: size,
        height: size,
        fill: color,
        rx: 1,
      },
    };
  }
  if (shape === 'triangle') {
    const points = `${x},${y - half} ${x - half},${y + half} ${x + half},${y + half}`;
    return {
      type: 'polygon' as const,
      props: {
        points,
        fill: color,
      },
    };
  }
  return {
    type: 'circle' as const,
    props: {
      cx: x,
      cy: y,
      r: half,
      fill: color,
    },
  };
}

export const CHART_THEME = {
  light: {
    bg: '#ffffff',
    grid: '#e2e8f0',
    text: '#334155',
    subtext: '#64748b',
    primary: '#2563eb', // Blue 600
    secondary: '#8b5cf6', // Violet 500
    tertiary: '#06b6d4', // Cyan 500
    success: '#10b981', // Emerald 500
    danger: '#ef4444', // Red 500
    par: '#64748b',
    heatmap: ['#f1f5f9', '#93c5fd', '#3b82f6', '#1d4ed8'],
  },
  dark: {
    bg: '#0b0f17',
    grid: '#1e293b',
    text: '#cbd5e1',
    subtext: '#94a3b8',
    primary: '#f59e0b', // Amber 500
    secondary: '#ec4899', // Pink 500
    tertiary: '#38bdf8', // Sky 400
    success: '#10b981', // Emerald 500
    danger: '#f43f5e', // Rose 500
    par: '#94a3b8',
    heatmap: ['#1e293b', '#b45309', '#f59e0b', '#fbbf24'],
  },
};
