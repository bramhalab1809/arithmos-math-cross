import React, { useState } from 'react';
import { DayActivity } from '../selectors/activity';
import { CHART_THEME } from './chartUtils';

interface HeatmapProps {
  days: DayActivity[];
  darkMode?: boolean;
}

export const Heatmap: React.FC<HeatmapProps> = ({ days, darkMode = false }) => {
  const [activeCell, setActiveCell] = useState<{
    date: string;
    count: number;
    wins: number;
    px: number;
    py: number;
  } | null>(null);

  const colors = darkMode ? CHART_THEME.dark.heatmap : CHART_THEME.light.heatmap;

  const getColor = (count: number) => {
    if (count === 0) return colors[0];
    if (count <= 2) return colors[1];
    if (count <= 5) return colors[2];
    return colors[3];
  };

  // Organize 84 days into 12 weeks of 7 days
  const cellSize = 12;
  const cellGap = 3;
  const padL = 24;
  const padT = 16;
  const width = padL + 12 * (cellSize + cellGap) + 10;
  const height = padT + 7 * (cellSize + cellGap) + 10;

  // Day of week labels for rows: Mon (1), Wed (3), Fri (5)
  const dayLabels = [
    { row: 1, text: 'M' },
    { row: 3, text: 'W' },
    { row: 5, text: 'F' },
  ];

  return (
    <div className="flex flex-col items-center justify-center w-full py-2 select-none">
      <div className="relative overflow-visible">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full max-w-[320px] h-auto overflow-visible font-sans">
          {/* Row day labels */}
          {dayLabels.map((lbl) => (
            <text
              key={lbl.row}
              x={padL - 6}
              y={padT + lbl.row * (cellSize + cellGap) + cellSize - 2}
              textAnchor="end"
              className="text-[9px] fill-slate-400 dark:fill-slate-500 font-mono"
            >
              {lbl.text}
            </text>
          ))}

          {/* Grid of days */}
          {days.map((day, i) => {
            const weekCol = Math.floor(i / 7);
            const dayRow = day.dayOfWeek;
            const x = padL + weekCol * (cellSize + cellGap);
            const y = padT + dayRow * (cellSize + cellGap);

            return (
              <rect
                key={day.date}
                x={x}
                y={y}
                width={cellSize}
                height={cellSize}
                rx="2"
                ry="2"
                fill={getColor(day.count)}
                className="cursor-pointer transition-opacity hover:opacity-80"
                onMouseEnter={() =>
                  setActiveCell({
                    date: day.date,
                    count: day.count,
                    wins: day.wins,
                    px: x + cellSize / 2,
                    py: y,
                  })
                }
                onMouseLeave={() => setActiveCell(null)}
              />
            );
          })}

          {/* Tooltip */}
          {activeCell && (
            <g transform={`translate(${Math.max(10, Math.min(activeCell.px - 45, width - 100))}, ${Math.max(0, activeCell.py - 24)})`}>
              <rect
                x="0"
                y="0"
                width="96"
                height="22"
                rx="4"
                fill={darkMode ? '#1e293b' : '#0f172a'}
                fillOpacity="0.95"
              />
              <text x="48" y="14" textAnchor="middle" className="text-[9px] fill-white font-mono">
                {activeCell.date}: {activeCell.count} ({activeCell.wins}W)
              </text>
            </g>
          )}
        </svg>
      </div>

      {/* Legend */}
      <div className="flex items-center justify-center gap-2 mt-3 text-[10px] text-slate-500 dark:text-slate-400">
        <span>Less</span>
        <div className="flex items-center gap-1">
          {colors.map((c, i) => (
            <span
              key={i}
              className="w-2.5 h-2.5 rounded-xs"
              style={{ backgroundColor: c }}
            />
          ))}
        </div>
        <span>More</span>
      </div>
    </div>
  );
};
