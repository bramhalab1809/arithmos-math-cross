import React, { useState } from 'react';
import { scaleLinear } from './chartUtils';

export interface LineSeries {
  id: string;
  name: string;
  color: string;
  dash?: string;
  shape?: 'circle' | 'square' | 'triangle';
  data: { x: number; y: number; label?: string; sublabel?: string }[];
}

interface LineChartProps {
  series: LineSeries[];
  xLabel?: string;
  yLabel?: string;
  yUnit?: string;
  darkMode?: boolean;
}

export const LineChart: React.FC<LineChartProps> = ({
  series,
  yUnit = '',
  darkMode = false,
}) => {
  const [activePoint, setActivePoint] = useState<{
    seriesName: string;
    label: string;
    value: number;
    sublabel?: string;
    px: number;
    py: number;
  } | null>(null);

  const allPoints = series.flatMap((s) => s.data);
  if (allPoints.length === 0) return null;

  const width = 460;
  const height = 180;
  const padL = 36;
  const padR = 20;
  const padT = 16;
  const padB = 28;

  const minX = Math.min(...allPoints.map((p) => p.x));
  const maxX = Math.max(...allPoints.map((p) => p.x));
  const minY = Math.min(0, ...allPoints.map((p) => p.y));
  const maxY = Math.max(...allPoints.map((p) => p.y), 10);

  const getX = (x: number) => scaleLinear(x, minX, maxX || minX + 1, padL, width - padR);
  const getY = (y: number) => scaleLinear(y, minY, maxY, height - padB, padT);

  // Y-axis ticks (3 ticks: min, mid, max)
  const yTicks = [minY, Math.round((minY + maxY) / 2), maxY];

  return (
    <div className="relative w-full select-none">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-auto overflow-visible font-mono"
      >
        {/* Horizontal grid lines */}
        {yTicks.map((val) => {
          const y = getY(val);
          return (
            <g key={val}>
              <line
                x1={padL}
                y1={y}
                x2={width - padR}
                y2={y}
                stroke={darkMode ? '#334155' : '#e2e8f0'}
                strokeWidth="1"
                strokeDasharray="2 2"
              />
              <text
                x={padL - 6}
                y={y + 3}
                textAnchor="end"
                className="text-[9px] fill-slate-400 dark:fill-slate-500 font-sans"
              >
                {val}
              </text>
            </g>
          );
        })}

        {/* Lines and Markers */}
        {series.map((s) => {
          if (s.data.length === 0) return null;
          const pathD = s.data.reduce((acc, pt, i) => {
            const x = getX(pt.x);
            const y = getY(pt.y);
            return i === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
          }, '');

          return (
            <g key={s.id}>
              <path
                d={pathD}
                fill="none"
                stroke={s.color}
                strokeWidth="2.2"
                strokeDasharray={s.dash}
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {s.data.map((pt, i) => {
                const px = getX(pt.x);
                const py = getY(pt.y);
                const isOnly = s.data.length < 30 || i % Math.ceil(s.data.length / 25) === 0 || i === s.data.length - 1;
                if (!isOnly) return null;

                return (
                  <circle
                    key={i}
                    cx={px}
                    cy={py}
                    r={3.5}
                    fill={s.color}
                    stroke={darkMode ? '#0b0f17' : '#ffffff'}
                    strokeWidth="1.5"
                    className="cursor-pointer transition-transform hover:scale-150"
                    onMouseEnter={() =>
                      setActivePoint({
                        seriesName: s.name,
                        label: pt.label || `Level ${pt.x}`,
                        value: pt.y,
                        sublabel: pt.sublabel,
                        px,
                        py,
                      })
                    }
                    onMouseLeave={() => setActivePoint(null)}
                  />
                );
              })}
            </g>
          );
        })}

        {/* Tooltip */}
        {activePoint && (
          <g transform={`translate(${Math.min(activePoint.px, width - 80)}, ${Math.max(activePoint.py - 25, 20)})`}>
            <rect
              x="-6"
              y="-14"
              width="90"
              height="28"
              rx="4"
              fill={darkMode ? '#1e293b' : '#0f172a'}
              fillOpacity="0.95"
            />
            <text x="39" y="-2" textAnchor="middle" className="text-[9px] fill-white font-medium font-sans">
              {activePoint.label}
            </text>
            <text x="39" y="9" textAnchor="middle" className="text-[10px] font-bold fill-amber-300 font-sans">
              {activePoint.value}
              {yUnit}
            </text>
          </g>
        )}
      </svg>

      {/* Legend */}
      <div className="flex flex-wrap items-center justify-center gap-4 mt-2 pt-1 border-t border-slate-100 dark:border-slate-800/60">
        {series.map((s) => (
          <div key={s.id} className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400">
            <span
              className="inline-block w-3.5 h-1 rounded-full"
              style={{
                backgroundColor: s.color,
                borderTop: s.dash ? `1px dashed ${s.color}` : undefined,
              }}
            />
            <span>{s.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
