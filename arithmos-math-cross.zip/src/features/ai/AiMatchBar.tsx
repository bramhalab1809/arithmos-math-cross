import React, { useState } from 'react';
import { Bot, Check, Copy, Play, Sparkles, Zap } from '../../icons';
import { AiControllerState } from './useAiController';

interface AiMatchBarProps {
  darkMode: boolean;
  isMultiplayer: boolean;
  ai: AiControllerState;
  playerFilledCount: number;
}

export const AiMatchBar: React.FC<AiMatchBarProps> = ({
  darkMode,
  isMultiplayer,
  ai,
  playerFilledCount,
}) => {
  const [copiedBoard, setCopiedBoard] = useState(false);
  const [showPasteBox, setShowPasteBox] = useState(false);
  const [pasteText, setPasteText] = useState('');
  const [appliedMsg, setAppliedMsg] = useState<string | null>(null);

  if (!isMultiplayer) return null;

  const aiPct = Math.min(100, Math.round((ai.aiSolvedCount / ai.totalEditable) * 100));
  const playerPct = Math.min(100, Math.round((playerFilledCount / ai.totalEditable) * 100));

  const handleCopyBoard = () => {
    ai.copyBoardForAi();
    setCopiedBoard(true);
    setTimeout(() => setCopiedBoard(false), 1600);
  };

  const handleApplyMoves = () => {
    const count = ai.applyExternalMovesText(pasteText);
    setAppliedMsg(count > 0 ? `Applied ${count} move${count > 1 ? 's' : ''}!` : 'No valid R1C1=N moves found');
    if (count > 0) setPasteText('');
    setTimeout(() => setAppliedMsg(null), 2000);
  };

  return (
    <div
      className={`w-full max-w-4xl mx-auto px-3 py-2 rounded-2xl border transition-all ${
        darkMode ? 'bg-slate-900/90 border-slate-800 text-slate-100' : 'bg-white/95 border-slate-200 text-slate-900 shadow-xs'
      }`}
    >
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2.5 min-w-0 flex-1">
          <div className="p-1.5 rounded-xl bg-cyan-500/15 border border-cyan-500/30 text-cyan-400 shrink-0">
            <Bot className="w-4 h-4" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 text-xs font-bold flex-wrap">
              <span className="truncate">{ai.profile.name}</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-md bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 uppercase">
                {ai.matchMode === 'relay' ? 'Web AI Relay' : `Target ${ai.aiTargetLabel}`}
              </span>
              {ai.matchMode === 'duel' && (
                <span className="text-[10px] font-mono opacity-75">
                  AI {ai.aiSolvedCount}/{ai.totalEditable} vs You {playerFilledCount}/{ai.totalEditable}
                </span>
              )}
            </div>
            {ai.matchMode === 'duel' && (
              <div className="w-full h-1.5 rounded-full bg-slate-800/50 overflow-hidden mt-1 flex">
                <div className="h-full bg-cyan-400 transition-all duration-300" style={{ width: `${aiPct}%` }} title={`AI: ${aiPct}%`} />
                <div className="h-full bg-emerald-400 transition-all duration-300" style={{ width: `${Math.max(0, playerPct - aiPct)}%` }} />
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            type="button"
            onClick={ai.triggerSingleAiStep}
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-semibold bg-cyan-500/15 border border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/25 cursor-pointer"
            title="Let AI fill one cell on the board"
          >
            <Zap className="w-3 h-3" />
            <span>AI Step</span>
          </button>

          <button
            type="button"
            onClick={() => ai.setAutoPlayActive(!ai.autoPlayActive)}
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-semibold border cursor-pointer ${
              ai.autoPlayActive
                ? 'bg-emerald-600 text-white border-emerald-500'
                : 'bg-purple-500/15 border-purple-500/30 text-purple-400 hover:bg-purple-500/25'
            }`}
            title="Toggle AI Auto-Play on this Multiplayer board"
          >
            <Play className="w-3 h-3 fill-current" />
            <span>{ai.autoPlayActive ? 'Auto-Playing' : 'AI Auto-Play'}</span>
          </button>

          <button
            type="button"
            onClick={handleCopyBoard}
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-semibold border cursor-pointer ${
              copiedBoard
                ? 'border-emerald-500 bg-emerald-500/20 text-emerald-400'
                : darkMode
                ? 'border-slate-700 bg-slate-800 text-slate-300'
                : 'border-slate-200 bg-slate-100 text-slate-700'
            }`}
            title="Copy live R/C board equations for Gemini, ChatGPT, or Claude"
          >
            {copiedBoard ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
            <span>{copiedBoard ? 'Copied Board!' : 'Copy Board for AI'}</span>
          </button>

          <button
            type="button"
            onClick={() => setShowPasteBox((v) => !v)}
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-semibold border cursor-pointer ${
              showPasteBox
                ? 'border-cyan-500 bg-cyan-500/20 text-cyan-300'
                : darkMode
                ? 'border-slate-700 bg-slate-800 text-slate-300'
                : 'border-slate-200 bg-slate-100 text-slate-700'
            }`}
          >
            <Sparkles className="w-3 h-3 text-cyan-400" />
            <span>Paste AI Move</span>
          </button>
        </div>
      </div>

      {showPasteBox && (
        <div className="mt-2 pt-2 border-t border-slate-200/40 dark:border-slate-800 flex items-center gap-2 flex-wrap">
          <input
            type="text"
            value={pasteText}
            onChange={(e) => setPasteText(e.target.value)}
            placeholder="Paste reply from Gemini / ChatGPT / Claude (e.g. R1C2=4, R2C1=2)..."
            className={`flex-1 text-xs font-mono px-2.5 py-1 rounded-xl border ${
              darkMode ? 'bg-slate-950 border-slate-800 text-slate-200' : 'bg-slate-50 border-slate-200 text-slate-800'
            }`}
          />
          <button
            type="button"
            onClick={handleApplyMoves}
            className="px-3 py-1 rounded-xl text-xs font-semibold bg-cyan-600 text-white hover:bg-cyan-500 cursor-pointer"
          >
            Apply Moves
          </button>
          {appliedMsg && <span className="text-[11px] font-mono text-emerald-400 font-semibold">{appliedMsg}</span>}
        </div>
      )}
    </div>
  );
};
