import { MathCrosswordPuzzle } from '../../engine/types';

export interface ParsedAiMove {
  row: number;
  col: number;
  value: number;
}

export function buildExternalAiAgentPrompt(): string {
  return `You are playing "Arithmos — Mathematical Crossword" with me as my live AI Opponent / Co-Pilot!

HOW THE BOARD WORKS:
- An N x N grid of positive integers has Row coordinates R1..RN (top to bottom) and Column coordinates C1..CN (left to right).
- Each row equation reads left-to-right: RrC1 (op) RrC2 ... = RrCN
- Each column equation reads top-to-bottom: R1Cc (op) R2Cc ... = RNCc
- Operator precedence is strictly left-to-right / top-to-bottom as written on the crossword grid.
- Empty cells are shown as [?]. Clue or filled cells show their integer value.

HOW TO REPLY WHEN I PASTE A BOARD STATE:
Whenever I paste a board state (or ask for your next move), reply with ONLY the cell coordinates and numbers in this exact compact format so I can paste your reply directly into Arithmos:

R1C2=4, R2C1=2

(You can provide 1 move for Turn-by-Turn mode, or all remaining empty cells to solve the entire board at once!)
Ready? Reply "READY FOR BOARD!" and wait for me to paste the first Arithmos board.`;
}

export function serializeBoardForExternalAi(puzzle: MathCrosswordPuzzle): string {
  const sz = puzzle.size;
  const lines: string[] = [];
  lines.push(`ARITHMOS BOARD (${sz}x${sz})`);
  lines.push(`Columns: ${Array.from({ length: sz }, (_, c) => `C${c + 1}`).join('  ')}`);
  lines.push('');

  for (let r = 0; r < sz; r++) {
    const rowTokens: string[] = [];
    for (let c = 0; c < sz; c++) {
      const cell = puzzle.cells[r][c];
      const val = cell.isClue ? String(cell.solution) : cell.userValue.trim() || '?';
      rowTokens.push(`R${r + 1}C${c + 1}:${val === '?' ? '[?]' : val}`);
      if (c < sz - 2) {
        rowTokens.push(puzzle.rowOps[r][c]);
      } else if (c === sz - 2) {
        rowTokens.push('=');
      }
    }
    lines.push(`Row R${r + 1}: ${rowTokens.join(' ')}`);
  }

  lines.push('');
  for (let c = 0; c < sz; c++) {
    const colTokens: string[] = [];
    for (let r = 0; r < sz; r++) {
      const cell = puzzle.cells[r][c];
      const val = cell.isClue ? String(cell.solution) : cell.userValue.trim() || '?';
      colTokens.push(val === '?' ? '[?]' : val);
      if (r < sz - 2) {
        colTokens.push(puzzle.colOps[r][c]);
      } else if (r === sz - 2) {
        colTokens.push('=');
      }
    }
    lines.push(`Col C${c + 1}: ${colTokens.join(' ')}`);
  }

  lines.push('');
  lines.push('Reply with moves in format: R1C2=4, R2C1=2');
  return lines.join('\n');
}

export function parseExternalAiMoves(rawText: string, puzzle: MathCrosswordPuzzle): ParsedAiMove[] {
  const moves: ParsedAiMove[] = [];
  if (!rawText || !rawText.trim()) return moves;

  const regex = /R(\d+)\s*C(\d+)\s*[=:]\s*(\d+)/gi;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(rawText)) !== null) {
    const r = parseInt(match[1], 10) - 1;
    const c = parseInt(match[2], 10) - 1;
    const val = parseInt(match[3], 10);
    if (
      r >= 0 &&
      r < puzzle.size &&
      c >= 0 &&
      c < puzzle.size &&
      Number.isFinite(val) &&
      val > 0 &&
      !puzzle.cells[r][c].isClue
    ) {
      moves.push({ row: r, col: c, value: val });
    }
  }

  if (moves.length > 0) return moves;

  try {
    const cleaned = rawText.replace(/```(?:json)?/gi, '').replace(/```/g, '').trim();
    const parsed = JSON.parse(cleaned);
    const arr = Array.isArray(parsed) ? parsed : Array.isArray(parsed?.moves) ? parsed.moves : [];
    for (const item of arr) {
      const r = Number(item.row ?? item.r) - (item.oneBased ? 1 : 0);
      const c = Number(item.col ?? item.c) - (item.oneBased ? 1 : 0);
      const val = Number(item.value ?? item.val);
      if (r >= 0 && r < puzzle.size && c >= 0 && c < puzzle.size && val > 0 && !puzzle.cells[r][c].isClue) {
        moves.push({ row: r, col: c, value: val });
      }
    }
  } catch {
    // ignore
  }

  return moves;
}
