export type AiProvider = 'gemini' | 'chatgpt' | 'claude' | 'custom';
export type AiStrategy = 'methodical' | 'speedster' | 'humanlike';
export type AiMatchMode = 'duel' | 'relay';

export interface AiAgentProfile {
  id: string;
  name: string;
  provider: AiProvider;
  strategy: AiStrategy;
  stepDelayMs: number;
  accuracy: number;
  isBuiltIn?: boolean;
}

const STORAGE_PROFILES_KEY = 'arithmos_v1_ai_profiles';
const STORAGE_ACTIVE_ID_KEY = 'arithmos_v1_ai_active_id';
const STORAGE_MATCH_MODE_KEY = 'arithmos_v1_ai_match_mode';

export const BUILT_IN_AI_PROFILES: AiAgentProfile[] = [
  {
    id: 'ai_gemini_flash',
    name: 'Gemini 2.5 Flash',
    provider: 'gemini',
    strategy: 'speedster',
    stepDelayMs: 3200,
    accuracy: 0.96,
    isBuiltIn: true,
  },
  {
    id: 'ai_chatgpt_o3',
    name: 'ChatGPT o3-Mini',
    provider: 'chatgpt',
    strategy: 'methodical',
    stepDelayMs: 4200,
    accuracy: 0.98,
    isBuiltIn: true,
  },
  {
    id: 'ai_claude_sonnet',
    name: 'Claude 3.7 Sonnet',
    provider: 'claude',
    strategy: 'humanlike',
    stepDelayMs: 3800,
    accuracy: 0.95,
    isBuiltIn: true,
  },
];

export function loadAiProfiles(): AiAgentProfile[] {
  try {
    localStorage.removeItem('arithmos_v1_ai_copilot');
    const raw = localStorage.getItem(STORAGE_PROFILES_KEY);
    if (!raw) return BUILT_IN_AI_PROFILES;
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return BUILT_IN_AI_PROFILES;
    const custom = parsed.filter((p) => p && typeof p.id === 'string' && !p.isBuiltIn);
    return [...BUILT_IN_AI_PROFILES, ...custom];
  } catch {
    return BUILT_IN_AI_PROFILES;
  }
}

export function saveCustomAiProfile(profile: AiAgentProfile): AiAgentProfile[] {
  const all = loadAiProfiles().filter((p) => !p.isBuiltIn && p.id !== profile.id);
  const next = [...all, { ...profile, isBuiltIn: false }];
  try {
    localStorage.setItem(STORAGE_PROFILES_KEY, JSON.stringify(next));
  } catch {}
  return [...BUILT_IN_AI_PROFILES, ...next];
}

export function deleteCustomAiProfile(id: string): AiAgentProfile[] {
  const custom = loadAiProfiles().filter((p) => !p.isBuiltIn && p.id !== id);
  try {
    localStorage.setItem(STORAGE_PROFILES_KEY, JSON.stringify(custom));
  } catch {}
  return [...BUILT_IN_AI_PROFILES, ...custom];
}

export function getActiveAiProfile(): AiAgentProfile {
  const all = loadAiProfiles();
  try {
    const id = localStorage.getItem(STORAGE_ACTIVE_ID_KEY);
    return all.find((p) => p.id === id) || all[0];
  } catch {
    return all[0];
  }
}

export function setActiveAiProfile(id: string): void {
  try {
    localStorage.setItem(STORAGE_ACTIVE_ID_KEY, id);
  } catch {}
}

export function getActiveMatchMode(): AiMatchMode {
  try {
    return localStorage.getItem(STORAGE_MATCH_MODE_KEY) === 'relay' ? 'relay' : 'duel';
  } catch {
    return 'duel';
  }
}

export function setActiveMatchMode(mode: AiMatchMode): void {
  try {
    localStorage.setItem(STORAGE_MATCH_MODE_KEY, mode);
  } catch {}
}
