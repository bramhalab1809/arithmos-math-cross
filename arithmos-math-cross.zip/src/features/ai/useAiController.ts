import { useCallback, useEffect, useRef, useState } from 'react';
import { soundEngine } from '../../audio/soundEngine';
import { GameAction, GameSessionState } from '../game/state/gameTypes';
import { AiAgentProfile, AiMatchMode, getActiveAiProfile, getActiveMatchMode } from './aiTypes';
import { parseExternalAiMoves, serializeBoardForExternalAi } from './aiBridgePrompt';

export interface AiControllerState {
  profile: AiAgentProfile;
  matchMode: AiMatchMode;
  aiSolvedCount: number;
  totalEditable: number;
  aiTargetLabel: string;
  aiFinished: boolean;
  autoPlayActive: boolean;
  setAutoPlayActive: (val: boolean) => void;
  triggerSingleAiStep: () => void;
  applyExternalMovesText: (raw: string) => number;
  copyBoardForAi: () => string;
}

export function useAiController(
  state: GameSessionState,
  dispatch: React.Dispatch<GameAction>,
  onCellInputChange: (row: number, col: number, val: string) => void
): AiControllerState {
  const [profile, setProfile] = useState<AiAgentProfile>(() => getActiveAiProfile());
  const [matchMode, setMatchMode] = useState<AiMatchMode>(() => getActiveMatchMode());
  const [aiSolvedCount, setAiSolvedCount] = useState(0);
  const [aiTargetLabel, setAiTargetLabel] = useState('R1C1');
  const [autoPlayActive, setAutoPlayActive] = useState(false);

  const puzzle = state.puzzle;
  const isMultiplayer = state.mode === 'multiplayer';
  const isPlaying = state.gameState === 'PLAYING';
  const announcedFinishRef = useRef(false);

  const editableCoords = useRef<Array<{ row: number; col: number; solution: number }>>([]);
  useEffect(() => {
    setProfile(getActiveAiProfile());
    setMatchMode(getActiveMatchMode());
    announcedFinishRef.current = false;
    const coords: Array<{ row: number; col: number; solution: number }> = [];
    for (let r = 0; r < puzzle.size; r++) {
      for (let c = 0; c < puzzle.size; c++) {
        if (!puzzle.cells[r][c].isClue) {
          coords.push({ row: r, col: c, solution: puzzle.cells[r][c].solution });
        }
      }
    }
    editableCoords.current = coords;
    setAiSolvedCount(0);
    if (coords[0]) setAiTargetLabel(`R${coords[0].row + 1}C${coords[0].col + 1}`);
  }, [puzzle.id, state.retriesCount]);

  const triggerSingleAiStep = useCallback(() => {
    if (!isMultiplayer || state.gameState !== 'PLAYING') return;
    for (let r = 0; r < puzzle.size; r++) {
      for (let c = 0; c < puzzle.size; c++) {
        const cell = puzzle.cells[r][c];
        if (!cell.isClue && parseInt(cell.userValue, 10) !== cell.solution) {
          dispatch({ type: 'SET_FOCUS', pos: { row: r, col: c } });
          onCellInputChange(r, c, String(cell.solution));
          setAiTargetLabel(`R${r + 1}C${c + 1}`);
          return;
        }
      }
    }
  }, [isMultiplayer, puzzle, state.gameState, dispatch, onCellInputChange]);

  const applyExternalMovesText = useCallback(
    (raw: string): number => {
      if (!isMultiplayer) return 0;
      const moves = parseExternalAiMoves(raw, puzzle);
      for (const m of moves) {
        dispatch({ type: 'SET_FOCUS', pos: { row: m.row, col: m.col } });
        onCellInputChange(m.row, m.col, String(m.value));
      }
      return moves.length;
    },
    [isMultiplayer, puzzle, dispatch, onCellInputChange]
  );

  const copyBoardForAi = useCallback((): string => {
    const text = serializeBoardForExternalAi(puzzle);
    navigator.clipboard?.writeText(text);
    return text;
  }, [puzzle]);

  // Multiplayer AI Opponent race ticker (ONLY in 'duel' mode)
  useEffect(() => {
    if (!isMultiplayer || !isPlaying || matchMode !== 'duel') return;
    const total = editableCoords.current.length;
    if (total === 0) return;

    const interval = window.setInterval(() => {
      setAiSolvedCount((prev) => {
        if (prev >= total) return total;
        const hit = Math.random() <= profile.accuracy;
        const next = hit ? prev + 1 : prev;
        const target = editableCoords.current[Math.min(next, total - 1)];
        if (target) setAiTargetLabel(`R${target.row + 1}C${target.col + 1}`);
        if (next >= total && !announcedFinishRef.current) {
          announcedFinishRef.current = true;
          soundEngine.playTimeWarning();
          dispatch({
            type: 'SET_BANNER',
            banner: {
              type: 'error',
              message: `${profile.name} finished the board first! Complete your cells or press Retry for a rematch.`,
            },
          });
        }
        return next;
      });
    }, profile.stepDelayMs);

    return () => window.clearInterval(interval);
  }, [isMultiplayer, isPlaying, matchMode, puzzle.id, profile.stepDelayMs, profile.accuracy, profile.name, dispatch]);

  // Multiplayer Auto-Play ticker
  useEffect(() => {
    if (!isMultiplayer || !autoPlayActive || !isPlaying) return;
    const timer = window.setInterval(() => {
      triggerSingleAiStep();
    }, Math.max(900, Math.round(profile.stepDelayMs * 0.55)));
    return () => window.clearInterval(timer);
  }, [isMultiplayer, autoPlayActive, isPlaying, profile.stepDelayMs, triggerSingleAiStep]);

  useEffect(() => {
    (window as unknown as Record<string, unknown>).arithmosAI = {
      getBoardText: () => serializeBoardForExternalAi(puzzle),
      applyMoves: (text: string) => applyExternalMovesText(text),
      step: () => triggerSingleAiStep(),
    };
  }, [puzzle, applyExternalMovesText, triggerSingleAiStep]);

  const totalEditable = editableCoords.current.length || 1;
  return {
    profile,
    matchMode,
    aiSolvedCount,
    totalEditable,
    aiTargetLabel,
    aiFinished: aiSolvedCount >= totalEditable,
    autoPlayActive,
    setAutoPlayActive,
    triggerSingleAiStep,
    applyExternalMovesText,
    copyBoardForAi,
  };
}
