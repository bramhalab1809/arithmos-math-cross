import React from 'react';

const SHORTCUTS: { key: string; label: string }[] = [
  { key: '0–9', label: 'Enter digit (0 clears)' },
  { key: 'Arrows', label: 'Navigate cells' },
  { key: 'Enter', label: 'Next cell' },
  { key: 'Backspace', label: 'Clear digit' },
  { key: 'D / Tab', label: 'Toggle axis' },
  { key: 'H (twice)', label: 'Hint' },
  { key: 'C (twice)', label: 'Check board' },
  { key: 'K', label: 'Calculator' },
  { key: 'Ctrl+Z', label: 'Undo' },
  { key: 'Esc', label: 'Pause / Resume' },
];

export const HelpSection: React.FC<{ darkMode: boolean }> = ({ darkMode }) => {
  return (
    <div className="space-y-2">
      <h3 className={`text-[11px] font-mono font-bold tracking-wider uppercase mb-1 ${
        darkMode ? 'text-amber-400' : 'text-blue-600'
      }`}>
        How to Play &amp; Shortcuts
      </h3>

      <div className={`p-2.5 rounded-xl border text-xs font-mono grid grid-cols-2 gap-1.5 ${
        darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-slate-50 border-slate-200'
      }`}>
        {SHORTCUTS.map((s) => (
          <div key={s.key} className="flex items-center justify-between gap-1 text-[11px]">
            <span className={`px-1 py-0.2 rounded font-bold border shrink-0 ${
              darkMode ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-200 text-slate-800'
            }`}>
              {s.key}
            </span>
            <span className="text-right text-slate-500 dark:text-slate-400 truncate">
              {s.label}
            </span>
          </div>
        ))}
      </div>

      <p className={`text-[11px] leading-tight ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
        Linear: Left-to-right and top-to-bottom evaluation.
      </p>
    </div>
  );
};
