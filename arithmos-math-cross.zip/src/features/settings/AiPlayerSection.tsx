import React, { useState } from 'react';
import { Bot, Check, Copy, ExternalLink, Plus, Trash2 } from '../../icons';
import {
  AiAgentProfile,
  AiProvider,
  AiStrategy,
  deleteCustomAiProfile,
  getActiveAiProfile,
  loadAiProfiles,
  saveCustomAiProfile,
  setActiveAiProfile,
} from '../ai/aiTypes';
import { buildExternalAiAgentPrompt } from '../ai/aiBridgePrompt';
import { SettingsFolder } from './SettingsFolder';

interface AiPlayerSectionProps {
  darkMode: boolean;
}

export const AiPlayerSection: React.FC<AiPlayerSectionProps> = ({ darkMode }) => {
  const [profiles, setProfiles] = useState<AiAgentProfile[]>(() => loadAiProfiles());
  const [activeId, setActiveId] = useState<string>(() => getActiveAiProfile().id);
  const [copiedBridge, setCopiedBridge] = useState(false);

  const [newName, setNewName] = useState('');
  const [newProvider, setNewProvider] = useState<AiProvider>('gemini');
  const [newStrategy, setNewStrategy] = useState<AiStrategy>('speedster');
  const [newDelaySec, setNewDelaySec] = useState<number>(3);

  const handleSelectProfile = (id: string) => {
    setActiveAiProfile(id);
    setActiveId(id);
  };

  const handleCreateAgent = () => {
    if (!newName.trim()) return;
    const created: AiAgentProfile = {
      id: `custom_ai_${Date.now().toString(36)}`,
      name: newName.trim(),
      provider: newProvider,
      strategy: newStrategy,
      stepDelayMs: Math.max(1000, Math.min(12000, Math.round(newDelaySec * 1000))),
      accuracy: 0.96,
      isBuiltIn: false,
    };
    const next = saveCustomAiProfile(created);
    setProfiles(next);
    handleSelectProfile(created.id);
    setNewName('');
  };

  const handleDeleteAgent = (id: string) => {
    const next = deleteCustomAiProfile(id);
    setProfiles(next);
    if (activeId === id && next[0]) handleSelectProfile(next[0].id);
  };

  const handleCopyBridgePrompt = () => {
    navigator.clipboard?.writeText(buildExternalAiAgentPrompt());
    setCopiedBridge(true);
    setTimeout(() => setCopiedBridge(false), 1600);
  };

  const inputCls = darkMode ? 'bg-slate-950 border-slate-800 text-slate-200' : 'bg-white border-slate-200 text-slate-800';

  return (
    <SettingsFolder
      title="Multiplayer AI & Bridge Studio"
      icon={<Bot className="w-4 h-4" />}
      defaultOpen={false}
      darkMode={darkMode}
    >
      <div className="space-y-3">
        <div className="space-y-1.5">
          <div className="text-[11px] font-mono uppercase opacity-70">Multiplayer AI Opponent Profile</div>
          <div className="space-y-1.5">
            {profiles.map((p) => {
              const active = p.id === activeId;
              return (
                <div
                  key={p.id}
                  className={`flex items-center justify-between gap-2 p-2 rounded-xl border text-xs ${
                    active
                      ? 'border-cyan-500 bg-cyan-500/15 text-cyan-400'
                      : darkMode
                      ? 'border-slate-800 bg-slate-900/60 text-slate-300'
                      : 'border-slate-200 bg-slate-50 text-slate-700'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => handleSelectProfile(p.id)}
                    className="flex-1 text-left flex items-center justify-between gap-2 cursor-pointer"
                  >
                    <span className="font-bold">{p.name}</span>
                    <span className="text-[10px] font-mono opacity-75">
                      {p.strategy} • {(p.stepDelayMs / 1000).toFixed(1)}s/move
                    </span>
                  </button>
                  {!p.isBuiltIn && (
                    <button
                      type="button"
                      onClick={() => handleDeleteAgent(p.id)}
                      className="p-1 text-rose-400 hover:text-rose-300 cursor-pointer"
                      title="Delete custom AI profile"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <div className={`p-2.5 rounded-xl border space-y-2 ${darkMode ? 'border-slate-800 bg-slate-950/60' : 'border-slate-200 bg-slate-50'}`}>
          <div className="text-[11px] font-bold">Create Custom Multiplayer AI Agent</div>
          <div className="grid grid-cols-2 gap-1.5">
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="Agent Name (e.g. DeepSeek R1)"
              className={`col-span-2 px-2.5 py-1 rounded-lg border text-xs ${inputCls}`}
            />
            <select value={newProvider} onChange={(e) => setNewProvider(e.target.value as AiProvider)} className={`px-2 py-1 rounded-lg border text-xs font-mono ${inputCls}`}>
              <option value="gemini">Gemini</option>
              <option value="chatgpt">ChatGPT</option>
              <option value="claude">Claude</option>
              <option value="custom">Custom Bot</option>
            </select>
            <select value={newStrategy} onChange={(e) => setNewStrategy(e.target.value as AiStrategy)} className={`px-2 py-1 rounded-lg border text-xs font-mono ${inputCls}`}>
              <option value="speedster">Speedster</option>
              <option value="methodical">Methodical</option>
              <option value="humanlike">Human-like</option>
            </select>
          </div>
          <div className="flex items-center justify-between gap-2">
            <label className="text-[11px] font-mono opacity-75">
              Sec/Move: {newDelaySec}s
              <input
                type="range"
                min={1}
                max={10}
                step={0.5}
                value={newDelaySec}
                onChange={(e) => setNewDelaySec(Number(e.target.value))}
                className="ml-2 align-middle w-24"
              />
            </label>
            <button
              type="button"
              onClick={handleCreateAgent}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold bg-cyan-600 text-white hover:bg-cyan-500 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Save Agent</span>
            </button>
          </div>
        </div>

        <div className="pt-1 flex items-center justify-between gap-2 flex-wrap">
          <button
            type="button"
            onClick={handleCopyBridgePrompt}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-semibold border-cyan-500/30 bg-cyan-500/10 text-cyan-400 cursor-pointer"
          >
            {copiedBridge ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedBridge ? 'Copied Web AI Bridge Prompt!' : 'Copy Web AI Bridge Prompt'}</span>
          </button>
          <div className="flex items-center gap-1 text-[11px]">
            <a href="https://gemini.google.com" target="_blank" rel="noopener noreferrer" className="px-2 py-1 rounded-lg border border-blue-500/30 text-blue-400 inline-flex items-center gap-0.5">
              <span>Gemini</span>
              <ExternalLink className="w-2.5 h-2.5" />
            </a>
            <a href="https://chatgpt.com" target="_blank" rel="noopener noreferrer" className="px-2 py-1 rounded-lg border border-emerald-500/30 text-emerald-400 inline-flex items-center gap-0.5">
              <span>ChatGPT</span>
              <ExternalLink className="w-2.5 h-2.5" />
            </a>
            <a href="https://claude.ai" target="_blank" rel="noopener noreferrer" className="px-2 py-1 rounded-lg border border-amber-500/30 text-amber-400 inline-flex items-center gap-0.5">
              <span>Claude</span>
              <ExternalLink className="w-2.5 h-2.5" />
            </a>
          </div>
        </div>
      </div>
    </SettingsFolder>
  );
};
