import React from 'react';

export interface SettingRowProps {
  label: string;
  tooltip?: string;
  children: React.ReactNode;
}

export const SettingRow: React.FC<SettingRowProps> = ({
  label,
  tooltip,
  children,
}) => {
  return (
    <div className="flex items-center justify-between gap-3 py-1.5 border-b border-slate-200/50 dark:border-slate-800/50 last:border-b-0">
      <span
        className="text-xs sm:text-sm font-medium text-slate-800 dark:text-slate-200 truncate select-none"
        title={tooltip}
      >
        {label}
      </span>
      <div className="shrink-0">{children}</div>
    </div>
  );
};

export const ToggleSwitch: React.FC<{
  checked: boolean;
  disabled?: boolean;
  onChange: () => void;
  darkMode: boolean;
  'aria-label'?: string;
}> = ({ checked, disabled = false, onChange, darkMode, 'aria-label': ariaLabel }) => (
  <button
    type="button"
    role="switch"
    disabled={disabled}
    aria-checked={checked}
    aria-label={ariaLabel}
    onClick={onChange}
    className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out disabled:opacity-40 disabled:cursor-not-allowed ${
      checked
        ? darkMode
          ? 'bg-amber-500'
          : 'bg-blue-600'
        : darkMode
        ? 'bg-slate-800'
        : 'bg-slate-300'
    }`}
  >
    <span
      className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
        checked ? 'translate-x-4' : 'translate-x-0'
      }`}
    />
  </button>
);
