import React, { useRef, useState } from 'react';
import { Download, RotateCcw, Trash2, Upload } from '../../icons';
import { ConfirmModal } from '../../components/ConfirmModal';
import { SettingRow } from './SettingRow';
import { loadState, saveState } from '../../storage/storage';
import { resetMode } from '../../storage/modes';
import { DEFAULT_STORED_STATE_V3, GameMode } from '../../storage/schema';
import { clearAllSessions, clearSessionsForMode } from '../../storage/sessionStorage';
import { clearHistory, estimateHistoryBytes, importHistory, loadHistory } from '../../storage/history';
import { AUDIO_STUDIO_STORAGE_KEY_V2 } from '../../audio/customAudioSynth';
import { validateExpression } from '../../audio/expr';
import { BGM_STORAGE_KEY, SFX_MIXER_KEY, soundEngine } from '../../audio/soundEngine';

interface DataSectionProps {
  darkMode: boolean;
  onResetAllProgress: () => void;
}

export const DataSection: React.FC<DataSectionProps> = ({
  darkMode,
  onResetAllProgress,
}) => {
  const [resetTarget, setResetTarget] = useState<GameMode | 'all' | null>(null);
  const [confirmClearHistory, setConfirmClearHistory] = useState(false);
  const [historyBytes, setHistoryBytes] = useState(estimateHistoryBytes());
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleExport = () => {
    let audioStudio: unknown = null;
    let sfxMixer: unknown = null;
    let bgm: unknown = null;
    try {
      const rawStudio = localStorage.getItem(AUDIO_STUDIO_STORAGE_KEY_V2);
      if (rawStudio) audioStudio = JSON.parse(rawStudio);
      const rawMixer = localStorage.getItem(SFX_MIXER_KEY);
      if (rawMixer) sfxMixer = JSON.parse(rawMixer);
      const rawBgm = localStorage.getItem(BGM_STORAGE_KEY);
      if (rawBgm) bgm = JSON.parse(rawBgm);
    } catch {}

    const backup = {
      version: 3,
      exportedAt: new Date().toISOString(),
      state: loadState(),
      history: loadHistory(),
      audioStudio,
      sfxMixer,
      bgm,
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `arithmos-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed && typeof parsed === 'object') {
          if (parsed.state) saveState(parsed.state);
          if (parsed.history) importHistory(parsed.history);
          try {
            if (parsed.audioStudio && typeof parsed.audioStudio === 'object') {
              const safeMap: Record<string, unknown> = {};
              Object.entries(parsed.audioStudio).forEach(([k, v]) => {
                const item = v as { formula?: string };
                if (typeof item?.formula === 'string' && validateExpression(item.formula)) safeMap[k] = v;
              });
              localStorage.setItem(AUDIO_STUDIO_STORAGE_KEY_V2, JSON.stringify(safeMap));
            }
            if (parsed.sfxMixer) localStorage.setItem(SFX_MIXER_KEY, JSON.stringify(parsed.sfxMixer));
            if (parsed.bgm) localStorage.setItem(BGM_STORAGE_KEY, JSON.stringify(parsed.bgm));
          } catch {}
          clearAllSessions();
          window.location.reload();
        }
      } catch {}
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleConfirmReset = () => {
    if (resetTarget === 'all') {
      clearAllSessions();
      clearHistory();
      saveState(DEFAULT_STORED_STATE_V3);
      try {
        localStorage.removeItem(AUDIO_STUDIO_STORAGE_KEY_V2);
        localStorage.removeItem(SFX_MIXER_KEY);
        localStorage.removeItem(BGM_STORAGE_KEY);
      } catch {}
      soundEngine.reloadBuffers();
      onResetAllProgress();
    } else if (resetTarget) {
      clearSessionsForMode(resetTarget);
      clearHistory(resetTarget);
      saveState((prev) => resetMode(prev, resetTarget));
      onResetAllProgress();
    }
    setHistoryBytes(estimateHistoryBytes());
    setResetTarget(null);
  };

  return (
    <div className="space-y-1">
      <SettingRow label="Export JSON" tooltip="Download all saves, history, and custom audio">
        <button
          type="button"
          onClick={handleExport}
          className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-xl border text-xs font-semibold cursor-pointer transition-colors ${
            darkMode ? 'border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700' : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export</span>
        </button>
      </SettingRow>

      <SettingRow label="Import JSON" tooltip="Restore saves, history, and audio from backup">
        <input ref={fileInputRef} type="file" accept=".json,application/json" onChange={handleImportFile} className="hidden" />
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-xl border text-xs font-semibold cursor-pointer transition-colors ${
            darkMode ? 'border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700' : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Upload className="w-3.5 h-3.5" />
          <span>Import</span>
        </button>
      </SettingRow>

      <SettingRow label="Reset Slots" tooltip="Selectively reset mode or all data">
        <div className="flex items-center gap-1 flex-wrap">
          {(['endless', 'star', 'hardcore', 'practice'] as GameMode[]).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => setResetTarget(m)}
              className={`px-2 py-0.5 rounded-lg border text-[11px] font-semibold capitalize cursor-pointer transition-colors ${
                darkMode ? 'border-slate-700 bg-slate-800/80 text-slate-300 hover:text-white' : 'border-slate-200 bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {m}
            </button>
          ))}
          <button
            type="button"
            onClick={() => setResetTarget('all')}
            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg border text-[11px] font-semibold cursor-pointer transition-colors ${
              darkMode ? 'border-rose-500/40 bg-rose-500/10 text-rose-300 hover:bg-rose-500/20' : 'border-rose-300 bg-rose-50 text-rose-700 hover:bg-rose-100'
            }`}
          >
            <RotateCcw className="w-3 h-3" />
            <span>All</span>
          </button>
        </div>
      </SettingRow>

      <SettingRow label="Clear History" tooltip="Delete past level logs only">
        <div className="flex items-center gap-2">
          {historyBytes > 0 && (
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full border border-slate-700/60 text-slate-400 tabular-nums">
              {historyBytes < 1024 ? `${historyBytes} B` : `${(historyBytes / 1024).toFixed(1)} KB`}
            </span>
          )}
          <button
            type="button"
            onClick={() => setConfirmClearHistory(true)}
            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-xl border text-xs font-semibold cursor-pointer transition-colors ${
              darkMode ? 'border-rose-500/40 bg-rose-500/10 text-rose-300 hover:bg-rose-500/20' : 'border-rose-300 bg-rose-50 text-rose-700 hover:bg-rose-100'
            }`}
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear</span>
          </button>
        </div>
      </SettingRow>

      <ConfirmModal
        isOpen={resetTarget !== null}
        title={resetTarget === 'all' ? 'Reset all progress?' : `Reset ${resetTarget} mode?`}
        message={resetTarget === 'all' ? 'All progress in Endless, Star, Hardcore, and Practice will be erased.' : `Progress and ratings for ${resetTarget} will be erased.`}
        confirmLabel={resetTarget === 'all' ? 'Reset Everything' : 'Reset Mode'}
        isDestructive
        darkMode={darkMode}
        onConfirm={handleConfirmReset}
        onCancel={() => setResetTarget(null)}
      />

      <ConfirmModal
        isOpen={confirmClearHistory}
        title="Clear history?"
        message="All saved level history will be erased. Current levels and ratings remain intact."
        confirmLabel="Clear History"
        isDestructive
        darkMode={darkMode}
        onConfirm={() => {
          clearHistory();
          setHistoryBytes(0);
          setConfirmClearHistory(false);
        }}
        onCancel={() => setConfirmClearHistory(false)}
      />
    </div>
  );
};
