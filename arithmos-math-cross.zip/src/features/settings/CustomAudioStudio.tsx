import React, { useEffect, useState } from 'react';
import { Check, Code2, Info, Play, RotateCcw, Sparkles } from '../../icons';
import { CueId } from '../../audio/audioBuffers';
import {
  AI_STUDIO_PROMPT,
  ALL_STUDIO_TARGETS,
  StudioConfigMap,
  loadStudioConfigMap,
  parseAiPasteInput,
  resetStudioCueConfig,
  saveStudioCueConfig,
  validateCustomFormula,
} from '../../audio/customAudioSynth';
import { soundEngine } from '../../audio/soundEngine';
import { DspGuideModal } from './DspGuideModal';

interface CustomAudioStudioProps {
  darkMode: boolean;
  onStudioChange?: () => void;
}

export const CustomAudioStudio: React.FC<CustomAudioStudioProps> = ({ darkMode, onStudioChange }) => {
  const [studioMap, setStudioMap] = useState<StudioConfigMap>(() => loadStudioConfigMap());
  const [selectedTargets, setSelectedTargets] = useState<CueId[]>(['tick']);
  const [formula, setFormula] = useState(() => studioMap.tick?.formula || 'Math.sin(2 * Math.PI * 440 * t) * Math.exp(-t * 16)');
  const [durationSec, setDurationSec] = useState(() => studioMap.tick?.durationSec || 0.15);
  const [copiedPrompt, setCopiedPrompt] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [showInfo, setShowInfo] = useState(false);

  useEffect(() => () => soundEngine.stopPreview(), []);

  const isValid = validateCustomFormula(formula);

  const handleTest = () => soundEngine.previewCustomFormula(formula, durationSec);

  const handleResetSelected = () => {
    const updated = resetStudioCueConfig(selectedTargets);
    setStudioMap(updated);
    soundEngine.reloadBuffers();
    const active = selectedTargets[0] || 'tick';
    setFormula(updated[active].formula);
    setDurationSec(updated[active].durationSec);
    onStudioChange?.();
  };

  const handleSave = () => {
    const updated = saveStudioCueConfig(selectedTargets, formula, durationSec);
    setStudioMap(updated);
    soundEngine.reloadBuffers();
    soundEngine.previewCustomFormula(formula, durationSec);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 1500);
    onStudioChange?.();
  };

  const handleCopyPrompt = () => {
    navigator.clipboard?.writeText(AI_STUDIO_PROMPT);
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 1500);
  };

  const toggleTarget = (id: CueId) => {
    setSelectedTargets((prev) => {
      const isSelected = prev.includes(id);
      const next = isSelected ? (prev.length > 1 ? prev.filter((c) => c !== id) : prev) : [...prev, id];
      if (!isSelected && studioMap[id]?.formula) {
        setFormula(studioMap[id].formula);
        setDurationSec(studioMap[id].durationSec);
      }
      return next;
    });
  };

  const toggleSelectAll = () => {
    setSelectedTargets((p) => (p.length === ALL_STUDIO_TARGETS.length ? ['tick'] : ALL_STUDIO_TARGETS.map((c) => c.id)));
  };

  const handleFormulaChange = (val: string) => {
    if (val.includes('Formula:') || val.includes('Duration:') || val.includes('```') || val.includes('\n')) {
      const parsed = parseAiPasteInput(val, durationSec);
      setFormula(parsed.formula);
      setDurationSec(parsed.durationSec);
    } else {
      setFormula(val);
    }
  };

  return (
    <div className="space-y-3 pt-1 text-xs">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <span className="font-semibold text-slate-700 dark:text-slate-300">Procedural DSP Synthesis</span>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setShowInfo((v) => !v)}
            className={`p-1 rounded-lg border text-xs cursor-pointer transition-colors ${
              showInfo ? 'border-blue-500 bg-blue-500/20 text-blue-400' : darkMode ? 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-slate-200' : 'border-slate-200 bg-white text-slate-500 hover:text-slate-800'
            }`}
            title="Code-to-Audio Guide"
            aria-label="Code-to-Audio Guide"
          >
            <Info className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={handleCopyPrompt}
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border text-[11px] font-semibold cursor-pointer transition-colors ${
              darkMode ? 'border-slate-700 bg-slate-800 text-slate-300 hover:text-white' : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-100'
            }`}
          >
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span>{copiedPrompt ? 'Copied!' : 'Copy AI Prompt'}</span>
          </button>
        </div>
      </div>

      {showInfo && <DspGuideModal darkMode={darkMode} onClose={() => setShowInfo(false)} />}

      <div className="space-y-1.5">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-mono uppercase tracking-wider opacity-60">
            Step 1: Target Sound ({selectedTargets.length}/10)
          </span>
          <button type="button" onClick={toggleSelectAll} className="text-[10px] font-mono opacity-70 hover:opacity-100 cursor-pointer underline">
            {selectedTargets.length === ALL_STUDIO_TARGETS.length ? 'Deselect All' : 'Select All 10'}
          </button>
        </div>
        <div className="flex flex-wrap gap-1">
          {ALL_STUDIO_TARGETS.map((t) => {
            const isSelected = selectedTargets.includes(t.id);
            const isCustom = studioMap[t.id]?.enabled;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => toggleTarget(t.id)}
                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg border text-[10px] font-semibold cursor-pointer transition-all ${
                  isSelected
                    ? darkMode ? 'border-amber-500 bg-amber-500/20 text-amber-300 shadow-xs' : 'border-blue-500 bg-blue-100 text-blue-800 shadow-xs'
                    : darkMode ? 'border-slate-800 bg-slate-900/40 text-slate-400 hover:text-slate-200' : 'border-slate-200 bg-slate-50 text-slate-500 hover:text-slate-800'
                }`}
              >
                {isCustom && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />}
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="space-y-1">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-mono uppercase tracking-wider opacity-60 flex items-center gap-1">
            <Code2 className="w-3 h-3" /> Step 2: Formula / Paste AI Output
          </span>
          <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded-md font-bold ${isValid ? 'bg-emerald-500/15 text-emerald-400' : 'bg-red-500/15 text-red-400'}`}>
            {isValid ? 'Valid DSP' : 'Syntax Error'}
          </span>
        </div>
        <textarea
          rows={3}
          value={formula}
          onChange={(e) => handleFormulaChange(e.target.value)}
          className={`w-full font-mono text-[11px] p-2 rounded-xl border leading-relaxed resize-none focus:outline-hidden ${
            darkMode ? 'bg-slate-950/80 border-slate-800 text-slate-200 focus:border-amber-400' : 'bg-slate-100 border-slate-200 text-slate-800 focus:border-blue-500'
          }`}
          placeholder="Math.sin(pi2 * 440 * t) * Math.exp(-t * 16)"
          spellCheck={false}
        />
      </div>

      <div className="flex items-center justify-between gap-3 px-1 py-0.5">
        <span className="text-[10px] font-mono uppercase tracking-wider opacity-60">Duration</span>
        <div className="flex items-center gap-2 flex-1 max-w-[200px]">
          <input
            type="range"
            min="0.05"
            max="1.20"
            step="0.01"
            value={durationSec}
            onChange={(e) => setDurationSec(Number(e.target.value))}
            className={`w-full h-1.5 rounded-lg appearance-none cursor-pointer ${darkMode ? 'bg-slate-800 accent-amber-400' : 'bg-slate-200 accent-blue-600'}`}
          />
          <span className="font-mono text-[10px] tabular-nums w-12 text-right opacity-80">{durationSec.toFixed(2)}s</span>
        </div>
      </div>

      <div className="flex items-center gap-2 pt-1">
        <button
          type="button"
          onClick={handleTest}
          disabled={!isValid}
          className={`flex-1 inline-flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-xl border text-xs font-semibold cursor-pointer transition-colors disabled:opacity-40 disabled:cursor-not-allowed ${
            darkMode ? 'border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700' : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Play className="w-3.5 h-3.5" />
          <span>Test Sound</span>
        </button>
        <button
          type="button"
          onClick={handleResetSelected}
          className={`p-1.5 rounded-xl border text-xs cursor-pointer transition-colors ${
            darkMode ? 'border-slate-700 bg-slate-800 text-slate-300 hover:text-white' : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-100'
          }`}
          title="Reset selected to default"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>
        <button
          type="button"
          onClick={handleSave}
          disabled={!isValid}
          className={`flex-1 inline-flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-xl text-xs font-semibold cursor-pointer transition-colors disabled:opacity-40 disabled:cursor-not-allowed ${
            darkMode ? 'bg-amber-500 text-slate-950 hover:bg-amber-400' : 'bg-blue-600 text-white hover:bg-blue-500'
          }`}
        >
          <Check className="w-3.5 h-3.5" />
          <span>{saveSuccess ? 'Saved & Active!' : `Save & Activate (${selectedTargets.length})`}</span>
        </button>
      </div>
    </div>
  );
};
