import React, { useEffect, useRef } from 'react';
import { Database, HelpCircle, Palette, Settings, X } from '../../icons';
import { ThemeMode } from '../../storage/schema';
import { SoundSection } from './SoundSection';
import { ThemeSection } from './ThemeSection';
import { DataSection } from './DataSection';
import { HelpSection } from './HelpSection';
import { SettingsFolder } from './SettingsFolder';

export interface HomeSettingsSheetProps {
  isOpen: boolean;
  muted: boolean;
  volume: number;
  themeMode: ThemeMode;
  darkMode: boolean;
  onClose: () => void;
  onToggleMute: () => void;
  onChangeVolume: (v: number) => void;
  onSelectThemeMode: (m: ThemeMode) => void;
  onResetAllProgress: () => void;
}

export const HomeSettingsSheet: React.FC<HomeSettingsSheetProps> = ({
  isOpen,
  muted,
  volume,
  themeMode,
  darkMode,
  onClose,
  onToggleMute,
  onChangeVolume,
  onSelectThemeMode,
  onResetAllProgress,
}) => {
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-xs select-none"
      role="dialog"
      aria-modal="true"
      aria-label="Settings"
    >
      <div
        ref={dialogRef}
        className={`w-full max-w-lg max-h-[90dvh] flex flex-col rounded-3xl border shadow-2xl overflow-hidden ${
          darkMode
            ? 'bg-[#131B2E] border-slate-800 text-slate-100'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Header */}
        <div className={`flex items-center justify-between px-5 py-3 border-b ${
          darkMode ? 'border-slate-800 bg-slate-900/50' : 'border-slate-100 bg-slate-50/50'
        }`}>
          <div className="flex items-center gap-2">
            <Settings className={`w-4 h-4 ${darkMode ? 'text-amber-400' : 'text-blue-600'}`} />
            <h2 className="font-bold text-sm tracking-tight">Settings</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-200 cursor-pointer"
            aria-label="Close settings"
            title="Close (Esc)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body: 4 Boxed Folders */}
        <div className="flex-1 overflow-y-auto px-4 sm:px-5 py-4 space-y-3 min-h-0 custom-scrollbar">
          {/* Folder 1: Audio Engine & Mixer */}
          <SoundSection
            muted={muted}
            volume={volume}
            darkMode={darkMode}
            onToggleMute={onToggleMute}
            onChangeVolume={onChangeVolume}
          />

          {/* Folder 2: Display & Theme */}
          <SettingsFolder
            title="Display & Theme"
            icon={<Palette className="w-4 h-4" />}
            defaultOpen={false}
            darkMode={darkMode}
          >
            <ThemeSection
              themeMode={themeMode}
              darkMode={darkMode}
              onSelectThemeMode={onSelectThemeMode}
            />
          </SettingsFolder>

          {/* Folder 3: Rules & Gameplay Guide */}
          <SettingsFolder
            title="Rules & Guide"
            icon={<HelpCircle className="w-4 h-4" />}
            defaultOpen={false}
            darkMode={darkMode}
          >
            <HelpSection darkMode={darkMode} />
          </SettingsFolder>

          {/* Folder 4: Data & Backup */}
          <SettingsFolder
            title="Data & Backup"
            icon={<Database className="w-4 h-4" />}
            defaultOpen={false}
            darkMode={darkMode}
          >
            <DataSection
              darkMode={darkMode}
              onResetAllProgress={() => {
                onResetAllProgress();
                onClose();
              }}
            />
          </SettingsFolder>
        </div>
      </div>
    </div>
  );
};
