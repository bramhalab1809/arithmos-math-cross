import React from 'react';
import { Sun, Moon, Monitor } from '../../icons';
import { ThemeMode } from '../../storage/schema';
import { SettingRow } from './SettingRow';

interface ThemeSectionProps {
  themeMode: ThemeMode;
  darkMode: boolean;
  onSelectThemeMode: (mode: ThemeMode) => void;
}

const THEME_OPTIONS: { id: ThemeMode; label: string; icon: React.FC<{ className?: string }> }[] = [
  { id: 'light', label: 'Light', icon: Sun },
  { id: 'dark', label: 'Dark', icon: Moon },
  { id: 'system', label: 'System', icon: Monitor },
];

export const ThemeSection: React.FC<ThemeSectionProps> = ({
  themeMode,
  darkMode,
  onSelectThemeMode,
}) => {
  return (
    <div className="space-y-1">
      <h3 className={`text-[11px] font-mono font-bold tracking-wider uppercase mb-1 ${
        darkMode ? 'text-amber-400' : 'text-blue-600'
      }`}>
        Theme
      </h3>

      <SettingRow label="Appearance" tooltip="Select light, dark, or system theme">
        <div
          className={`inline-flex items-center gap-1 p-0.5 rounded-xl border ${
            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-slate-100 border-slate-200'
          }`}
          role="radiogroup"
          aria-label="Theme mode"
        >
          {THEME_OPTIONS.map((opt) => {
            const active = themeMode === opt.id;
            const Icon = opt.icon;
            return (
              <button
                key={opt.id}
                type="button"
                role="radio"
                aria-checked={active}
                onClick={() => onSelectThemeMode(opt.id)}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                  active
                    ? darkMode
                      ? 'bg-amber-500 text-slate-950 shadow-sm'
                      : 'bg-white text-slate-900 shadow-sm'
                    : darkMode
                    ? 'text-slate-400 hover:text-slate-200'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{opt.label}</span>
              </button>
            );
          })}
        </div>
      </SettingRow>
    </div>
  );
};
