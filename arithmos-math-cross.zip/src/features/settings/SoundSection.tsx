import React, { useState } from 'react';
import { Code2, Play, Sliders, Volume2, VolumeX } from '../../icons';
import { SettingRow } from './SettingRow';
import { SettingsFolder } from './SettingsFolder';
import { CustomAudioStudio } from './CustomAudioStudio';
import { CueId } from '../../audio/audioBuffers';
import { ALL_SFX_CUES, loadStudioConfigMap } from '../../audio/customAudioSynth';
import { soundEngine } from '../../audio/soundEngine';

interface SoundSectionProps {
  muted: boolean;
  volume: number;
  darkMode: boolean;
  onToggleMute: () => void;
  onChangeVolume: (v: number) => void;
}

export const SoundSection: React.FC<SoundSectionProps> = ({
  muted, volume, darkMode, onToggleMute, onChangeVolume,
}) => {
  const [mixer, setMixer] = useState(soundEngine.getMixer());
  const [bgmEnabled, setBgmEnabled] = useState(soundEngine.isBgmEnabled());
  const [bgmVolume, setBgmVolume] = useState(soundEngine.getBgmVolume());
  const [studioMap, setStudioMap] = useState(() => loadStudioConfigMap());
  const volumePercent = Math.round(volume * 100);

  const updateMixer = (cue: CueId, enabled: boolean, vol: number) => {
    soundEngine.setMixer(cue, enabled, vol);
    setMixer(soundEngine.getMixer());
  };

  const handleToggleBgm = () => {
    const next = !bgmEnabled;
    soundEngine.setBgmEnabled(next);
    setBgmEnabled(next);
  };

  const handleChangeBgmVolume = (vol: number) => {
    soundEngine.setBgmVolume(vol);
    setBgmVolume(vol);
  };

  return (
    <SettingsFolder
      title="Audio & Music"
      icon={muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
      badge={
        <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
          muted ? 'bg-slate-800 text-slate-400' : darkMode ? 'bg-amber-500/20 text-amber-300' : 'bg-blue-100 text-blue-700'
        }`}>
          {muted ? 'MUTED' : `${volumePercent}%`}
        </span>
      }
      defaultOpen={false}
      darkMode={darkMode}
    >
      <div className="space-y-3.5">
        {/* 1. Master Audio & BGM */}
        <SettingsFolder title="Master Audio & BGM" icon={<Volume2 className="w-4 h-4" />} defaultOpen={false} darkMode={darkMode}>
          <div className="space-y-2">
            <SettingRow label="Sound Effects" tooltip="Mechanical ticks and audio chimes">
              <button
                type="button" onClick={onToggleMute}
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-xl border text-xs font-semibold cursor-pointer transition-colors ${
                  !muted
                    ? darkMode ? 'bg-amber-500/15 border-amber-500/40 text-amber-300' : 'bg-blue-50 border-blue-300 text-blue-700'
                    : darkMode ? 'bg-slate-900 border-slate-800 text-slate-400' : 'bg-slate-100 border-slate-200 text-slate-500'
                }`}
              >
                {muted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                <span>{muted ? 'Muted' : 'Enabled'}</span>
              </button>
            </SettingRow>

            <SettingRow label="Master Volume" tooltip="Master sound volume">
              <div className="flex items-center gap-2 w-32 sm:w-40">
                <input
                  type="range" min="0" max="100" step="1" disabled={muted}
                  value={muted ? 0 : volumePercent}
                  onChange={(e) => onChangeVolume(Number(e.target.value) / 100)}
                  className={`w-full h-1.5 rounded-lg appearance-none cursor-pointer ${
                    muted ? 'opacity-40 cursor-not-allowed' : 'opacity-100'
                  } ${darkMode ? 'bg-slate-800 accent-amber-400' : 'bg-slate-200 accent-blue-600'}`}
                />
                <span className="text-xs font-mono tabular-nums w-7 text-right text-slate-500 dark:text-slate-400">
                  {muted ? '0%' : `${volumePercent}%`}
                </span>
              </div>
            </SettingRow>

            <SettingRow label="Background Music" tooltip="Ambient background loop (ambient-loop.mp3)">
              <button
                type="button" onClick={handleToggleBgm}
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-xl border text-xs font-semibold cursor-pointer transition-colors ${
                  bgmEnabled && !muted
                    ? darkMode ? 'bg-amber-500/15 border-amber-500/40 text-amber-300' : 'bg-blue-50 border-blue-300 text-blue-700'
                    : darkMode ? 'bg-slate-900 border-slate-800 text-slate-400' : 'bg-slate-100 border-slate-200 text-slate-500'
                }`}
              >
                <span>{bgmEnabled && !muted ? 'Music On' : 'Music Off'}</span>
              </button>
            </SettingRow>

            <SettingRow label="Music Volume" tooltip="Background loop volume">
              <div className="flex items-center gap-2 w-32 sm:w-40">
                <input
                  type="range" min="0" max="100" step="1" disabled={!bgmEnabled || muted}
                  value={!bgmEnabled || muted ? 0 : Math.round(bgmVolume * 100)}
                  onChange={(e) => handleChangeBgmVolume(Number(e.target.value) / 100)}
                  className={`w-full h-1.5 rounded-lg appearance-none cursor-pointer ${
                    !bgmEnabled || muted ? 'opacity-40 cursor-not-allowed' : 'opacity-100'
                  } ${darkMode ? 'bg-slate-800 accent-amber-400' : 'bg-slate-200 accent-blue-600'}`}
                />
                <span className="text-xs font-mono tabular-nums w-7 text-right text-slate-500 dark:text-slate-400">
                  {!bgmEnabled || muted ? '0%' : `${Math.round(bgmVolume * 100)}%`}
                </span>
              </div>
            </SettingRow>
          </div>
        </SettingsFolder>

        {/* 2. Advanced Audio (SFX Mixer) */}
        <SettingsFolder title="Per-Event SFX Mixer" icon={<Sliders className="w-4 h-4" />} defaultOpen={false} darkMode={darkMode}>
          <div className="space-y-2">
            {ALL_SFX_CUES.map((item) => {
              const cfg = mixer[item.id] || { enabled: false, volume: 1.0 };
              const isCustomActive = Boolean(studioMap[item.id]?.enabled && studioMap[item.id]?.formula);
              return (
                <div key={item.id} className="flex items-center justify-between gap-2 py-1 border-b border-slate-100 dark:border-slate-800/60 last:border-b-0">
                  <div className="min-w-0 flex-1">
                    <label className="flex items-center gap-2 cursor-pointer text-xs font-medium">
                      <input
                        type="checkbox" checked={cfg.enabled}
                        onChange={(e) => updateMixer(item.id, e.target.checked, cfg.volume)}
                        className="w-3.5 h-3.5 rounded cursor-pointer accent-blue-600 dark:accent-amber-400"
                      />
                      <span className="truncate">{item.label}</span>
                      {isCustomActive && (
                        <span className="text-[8px] font-mono px-1 py-0.5 rounded bg-emerald-500/15 text-emerald-400 font-bold shrink-0">
                          DSP
                        </span>
                      )}
                    </label>
                    <p className="text-[10px] text-slate-400 truncate pl-5.5">{item.desc}</p>
                  </div>

                  <div className="flex items-center gap-1.5 w-32 shrink-0 justify-end">
                    <button
                      type="button" onClick={() => soundEngine.playCue(item.id, true)}
                      className={`p-1 rounded-lg border text-xs cursor-pointer transition-colors ${
                        darkMode ? 'border-slate-800 bg-slate-900 text-slate-300 hover:text-white' : 'border-slate-200 bg-white text-slate-600 hover:text-slate-900'
                      }`}
                      title={`Audition ${item.label}`} aria-label={`Audition ${item.label}`}
                    >
                      <Play className="w-2.5 h-2.5 fill-current" />
                    </button>
                    <input
                      type="range" min="0" max="100" step="5" disabled={!cfg.enabled || muted}
                      value={Math.round(cfg.volume * 100)}
                      onChange={(e) => updateMixer(item.id, cfg.enabled, Number(e.target.value) / 100)}
                      className="w-16 h-1 rounded-lg appearance-none cursor-pointer accent-blue-600 dark:accent-amber-400 bg-slate-200 dark:bg-slate-800 disabled:opacity-30"
                    />
                    <span className="text-[10px] font-mono tabular-nums w-6 text-right text-slate-500">
                      {Math.round(cfg.volume * 100)}%
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </SettingsFolder>

        {/* 3. Code-to-Audio Studio */}
        <SettingsFolder
          title="Code-to-Audio Studio" icon={<Code2 className="w-4 h-4" />}
          badge={<span className="text-[9px] font-mono px-1.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">DSP</span>}
          defaultOpen={false} darkMode={darkMode}
        >
          <CustomAudioStudio darkMode={darkMode} onStudioChange={() => setStudioMap(loadStudioConfigMap())} />
        </SettingsFolder>
      </div>
    </SettingsFolder>
  );
};
