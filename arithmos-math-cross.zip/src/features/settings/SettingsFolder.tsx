import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from '../../icons';

export interface SettingsFolderProps {
  title: string;
  icon?: React.ReactNode;
  badge?: React.ReactNode;
  defaultOpen?: boolean;
  isOpen?: boolean;
  onToggle?: () => void;
  darkMode: boolean;
  children: React.ReactNode;
}

export const SettingsFolder: React.FC<SettingsFolderProps> = ({
  title,
  icon,
  badge,
  defaultOpen = false,
  isOpen: controlledOpen,
  onToggle,
  darkMode,
  children,
}) => {
  const [internalOpen, setInternalOpen] = useState(defaultOpen);
  const isOpen = controlledOpen !== undefined ? controlledOpen : internalOpen;

  const handleToggle = () => {
    if (onToggle) onToggle();
    else setInternalOpen((prev) => !prev);
  };

  return (
    <div
      className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
        darkMode
          ? 'bg-slate-900/60 border-slate-800 shadow-sm'
          : 'bg-white/80 border-slate-200 shadow-xs'
      }`}
    >
      <button
        type="button"
        onClick={handleToggle}
        aria-expanded={isOpen}
        className={`w-full flex items-center justify-between px-3.5 py-2.5 text-left cursor-pointer transition-colors select-none ${
          darkMode ? 'hover:bg-slate-800/50' : 'hover:bg-slate-50'
        }`}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          {icon && (
            <div className={`p-1 rounded-lg shrink-0 ${
              darkMode ? 'bg-slate-800 text-amber-400' : 'bg-slate-100 text-blue-600'
            }`}>
              {icon}
            </div>
          )}
          <span className="font-semibold text-xs tracking-tight truncate">
            {title}
          </span>
          {badge && <div className="shrink-0">{badge}</div>}
        </div>

        <div className="flex items-center text-slate-400 ml-2 shrink-0">
          {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </div>
      </button>

      {isOpen && (
        <div className={`px-3.5 py-3 border-t space-y-2.5 ${
          darkMode ? 'border-slate-800/80 bg-slate-950/20' : 'border-slate-100 bg-slate-50/30'
        }`}>
          {children}
        </div>
      )}
    </div>
  );
};
