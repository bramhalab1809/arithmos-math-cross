import React from 'react';
import { Code2, Sparkles, Volume2, X } from '../../icons';

interface DspGuideModalProps {
  darkMode: boolean;
  onClose: () => void;
}

export const DspGuideModal: React.FC<DspGuideModalProps> = ({ darkMode, onClose }) => (
  <div
    className={`p-3 rounded-2xl border space-y-2 text-xs leading-relaxed transition-all shadow-lg ${
      darkMode ? 'bg-slate-900 border-slate-700 text-slate-200' : 'bg-slate-50 border-slate-200 text-slate-800'
    }`}
  >
    <div className="flex items-center justify-between font-bold text-xs pb-1 border-b border-slate-200 dark:border-slate-800">
      <span className="flex items-center gap-1.5 text-blue-600 dark:text-amber-400">
        <Sparkles className="w-3.5 h-3.5" /> Code-to-Audio 3-Step Guide
      </span>
      <button type="button" onClick={onClose} className="cursor-pointer opacity-60 hover:opacity-100 p-0.5" aria-label="Close guide">
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-0.5">
      <div className={`p-2 rounded-xl border ${darkMode ? 'bg-slate-950/60 border-slate-800' : 'bg-white border-slate-200'}`}>
        <div className="font-bold text-[11px] text-amber-500 flex items-center gap-1">
          <Sparkles className="w-3 h-3 shrink-0" /> 1. Copy Prompt
        </div>
        <p className="text-[10px] opacity-75 mt-0.5 leading-snug">
          Paste in Gemini/AI; tell it what sound you want (wooden tap, chime, zap).
        </p>
      </div>
      <div className={`p-2 rounded-xl border ${darkMode ? 'bg-slate-950/60 border-slate-800' : 'bg-white border-slate-200'}`}>
        <div className="font-bold text-[11px] text-emerald-500 flex items-center gap-1">
          <Code2 className="w-3 h-3 shrink-0" /> 2. Paste Formula
        </div>
        <p className="text-[10px] opacity-75 mt-0.5 leading-snug">
          Paste JS wave line below (or tap any preset card to audition immediately).
        </p>
      </div>
      <div className={`p-2 rounded-xl border ${darkMode ? 'bg-slate-950/60 border-slate-800' : 'bg-white border-slate-200'}`}>
        <div className="font-bold text-[11px] text-cyan-500 flex items-center gap-1">
          <Volume2 className="w-3 h-3 shrink-0" /> 3. Pick &amp; Save
        </div>
        <p className="text-[10px] opacity-75 mt-0.5 leading-snug">
          Select target SFX events (Tick, Victory, etc.) &amp; tap Save &amp; Apply.
        </p>
      </div>
    </div>
  </div>
);

