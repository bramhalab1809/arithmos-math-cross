import { useState, useEffect, useCallback } from 'react';
import { loadState, saveState } from '../../storage/storage';
import { GameMode, ModeControls, ThemeMode } from '../../storage/schema';
import { soundEngine } from '../../audio/soundEngine';

function getSystemPrefersDark(): boolean {
  if (typeof window === 'undefined') return true;
  return window.matchMedia?.('(prefers-color-scheme: dark)')?.matches ?? true;
}

export function useSettings() {
  const [stored, setStored] = useState(() => loadState());
  const [systemDark, setSystemDark] = useState(() => getSystemPrefersDark());

  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const media = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = (e: MediaQueryListEvent) => setSystemDark(e.matches);
    media.addEventListener('change', handler);
    return () => media.removeEventListener('change', handler);
  }, []);

  const resolvedDarkMode =
    stored.settings.themeMode === 'dark'
      ? true
      : stored.settings.themeMode === 'light'
      ? false
      : systemDark;

  const setMuted = useCallback((m: boolean) => {
    soundEngine.setMuted(m);
    setStored(saveState({ muted: m }));
  }, []);

  const toggleMute = useCallback(() => {
    const next = soundEngine.toggleMute();
    setStored(saveState({ muted: next }));
  }, []);

  const setVolume = useCallback((v: number) => {
    soundEngine.setVolume(v);
    setStored(saveState({ volume: v }));
  }, []);

  const setThemeMode = useCallback((mode: ThemeMode) => {
    const nextDark = mode === 'dark' ? true : mode === 'light' ? false : getSystemPrefersDark();
    setStored(saveState({ themeMode: mode, darkMode: nextDark }));
  }, []);

  const toggleModeControl = useCallback(
    (mode: GameMode, key: keyof ModeControls) => {
      setStored((prev) => {
        const curControls = prev.settings.controls[mode];
        const nextControls = {
          ...prev.settings.controls,
          [mode]: {
            ...curControls,
            [key]: !curControls[key],
          },
        };
        return saveState({
          settings: {
            ...prev.settings,
            controls: nextControls,
          },
        });
      });
    },
    []
  );

  return {
    muted: stored.settings.muted,
    volume: stored.settings.volume,
    themeMode: stored.settings.themeMode,
    controls: stored.settings.controls,
    resolvedDarkMode,
    setMuted,
    toggleMute,
    setVolume,
    setThemeMode,
    toggleModeControl,
    refreshSettings: () => setStored(loadState()),
  };
}
