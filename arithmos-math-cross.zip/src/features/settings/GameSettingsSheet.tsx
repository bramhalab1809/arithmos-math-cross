import React, { useEffect } from 'react';
import { Monitor, Settings, SlidersHorizontal, X } from '../../icons';
import { GameMode, ModeControls } from '../../storage/schema';
import { getModeRules } from '../game/state/modeRules';
import { SettingRow, ToggleSwitch } from './SettingRow';
import { SettingsFolder } from './SettingsFolder';
import { SoundSection } from './SoundSection';
import { AiPlayerSection } from './AiPlayerSection';

export interface GameSettingsSheetProps {
  isOpen: boolean;
  mode: GameMode;
  muted: boolean;
  volume: number;
  darkMode: boolean;
  controls: ModeControls;
  onClose: () => void;
  onToggleMute: () => void;
  onChangeVolume: (v: number) => void;
  onToggleControl: (key: keyof ModeControls) => void;
}

export const GameSettingsSheet: React.FC<GameSettingsSheetProps> = ({
  isOpen,
  mode,
  muted,
  volume,
  darkMode,
  controls,
  onClose,
  onToggleMute,
  onChangeVolume,
  onToggleControl,
}) => {
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const rules = getModeRules(mode);
  const isCoarse = typeof window !== 'undefined' && window.matchMedia?.('(pointer: coarse)')?.matches;
  const modeName = mode.charAt(0).toUpperCase() + mode.slice(1);

  const controlItems: Array<{
    key: keyof ModeControls;
    label: string;
    tooltip: string;
    checked: boolean;
    disabled?: boolean;
    show?: boolean;
  }> = [
    { key: 'autoAdvance', label: 'Auto-advance', tooltip: 'Advance to next cell upon fill', checked: controls.autoAdvance },
    { key: 'numpad', label: 'Show numpad', tooltip: isCoarse ? 'Required on touch screens' : 'Display on-screen numpad', checked: isCoarse ? true : controls.numpad, disabled: isCoarse },
    { key: 'equations', label: 'Show equations', tooltip: 'Display row and col equations', checked: controls.equations },
    { key: 'undoRedo', label: 'Show undo/redo', tooltip: 'Display undo and redo buttons', checked: controls.undoRedo },
    { key: 'hint', label: 'Show hint button', tooltip: 'Display Hint in toolbar', checked: controls.hint, show: rules.hasHints },
    { key: 'check', label: 'Show check button', tooltip: 'Display Check in toolbar', checked: controls.check },
    { key: 'retry', label: 'Show retry button', tooltip: 'Display Retry in toolbar', checked: controls.retry },
    { key: 'swap', label: 'Show swap button', tooltip: 'Display Swap in toolbar', checked: controls.swap },
    { key: 'calculator', label: 'Show calculator button', tooltip: 'Display Calculator in toolbar', checked: controls.calculator },
    { key: 'levelInfo', label: 'Level info', tooltip: 'Show grid size, tier, rating & unique badge', checked: controls.levelInfo },
    { key: 'timer', label: 'Show timer', tooltip: 'Display timer countdown/counter', checked: controls.timer },
    { key: 'hearts', label: 'Show hearts', tooltip: 'Display hearts counter', checked: controls.hearts, show: rules.hasHearts },
    { key: 'keyHints', label: 'Show key hints', tooltip: 'Display keyboard shortcuts', checked: controls.keyHints },
    { key: 'timeGlow', label: 'Time pressure glow', tooltip: 'Vignette pulse under 30s', checked: controls.timeGlow },
  ];

  const gameplayKeys = ['autoAdvance', 'numpad', 'undoRedo', 'hint', 'check', 'retry', 'swap', 'calculator'];
  const hudKeys = ['equations', 'levelInfo', 'timer', 'hearts', 'keyHints', 'timeGlow'];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs select-none"
      role="dialog"
      aria-modal="true"
      aria-label={`${modeName} Game Settings`}
    >
      <div
        className={`w-full max-w-md max-h-[90dvh] flex flex-col rounded-3xl border shadow-2xl overflow-hidden ${
          darkMode ? 'bg-[#131B2E] border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Header */}
        <div className={`flex items-center justify-between px-5 py-3 border-b ${
          darkMode ? 'border-slate-800 bg-slate-900/50' : 'border-slate-100 bg-slate-50/50'
        }`}>
          <div className="flex items-center gap-2">
            <Settings className={`w-4 h-4 ${darkMode ? 'text-amber-400' : 'text-blue-600'}`} />
            <h2 className="font-bold text-sm tracking-tight">{modeName} Settings</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-200 cursor-pointer"
            aria-label="Close settings"
            title="Close (Esc)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content with Boxed Folders */}
        <div className="flex-1 overflow-y-auto px-4 sm:px-5 py-3 space-y-3 min-h-0 custom-scrollbar">
          {/* Full Audio & Music Section */}
          <SoundSection
            muted={muted}
            volume={volume}
            darkMode={darkMode}
            onToggleMute={onToggleMute}
            onChangeVolume={onChangeVolume}
          />

          {/* AI Player & Bridge Studio */}
          <AiPlayerSection darkMode={darkMode} />

          {/* Folder 1: Gameplay Controls */}
          <SettingsFolder
            title="Toolbar & Input"
            icon={<SlidersHorizontal className="w-4 h-4" />}
            defaultOpen={true}
            darkMode={darkMode}
          >
            {controlItems
              .filter((i) => gameplayKeys.includes(i.key) && i.show !== false)
              .map((item) => (
                <SettingRow key={item.key} label={item.label} tooltip={item.tooltip}>
                  <ToggleSwitch
                    checked={item.checked}
                    disabled={item.disabled}
                    onChange={() => onToggleControl(item.key)}
                    darkMode={darkMode}
                    aria-label={`Toggle ${item.label}`}
                  />
                </SettingRow>
              ))}
          </SettingsFolder>

          {/* Folder 2: Display & HUD */}
          <SettingsFolder
            title="HUD & Display"
            icon={<Monitor className="w-4 h-4" />}
            defaultOpen={false}
            darkMode={darkMode}
          >
            {controlItems
              .filter((i) => hudKeys.includes(i.key) && i.show !== false)
              .map((item) => (
                <SettingRow key={item.key} label={item.label} tooltip={item.tooltip}>
                  <ToggleSwitch
                    checked={item.checked}
                    disabled={item.disabled}
                    onChange={() => onToggleControl(item.key)}
                    darkMode={darkMode}
                    aria-label={`Toggle ${item.label}`}
                  />
                </SettingRow>
              ))}
          </SettingsFolder>
        </div>
      </div>
    </div>
  );
};
