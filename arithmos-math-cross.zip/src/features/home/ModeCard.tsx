import React from 'react';
import { Flame, Lock, Play, Star, Trophy } from '../../icons';

export interface ModeCardProps {
  title: string;
  icon: React.ReactNode;
  accentColor: 'amber' | 'yellow' | 'emerald' | 'purple' | 'rose' | 'cyan' | 'slate';
  level?: number;
  rating?: number;
  hasActiveSessionInMode?: boolean;
  activeLevel?: number;
  darkMode: boolean;
  stars?: number;
  currentStreak?: number;
  bestStreak?: number;
  customContent?: React.ReactNode;
  subtitle?: string;
  isLocked?: boolean;
  lockedBadge?: string;
  onPlay?: () => void;
}

export const ModeCard: React.FC<ModeCardProps> = ({
  title,
  icon,
  accentColor,
  level,
  rating,
  hasActiveSessionInMode = false,
  darkMode,
  stars,
  currentStreak,
  bestStreak,
  customContent,
  subtitle,
  isLocked = false,
  lockedBadge,
  onPlay,
}) => {
  const iconCircleBg = {
    amber: darkMode ? 'bg-amber-500/15 text-amber-400 border-amber-500/30' : 'bg-amber-50 text-amber-600 border-amber-200',
    yellow: darkMode ? 'bg-yellow-400/15 text-yellow-300 border-yellow-400/30' : 'bg-yellow-50 text-yellow-600 border-yellow-200',
    emerald: darkMode ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30' : 'bg-emerald-50 text-emerald-600 border-emerald-200',
    purple: darkMode ? 'bg-purple-500/15 text-purple-400 border-purple-500/30' : 'bg-purple-50 text-purple-600 border-purple-200',
    rose: darkMode ? 'bg-rose-500/15 text-rose-400 border-rose-500/30' : 'bg-rose-50 text-rose-600 border-rose-200',
    cyan: darkMode ? 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30' : 'bg-cyan-50 text-cyan-600 border-cyan-200',
    slate: darkMode ? 'bg-slate-800/50 text-slate-400 border-slate-700/50' : 'bg-slate-100 text-slate-400 border-slate-200',
  }[accentColor];

  const handleClick = () => {
    if (!isLocked && onPlay) onPlay();
  };

  return (
    <div
      role="button"
      data-bird-perch={`mode-${title.toLowerCase().replace(/\s+/g, '-')}`}
      tabIndex={isLocked ? -1 : 0}
      onClick={handleClick}
      onKeyDown={(e) => {
        if (!isLocked && (e.key === 'Enter' || e.key === ' ')) {
          e.preventDefault();
          handleClick();
        }
      }}
      className={`group relative overflow-hidden rounded-2xl p-2.5 sm:p-3.5 border transition-all duration-150 select-none outline-none flex flex-col items-center justify-between text-center h-full min-w-0 ${
        isLocked
          ? darkMode
            ? 'bg-slate-900/40 border-slate-800/60 opacity-60 cursor-not-allowed'
            : 'bg-slate-50 border-slate-200 opacity-60 cursor-not-allowed'
          : darkMode
          ? 'bg-slate-900/90 border-amber-500/50 shadow-lg shadow-amber-500/10 ring-1 ring-amber-500/30 hover:border-amber-500/70 cursor-pointer'
          : 'bg-white border-blue-500/50 shadow-lg shadow-blue-500/10 ring-1 ring-blue-500/30 hover:border-blue-500/70 cursor-pointer'
      }`}
    >
      {/* Top: Icon + Title */}
      <div className="flex flex-col items-center justify-start w-full gap-1 sm:gap-1.5 min-w-0">
        <div className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full border flex items-center justify-center shrink-0 ${iconCircleBg}`}>
          {icon}
        </div>
        <div className="flex items-center justify-center gap-1.5 max-w-full min-w-0 px-1">
          <h2 className="text-xs sm:text-base font-bold tracking-tight truncate">{title}</h2>
          {hasActiveSessionInMode && (
            <span className="flex h-2 w-2 relative shrink-0" title="Active session in progress">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
            </span>
          )}
          {isLocked && (
            <span className="text-[9px] font-mono px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-400 font-bold border border-slate-700/60 shrink-0">
              {lockedBadge || 'LOCKED'}
            </span>
          )}
        </div>
      </div>

      {/* Middle: Level/Rating or Subtitle */}
      <div className="w-full flex flex-col items-center justify-center my-1 min-w-0">
        {level !== undefined ? (
          <div className="flex flex-col items-center justify-center">
            <span className="text-xl sm:text-3xl font-extrabold font-mono tabular-nums leading-none tracking-tight">
              {level}
            </span>
            <span className="text-[9px] sm:text-[10px] font-mono tracking-widest uppercase opacity-50 mt-0.5">
              LEVEL
            </span>
            {rating !== undefined && (
              <span
                className={`mt-0.5 text-[10px] sm:text-[11px] font-mono font-semibold px-2 py-0.2 rounded-full border tabular-nums ${
                  darkMode ? 'bg-slate-800/80 border-slate-700 text-slate-300' : 'bg-slate-100 border-slate-200 text-slate-700'
                }`}
              >
                {rating}
              </span>
            )}
          </div>
        ) : subtitle ? (
          <div className="text-[10px] sm:text-xs text-center opacity-70 line-clamp-2 px-1 leading-snug">
            {subtitle}
          </div>
        ) : null}

        {stars !== undefined && (
          <div className="flex items-center justify-center gap-2.5 sm:gap-3.5 text-[10px] sm:text-xs font-mono tabular-nums pt-1">
            <div className="flex items-center gap-0.5 text-amber-400">
              <Star className="w-3 h-3 fill-current" />
              <span>{stars}</span>
            </div>
            <div className="flex items-center gap-0.5 text-orange-400">
              <Flame className="w-3 h-3" />
              <span>{currentStreak ?? 0}</span>
            </div>
            <div className="flex items-center gap-0.5 text-yellow-500">
              <Trophy className="w-3 h-3" />
              <span>{bestStreak ?? 0}</span>
            </div>
          </div>
        )}

        {Boolean(customContent) && <div className="w-full mt-1">{customContent}</div>}
      </div>

      {/* Bottom: Centered Play Button */}
      <div className="flex items-center justify-center pt-1 shrink-0">
        {isLocked ? (
          <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-full flex items-center justify-center border border-slate-700/50 opacity-40">
            <Lock className="w-4 h-4" />
          </div>
        ) : (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handleClick();
            }}
            className={`relative w-9 h-9 sm:w-11 sm:h-11 rounded-full flex items-center justify-center transition-all cursor-pointer shadow-md group-hover:scale-105 ${
              darkMode ? 'bg-amber-500 text-slate-950 ring-4 ring-amber-500/30' : 'bg-blue-600 text-white ring-4 ring-blue-500/30'
            }`}
            aria-label={`Play ${title}`}
          >
            <Play className="w-4 h-4 sm:w-5 sm:h-5 fill-current ml-0.5" />
          </button>
        )}
      </div>
    </div>
  );
};
