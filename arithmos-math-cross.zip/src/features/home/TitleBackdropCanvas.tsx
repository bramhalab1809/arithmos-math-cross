import React, { useEffect, useRef } from 'react';

interface FloatingGlyph {
  x: number;
  y: number;
  vx: number;
  vy: number;
  char: string;
  alpha: number;
  size: number;
}

interface TitleBackdropCanvasProps {
  darkMode: boolean;
}

export const TitleBackdropCanvas: React.FC<TitleBackdropCanvasProps> = ({ darkMode }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Isolated 60fps atmospheric math lattice canvas loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId = 0;
    let lastTime = performance.now();

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener('resize', resize);

    const symbols = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '−', '×', '÷', '='];
    const glyphs: FloatingGlyph[] = Array.from({ length: 34 }, (_, i) => ({
      x: (i * 197) % window.innerWidth,
      y: (i * 131) % window.innerHeight,
      vx: (i % 2 === 0 ? 1 : -1) * (8 + (i % 5) * 3),
      vy: -10 - (i % 4) * 4,
      char: symbols[i % symbols.length],
      alpha: 0.05 + (i % 4) * 0.025,
      size: 16 + (i % 3) * 6,
    }));

    let gridOffset = 0;

    const render = (now: number) => {
      const rawDt = (now - lastTime) / 1000;
      const dt = Math.min(rawDt, 0.05);
      lastTime = now;

      const w = window.innerWidth;
      const h = window.innerHeight;

      ctx.clearRect(0, 0, w, h);

      // Subtle architectural blueprint grid
      gridOffset = (gridOffset + dt * 12) % 64;
      ctx.strokeStyle = darkMode ? 'rgba(148, 163, 184, 0.055)' : 'rgba(15, 23, 42, 0.045)';
      ctx.lineWidth = 1;

      const step = 64;
      for (let x = -step + (gridOffset % step); x < w; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = -step + (gridOffset % step); y < h; y += step) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Floating mathematical glyphs
      ctx.font = '600 18px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      for (const g of glyphs) {
        g.x += g.vx * dt;
        g.y += g.vy * dt;
        if (g.x < -40) g.x = w + 40;
        if (g.x > w + 40) g.x = -40;
        if (g.y < -40) g.y = h + 40;

        ctx.fillStyle = darkMode
          ? `rgba(245, 158, 11, ${g.alpha})`
          : `rgba(37, 99, 235, ${g.alpha})`;
        ctx.font = `600 ${g.size}px "JetBrains Mono", monospace`;
        ctx.fillText(g.char, g.x, g.y);
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
    };
  }, [darkMode]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full pointer-events-none"
      aria-hidden="true"
    />
  );
};
