import React, { useState } from 'react';
import { BarChart3, Flame, FlaskConical, Infinity, Settings, Star, Swords, Wrench, Zap } from '../../icons';
import { ActivePuzzleSession, GameMode } from '../../storage/schema';
import { loadState } from '../../storage/storage';
import { listSessions, sessionKeyFor } from '../../storage/sessionStorage';
import { loadMistakes } from '../../storage/mistakes';
import { TitleBackdropCanvas } from './TitleBackdropCanvas';
import { TitleEmblem } from './TitleEmblem';
import { ModeCard } from './ModeCard';
import { GridSizePicker } from './GridSizePicker';
import { InstallAppButton } from './InstallAppButton';

export interface TitleScreenProps {
  darkMode: boolean;
  onResumeGame: (session?: ActivePuzzleSession) => void;
  onStartGame: (mode: GameMode, rating: number, level: number, size: number | null) => void;
  onOpenLevelMap: (mode: 'endless' | 'star' | 'practice' | 'hardcore', practiceSize?: 'auto' | 3 | 4 | 5 | 6 | 7) => void;
  onOpenSettings: () => void;
  onOpenAnalytics?: () => void;
  onOpenLab: () => void;
  onOpenMistakes: () => void;
  onOpenMultiplayer: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  darkMode,
  onOpenLevelMap,
  onOpenSettings,
  onOpenAnalytics,
  onOpenLab,
  onOpenMistakes,
  onOpenMultiplayer,
}) => {
  const stored = loadState();
  const sessions = listSessions();
  const mistakes = loadMistakes();
  const pendingMistakes = mistakes.filter((m) => !m.repaired).length;

  const [practiceSize, setPracticeSize] = useState<'auto' | 3 | 4 | 5 | 6 | 7>(
    (stored.modes.practice?.lastGridSize as 'auto' | 3 | 4 | 5 | 6 | 7) || 'auto'
  );
  const [hardcoreSize, setHardcoreSize] = useState<'auto' | 3 | 4 | 5 | 6 | 7>(
    (stored.modes.hardcore?.lastGridSize as 'auto' | 3 | 4 | 5 | 6 | 7) || 'auto'
  );

  const endlessSession = sessions['endless'];
  const starSession = sessions['star'];
  const practiceKey = sessionKeyFor('practice', practiceSize === 'auto' ? null : practiceSize, practiceSize === 'auto');
  const practiceSession = sessions[practiceKey];

  const hardcoreKey = sessionKeyFor('hardcore', hardcoreSize === 'auto' ? null : hardcoreSize, hardcoreSize === 'auto');
  const hardcoreSession = sessions[hardcoreKey];

  const practiceSlotKey = String(practiceSize);
  const practiceSlot =
    stored.modes.practice?.slots?.[practiceSlotKey as keyof typeof stored.modes.practice.slots] || {
      rating: 100, level: 1, played: 0,
    };

  const hardcoreSlotKey = String(hardcoreSize);
  const hardcoreSlot =
    stored.modes.hardcore?.slots?.[hardcoreSlotKey as keyof typeof stored.modes.practice.slots] || {
      rating: 120, level: 1, played: 0,
    };

  const getLevels = (c?: any) => ({ auto: c?.slots?.auto?.level ?? 1, '3': c?.slots?.['3']?.level ?? 1, '4': c?.slots?.['4']?.level ?? 1, '5': c?.slots?.['5']?.level ?? 1, '6': c?.slots?.['6']?.level ?? 1, '7': c?.slots?.['7']?.level ?? 1 });
  const getRatings = (c?: any, base = 100) => ({ auto: c?.slots?.auto?.rating ?? base, '3': c?.slots?.['3']?.rating ?? base, '4': c?.slots?.['4']?.rating ?? base, '5': c?.slots?.['5']?.rating ?? base, '6': c?.slots?.['6']?.rating ?? base, '7': c?.slots?.['7']?.rating ?? base });

  return (
    <div
      className={`relative w-screen min-h-dvh max-h-dvh overflow-y-auto overflow-x-hidden no-scrollbar select-none flex flex-col justify-between transition-colors duration-200 ${
        darkMode ? 'bg-[#0B0F17] text-slate-100' : 'bg-[#F8FAFC] text-slate-900'
      }`}
    >
      <TitleBackdropCanvas darkMode={darkMode} />

      <header className="relative z-10 flex items-center justify-end gap-2 px-4 sm:px-6 py-1.5 sm:py-2.5 max-w-6xl w-full mx-auto shrink-0">
        <InstallAppButton darkMode={darkMode} />
        {onOpenAnalytics && (
          <button
            type="button"
            onClick={onOpenAnalytics}
            className={`p-2 rounded-xl border transition-colors cursor-pointer ${
              darkMode ? 'border-slate-800 bg-slate-900/70 text-slate-300 hover:bg-slate-800 hover:text-white' : 'border-slate-200 bg-white/80 text-slate-700 hover:bg-slate-100 hover:text-slate-900'
            }`}
            aria-label="Analytics"
            title="Analytics"
          >
            <BarChart3 className="w-4 h-4" />
          </button>
        )}
        <button
          type="button"
          onClick={onOpenSettings}
          className={`p-2 rounded-xl border transition-colors cursor-pointer ${
            darkMode ? 'border-slate-800 bg-slate-900/70 text-slate-300 hover:bg-slate-800 hover:text-white' : 'border-slate-200 bg-white/80 text-slate-700 hover:bg-slate-100 hover:text-slate-900'
          }`}
          aria-label="Settings"
          title="Settings"
        >
          <Settings className="w-4 h-4" />
        </button>
      </header>

      <main className="relative z-10 max-w-6xl w-full mx-auto px-3 sm:px-6 py-0.5 my-auto flex flex-col items-center">
        <div className="home-brand-group mb-0.5 sm:mb-1.5">
          <TitleEmblem darkMode={darkMode} />
          <h1 className="home-brand-title font-display text-xl sm:text-2xl font-bold tracking-tight mb-0.5 sm:mb-1 text-center">
            Arithmos
          </h1>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 sm:gap-3 w-full items-stretch">
          <ModeCard
            title="Endless"
            accentColor="amber"
            icon={<Flame className="w-6 h-6 text-amber-500" />}
            level={stored.modes.endless.level}
            rating={stored.modes.endless.rating}
            hasActiveSessionInMode={Boolean(endlessSession)}
            activeLevel={endlessSession?.level}
            darkMode={darkMode}
            onPlay={() => onOpenLevelMap('endless')}
          />

          <ModeCard
            title="Star"
            accentColor="yellow"
            icon={<Star className="w-6 h-6 text-yellow-400 fill-yellow-400" />}
            level={stored.modes.star.level}
            rating={stored.modes.star.rating}
            hasActiveSessionInMode={Boolean(starSession)}
            activeLevel={starSession?.level}
            darkMode={darkMode}
            stars={stored.modes.star.totalStars}
            currentStreak={stored.modes.star.currentStreak}
            bestStreak={stored.modes.star.bestStreak}
            onPlay={() => onOpenLevelMap('star')}
          />

          <ModeCard
            title="Hardcore"
            accentColor="rose"
            icon={<Zap className="w-6 h-6 text-rose-500 fill-rose-500/20" />}
            level={hardcoreSlot.level}
            rating={hardcoreSize === 'auto' ? undefined : hardcoreSlot.rating}
            hasActiveSessionInMode={Boolean(hardcoreSession)}
            activeLevel={hardcoreSession?.level}
            darkMode={darkMode}
            customContent={
              <GridSizePicker
                allowAuto
                selectedSize={hardcoreSize}
                darkMode={darkMode}
                onSelectSize={(s) => setHardcoreSize(s as 'auto' | 3 | 4 | 5 | 6 | 7)}
                gridLevels={getLevels(stored.modes.hardcore)}
                gridRatings={getRatings(stored.modes.hardcore, 120)}
              />
            }
            onPlay={() => onOpenLevelMap('hardcore', hardcoreSize)}
          />

          <ModeCard
            title="Practice"
            accentColor="emerald"
            icon={<Infinity className="w-6 h-6 text-emerald-500" />}
            level={practiceSlot.level}
            rating={practiceSize === 'auto' ? undefined : practiceSlot.rating}
            hasActiveSessionInMode={Boolean(practiceSession)}
            activeLevel={practiceSession?.level}
            darkMode={darkMode}
            customContent={
              <GridSizePicker
                allowAuto
                selectedSize={practiceSize}
                darkMode={darkMode}
                onSelectSize={(s) => setPracticeSize(s as 'auto' | 3 | 4 | 5 | 6 | 7)}
                gridLevels={getLevels(stored.modes.practice)}
                gridRatings={getRatings(stored.modes.practice, 100)}
              />
            }
            onPlay={() => onOpenLevelMap('practice', practiceSize)}
          />

          <ModeCard
            title="Level Lab"
            accentColor="purple"
            icon={<FlaskConical className="w-6 h-6 text-purple-400" />}
            subtitle="Numbered project boxes, [+] builder & AI prompts"
            darkMode={darkMode}
            onPlay={onOpenLab}
          />

          <ModeCard
            title="Mistake Hub"
            accentColor="rose"
            icon={<Wrench className="w-6 h-6 text-rose-400" />}
            subtitle={pendingMistakes > 0 ? `${pendingMistakes} pending mistake boxes to repair` : 'Operator clinic & targeted error repair'}
            darkMode={darkMode}
            onPlay={onOpenMistakes}
          />

          <ModeCard
            title="Multiplayer"
            accentColor="cyan"
            icon={<Swords className="w-6 h-6 text-cyan-400" />}
            subtitle="Human vs. AI Arena & External Web AI Relay"
            darkMode={darkMode}
            onPlay={onOpenMultiplayer}
          />
        </div>
      </main>

      <div className="h-1 sm:h-2 shrink-0" aria-hidden="true" />
    </div>
  );
};
