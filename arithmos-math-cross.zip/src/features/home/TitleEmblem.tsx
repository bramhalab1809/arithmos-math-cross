import React from 'react';

interface TitleEmblemProps {
  darkMode: boolean;
}

export const TitleEmblem: React.FC<TitleEmblemProps> = ({ darkMode }) => {
  return (
    <div className="home-emblem-wrapper mb-2 sm:mb-4 emblem-animated shrink-0">
      <svg
        viewBox="0 0 84 84"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="home-emblem-svg mx-auto"
        aria-hidden="true"
      >
        <rect
          x="6"
          y="6"
          width="28"
          height="28"
          rx="6"
          className={
            darkMode ? 'stroke-amber-400 fill-amber-500/10' : 'stroke-blue-600 fill-blue-500/10'
          }
          strokeWidth="2.2"
        />
        <rect
          x="50"
          y="6"
          width="28"
          height="28"
          rx="6"
          className={darkMode ? 'stroke-slate-600 fill-slate-900/80' : 'stroke-slate-300 fill-white'}
          strokeWidth="2"
        />
        <rect
          x="6"
          y="50"
          width="28"
          height="28"
          rx="6"
          className={darkMode ? 'stroke-slate-600 fill-slate-900/80' : 'stroke-slate-300 fill-white'}
          strokeWidth="2"
        />
        <rect
          x="50"
          y="50"
          width="28"
          height="28"
          rx="6"
          className={
            darkMode
              ? 'stroke-emerald-400 fill-emerald-500/10'
              : 'stroke-emerald-600 fill-emerald-500/10'
          }
          strokeWidth="2.2"
        />
        {/* Horizontal and vertical operator connectors */}
        <path
          d="M38 20H46M42 16V24"
          className={darkMode ? 'stroke-amber-400' : 'stroke-blue-600'}
          strokeWidth="2.2"
          strokeLinecap="round"
        />
        <path
          d="M16 42H24M16 42H24"
          className={darkMode ? 'stroke-slate-400' : 'stroke-slate-500'}
          strokeWidth="2.2"
          strokeLinecap="round"
        />
        <path
          d="M60 40H68M60 44H68"
          className={darkMode ? 'stroke-emerald-400' : 'stroke-emerald-600'}
          strokeWidth="2.2"
          strokeLinecap="round"
        />
        <path
          d="M38 62H46M38 66H46"
          className={darkMode ? 'stroke-emerald-400' : 'stroke-emerald-600'}
          strokeWidth="2.2"
          strokeLinecap="round"
        />
        <text
          x="20"
          y="25"
          textAnchor="middle"
          className={`font-mono text-sm font-bold ${darkMode ? 'fill-amber-300' : 'fill-blue-700'}`}
        >
          3
        </text>
        <text
          x="64"
          y="25"
          textAnchor="middle"
          className={`font-mono text-sm font-bold ${darkMode ? 'fill-slate-200' : 'fill-slate-700'}`}
        >
          4
        </text>
        <text
          x="20"
          y="69"
          textAnchor="middle"
          className={`font-mono text-sm font-bold ${darkMode ? 'fill-slate-200' : 'fill-slate-700'}`}
        >
          2
        </text>
        <text
          x="64"
          y="69"
          textAnchor="middle"
          className={`font-mono text-sm font-bold ${
            darkMode ? 'fill-emerald-300' : 'fill-emerald-700'
          }`}
        >
          7
        </text>
      </svg>
    </div>
  );
};
