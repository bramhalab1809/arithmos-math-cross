import React from 'react';
import { Grid } from '../../icons';

export interface GridSizePickerProps {
  selectedSize: number | 'auto';
  darkMode: boolean;
  onSelectSize: (size: number | 'auto') => void;
  gridLevels?: Record<string, number>;
  gridRatings?: Record<string, number>;
  allowAuto?: boolean;
}

const SIZES = [3, 4, 5, 6, 7];

export const GridSizePicker: React.FC<GridSizePickerProps> = ({
  selectedSize,
  darkMode,
  onSelectSize,
  gridLevels,
  gridRatings,
  allowAuto = false,
}) => {
  return (
    <div
      className="flex items-center justify-center gap-1 flex-wrap max-w-full px-0.5 py-0.5"
      role="group"
      aria-label="Grid size selection"
    >
      {allowAuto && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onSelectSize('auto');
          }}
          aria-label="Auto grid size"
          title={`Auto Grid (Level ${gridLevels?.auto ?? 1})`}
          className={`shrink-0 inline-flex items-center gap-0.5 px-1.5 py-0.5 sm:px-2 sm:py-0.5 rounded-md text-[10px] sm:text-xs font-mono font-medium transition-all cursor-pointer border ${
            selectedSize === 'auto'
              ? darkMode
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-2xs'
                : 'bg-emerald-600/15 text-emerald-800 border-emerald-600/40 shadow-2xs'
              : darkMode
              ? 'bg-slate-800/60 text-slate-400 border-slate-700/60 hover:text-slate-200 hover:bg-slate-800'
              : 'bg-slate-100 text-slate-600 border-slate-200 hover:text-slate-900 hover:bg-slate-200/60'
          }`}
        >
          <Grid className="w-2.5 h-2.5 opacity-70" />
          <span>Auto</span>
        </button>
      )}

      {SIZES.map((size) => {
        const isSelected = size === selectedSize;
        const key = String(size);
        const lvl = gridLevels?.[key] ?? 1;
        const rtg = gridRatings?.[key];

        return (
          <button
            key={size}
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onSelectSize(size);
            }}
            aria-label={`${size} by ${size} grid`}
            title={`${size}x${size} (Level ${lvl}${rtg ? ` · Rating ${rtg}` : ''})`}
            className={`shrink-0 px-1.5 py-0.5 sm:px-2 sm:py-0.5 rounded-md text-[10px] sm:text-xs font-mono font-medium transition-all cursor-pointer border ${
              isSelected
                ? darkMode
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-2xs'
                  : 'bg-emerald-600/15 text-emerald-800 border-emerald-600/40 shadow-2xs'
                : darkMode
                ? 'bg-slate-800/60 text-slate-400 border-slate-700/60 hover:text-slate-200 hover:bg-slate-800'
                : 'bg-slate-100 text-slate-600 border-slate-200 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            {size}
          </button>
        );
      })}
    </div>
  );
};
