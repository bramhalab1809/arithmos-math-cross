import { useState, useCallback, useRef, useEffect } from 'react';
import {
  CalcOperator,
  CalcState,
  INITIAL_CALC_STATE,
  handleBackspace,
  handleDecimal,
  handleDigit,
  handleEquals,
  handleOperator,
  handleToggleSign,
} from './calcEngine';

export function useCalculator(
  isOpen = false,
  calcUsesRemaining: number = Infinity,
  onConsumeOpenUse?: () => void
) {
  const [calcState, setCalcState] = useState<CalcState>(INITIAL_CALC_STATE);
  const hasPaidOpenCostRef = useRef<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      hasPaidOpenCostRef.current = false;
    }
  }, [isOpen]);

  const triggerOpenCostIfNeeded = useCallback(() => {
    if (!hasPaidOpenCostRef.current) {
      hasPaidOpenCostRef.current = true;
      onConsumeOpenUse?.();
    }
  }, [onConsumeOpenUse]);

  const onDigit = useCallback((d: string) => {
    setCalcState((prev) => handleDigit(prev, d));
  }, []);

  const onDecimal = useCallback(() => {
    setCalcState((prev) => handleDecimal(prev));
  }, []);

  const onOperator = useCallback(
    (op: CalcOperator) => {
      triggerOpenCostIfNeeded();
      setCalcState((prev) => handleOperator(prev, op));
    },
    [triggerOpenCostIfNeeded]
  );

  const onEquals = useCallback(() => {
    triggerOpenCostIfNeeded();
    setCalcState((prev) => handleEquals(prev));
  }, [triggerOpenCostIfNeeded]);

  const onClear = useCallback(() => {
    setCalcState(INITIAL_CALC_STATE);
  }, []);

  const onToggleSign = useCallback(() => {
    setCalcState((prev) => handleToggleSign(prev));
  }, []);

  const onBackspace = useCallback(() => {
    setCalcState((prev) => handleBackspace(prev));
  }, []);

  const currentNumber = parseFloat(calcState.display);
  const isValidInteger = !calcState.error && Number.isInteger(currentNumber);

  return {
    calcState,
    onDigit,
    onDecimal,
    onOperator,
    onEquals,
    onClear,
    onToggleSign,
    onBackspace,
    currentNumber: Number.isNaN(currentNumber) ? null : currentNumber,
    isValidInteger,
  };
}
