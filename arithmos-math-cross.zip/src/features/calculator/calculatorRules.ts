export const CALCULATOR_POOL = 3;
export const CALCULATOR_OPEN_COST = 1;
export const CALCULATOR_INSERT_COST = 1;
