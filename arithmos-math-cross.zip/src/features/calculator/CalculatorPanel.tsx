import React, { useEffect, useRef, useState } from 'react';
import { Calculator, X, Delete, Infinity } from '../../icons';
import { CalculatorKey } from './CalculatorKey';
import { useCalculator } from './useCalculator';
import { GridPosition } from '../game/state/gameTypes';

export interface CalculatorPanelProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  focusedPos: GridPosition | null;
  isCellEditable: boolean;
  valueDomain: [number, number];
  calcUsesRemaining: number;
  onApplyToCell: (value: number) => void;
  onConsumeOpenUse?: () => void;
  className?: string;
}

export const CalculatorPanel: React.FC<CalculatorPanelProps> = ({
  isOpen,
  onClose,
  darkMode,
  focusedPos,
  isCellEditable,
  valueDomain,
  calcUsesRemaining,
  onApplyToCell,
  onConsumeOpenUse,
  className = '',
}) => {
  const panelRef = useRef<HTMLDivElement>(null);
  const [isFocused, setIsFocused] = useState(true);

  const {
    calcState,
    onDigit,
    onDecimal,
    onOperator,
    onEquals,
    onClear,
    onToggleSign,
    onBackspace,
    currentNumber,
    isValidInteger,
  } = useCalculator(isOpen, calcUsesRemaining, onConsumeOpenUse);

  useEffect(() => {
    if (isOpen) {
      panelRef.current?.focus();
      setIsFocused(true);
    }
  }, [isOpen]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape' || e.key === 'k' || e.key === 'K') {
      e.preventDefault();
      e.stopPropagation();
      onClose();
    } else if (e.key >= '0' && e.key <= '9') {
      e.preventDefault();
      e.stopPropagation();
      onDigit(e.key);
    } else if (e.key === '.') {
      e.preventDefault();
      e.stopPropagation();
      onDecimal();
    } else if (e.key === '+') {
      e.preventDefault();
      e.stopPropagation();
      onOperator('+');
    } else if (e.key === '-') {
      e.preventDefault();
      e.stopPropagation();
      onOperator('-');
    } else if (e.key === '*' || e.key === 'x' || e.key === 'X') {
      e.preventDefault();
      e.stopPropagation();
      onOperator('×');
    } else if (e.key === '/') {
      e.preventDefault();
      e.stopPropagation();
      onOperator('÷');
    } else if (e.key === 'Enter' || e.key === '=') {
      e.preventDefault();
      e.stopPropagation();
      onEquals();
    } else if (e.key === 'Backspace' || e.key === 'Delete') {
      e.preventDefault();
      e.stopPropagation();
      onBackspace();
    } else if (e.key === 'c' || e.key === 'C') {
      e.preventDefault();
      e.stopPropagation();
      onClear();
    }
  };

  if (!isOpen) return null;

  const [minVal, maxVal] = valueDomain;
  const hasUses = calcUsesRemaining > 0;
  const canUseInCell =
    hasUses &&
    isCellEditable &&
    isValidInteger &&
    currentNumber !== null &&
    currentNumber >= minVal &&
    currentNumber <= maxVal;

  let cellActionLabel = 'Select an empty cell';
  if (!hasUses) {
    cellActionLabel = 'No uses left';
  } else if (isCellEditable) {
    if (canUseInCell) {
      cellActionLabel = `Use ${currentNumber} in R${(focusedPos?.row ?? 0) + 1}C${(focusedPos?.col ?? 0) + 1}`;
    } else {
      cellActionLabel = `Result must be integer in ${minVal}–${maxVal}`;
    }
  }

  const handleUseInCell = () => {
    if (canUseInCell && currentNumber !== null) {
      onApplyToCell(currentNumber);
      onClear();
      panelRef.current?.focus();
    }
  };

  return (
    <div
      ref={panelRef}
      tabIndex={0}
      onFocus={() => setIsFocused(true)}
      onBlur={(e) => {
        if (!panelRef.current?.contains(e.relatedTarget as Node)) {
          setIsFocused(false);
        }
      }}
      onKeyDown={handleKeyDown}
      className={`w-full max-w-[360px] mx-auto rounded-2xl border p-2.5 sm:p-3 shadow-lg flex flex-col justify-between gap-1.5 sm:gap-2 select-none outline-none transition-all duration-150 ${
        isFocused ? 'ring-2 ring-indigo-500/80 border-indigo-500/50' : ''
      } ${
        darkMode ? 'bg-[#10172A] border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
      } ${className}`}
    >
      {/* Header */}
      <div className="flex items-center justify-between pb-1 border-b border-slate-200/60 dark:border-slate-800/60">
        <div className="flex items-center gap-1.5 text-xs font-semibold">
          <Calculator className="w-3.5 h-3.5 text-indigo-500" />
          <span>Calculator</span>
          {Number.isFinite(calcUsesRemaining) ? (
            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-indigo-500/15 text-indigo-400">
              {calcUsesRemaining} left
            </span>
          ) : (
            <span title="Unlimited uses">
              <Infinity className="w-3.5 h-3.5 text-indigo-400" />
            </span>
          )}
        </div>
        <button
          type="button"
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-slate-200 cursor-pointer"
          title="Close (Esc / K)"
          aria-label="Close calculator"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Live Display Screen */}
      <div
        className={`rounded-xl px-2.5 py-1.5 flex flex-col justify-end text-right border font-mono tabular-nums min-h-[48px] ${
          darkMode ? 'bg-slate-950/80 border-slate-800' : 'bg-slate-50 border-slate-200'
        }`}
      >
        <div className="text-[10px] text-slate-400 h-3.5 truncate">
          {calcState.formula}
        </div>
        <div className="text-lg sm:text-xl font-bold tracking-tight truncate leading-tight">
          {calcState.display}
        </div>
      </div>

      {/* Keypad Grid */}
      <div className="grid grid-cols-4 gap-1 sm:gap-1.5">
        <CalculatorKey label="C" onClick={onClear} variant="action" darkMode={darkMode} />
        <CalculatorKey label="±" onClick={onToggleSign} variant="action" darkMode={darkMode} />
        <CalculatorKey label={<Delete className="w-3.5 h-3.5" />} onClick={onBackspace} variant="action" darkMode={darkMode} />
        <CalculatorKey label="÷" onClick={() => onOperator('÷')} variant="operator" darkMode={darkMode} />
        <CalculatorKey label="7" onClick={() => onDigit('7')} darkMode={darkMode} />
        <CalculatorKey label="8" onClick={() => onDigit('8')} darkMode={darkMode} />
        <CalculatorKey label="9" onClick={() => onDigit('9')} darkMode={darkMode} />
        <CalculatorKey label="×" onClick={() => onOperator('×')} variant="operator" darkMode={darkMode} />

        <CalculatorKey label="4" onClick={() => onDigit('4')} darkMode={darkMode} />
        <CalculatorKey label="5" onClick={() => onDigit('5')} darkMode={darkMode} />
        <CalculatorKey label="6" onClick={() => onDigit('6')} darkMode={darkMode} />
        <CalculatorKey label="-" onClick={() => onOperator('-')} variant="operator" darkMode={darkMode} />

        <CalculatorKey label="1" onClick={() => onDigit('1')} darkMode={darkMode} />
        <CalculatorKey label="2" onClick={() => onDigit('2')} darkMode={darkMode} />
        <CalculatorKey label="3" onClick={() => onDigit('3')} darkMode={darkMode} />
        <CalculatorKey label="+" onClick={() => onOperator('+')} variant="operator" darkMode={darkMode} />

        <CalculatorKey label="0" onClick={() => onDigit('0')} colSpan={2} darkMode={darkMode} />
        <CalculatorKey label="." onClick={onDecimal} darkMode={darkMode} />
        <CalculatorKey label="=" onClick={onEquals} variant="equals" darkMode={darkMode} />
      </div>

      {/* Cell Paste Action - keeps panel open, clears display */}
      <button
        type="button"
        disabled={!canUseInCell}
        onClick={handleUseInCell}
        className="w-full py-1.5 px-2.5 rounded-xl font-medium text-xs border transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed bg-indigo-600 hover:bg-indigo-700 text-white border-indigo-500/50"
      >
        {cellActionLabel}
      </button>
    </div>
  );
};
