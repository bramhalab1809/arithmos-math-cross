import React from 'react';

export interface CalculatorKeyProps {
  label: React.ReactNode;
  onClick: () => void;
  variant?: 'digit' | 'operator' | 'action' | 'equals';
  colSpan?: number;
  darkMode: boolean;
  disabled?: boolean;
}

export const CalculatorKey: React.FC<CalculatorKeyProps> = ({
  label,
  onClick,
  variant = 'digit',
  colSpan = 1,
  darkMode,
  disabled = false,
}) => {
  let colorClasses = '';

  if (variant === 'equals') {
    colorClasses = darkMode
      ? 'bg-amber-600 hover:bg-amber-500 text-white font-bold border-amber-500/50'
      : 'bg-amber-500 hover:bg-amber-600 text-white font-bold border-amber-600/30';
  } else if (variant === 'operator') {
    colorClasses = darkMode
      ? 'bg-indigo-950/60 hover:bg-indigo-900/80 text-indigo-300 font-semibold border-indigo-700/40'
      : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold border-indigo-200';
  } else if (variant === 'action') {
    colorClasses = darkMode
      ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium border-slate-700'
      : 'bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium border-slate-200';
  } else {
    // Digit
    colorClasses = darkMode
      ? 'bg-slate-900/90 hover:bg-slate-800 text-slate-100 font-semibold border-slate-800'
      : 'bg-white hover:bg-slate-50 text-slate-900 font-semibold border-slate-200 shadow-2xs';
  }

  const spanClass = colSpan === 2 ? 'col-span-2' : 'col-span-1';

  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={`h-10 rounded-xl border flex items-center justify-center text-sm font-mono transition-colors active:scale-95 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${spanClass} ${colorClasses}`}
    >
      {label}
    </button>
  );
};
