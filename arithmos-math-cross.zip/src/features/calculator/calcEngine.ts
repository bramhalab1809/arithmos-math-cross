export type CalcOperator = '+' | '-' | '×' | '÷';

export type CalcToken =
  | { type: 'number'; value: string }
  | { type: 'op'; op: CalcOperator };

export interface CalcState {
  tokens: CalcToken[];
  isFinalized: boolean;
  formula: string;
  display: string;
  error: string | null;
}

export const INITIAL_CALC_STATE: CalcState = {
  tokens: [],
  isFinalized: false,
  formula: '',
  display: '0',
  error: null,
};

export function formatResultNumber(val: number): string {
  if (!Number.isFinite(val)) return 'Error';
  const rounded = parseFloat(val.toFixed(8));
  const str = rounded.toString();
  if (str.length > 12) {
    return rounded.toPrecision(8).replace(/\.?0+$/, '');
  }
  return str;
}

export function executeOp(left: number, right: number, op: CalcOperator): { value: number; error: string | null } {
  switch (op) {
    case '+':
      return { value: left + right, error: null };
    case '-':
      return { value: left - right, error: null };
    case '×':
      return { value: left * right, error: null };
    case '÷':
      if (right === 0) return { value: 0, error: 'Cannot divide by 0' };
      return { value: left / right, error: null };
  }
}

export function evaluateTokens(tokens: CalcToken[], isFinalized: boolean): { formula: string; display: string; error: string | null } {
  if (tokens.length === 0) {
    return { formula: '', display: '0', error: null };
  }

  let formula = tokens.map((t) => (t.type === 'number' ? t.value : t.op)).join(' ');
  if (isFinalized) {
    formula += ' =';
  }

  let result: number | null = null;
  let currentOp: CalcOperator | null = null;

  for (const t of tokens) {
    if (t.type === 'number') {
      const val = parseFloat(t.value);
      if (Number.isNaN(val)) continue;
      if (result === null) {
        result = val;
      } else if (currentOp) {
        const res = executeOp(result, val, currentOp);
        if (res.error) {
          return { formula, display: res.error, error: res.error };
        }
        result = res.value;
      }
    } else {
      currentOp = t.op;
    }
  }

  return {
    formula,
    display: result !== null ? formatResultNumber(result) : '0',
    error: null,
  };
}

export function handleDigit(state: CalcState, digit: string): CalcState {
  if (state.error || state.isFinalized) {
    const tokens: CalcToken[] = [{ type: 'number', value: digit }];
    return { ...state, tokens, isFinalized: false, ...evaluateTokens(tokens, false) };
  }

  const tokens = state.tokens.map((t) => ({ ...t }));
  if (tokens.length === 0) {
    tokens.push({ type: 'number', value: digit });
  } else {
    const last = tokens[tokens.length - 1];
    if (last.type === 'number') {
      if (last.value === '0') {
        last.value = digit;
      } else if (last.value.replace('-', '').replace('.', '').length < 12) {
        last.value += digit;
      }
    } else {
      tokens.push({ type: 'number', value: digit });
    }
  }

  return { ...state, tokens, isFinalized: false, ...evaluateTokens(tokens, false) };
}

export function handleDecimal(state: CalcState): CalcState {
  if (state.error || state.isFinalized) {
    const tokens: CalcToken[] = [{ type: 'number', value: '0.' }];
    return { ...state, tokens, isFinalized: false, ...evaluateTokens(tokens, false) };
  }

  const tokens = state.tokens.map((t) => ({ ...t }));
  if (tokens.length === 0 || tokens[tokens.length - 1].type === 'op') {
    tokens.push({ type: 'number', value: '0.' });
  } else {
    const last = tokens[tokens.length - 1];
    if (last.type === 'number' && !last.value.includes('.')) {
      last.value += '.';
    }
  }

  return { ...state, tokens, isFinalized: false, ...evaluateTokens(tokens, false) };
}

export function handleOperator(state: CalcState, op: CalcOperator): CalcState {
  if (state.error) return state;

  let tokens = state.tokens.map((t) => ({ ...t }));
  if (state.isFinalized) {
    tokens = [{ type: 'number', value: state.display }, { type: 'op', op }];
    return { ...state, tokens, isFinalized: false, ...evaluateTokens(tokens, false) };
  }

  if (tokens.length === 0) {
    tokens.push({ type: 'number', value: '0' }, { type: 'op', op });
  } else {
    const last = tokens[tokens.length - 1];
    if (last.type === 'op') {
      last.op = op;
    } else {
      tokens.push({ type: 'op', op });
    }
  }

  return { ...state, tokens, isFinalized: false, ...evaluateTokens(tokens, false) };
}

export function handleEquals(state: CalcState): CalcState {
  if (state.error || state.isFinalized || state.tokens.length < 2) return state;
  const tokens = state.tokens.filter((t, i) => !(i === state.tokens.length - 1 && t.type === 'op'));
  return { ...state, tokens, isFinalized: true, ...evaluateTokens(tokens, true) };
}

export function handleToggleSign(state: CalcState): CalcState {
  if (state.error || state.tokens.length === 0) return state;
  const tokens = state.tokens.map((t) => ({ ...t }));
  const last = tokens[tokens.length - 1];
  if (last.type === 'number') {
    if (last.value.startsWith('-')) {
      last.value = last.value.slice(1);
    } else if (last.value !== '0') {
      last.value = '-' + last.value;
    }
  }
  return { ...state, tokens, ...evaluateTokens(tokens, state.isFinalized) };
}

export function handleBackspace(state: CalcState): CalcState {
  if (state.error) return INITIAL_CALC_STATE;
  if (state.isFinalized) {
    return { ...state, isFinalized: false, ...evaluateTokens(state.tokens, false) };
  }

  const tokens = state.tokens.map((t) => ({ ...t }));
  if (tokens.length === 0) return state;

  const last = tokens[tokens.length - 1];
  if (last.type === 'number') {
    if (last.value.length <= 1 || (last.value.length === 2 && last.value.startsWith('-'))) {
      tokens.pop();
    } else {
      last.value = last.value.slice(0, -1);
    }
  } else {
    tokens.pop();
  }

  return { ...state, tokens, isFinalized: false, ...evaluateTokens(tokens, false) };
}
