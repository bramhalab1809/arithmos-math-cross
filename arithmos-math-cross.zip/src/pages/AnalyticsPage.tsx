import React, { useMemo, useState } from 'react';
import { HistoryRecord, loadHistory } from '../storage/history';
import { GameMode } from '../storage/schema';
import { ArrowLeft, BarChart3 } from '../icons';
import {
  ModeTabs,
  RangeSwitch,
  HistoryRange,
  InsightChips,
  SummaryCards,
  ChartsGrid,
  BreakdownChartsGrid,
  LevelTable,
  LevelDetail,
} from '../features/analytics/components';
import {
  selectSummary,
  selectSeries,
  selectGridStats,
  selectOperatorMastery,
  selectActivity,
  selectInsights,
} from '../features/analytics/selectors';

interface AnalyticsPageProps {
  initialMode?: GameMode;
  initialEntryId?: string;
  darkMode?: boolean;
  onBack: () => void;
  onPlayMode?: (mode: GameMode, level?: number) => void;
}

export const AnalyticsPage: React.FC<AnalyticsPageProps> = ({
  initialMode = 'endless',
  initialEntryId,
  darkMode = false,
  onBack,
  onPlayMode,
}) => {
  const allRecords = useMemo(() => loadHistory(), []);

  const initialEntry = useMemo(() => {
    if (!initialEntryId) return null;
    return allRecords.find((r) => r.id === initialEntryId) || null;
  }, [allRecords, initialEntryId]);

  const [mode, setMode] = useState<GameMode>(initialEntry?.mode ?? initialMode);
  const [gridFilter, setGridFilter] = useState<number | 'all'>('all');
  const [range, setRange] = useState<HistoryRange>(25);
  const [selectedEntry, setSelectedEntry] = useState<HistoryRecord | null>(initialEntry);

  const counts: Record<GameMode, number> = useMemo(() => ({
    endless: allRecords.filter((r) => r.mode === 'endless').length,
    star: allRecords.filter((r) => r.mode === 'star').length,
    practice: allRecords.filter((r) => r.mode === 'practice').length,
    lab: allRecords.filter((r) => r.mode === 'lab').length,
    repair: allRecords.filter((r) => r.mode === 'repair').length,
    multiplayer: allRecords.filter((r) => r.mode === 'multiplayer').length,
  }), [allRecords]);

  const baseModeRecords = useMemo(
    () => allRecords.filter((r) => r.mode === mode),
    [allRecords, mode]
  );

  const modeRecords = useMemo(() => {
    if (mode === 'practice' && gridFilter !== 'all') {
      return baseModeRecords.filter((r) => r.gridSize === gridFilter);
    }
    return baseModeRecords;
  }, [baseModeRecords, mode, gridFilter]);

  const handleSelectMode = (newMode: GameMode) => {
    setMode(newMode);
    setGridFilter('all');
  };

  const rangeRecords = useMemo(() => {
    if (range === 'all') return modeRecords;
    return modeRecords.slice(0, range);
  }, [modeRecords, range]);

  const summary = useMemo(() => selectSummary(rangeRecords), [rangeRecords]);
  const series = useMemo(() => selectSeries(rangeRecords), [rangeRecords]);
  const grids = useMemo(() => selectGridStats(rangeRecords), [rangeRecords]);
  const operators = useMemo(() => selectOperatorMastery(rangeRecords), [rangeRecords]);
  const activity = useMemo(() => selectActivity(modeRecords), [modeRecords]);
  const insights = useMemo(() => selectInsights(modeRecords), [modeRecords]);

  const selectedIndex = selectedEntry ? modeRecords.findIndex((r) => r.id === selectedEntry.id) : -1;

  const handlePrevEntry = () => {
    if (selectedIndex < modeRecords.length - 1 && selectedIndex >= 0) {
      setSelectedEntry(modeRecords[selectedIndex + 1]);
    }
  };

  const handleNextEntry = () => {
    if (selectedIndex > 0) {
      setSelectedEntry(modeRecords[selectedIndex - 1]);
    }
  };

  const handlePlayNext = (entry: HistoryRecord) => {
    setSelectedEntry(null);
    onPlayMode?.(entry.mode);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#0B0F17] text-slate-900 dark:text-slate-100 p-3 sm:p-6 lg:p-8 transition-colors select-none">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-2 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              aria-label="Back to home"
              className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shadow-2xs cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-blue-600 dark:text-amber-500" />
                <span>Analytics</span>
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Performance, telemetry & progression insights
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
            <ModeTabs currentMode={mode} onSelectMode={handleSelectMode} counts={counts} />
            <RangeSwitch currentRange={range} onSelectRange={setRange} totalEntries={modeRecords.length} />
          </div>
        </div>

        {/* Practice Grid Filter Bar */}
        {mode === 'practice' && (
          <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 w-fit text-xs font-semibold">
            <span className="px-2 text-slate-400 font-mono text-[11px] uppercase">Grid</span>
            {(['all', 3, 4, 5, 6, 7] as const).map((sz) => (
              <button
                key={sz}
                type="button"
                onClick={() => setGridFilter(sz)}
                className={`px-3 py-1 rounded-xl transition-all cursor-pointer ${
                  gridFilter === sz
                    ? 'bg-blue-600 text-white dark:bg-amber-500 dark:text-slate-950 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {sz === 'all' ? 'All' : `${sz}×${sz}`}
              </button>
            ))}
          </div>
        )}

        {/* Actionable Insight Chips */}
        <InsightChips chips={insights} />

        {/* 6 Key Metric Cards */}
        <SummaryCards stats={summary} mode={mode} />

        {/* Custom SVG Charts Grid */}
        <ChartsGrid
          series={series}
          grids={grids}
          operators={operators}
          activity={activity}
          darkMode={darkMode}
        />

        {/* Outcome Breakdown, Accuracy & Progression Breakdown Charts */}
        <BreakdownChartsGrid
          records={rangeRecords}
          series={series}
          mode={mode}
          darkMode={darkMode}
        />

        {/* Level History Table */}
        <LevelTable
          entries={modeRecords}
          mode={mode}
          onSelectEntry={setSelectedEntry}
        />
      </div>

      {/* Level Detail Modal */}
      {selectedEntry && (
        <LevelDetail
          entry={selectedEntry}
          currentIndex={selectedIndex}
          totalEntries={modeRecords.length}
          onPrev={handlePrevEntry}
          onNext={handleNextEntry}
          onClose={() => setSelectedEntry(null)}
          onPlayNext={handlePlayNext}
        />
      )}
    </div>
  );
};
