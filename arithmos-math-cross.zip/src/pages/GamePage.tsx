import React, { useState, useEffect } from 'react';
import { GameAction, GameSessionState } from '../features/game/state/gameTypes';
import { GameMode, ModeControls } from '../storage/schema';
import { getModeRules } from '../features/game/state/modeRules';
import { getCellMaxValue } from '../engine';
import { TopBar } from '../features/game/components/TopBar';
import { OnboardingOverlay } from '../features/game/components/OnboardingOverlay';
import { EquationBar } from '../features/game/components/EquationBar';
import { Board } from '../features/game/components/Board';
import { ControlsColumn } from '../features/game/components/ControlsColumn';
import { PausedPlaceholder } from '../features/game/components/PausedPlaceholder';
import { GameModals } from '../features/game/components/GameModals';
import { TimePressureGlow } from '../features/game/components/TimePressureGlow';
import { CalculatorPanel } from '../features/calculator';
import { useAiController } from '../features/ai/useAiController';
import { AiMatchBar } from '../features/ai/AiMatchBar';

interface GamePageProps {
  state: GameSessionState;
  dispatch: React.Dispatch<GameAction>;
  inputRefs: React.MutableRefObject<(HTMLInputElement | null)[][]>;
  controls: ModeControls;
  isSettingsOpen: boolean;
  startPuzzleLevel: (m: GameMode, r: number, l: number, s: number | null, fn?: boolean) => void;
  handleRetryPuzzle: () => void;
  handleSwapPuzzle: () => void;
  handleCellInputChange: (r: number, c: number, v: string) => void;
  handleTriggerHint: () => void;
  handleValidateBoard: () => void;
  handleUndo: () => void;
  handleRedo: () => void;
  handleCellKeyDown: (e: React.KeyboardEvent<HTMLInputElement>, r: number, c: number) => void;
  handleNumpadPress: (digit: string) => void;
  resetCellAppendWindow?: () => void;
  onOpenSettings: () => void;
  onNextCustomAction?: () => boolean;
  onExitToHub?: () => void;
}

export const GamePage: React.FC<GamePageProps> = (p) => {
  const { state: s, dispatch: d, inputRefs, controls, isSettingsOpen } = p;
  const { gameState, level, darkMode, puzzle, focusedPos, direction } = s;
  const { elapsedSeconds, timeLimitSeconds, hintsUsed, checksUsed, heartsLeft } = s;
  const [isCalculatorOpen, setIsCalculatorOpen] = useState(false);
  const [windowWidth, setWindowWidth] = useState(() => (typeof window !== 'undefined' ? window.innerWidth : 1024));

  const ai = useAiController(s, d, p.handleCellInputChange);
  const playerFilledCount = puzzle.cells.flat().filter((c) => !c.isClue && c.userValue.trim() !== '').length;

  const rules = getModeRules(s.mode);
  const canUndo = s.history.past.some((e) => !puzzle.cells[e.row]?.[e.col]?.isHinted);
  const canRedo = s.history.future.some((e) => !puzzle.cells[e.row]?.[e.col]?.isHinted);
  const isCoarse = typeof window !== 'undefined' && window.matchMedia?.('(pointer: coarse)')?.matches;

  useEffect(() => {
    const handleResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const isUltraWide = windowWidth >= 1100;
  const isMediumWide = windowWidth >= 640 && windowWidth < 1100;
  const calcUsesRemaining = rules.calculatorLimit === Infinity ? Infinity : Math.max(0, rules.calculatorLimit - s.calculatorUses);

  const handleOpenCalculator = () => {
    if (rules.calculatorLimit !== Infinity && calcUsesRemaining <= 0) return;
    setIsCalculatorOpen(true);
  };

  const handleCloseCalculator = () => {
    setIsCalculatorOpen(false);
    if (focusedPos) inputRefs.current[focusedPos.row]?.[focusedPos.col]?.focus();
  };

  const handleApplyCalcToCell = (val: number) => {
    if (focusedPos && (rules.calculatorLimit === Infinity || calcUsesRemaining > 0)) {
      p.handleCellInputChange(focusedPos.row, focusedPos.col, String(val));
      if (rules.calculatorLimit !== Infinity) d({ type: 'CONSUME_CALCULATOR_USE' });
    }
  };

  useEffect(() => {
    if (gameState !== 'PLAYING') return;
    const h = (e: KeyboardEvent) => {
      if ((e.key === 'k' || e.key === 'K') && !e.ctrlKey && !e.metaKey && !e.altKey) {
        e.preventDefault();
        if (isCalculatorOpen) handleCloseCalculator();
        else handleOpenCalculator();
      }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [gameState, isCalculatorOpen, calcUsesRemaining]);

  const focusedCell = focusedPos ? puzzle.cells[focusedPos.row]?.[focusedPos.col] : null;
  const isCellEditable = Boolean(focusedCell && !focusedCell.isClue && !focusedCell.isHinted);

  const eqBar = controls.equations ? (
    <EquationBar
      puzzle={puzzle} focusedPos={focusedPos} direction={direction} darkMode={darkMode}
      statusBanner={s.statusBanner}
      onSelectDirection={(dir) => d({ type: 'SET_DIRECTION', direction: dir })}
      onDismissBanner={() => d({ type: 'SET_BANNER', banner: null })}
    />
  ) : null;

  const renderTutorial = (cls: string) =>
    s.showOnboarding && focusedPos ? (
      <div className={cls}>
        <OnboardingOverlay
          puzzle={puzzle} targetPos={focusedPos} step={s.onboardingStep} darkMode={darkMode}
          onNextStep={() => d({ type: 'ONBOARDING_NEXT' })} onDismiss={() => d({ type: 'ONBOARDING_DISMISS' })}
          onApplyTutorialDigit={(val) => p.handleCellInputChange(focusedPos.row, focusedPos.col, val)}
        />
      </div>
    ) : null;

  const renderCalcPanel = (customClass = '') => (
    <CalculatorPanel
      isOpen={isCalculatorOpen && gameState !== 'PAUSED'} onClose={handleCloseCalculator} darkMode={darkMode}
      focusedPos={focusedPos} isCellEditable={isCellEditable}
      valueDomain={[1, focusedPos ? getCellMaxValue(puzzle, focusedPos.row, focusedPos.col) : puzzle.profile.maxAnswer]}
      calcUsesRemaining={calcUsesRemaining} onApplyToCell={handleApplyCalcToCell}
      onConsumeOpenUse={() => { if (rules.calculatorLimit !== Infinity) d({ type: 'CONSUME_CALCULATOR_USE' }); }}
      className={customClass}
    />
  );

  const controlsColNode = (
    <ControlsColumn
      eqBar={eqBar} mode={s.mode} hintsUsed={hintsUsed} checksUsed={checksUsed} heartsLeft={heartsLeft}
      calculatorUses={s.calculatorUses} controls={controls} darkMode={darkMode} canUndo={canUndo} canRedo={canRedo}
      showNumpad={isCoarse || controls.numpad} onOpenCalculator={handleOpenCalculator}
      onTriggerHint={p.handleTriggerHint} onValidateBoard={p.handleValidateBoard}
      onRetrySamePuzzle={p.handleRetryPuzzle} onSwapNewPuzzle={p.handleSwapPuzzle}
      onNumpadPress={p.handleNumpadPress} onUndo={p.handleUndo} onRedo={p.handleRedo}
    />
  );

  return (
    <div className={`h-dvh max-h-dvh overflow-hidden w-screen flex flex-col justify-between transition-colors duration-200 select-none ${darkMode ? 'bg-[#0B0F17] text-slate-100' : 'bg-[#F8FAFC] text-slate-900'}`}>
      <TopBar
        mode={s.mode} level={level} elapsedSeconds={elapsedSeconds} timeLimitSeconds={timeLimitSeconds}
        heartsLeft={heartsLeft} darkMode={darkMode} controls={controls} rating={s.rating}
        gridSize={puzzle.size} tierName={puzzle.profile.tierName} puzzle={puzzle}
        onPause={() => d({ type: 'PAUSE' })}
      />

      {s.mode === 'multiplayer' && gameState === 'PLAYING' && (
        <div className="px-2 sm:px-4 pt-1 shrink-0">
          <AiMatchBar darkMode={darkMode} isMultiplayer={true} ai={ai} playerFilledCount={playerFilledCount} />
        </div>
      )}

      <TimePressureGlow
        remainingSeconds={Math.max(0, timeLimitSeconds - elapsedSeconds)}
        isActive={gameState === 'PLAYING' && rules.hasTimer && controls.timeGlow && !isSettingsOpen}
      />

      <main className="flex-1 min-h-0 min-w-0 flex flex-col wide:flex-row items-center justify-center p-2 sm:p-4 gap-2 wide:gap-6 w-full max-w-7xl mx-auto overflow-hidden">
        {gameState === 'PAUSED' ? (
          <PausedPlaceholder darkMode={darkMode} />
        ) : (
          <>
            {renderTutorial('w-full shrink-0 wide:hidden')}
            <div className="w-full shrink-0 max-w-[420px] mx-auto wide:hidden">{eqBar}</div>
            <div className="flex-1 min-h-0 min-w-0 h-full w-full flex flex-col items-center justify-center gap-2">
              {renderTutorial('hidden wide:block w-full max-w-xl shrink-0')}
              <div className="flex-1 min-h-0 min-w-0 w-full h-full flex items-center justify-center [container-type:size]">
                <Board
                  puzzle={puzzle} focusedPos={focusedPos} darkMode={darkMode}
                  showOnboarding={s.showOnboarding} onboardingStep={s.onboardingStep} inputRefs={inputRefs}
                  onFocusPos={(r, c) => { p.resetCellAppendWindow?.(); d({ type: 'SET_FOCUS', pos: { row: r, col: c } }); }}
                  onChangeValue={(r, c, v) => p.handleCellInputChange(r, c, v)}
                  onKeyDownCell={(e, r, c) => p.handleCellKeyDown(e, r, c)}
                />
              </div>
            </div>
            {isUltraWide ? (
              <>
                <div className="w-[360px] lg:w-[380px] shrink-0">{controlsColNode}</div>
                {isCalculatorOpen && <div className="w-[320px] shrink-0">{renderCalcPanel()}</div>}
              </>
            ) : isMediumWide ? (
              <div className="w-[360px] lg:w-[380px] shrink-0">{isCalculatorOpen ? renderCalcPanel() : controlsColNode}</div>
            ) : (
              <div className="w-full shrink-0 max-w-[420px]">{isCalculatorOpen ? renderCalcPanel('max-h-[42dvh] overflow-y-auto') : controlsColNode}</div>
            )}
          </>
        )}
      </main>

      <GameModals
        state={s} dispatch={d} startPuzzleLevel={p.startPuzzleLevel}
        handleRetryPuzzle={p.handleRetryPuzzle} onOpenSettings={p.onOpenSettings}
        onNextCustomAction={p.onNextCustomAction} onExitToHub={p.onExitToHub}
      />
    </div>
  );
};
