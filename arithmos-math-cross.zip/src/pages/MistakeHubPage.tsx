import React, { useState } from 'react';
import { ArrowLeft, CheckCircle2, Play, RotateCcw, Trash2, Wrench } from '../icons';
import { MathOperator } from '../engine';
import {
  clearRepairedMistakes,
  createManualMistakeDrill,
  loadMistakes,
  MistakeRecord,
  setActiveMistakeId,
} from '../storage/mistakes';
import { formatTime } from '../features/game/components/TimerBar';

interface MistakeHubPageProps {
  darkMode: boolean;
  onBack: () => void;
  onStartRepair: (entry: MistakeRecord) => void;
}

const OP_LABELS: Record<MathOperator, { symbol: string; name: string }> = {
  '+': { symbol: '+', name: 'Addition' },
  '-': { symbol: '−', name: 'Subtraction' },
  '*': { symbol: '×', name: 'Multiplication' },
  '/': { symbol: '÷', name: 'Division' },
};

export const MistakeHubPage: React.FC<MistakeHubPageProps> = ({ darkMode, onBack, onStartRepair }) => {
  const [entries, setEntries] = useState<MistakeRecord[]>(() => loadMistakes());
  const [modeFilter, setModeFilter] = useState<'all' | 'endless' | 'star' | 'hardcore' | 'practice'>('all');

  const filtered = entries.filter((e) => modeFilter === 'all' || e.mode === modeFilter);
  const pendingCount = entries.filter((e) => !e.repaired).length;
  const repairedCount = entries.filter((e) => e.repaired).length;

  const opCounts: Record<MathOperator, number> = { '+': 0, '-': 0, '*': 0, '/': 0 };
  for (const e of entries) {
    if (!e.repaired) opCounts[e.operator] = (opCounts[e.operator] || 0) + 1;
  }

  const handleSelectEntry = (entry: MistakeRecord) => {
    setActiveMistakeId(entry.id);
    onStartRepair(entry);
  };

  const handleCreateDrill = (op: MathOperator) => {
    const drill = createManualMistakeDrill(modeFilter === 'all' ? 'practice' : modeFilter, op, 3);
    setEntries(loadMistakes());
    handleSelectEntry(drill);
  };

  const handleClearRepaired = () => {
    clearRepairedMistakes();
    setEntries(loadMistakes());
  };

  const cardCls = darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200 shadow-xs';

  return (
    <div className={`min-h-dvh max-h-dvh overflow-y-auto no-scrollbar transition-colors ${darkMode ? 'bg-[#0B0F17] text-slate-100' : 'bg-[#F8FAFC] text-slate-900'}`}>
      <div className="max-w-4xl mx-auto px-4 py-4 sm:py-6 space-y-4">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className={`p-2 rounded-xl border transition-colors cursor-pointer ${darkMode ? 'border-slate-800 bg-slate-900 text-slate-300 hover:text-white' : 'border-slate-200 bg-white text-slate-700 hover:text-slate-900'}`}
              title="Return to Home"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-400">
                <Wrench className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl font-bold tracking-tight">Mistake Hub & Repair Clinic</h1>
                <p className="text-xs text-slate-400">Review errors from Endless, Star & Practice — click any box to repair it</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="px-3 py-1.5 rounded-xl border text-xs font-mono font-bold border-rose-500/30 bg-rose-500/10 text-rose-400">
              {pendingCount} Pending
            </div>
            <div className="px-3 py-1.5 rounded-xl border text-xs font-mono font-bold border-emerald-500/30 bg-emerald-500/10 text-emerald-400">
              {repairedCount} Repaired
            </div>
            {repairedCount > 0 && (
              <button type="button" onClick={handleClearRepaired} className="p-1.5 rounded-xl border border-slate-700/60 text-slate-400 hover:text-rose-400 cursor-pointer" title="Clear repaired history">
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-2.5">
          {(['+', '-', '*', '/'] as MathOperator[]).map((op) => {
            const count = opCounts[op];
            return (
              <div key={op} className={`p-2.5 sm:p-3 rounded-2xl border flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2 overflow-hidden min-w-0 ${cardCls}`}>
                <div className="flex items-center gap-2 min-w-0">
                  <div className={`w-8 h-8 sm:w-10 sm:h-10 shrink-0 rounded-xl font-mono font-black text-base sm:text-lg flex items-center justify-center border ${count > 0 ? 'border-rose-500/40 bg-rose-500/15 text-rose-400' : 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400'}`}>
                    {OP_LABELS[op].symbol}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-bold truncate">{OP_LABELS[op].name}</div>
                    <div className="text-[10px] sm:text-[11px] font-mono opacity-70 truncate">{count > 0 ? `${count} pending` : 'Clean'}</div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleCreateDrill(op)}
                  className="shrink-0 w-full sm:w-auto text-center px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-rose-500/15 border border-rose-500/30 text-rose-400 hover:bg-rose-500/25 cursor-pointer"
                  title={`Launch ${OP_LABELS[op].name} repair drill`}
                >
                  Drill
                </button>
              </div>
            );
          })}
        </div>

        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-1 flex-wrap p-1 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900/60">
            {(['all', 'endless', 'star', 'hardcore', 'practice'] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setModeFilter(m)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold uppercase cursor-pointer transition-colors ${
                  modeFilter === m ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {m}
              </button>
            ))}
          </div>
          <span className="text-xs font-mono opacity-70">Click a box to solve its targeted repair board. Repaired boxes turn green with solve time.</span>
        </div>

        <div className={`p-4 rounded-2xl border ${cardCls}`}>
          {filtered.length === 0 ? (
            <div className="py-8 text-center space-y-3">
              <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
              <div className="text-sm font-bold">No Mistakes Logged in This View</div>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Any wrong check or equation slip in Endless, Star, or Practice automatically appears here so you can master your weak operators.
              </p>
              <div className="flex items-center justify-center gap-2 pt-1 flex-wrap">
                {(['+', '-', '*', '/'] as MathOperator[]).map((op) => (
                  <button
                    key={op}
                    type="button"
                    onClick={() => handleCreateDrill(op)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold bg-rose-600 text-white hover:bg-rose-500 cursor-pointer"
                  >
                    <Play className="w-3 h-3 fill-current" />
                    <span>Practice {OP_LABELS[op].symbol} Drill</span>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-3">
              {filtered.map((entry, idx) => {
                const isRepaired = entry.repaired;
                return (
                  <div key={entry.id} className="flex flex-col items-center">
                    <button
                      type="button"
                      onClick={() => handleSelectEntry(entry)}
                      title={`${entry.mode.toUpperCase()} #${entry.level} • ${entry.failedEquation || ''} (${entry.gridSize}x${entry.gridSize})`}
                      className={`w-14 h-14 rounded-2xl font-mono flex flex-col items-center justify-center transition-all cursor-pointer select-none ${
                        isRepaired
                          ? 'border-2 border-emerald-500 bg-emerald-500/10 text-emerald-500 dark:text-emerald-300 shadow-xs'
                          : 'border-2 border-rose-500/70 bg-rose-500/10 text-rose-500 dark:text-rose-300 hover:scale-105'
                      }`}
                    >
                      <span className="text-base font-black leading-none">{OP_LABELS[entry.operator].symbol}</span>
                      <span className="text-[10px] font-bold opacity-80 mt-0.5">
                        #{idx + 1}•{entry.gridSize}x{entry.gridSize}
                      </span>
                    </button>
                    <div className="h-4 mt-1 flex items-center justify-center text-[10px] font-mono">
                      {isRepaired && entry.repairTimeSec !== undefined ? (
                        <span className="text-emerald-500 dark:text-emerald-400 font-semibold">{formatTime(entry.repairTimeSec)}</span>
                      ) : (
                        <span className="text-rose-400 font-semibold flex items-center gap-0.5">
                          <RotateCcw className="w-2.5 h-2.5" />
                          <span>{entry.mode.slice(0, 3).toUpperCase()}</span>
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
