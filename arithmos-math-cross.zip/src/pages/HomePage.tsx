import React from 'react';
import { TitleScreen, TitleScreenProps } from '../features/home/TitleScreen';

export const HomePage: React.FC<TitleScreenProps> = (props) => {
  return <TitleScreen {...props} />;
};
