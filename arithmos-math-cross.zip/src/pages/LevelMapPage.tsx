import React, { useMemo, useState } from 'react';
import { ArrowLeft, Cloud, Flame, Infinity, Lock, Play, Star, Zap } from '../icons';
import { GridSizePicker } from '../features/home/GridSizePicker';
import { formatTime } from '../features/game/components/TimerBar';
import { CHUNK_SIZE, getLevelMapSlotKey, getVisibleFogChunkCount, loadLevelMap } from '../storage/levelMap';
import { loadState } from '../storage/storage';

export interface LevelMapPageProps {
  mode: 'endless' | 'star' | 'practice' | 'hardcore';
  initialPracticeGrid?: 'auto' | 3 | 4 | 5 | 6 | 7;
  darkMode: boolean;
  onBack: () => void;
  onSelectLevel: (level: number, sizeOverride: number | null, rating: number) => void;
}

export const LevelMapPage: React.FC<LevelMapPageProps> = ({
  mode,
  initialPracticeGrid = 'auto',
  darkMode,
  onBack,
  onSelectLevel,
}) => {
  const stored = loadState();
  const [practiceSize, setPracticeSize] = useState<number | 'auto'>(initialPracticeGrid);
  const isGridPickerMode = mode === 'practice' || mode === 'hardcore';
  const overrideSize = isGridPickerMode ? (practiceSize === 'auto' ? null : practiceSize) : null;
  const slotKey = getLevelMapSlotKey(mode, overrideSize);

  const slotInfo = useMemo(() => {
    if (mode === 'endless') return stored.modes.endless;
    if (mode === 'star') return stored.modes.star;
    const container = mode === 'hardcore' ? stored.modes.hardcore : stored.modes.practice;
    const k = String(practiceSize) as keyof typeof stored.modes.practice.slots;
    return container?.slots?.[k] || { level: 1, rating: mode === 'hardcore' ? 120 : 100, played: 0 };
  }, [mode, practiceSize, stored]);

  const solvedMap = useMemo(() => loadLevelMap(slotKey), [slotKey]);
  const currentUnlockedLevel = Math.max(1, slotInfo.level);
  const visibleClearLimit = getVisibleFogChunkCount(solvedMap, currentUnlockedLevel);
  const solvedCount = Object.keys(solvedMap).length;

  const getContainer = () => (mode === 'hardcore' ? stored.modes.hardcore : stored.modes.practice);
  const practiceLevels: Record<string, number> = {
    auto: getContainer()?.slots?.auto?.level ?? 1,
    '3': getContainer()?.slots?.['3']?.level ?? 1,
    '4': getContainer()?.slots?.['4']?.level ?? 1,
    '5': getContainer()?.slots?.['5']?.level ?? 1,
    '6': getContainer()?.slots?.['6']?.level ?? 1,
    '7': getContainer()?.slots?.['7']?.level ?? 1,
  };

  const practiceRatings: Record<string, number> = {
    auto: getContainer()?.slots?.auto?.rating ?? (mode === 'hardcore' ? 120 : 100),
    '3': getContainer()?.slots?.['3']?.rating ?? (mode === 'hardcore' ? 120 : 100),
    '4': getContainer()?.slots?.['4']?.rating ?? (mode === 'hardcore' ? 120 : 100),
    '5': getContainer()?.slots?.['5']?.rating ?? (mode === 'hardcore' ? 120 : 100),
    '6': getContainer()?.slots?.['6']?.rating ?? (mode === 'hardcore' ? 120 : 100),
    '7': getContainer()?.slots?.['7']?.rating ?? (mode === 'hardcore' ? 120 : 100),
  };

  const modeMeta = {
    endless: { title: 'Endless Mode', icon: <Flame className="w-5 h-5 text-amber-500" /> },
    star: { title: 'Star Mode', icon: <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" /> },
    practice: { title: 'Practice Mode', icon: <Infinity className="w-5 h-5 text-emerald-500" /> },
    hardcore: { title: 'Hardcore 4-Way =', icon: <Zap className="w-5 h-5 text-rose-500 fill-rose-500/20" /> },
  }[mode];

  const clearLevels = Array.from({ length: visibleClearLimit }, (_, i) => i + 1);
  const fogLevels = Array.from({ length: CHUNK_SIZE }, (_, i) => visibleClearLimit + i + 1);

  return (
    <div className={`min-h-dvh max-h-dvh overflow-y-auto no-scrollbar select-none transition-colors ${darkMode ? 'bg-[#0B0F17] text-slate-100' : 'bg-[#F8FAFC] text-slate-900'}`}>
      <div className="max-w-4xl mx-auto px-4 py-4 sm:py-6 space-y-5">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className={`p-2 rounded-xl border transition-colors cursor-pointer ${darkMode ? 'border-slate-800 bg-slate-900 text-slate-300 hover:text-white' : 'border-slate-200 bg-white text-slate-700 hover:text-slate-900'}`}
              title="Back to Home"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-2.5">
              <div className={`p-2 rounded-xl border ${darkMode ? 'border-slate-800 bg-slate-900/90' : 'border-slate-200 bg-white'}`}>
                {modeMeta.icon}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-lg sm:text-xl font-bold tracking-tight">{modeMeta.title}</h1>
                  <span className={`text-[11px] font-mono px-2 py-0.5 rounded-full border font-semibold ${darkMode ? 'bg-slate-900 border-slate-800 text-slate-300' : 'bg-slate-100 border-slate-200 text-slate-700'}`}>
                    Rating {slotInfo.rating}
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  {solvedCount} / {visibleClearLimit} Solved • Select any unlocked box to play
                </p>
              </div>
            </div>
          </div>

          <button
            type="button"
            data-bird-perch="map-play-btn"
            onClick={() => onSelectLevel(currentUnlockedLevel, overrideSize, slotInfo.rating)}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold cursor-pointer transition-all shadow-md ${darkMode ? 'bg-amber-500 text-slate-950 hover:bg-amber-400' : 'bg-blue-600 text-white hover:bg-blue-500'}`}
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Play #{currentUnlockedLevel}</span>
          </button>
        </div>

        {isGridPickerMode && (
          <div className={`p-3 rounded-2xl border flex items-center justify-between gap-3 flex-wrap ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
            <span className="text-xs font-semibold opacity-75">
              {mode === 'hardcore' ? 'Architecture Size Track:' : 'Grid Size Track:'}
            </span>
            <GridSizePicker
              allowAuto
              selectedSize={practiceSize}
              darkMode={darkMode}
              onSelectSize={setPracticeSize}
              gridLevels={practiceLevels}
              gridRatings={practiceRatings}
            />
          </div>
        )}

        <div className="grid grid-cols-5 sm:grid-cols-10 gap-2.5 sm:gap-3 pt-1">
          {clearLevels.map((lvl) => {
            const rec = solvedMap[lvl];
            const isSolved = Boolean(rec);
            const isCurrent = lvl === currentUnlockedLevel;

            return (
              <div key={lvl} className="flex flex-col items-center">
                <button
                  type="button"
                  data-bird-perch={`map-lvl-${lvl}`}
                  onClick={() => onSelectLevel(lvl, overrideSize, slotInfo.rating)}
                  className={`w-full aspect-square rounded-xl font-mono text-base sm:text-lg font-extrabold flex items-center justify-center transition-all cursor-pointer select-none ${
                    isSolved
                      ? 'border-2 border-emerald-500 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 shadow-xs'
                      : isCurrent
                      ? darkMode
                        ? 'border-2 border-amber-400 bg-amber-500/20 text-amber-300 ring-2 ring-amber-400/30 scale-[1.03]'
                        : 'border-2 border-blue-600 bg-blue-50 text-blue-700 ring-2 ring-blue-500/30 scale-[1.03]'
                      : darkMode
                      ? 'border border-slate-800 bg-slate-900/80 text-slate-300 hover:border-slate-600 hover:text-white'
                      : 'border border-slate-200 bg-white text-slate-700 hover:border-slate-400 shadow-2xs'
                  }`}
                >
                  {lvl}
                </button>
                <div className="h-4 mt-1 flex items-center justify-center gap-0.5">
                  {isSolved && rec ? (
                    <>
                      <span className="text-[10px] font-mono font-semibold text-emerald-400 tabular-nums">
                        {formatTime(rec.bestTimeSec)}
                      </span>
                      {(mode === 'star' || mode === 'hardcore') && rec.stars && (
                        <span className="inline-flex items-center text-yellow-400 ml-0.5">
                          <Star className="w-2.5 h-2.5 fill-current" />
                        </span>
                      )}
                    </>
                  ) : isCurrent ? (
                    <span className="text-[9px] font-mono font-bold uppercase tracking-wider text-amber-400">NEXT</span>
                  ) : null}
                </div>
              </div>
            );
          })}
        </div>

        <div className="relative rounded-2xl overflow-hidden pt-2 pb-4 px-2">
          <div className="grid grid-cols-5 sm:grid-cols-10 gap-2.5 sm:gap-3 opacity-35 pointer-events-none select-none">
            {fogLevels.map((lvl) => (
              <div key={lvl} className="flex flex-col items-center">
                <div className={`w-full aspect-square rounded-xl font-mono text-base font-bold flex items-center justify-center border ${darkMode ? 'border-slate-800 bg-slate-900 text-slate-600' : 'border-slate-200 bg-slate-100 text-slate-400'}`}>
                  {lvl}
                </div>
              </div>
            ))}
          </div>

          <div className={`absolute inset-0 backdrop-blur-[3px] flex flex-col items-center justify-center gap-1.5 transition-all ${darkMode ? 'bg-gradient-to-b from-slate-950/40 via-slate-950/80 to-slate-950/95' : 'bg-gradient-to-b from-white/40 via-slate-100/85 to-slate-100/95'}`}>
            <div className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border text-xs font-mono font-semibold shadow-sm ${darkMode ? 'bg-slate-900/95 border-slate-700 text-slate-300' : 'bg-white/95 border-slate-300 text-slate-700'}`}>
              <Cloud className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span>
                Fog of War • Complete #{visibleClearLimit} to reveal #{visibleClearLimit + 1}–#{visibleClearLimit + CHUNK_SIZE}
              </span>
              <Lock className="w-3 h-3 opacity-60" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
