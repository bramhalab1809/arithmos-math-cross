import React, { useState } from 'react';
import { ArrowLeft, FlaskConical, Plus } from '../icons';
import { LabPack } from '../features/lab/schema/packTypes';
import { deleteLabPack, loadLabPacks } from '../storage/packs';
import { PackCard } from '../features/lab/components/PackCard';
import { PackEditor } from '../features/lab/components/PackEditor';

interface LabPageProps {
  darkMode: boolean;
  onBack: () => void;
  onStartLevel: (pack: LabPack, levelIndex: number) => void;
}

export const LabPage: React.FC<LabPageProps> = ({ darkMode, onBack, onStartLevel }) => {
  const [activeTab, setActiveTab] = useState<'packs' | 'create'>('packs');
  const [packs, setPacks] = useState<LabPack[]>(() => loadLabPacks());

  const refreshPacks = () => {
    setPacks(loadLabPacks());
  };

  const handleDeletePack = (packId: string) => {
    deleteLabPack(packId);
    refreshPacks();
  };

  const handlePackSaved = (_saved: LabPack) => {
    refreshPacks();
    setActiveTab('packs');
  };

  return (
    <div
      className={`min-h-dvh max-h-dvh overflow-y-auto no-scrollbar transition-colors ${
        darkMode ? 'bg-[#0B0F17] text-slate-100' : 'bg-[#F8FAFC] text-slate-900'
      }`}
    >
      <div className="max-w-4xl mx-auto px-4 py-4 sm:py-6 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                darkMode
                  ? 'border-slate-800 bg-slate-900 text-slate-300 hover:text-white'
                  : 'border-slate-200 bg-white text-slate-700 hover:text-slate-900'
              }`}
              title="Return to Home"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-2">
              <div
                className={`p-2 rounded-xl border ${
                  darkMode
                    ? 'border-purple-500/30 bg-purple-500/10 text-purple-400'
                    : 'border-purple-200 bg-purple-50 text-purple-700'
                }`}
              >
                <FlaskConical className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl font-bold tracking-tight">Level Lab Projects</h1>
                <p className="text-xs text-slate-400">
                  Play numbered project boxes, click [+] to add levels, or build with Gemini / ChatGPT / Claude
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 p-1 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900/60">
            <button
              type="button"
              onClick={() => setActiveTab('packs')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                activeTab === 'packs'
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Projects ({packs.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('create')}
              className={`inline-flex items-center gap-1 px-3 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                activeTab === 'create'
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Plus className="w-3 h-3" />
              <span>New Project / AI Prompt</span>
            </button>
          </div>
        </div>

        {/* Content Tabs */}
        {activeTab === 'packs' ? (
          <div className="space-y-3 pt-2">
            {packs.map((pack) => (
              <PackCard
                key={pack.id}
                pack={pack}
                darkMode={darkMode}
                canDelete={packs.length > 1}
                onSelectLevel={onStartLevel}
                onDelete={handleDeletePack}
                onPacksChanged={refreshPacks}
              />
            ))}
          </div>
        ) : (
          <div className="pt-2">
            <PackEditor darkMode={darkMode} onPackSaved={handlePackSaved} />
          </div>
        )}
      </div>
    </div>
  );
};
