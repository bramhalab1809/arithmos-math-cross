import React, { useState } from 'react';
import { ArrowLeft, Bot, Check, Copy, ExternalLink, Play, Swords, Zap } from '../icons';
import {
  AiAgentProfile,
  AiMatchMode,
  getActiveAiProfile,
  loadAiProfiles,
  setActiveAiProfile,
  setActiveMatchMode,
} from '../features/ai/aiTypes';
import { buildExternalAiAgentPrompt } from '../features/ai/aiBridgePrompt';

interface MultiplayerPageProps {
  darkMode: boolean;
  onBack: () => void;
  onStartMatch: (gridSize: number) => void;
}

const GRID_SIZES = [3, 4, 5, 6, 7];

export const MultiplayerPage: React.FC<MultiplayerPageProps> = ({
  darkMode,
  onBack,
  onStartMatch,
}) => {
  const [profiles] = useState<AiAgentProfile[]>(() => loadAiProfiles());
  const [selectedId, setSelectedId] = useState<string>(() => getActiveAiProfile().id);
  const [gridSize, setGridSize] = useState<number>(3);
  const [copiedPrompt, setCopiedPrompt] = useState(false);

  const handleSelectProfile = (id: string) => {
    setSelectedId(id);
    setActiveAiProfile(id);
  };

  const handleCopyExternalPrompt = () => {
    navigator.clipboard?.writeText(buildExternalAiAgentPrompt());
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 1800);
  };

  const handleLaunchMatch = (mode: AiMatchMode) => {
    setActiveAiProfile(selectedId);
    setActiveMatchMode(mode);
    onStartMatch(gridSize);
  };

  const cardCls = darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200 shadow-xs';

  return (
    <div
      className={`min-h-dvh max-h-dvh overflow-y-auto no-scrollbar transition-colors ${
        darkMode ? 'bg-[#0B0F17] text-slate-100' : 'bg-[#F8FAFC] text-slate-900'
      }`}
    >
      <div className="max-w-4xl mx-auto px-4 py-4 sm:py-6 space-y-4">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                darkMode
                  ? 'border-slate-800 bg-slate-900 text-slate-300 hover:text-white'
                  : 'border-slate-200 bg-white text-slate-700 hover:text-slate-900'
              }`}
              title="Return to Home"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl border border-cyan-500/30 bg-cyan-500/10 text-cyan-400">
                <Swords className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl font-bold tracking-tight">Multiplayer — Human vs. AI Arena</h1>
                <p className="text-xs text-slate-400">
                  Race built-in AI challengers in real time OR connect Gemini, ChatGPT, or Claude via the live R/C Board Relay
                </p>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => handleLaunchMatch('duel')}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-bold bg-cyan-600 text-white hover:bg-cyan-500 cursor-pointer shadow-xs"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Start Live AI Duel ({gridSize}x{gridSize})</span>
          </button>
        </div>

        <div className={`p-4 rounded-2xl border space-y-3 ${cardCls}`}>
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div>
              <h2 className="text-sm font-bold">1. Select Your AI Challenger</h2>
              <p className="text-xs text-slate-400">Each AI challenger has its own solving cadence, accuracy, and target cell HUD</p>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-mono opacity-75">Arena Grid:</span>
              {GRID_SIZES.map((sz) => (
                <button
                  key={sz}
                  type="button"
                  onClick={() => setGridSize(sz)}
                  className={`px-2.5 py-1 rounded-xl text-xs font-mono font-bold border cursor-pointer ${
                    gridSize === sz
                      ? 'bg-cyan-600 text-white border-cyan-500'
                      : darkMode
                      ? 'border-slate-800 bg-slate-950 text-slate-300'
                      : 'border-slate-200 bg-slate-50 text-slate-700'
                  }`}
                >
                  {sz}x{sz}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {profiles.map((p) => {
              const selected = p.id === selectedId;
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => handleSelectProfile(p.id)}
                  className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                    selected
                      ? 'border-2 border-cyan-500 bg-cyan-500/10'
                      : darkMode
                      ? 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
                      : 'border-slate-200 bg-slate-50 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <Bot className={`w-4 h-4 ${selected ? 'text-cyan-400' : 'text-slate-400'}`} />
                      <span className="font-bold text-sm">{p.name}</span>
                    </div>
                    <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full border border-cyan-500/30 bg-cyan-500/10 text-cyan-400">
                      {p.provider}
                    </span>
                  </div>
                  <div className="mt-2 flex items-center justify-between text-xs font-mono opacity-75">
                    <span>Style: {p.strategy}</span>
                    <span>{(p.stepDelayMs / 1000).toFixed(1)}s / cell</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className={`p-4 rounded-2xl border space-y-3 ${cardCls}`}>
          <div className="flex items-start justify-between gap-3 flex-wrap">
            <div>
              <h2 className="text-sm font-bold">2. Play With Real External Gemini, ChatGPT, or Claude (Live Board Relay)</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Since the puzzle board has R1..RN and C1..CN coordinates, any web AI can read your board and reply with moves like <code className="font-mono text-cyan-400">R1C2=4, R2C1=2</code>!
              </p>
            </div>
            <button
              type="button"
              onClick={() => handleLaunchMatch('relay')}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold bg-purple-600 text-white hover:bg-purple-500 cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Start Match with Web AI Relay Bar</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
            <div className={`p-3 rounded-xl border ${darkMode ? 'border-slate-800 bg-slate-950/60' : 'border-slate-200 bg-slate-50'}`}>
              <div className="font-bold text-cyan-400 mb-1">Step 1 — Copy AI Handshake</div>
              <p className="opacity-80">Click "Copy External AI Rules Prompt" below and paste it into Gemini, ChatGPT, or Claude.</p>
            </div>
            <div className={`p-3 rounded-xl border ${darkMode ? 'border-slate-800 bg-slate-950/60' : 'border-slate-200 bg-slate-50'}`}>
              <div className="font-bold text-purple-400 mb-1">Step 2 — Copy Board in Match</div>
              <p className="opacity-80">Inside Multiplayer, click "Copy Board for AI" on the top AI bar to copy the R/C equations.</p>
            </div>
            <div className={`p-3 rounded-xl border ${darkMode ? 'border-slate-800 bg-slate-950/60' : 'border-slate-200 bg-slate-50'}`}>
              <div className="font-bold text-emerald-400 mb-1">Step 3 — Paste AI Move</div>
              <p className="opacity-80">Paste the AI's reply (<code className="font-mono">R1C2=4</code>) into "Paste AI Move" and watch it fill the board!</p>
            </div>
          </div>

          <div className="pt-1 flex items-center justify-between gap-2 flex-wrap">
            <button
              type="button"
              onClick={handleCopyExternalPrompt}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold border-cyan-500/40 bg-cyan-500/15 text-cyan-300 cursor-pointer"
            >
              {copiedPrompt ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedPrompt ? 'Copied External AI Rules Prompt!' : 'Copy External AI Rules Prompt'}</span>
            </button>

            <div className="flex items-center gap-1.5 text-xs">
              <span className="opacity-60 text-[11px]">Launch AI Tab:</span>
              <a href="https://gemini.google.com" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-blue-500/30 bg-blue-500/10 text-blue-400 font-semibold">
                <span>Gemini</span>
                <ExternalLink className="w-3 h-3" />
              </a>
              <a href="https://chatgpt.com" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 font-semibold">
                <span>ChatGPT</span>
                <ExternalLink className="w-3 h-3" />
              </a>
              <a href="https://claude.ai" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-amber-500/30 bg-amber-500/10 text-amber-400 font-semibold">
                <span>Claude</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
