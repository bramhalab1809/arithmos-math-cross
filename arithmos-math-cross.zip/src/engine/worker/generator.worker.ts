import { generateMathCrossword } from '../generator';

self.onmessage = (e: MessageEvent) => {
  const { requestId, rating, level, overrideSize, overrideGridSize, blanksScale, options } = e.data ?? {};
  try {
    const size = overrideSize !== undefined ? overrideSize : overrideGridSize;
    const opts = { ...(options ?? {}), ...(blanksScale !== undefined ? { blanksScale } : {}) };
    const puzzle = generateMathCrossword(rating, level, size, opts);
    self.postMessage({ requestId, puzzle });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Puzzle generation failed';
    self.postMessage({ requestId, error: msg });
  }
};
