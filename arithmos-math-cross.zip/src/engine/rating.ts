import { RatingAdjustmentResult } from './types';

/**
 * Adaptive Rating Calculator:
 * Evaluates solve speed against the puzzle countdown limit (timeLimitSeconds),
 * plus hints used and distinct mistakes made.
 */
export function calculateRatingAdjustment(
  currentRating: number,
  elapsedSeconds: number,
  timeLimitSeconds: number,
  hintsUsed: number,
  errorsMade: number
): RatingAdjustmentResult {
  const safeElapsed = Math.max(1, elapsedSeconds);
  const safeLimit = Math.max(1, timeLimitSeconds);
  const timeRatio = safeElapsed / safeLimit;

  let delta = 0;
  let performanceLabel = 'Steady Solve';

  if (hintsUsed === 0 && errorsMade === 0 && timeRatio <= 0.55) {
    delta = 50;
    performanceLabel = 'Flawless Blitz';
  } else if (hintsUsed === 0 && timeRatio <= 0.75) {
    delta = Math.max(32, Math.round(45 - errorsMade * 5));
    performanceLabel = 'Optimal Mastery';
  } else if (hintsUsed === 0 && timeRatio <= 0.9) {
    delta = Math.max(16, Math.round(26 - errorsMade * 4));
    performanceLabel = 'Clean Deduction';
  } else if (hintsUsed === 1 && timeRatio <= 0.85) {
    delta = 10;
    performanceLabel = 'Assisted Solve';
  } else if (hintsUsed <= 2 && timeRatio <= 1.0) {
    delta = 0;
    performanceLabel = 'Rating Maintained';
  } else {
    delta = -Math.min(15, hintsUsed * 6 + (timeRatio > 0.95 ? 6 : 0));
    performanceLabel = 'Adaptive Calibration';
  }

  const newRating = Math.max(100, currentRating + delta);
  return {
    previousRating: currentRating,
    newRating,
    delta: newRating - currentRating,
    performanceLabel,
    timeRatio,
  };
}

/**
 * Applies a -8 rating adjustment (clamped >= 100) when the countdown expires.
 */
export function calculateTimeUpPenalty(currentRating: number): RatingAdjustmentResult {
  const newRating = Math.max(100, currentRating - 8);
  return {
    previousRating: currentRating,
    newRating,
    delta: newRating - currentRating,
    performanceLabel: 'Time Expired',
    timeRatio: 1,
  };
}
