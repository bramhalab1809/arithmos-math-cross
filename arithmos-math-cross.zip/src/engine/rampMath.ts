/**
 * Math utilities for smooth continuous difficulty curves.
 */

export function clamp01(v: number): number {
  return Math.max(0, Math.min(1, v));
}

export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * clamp01(t);
}

export function lerpRound(a: number, b: number, t: number): number {
  return Math.round(lerp(a, b, t));
}

export function progressInRange(val: number, min: number, max: number): number {
  if (max <= min) return 0;
  return clamp01((val - min) / (max - min));
}
