import { MathCrosswordPuzzle, MathOperator } from './types';
import { solveSingleUnknownInLine } from './lineSolver';
import { getPuzzleEquations } from './equations';

/**
 * Counts equations (rows, columns, or Hardcore arms) that currently have exactly one unknown (blank) cell.
 */
export function countFirstMoves(puzzle: MathCrosswordPuzzle): number {
  const equations = getPuzzleEquations(puzzle);
  let count = 0;

  for (const eq of equations) {
    const allPts = [...eq.operandCells, eq.resultCell];
    let unknowns = 0;
    for (const p of allPts) {
      const cell = puzzle.cells[p.row]?.[p.col];
      if (cell && !cell.isVoid && !cell.isClue) unknowns++;
    }
    if (unknowns === 1) count++;
  }

  return count;
}

/**
 * Checks if a board state is solvable purely through single-unknown line eliminations.
 */
export function isDominoSolvableGrid(
  initialBoard: (number | null)[][],
  rowOps: MathOperator[][],
  colOps: MathOperator[][]
): boolean {
  const N = initialBoard.length;
  const board = initialBoard.map((row) => [...row]);
  let remainingNulls = 0;

  for (let r = 0; r < N; r++) {
    for (let c = 0; c < N; c++) {
      if (board[r][c] === null) remainingNulls++;
    }
  }

  if (remainingNulls === 0) return true;

  let progress = true;
  while (progress && remainingNulls > 0) {
    progress = false;

    // Evaluate rows with exactly one unknown
    for (let r = 0; r < N; r++) {
      let nullCount = 0;
      let nullC = -1;
      for (let c = 0; c < N; c++) {
        if (board[r][c] === null) {
          nullCount++;
          nullC = c;
        }
      }
      if (nullCount === 1) {
        const deduced = solveSingleUnknownInLine(board[r], rowOps[r]);
        if (deduced !== null && deduced >= 1) {
          board[r][nullC] = deduced;
          remainingNulls--;
          progress = true;
          if (remainingNulls === 0) return true;
        }
      }
    }

    // Evaluate columns with exactly one unknown
    for (let c = 0; c < N; c++) {
      let nullCount = 0;
      let nullR = -1;
      const colValues: (number | null)[] = [];
      for (let r = 0; r < N; r++) {
        const val = board[r][c];
        colValues.push(val);
        if (val === null) {
          nullCount++;
          nullR = r;
        }
      }
      if (nullCount === 1) {
        const cOps: MathOperator[] = [];
        for (let r = 0; r < N - 2; r++) cOps.push(colOps[r][c]);
        const deduced = solveSingleUnknownInLine(colValues, cOps);
        if (deduced !== null && deduced >= 1) {
          board[nullR][c] = deduced;
          remainingNulls--;
          progress = true;
          if (remainingNulls === 0) return true;
        }
      }
    }
  }

  return remainingNulls === 0;
}

/**
 * Checks if a complete puzzle can be solved by domino deductions alone.
 */
export function isDominoSolvable(puzzle: MathCrosswordPuzzle): boolean {
  const N = puzzle.size;
  const board: (number | null)[][] = puzzle.cells.map((r) =>
    r.map((c) => (c.isVoid ? 0 : c.isClue ? c.solution : null))
  );
  return isDominoSolvableGrid(board, puzzle.rowOps, puzzle.colOps);
}

/**
 * Finds the unknown cell of the first single-unknown line (rows in reading order, then cols).
 * Returns { row, col, direction }. Falls back to first blank cell with direction 'row'.
 */
export function findBestStartCell(puzzle: MathCrosswordPuzzle): {
  row: number;
  col: number;
  direction: 'row' | 'col';
} {
  const N = puzzle.size;
  const equations = getPuzzleEquations(puzzle);

  // 1. Check equations with exactly 1 unknown cell
  for (const eq of equations) {
    const allPts = [...eq.operandCells, eq.resultCell];
    const unknowns = allPts.filter((p) => {
      const cell = puzzle.cells[p.row]?.[p.col];
      return cell && !cell.isVoid && !cell.isClue;
    });
    if (unknowns.length === 1) {
      return { row: unknowns[0].row, col: unknowns[0].col, direction: eq.axis };
    }
  }

  // 2. Fallback: find first editable cell in reading order
  for (let r = 0; r < N; r++) {
    for (let c = 0; c < N; c++) {
      const cell = puzzle.cells[r][c];
      if (!cell.isVoid && !cell.isClue) {
        return { row: r, col: c, direction: 'row' };
      }
    }
  }

  return { row: 0, col: 0, direction: 'row' };
}
