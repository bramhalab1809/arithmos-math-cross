import { MathCrosswordPuzzle } from './types';

/**
 * Computes the countdown time limit in seconds for a puzzle.
 * - floorSeconds = targetBlanks * 7
 * - timeFactor = Math.max(1.1, 2.2 - 0.04 * Math.max(1, level))
 * - timeLimitSeconds = Math.max(floorSeconds, Math.round(parTimeSeconds * timeFactor))
 */
export function calculatePuzzleTimeLimit(
  puzzle: MathCrosswordPuzzle,
  level: number
): number {
  const floorSeconds = puzzle.profile.targetBlanks * 7;
  const timeFactor = Math.max(1.1, 2.2 - 0.04 * Math.max(1, level));
  return Math.max(floorSeconds, Math.round(puzzle.profile.parTimeSeconds * timeFactor));
}
