import { MathCrosswordPuzzle } from './types';
import { GeneratePuzzleOptions, generateMathCrossword } from './generator';

let worker: Worker | null = null;
let currentRequestId = 0;
let pendingResolve: ((puzzle: MathCrosswordPuzzle) => void) | null = null;
let pendingReject: ((err: unknown) => void) | null = null;
let timeoutHandle: ReturnType<typeof setTimeout> | null = null;

function cleanupPending() {
  if (timeoutHandle) {
    clearTimeout(timeoutHandle);
    timeoutHandle = null;
  }
  pendingResolve = null;
  pendingReject = null;
}

function initWorker(
  rating: number,
  level: number,
  overrideGridSize?: number | null
): Worker | null {
  if (typeof window === 'undefined' || typeof Worker === 'undefined') return null;
  if (!worker) {
    try {
      worker = new Worker(new URL('./worker/generator.worker.ts', import.meta.url), {
        type: 'module',
      });
      worker.onmessage = (e: MessageEvent) => {
        const { requestId, puzzle, error } = e.data ?? {};
        if (requestId !== currentRequestId) return;

        const resolve = pendingResolve;
        const reject = pendingReject;
        cleanupPending();

        if (error) {
          try {
            const fallback = generateMathCrossword(rating, level, overrideGridSize, {
              blanksScale: 0.8,
            });
            if (resolve) resolve(fallback);
          } catch (err) {
            if (reject) reject(new Error(error));
          }
        } else if (puzzle && resolve) {
          resolve(puzzle);
        }
      };
      worker.onerror = () => {
        if (worker) {
          worker.terminate();
          worker = null;
        }
        const resolve = pendingResolve;
        cleanupPending();
        if (resolve) {
          try {
            const fallback = generateMathCrossword(rating, level, overrideGridSize, {
              blanksScale: 0.8,
            });
            resolve(fallback);
          } catch (err) {
            if (pendingReject) pendingReject(err);
          }
        }
      };
    } catch {
      worker = null;
    }
  }
  return worker;
}

export function generatePuzzleAsync(
  rating: number,
  level: number,
  overrideGridSize?: number | null,
  options?: GeneratePuzzleOptions
): Promise<MathCrosswordPuzzle> {
  const reqId = ++currentRequestId;
  cleanupPending();

  const w = initWorker(rating, level, overrideGridSize);
  if (!w) {
    return Promise.resolve(generateMathCrossword(rating, level, overrideGridSize, options));
  }

  return new Promise<MathCrosswordPuzzle>((resolve, reject) => {
    pendingResolve = resolve;
    pendingReject = reject;

    timeoutHandle = setTimeout(() => {
      if (currentRequestId === reqId) {
        if (worker) {
          worker.terminate();
          worker = null;
        }
        cleanupPending();
        try {
          const fallback = generateMathCrossword(rating, level, overrideGridSize, {
            blanksScale: 0.8,
          });
          resolve(fallback);
        } catch (err) {
          reject(err);
        }
      }
    }, 4000);

    w.postMessage({
      requestId: reqId,
      rating,
      level,
      overrideSize: overrideGridSize,
      overrideGridSize,
      blanksScale: options?.blanksScale,
      options,
    });
  });
}
