import { CellData, DifficultyProfile, MathCrosswordPuzzle, MathOperator } from './types';
import { isCompleteLineValid } from './lineSolver';
import { evaluateLinearChain } from './ops';
import { LabGridLevel } from '../features/lab/schema/packTypes';

export function verifyLabGrid(level: LabGridLevel): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  const N = level.size;

  for (let r = 0; r < N; r++) {
    const rVals = level.cells[r].map((c) => c.solution);
    if (!isCompleteLineValid(rVals, level.rowOps[r])) {
      const expected = evaluateLinearChain(rVals.slice(0, N - 1), level.rowOps[r]);
      errors.push(`Row ${r + 1} does not balance (expected ${expected}, but got ${rVals[N - 1]}).`);
    }
  }

  for (let c = 0; c < N; c++) {
    const cVals = level.cells.map((row) => row[c].solution);
    const cOps: MathOperator[] = [];
    for (let r = 0; r < N - 2; r++) cOps.push(level.colOps[r][c]);
    if (!isCompleteLineValid(cVals, cOps)) {
      const expected = evaluateLinearChain(cVals.slice(0, N - 1), cOps);
      errors.push(`Column ${c + 1} does not balance (expected ${expected}, but got ${cVals[N - 1]}).`);
    }
  }

  return { valid: errors.length === 0, errors };
}

export function repairLabGrid(level: LabGridLevel): LabGridLevel {
  const N = level.size;
  const repairedCells = level.cells.map((row) => row.map((cell) => ({ ...cell })));

  for (let r = 0; r < N - 1; r++) {
    const operands = repairedCells[r].slice(0, N - 1).map((c) => c.solution);
    const ans = evaluateLinearChain(operands, level.rowOps[r]);
    if (ans !== null) repairedCells[r][N - 1].solution = Math.max(1, Math.round(ans));
  }

  for (let c = 0; c < N - 1; c++) {
    const operands = repairedCells.slice(0, N - 1).map((row) => row[c].solution);
    const cOps: MathOperator[] = [];
    for (let r = 0; r < N - 2; r++) cOps.push(level.colOps[r][c]);
    const ans = evaluateLinearChain(operands, cOps);
    if (ans !== null) repairedCells[N - 1][c].solution = Math.max(1, Math.round(ans));
  }

  const lastRowOperands = repairedCells[N - 1].slice(0, N - 1).map((c) => c.solution);
  const cornerAns = evaluateLinearChain(lastRowOperands, level.rowOps[N - 1]);
  if (cornerAns !== null) repairedCells[N - 1][N - 1].solution = Math.max(1, Math.round(cornerAns));

  return {
    ...level,
    cells: repairedCells,
  };
}

export function convertLabGridToPuzzle(level: LabGridLevel, levelIndex = 1): MathCrosswordPuzzle {
  const N = level.size;
  const cells: CellData[][] = [];

  for (let r = 0; r < N; r++) {
    const rowCells: CellData[] = [];
    for (let c = 0; c < N; c++) {
      const cellDef = level.cells[r][c];
      rowCells.push({
        row: r,
        col: c,
        solution: cellDef.solution,
        isClue: cellDef.isClue,
        userValue: cellDef.isClue ? String(cellDef.solution) : '',
        isHinted: false,
        isError: false,
        hasStar: Boolean(cellDef.hasStar),
      });
    }
    cells.push(rowCells);
  }

  let maxAnswer = 15;
  cells.forEach((row) => row.forEach((c) => { if (c.solution > maxAnswer) maxAnswer = c.solution; }));

  const profile: DifficultyProfile = {
    tierName: 'medium',
    gridSize: N,
    allowedOperators: ['+', '-', '*', '/'],
    minValue: 1,
    maxOperand: maxAnswer,
    maxAnswer,
    targetBlanks: cells.flat().filter((c) => !c.isClue).length,
    parTimeSeconds: 120,
    operandCap: maxAnswer,
  };

  return {
    id: `lab-grid-${levelIndex}-${Date.now()}`,
    level: levelIndex,
    ratingAtGeneration: 1000,
    profile,
    size: N,
    cells,
    rowOps: level.rowOps,
    colOps: level.colOps,
    verifiedSolutionsCount: 1,
    generationSteps: 1,
    flow: {
      firstMoves: 2,
      domino: false,
      relief: false,
      easeApplied: false,
      paced: 1000,
    },
  };
}
