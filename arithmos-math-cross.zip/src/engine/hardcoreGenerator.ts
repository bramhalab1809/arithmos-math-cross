import {
  CellData,
  DifficultyProfile,
  MathCrosswordPuzzle,
  MathOperator,
  PuzzleEquation,
} from './types';
import { getDifficultyProfile } from './difficulty';
import { evaluateLinearChain } from './ops';
import { solveSingleUnknownInLine } from './lineSolver';

export type HardcoreTopology =
  | 'cross_plus'
  | 'crown_h_bridge'
  | 'pillar_h_frame'
  | 'chakravyuh_ring'
  | 'window_grid'
  | 'twin_island'
  | 'pinwheel_star'
  | 'hourglass_vault'
  | 'grand_7x7_hub'
  | 'grand_7x7_ring';

export interface HardcoreGenOptions {
  mode?: string;
  singleMasterAnswer?: boolean;
}

const RECENT_MASTER_ANSWERS_KEY = 'arithmos_recent_master_answers_v1';
const RECENT_TOPOLOGIES_KEY = 'arithmos_recent_topologies_v1';
const MAX_RECENT_ANSWERS = 36;
const MAX_RECENT_TOPOLOGIES = 5;

let memoryRecentAnswers: number[] = [];
let memoryRecentTopologies: HardcoreTopology[] = [];

function loadRecentMasterAnswers(): number[] {
  if (typeof window !== 'undefined') {
    try {
      const raw = window.localStorage.getItem(RECENT_MASTER_ANSWERS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          memoryRecentAnswers = parsed.filter((n) => typeof n === 'number');
        }
      }
    } catch {
      // ignore storage errors
    }
  }
  return memoryRecentAnswers;
}

function recordMasterAnswer(ans: number): void {
  const current = loadRecentMasterAnswers().filter((x) => x !== ans);
  current.push(ans);
  while (current.length > MAX_RECENT_ANSWERS) {
    current.shift();
  }
  memoryRecentAnswers = current;
  if (typeof window !== 'undefined') {
    try {
      window.localStorage.setItem(RECENT_MASTER_ANSWERS_KEY, JSON.stringify(current));
    } catch {
      // ignore storage errors
    }
  }
}

function loadRecentTopologies(): HardcoreTopology[] {
  if (typeof window !== 'undefined') {
    try {
      const raw = window.localStorage.getItem(RECENT_TOPOLOGIES_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          memoryRecentTopologies = parsed;
        }
      }
    } catch {
      // ignore
    }
  }
  return memoryRecentTopologies;
}

function recordTopology(t: HardcoreTopology): void {
  const current = loadRecentTopologies().filter((x) => x !== t);
  current.push(t);
  while (current.length > MAX_RECENT_TOPOLOGIES) {
    current.shift();
  }
  memoryRecentTopologies = current;
  if (typeof window !== 'undefined') {
    try {
      window.localStorage.setItem(RECENT_TOPOLOGIES_KEY, JSON.stringify(current));
    } catch {
      // ignore
    }
  }
}

function randInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function shuffle<T>(arr: T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

/**
 * Picks a fresh target answer in [minVal, maxVal] that is NOT in `boardExcluded`
 * and NOT in the persistent recent Master Answer history across puzzles/modes.
 */
function pickFreshTargetAnswer(
  minVal: number,
  maxVal: number,
  boardExcluded: Set<number>,
  recordInGlobalHistory = true
): number {
  const recent = new Set(loadRecentMasterAnswers());
  const candidates: number[] = [];
  for (let v = minVal; v <= maxVal; v++) {
    if (!boardExcluded.has(v) && !recent.has(v)) {
      candidates.push(v);
    }
  }

  if (candidates.length === 0) {
    const recentShort = new Set(loadRecentMasterAnswers().slice(-12));
    for (let v = minVal; v <= maxVal + 18; v++) {
      if (!boardExcluded.has(v) && !recentShort.has(v)) {
        candidates.push(v);
      }
    }
  }

  if (candidates.length === 0) {
    for (let v = minVal; v <= maxVal + 30; v++) {
      if (!boardExcluded.has(v)) {
        candidates.push(v);
      }
    }
  }

  const chosen = candidates.length > 0 ? pickRandom(candidates) : randInt(minVal, maxVal + 20);
  boardExcluded.add(chosen);
  if (recordInGlobalHistory) {
    recordMasterAnswer(chosen);
  }
  return chosen;
}

/**
 * Direct algebraic construction of a 2- or 3-operand BODMAS chain evaluating to `target`.
 */
function buildChainForTarget(
  target: number,
  numOperands: 2 | 3,
  fixedOperands: (number | null)[],
  allowedOps: MathOperator[],
  maxOperand: number
): { operands: number[]; ops: MathOperator[] } {
  const canSub = allowedOps.includes('-');
  const canMul = allowedOps.includes('*');
  const canDiv = allowedOps.includes('/');
  const effectiveMaxOp = Math.max(maxOperand, Math.min(45, Math.ceil(target * 0.75)));

  if (numOperands === 2) {
    const f0 = fixedOperands[0];
    const f1 = fixedOperands[1];

    if (f0 !== null && f1 !== null) {
      for (const op of shuffle(allowedOps)) {
        if (evaluateLinearChain([f0, f1], [op]) === target) {
          return { operands: [f0, f1], ops: [op] };
        }
      }
    }

    if (f0 !== null) {
      const candidates: { operands: number[]; ops: MathOperator[] }[] = [];
      if (target - f0 >= 1) candidates.push({ operands: [f0, target - f0], ops: ['+'] });
      if (canSub && f0 - target >= 1) candidates.push({ operands: [f0, f0 - target], ops: ['-'] });
      if (canMul && target % f0 === 0 && target / f0 >= 1 && target / f0 <= effectiveMaxOp) {
        candidates.push({ operands: [f0, target / f0], ops: ['*'] });
      }
      if (canDiv && f0 % target === 0 && f0 / target >= 1 && f0 / target <= effectiveMaxOp) {
        candidates.push({ operands: [f0, f0 / target], ops: ['/'] });
      }
      if (candidates.length > 0) return pickRandom(candidates);
    }

    if (f1 !== null) {
      const candidates: { operands: number[]; ops: MathOperator[] }[] = [];
      if (target - f1 >= 1) candidates.push({ operands: [target - f1, f1], ops: ['+'] });
      if (canSub && target + f1 <= effectiveMaxOp * 2) {
        candidates.push({ operands: [target + f1, f1], ops: ['-'] });
      }
      if (canMul && target % f1 === 0 && target / f1 >= 1) {
        candidates.push({ operands: [target / f1, f1], ops: ['*'] });
      }
      if (canDiv && target * f1 <= effectiveMaxOp * 2) {
        candidates.push({ operands: [target * f1, f1], ops: ['/'] });
      }
      if (candidates.length > 0) return pickRandom(candidates);
    }

    const candidates: { operands: number[]; ops: MathOperator[] }[] = [];
    if (target >= 2) {
      const a = randInt(1, Math.min(effectiveMaxOp, target - 1));
      candidates.push({ operands: [a, target - a], ops: ['+'] });
    }
    if (canSub) {
      const b = randInt(1, Math.min(18, effectiveMaxOp));
      candidates.push({ operands: [target + b, b], ops: ['-'] });
    }
    if (canMul) {
      for (let d = 2; d <= Math.min(16, effectiveMaxOp); d++) {
        if (target % d === 0 && target / d >= 2 && target / d <= effectiveMaxOp) {
          candidates.push({ operands: [d, target / d], ops: ['*'] });
        }
      }
    }
    if (canDiv) {
      const b = randInt(2, 5);
      if (target * b <= effectiveMaxOp * 2) {
        candidates.push({ operands: [target * b, b], ops: ['/'] });
      }
    }
    if (candidates.length > 0) return pickRandom(candidates);
    return { operands: [Math.max(1, target - 1), 1], ops: ['+'] };
  }

  // numOperands === 3: [a, b, c] with [op1, op2]
  const f0 = fixedOperands[0];
  const f1 = fixedOperands[1];
  const f2 = fixedOperands[2];

  for (let attempt = 0; attempt < 36; attempt++) {
    const op1 = pickRandom(allowedOps);
    const op2 = pickRandom(allowedOps);
    const a = f0 ?? randInt(1, effectiveMaxOp);
    const b = f1 ?? randInt(1, effectiveMaxOp);

    if (f2 !== null) {
      if (evaluateLinearChain([a, b, f2], [op1, op2]) === target) {
        return { operands: [a, b, f2], ops: [op1, op2] };
      }
      continue;
    }

    const ab = evaluateLinearChain([a, b], [op1]);
    if (ab !== null && ab >= 1) {
      if (target - ab >= 1 && target - ab <= effectiveMaxOp * 2) {
        if (evaluateLinearChain([a, b, target - ab], [op1, '+']) === target) {
          return { operands: [a, b, target - ab], ops: [op1, '+'] };
        }
      }
      if (canSub && ab - target >= 1 && ab - target <= effectiveMaxOp * 2) {
        if (evaluateLinearChain([a, b, ab - target], [op1, '-']) === target) {
          return { operands: [a, b, ab - target], ops: [op1, '-'] };
        }
      }
    }
  }

  const a = f0 ?? randInt(1, Math.max(1, Math.min(effectiveMaxOp, target - 2)));
  const b = f1 ?? randInt(1, Math.max(1, Math.min(effectiveMaxOp, Math.abs(target - a) - 1)));
  if (f2 !== null) {
    const rem = target - f2;
    if (rem >= 2) {
      const x = f0 ?? randInt(1, rem - 1);
      const y = f1 ?? Math.max(1, rem - x);
      if (x + y + f2 === target) return { operands: [x, y, f2], ops: ['+', '+'] };
    }
    const need = f2 + target;
    const x = f0 ?? randInt(1, need - 1);
    const y = f1 ?? Math.max(1, need - x);
    if (x + y - f2 === target) return { operands: [x, y, f2], ops: ['+', '-'] };
  }

  const sumAB = a + b;
  if (sumAB < target) {
    return { operands: [a, b, target - sumAB], ops: ['+', '+'] };
  } else if (sumAB > target) {
    return { operands: [a, b, sumAB - target], ops: ['+', '-'] };
  }
  return { operands: [a, b, 1], ops: ['+', '*'] };
}

/**
 * Step-by-step single-unknown deduction check to guarantee 100% mathematical uniqueness.
 */
export function isEquationPuzzleUniquelySolvable(puzzle: MathCrosswordPuzzle): boolean {
  const N = puzzle.size;
  const eqs = puzzle.equations ?? [];
  const known: (number | null)[][] = Array.from({ length: N }, (_, r) =>
    Array.from({ length: N }, (__, c) => {
      const cell = puzzle.cells[r][c];
      if (cell.isVoid) return 0;
      return cell.isClue ? cell.solution : null;
    })
  );

  let remainingBlanks = 0;
  for (let r = 0; r < N; r++) {
    for (let c = 0; c < N; c++) {
      if (!puzzle.cells[r][c].isVoid && known[r][c] === null) {
        remainingBlanks++;
      }
    }
  }
  if (remainingBlanks === 0) return true;

  let progress = true;
  while (progress && remainingBlanks > 0) {
    progress = false;
    for (const eq of eqs) {
      const allPos = [...eq.operandCells, eq.resultCell];
      let nullIdx = -1;
      let nullCount = 0;
      const lineVals: (number | null)[] = allPos.map((p, idx) => {
        const v = known[p.row][p.col];
        if (v === null) {
          nullCount++;
          nullIdx = idx;
        }
        return v;
      });

      if (nullCount === 1 && nullIdx !== -1) {
        const deduced = solveSingleUnknownInLine(lineVals, eq.ops);
        const targetPos = allPos[nullIdx];
        const expectedSol = puzzle.cells[targetPos.row][targetPos.col].solution;
        if (deduced !== null && deduced === expectedSol && deduced >= 1) {
          known[targetPos.row][targetPos.col] = deduced;
          remainingBlanks--;
          progress = true;
          if (remainingBlanks === 0) return true;
        } else {
          return false;
        }
      }
    }
  }

  return remainingBlanks === 0;
}

function finalizePuzzleFromEquations(
  N: number,
  solutions: (number | null)[][],
  isVoidMap: boolean[][],
  isHubMap: boolean[][],
  equations: PuzzleEquation[],
  profile: DifficultyProfile,
  level: number,
  rating: number,
  singleMasterAnswer: boolean
): MathCrosswordPuzzle {
  const hConnectors: (MathOperator | '=' | '')[][] = Array.from({ length: N }, () =>
    Array(Math.max(1, N - 1)).fill('')
  );
  const vConnectors: (MathOperator | '=' | '')[][] = Array.from({ length: Math.max(1, N - 1) }, () =>
    Array(N).fill('')
  );
  const rowOps: MathOperator[][] = Array.from({ length: N }, () =>
    Array(Math.max(1, N - 2)).fill('+')
  );
  const colOps: MathOperator[][] = Array.from({ length: Math.max(1, N - 2) }, () =>
    Array(N).fill('+')
  );

  for (const eq of equations) {
    if (eq.axis === 'row') {
      const r = eq.resultCell.row;
      for (let i = 0; i < eq.ops.length; i++) {
        const leftCol = Math.min(eq.operandCells[i].col, eq.operandCells[i + 1].col);
        hConnectors[r][leftCol] = eq.ops[i];
        if (leftCol < N - 2) rowOps[r][leftCol] = eq.ops[i];
      }
      hConnectors[eq.equalsConnector.row][eq.equalsConnector.col] = '=';
    } else {
      const c = eq.resultCell.col;
      for (let i = 0; i < eq.ops.length; i++) {
        const topRow = Math.min(eq.operandCells[i].row, eq.operandCells[i + 1].row);
        vConnectors[topRow][c] = eq.ops[i];
        if (topRow < N - 2) colOps[topRow][c] = eq.ops[i];
      }
      vConnectors[eq.equalsConnector.row][eq.equalsConnector.col] = '=';
    }
  }

  const cells: CellData[][] = Array.from({ length: N }, (_, r) =>
    Array.from({ length: N }, (__, c) => {
      const isVoid = isVoidMap[r][c] || solutions[r][c] === null;
      const sol = solutions[r][c] ?? 1;
      return {
        row: r,
        col: c,
        solution: sol,
        userValue: String(sol),
        isClue: !isVoid,
        isError: false,
        isHinted: false,
        isVoid,
        isWall: false,
        isHub: isHubMap[r][c],
      };
    })
  );

  const puzzle: MathCrosswordPuzzle = {
    id: `hc-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    size: N,
    cells,
    rowOps,
    colOps,
    hConnectors,
    vConnectors,
    equations,
    level,
    ratingAtGeneration: rating,
    profile,
    verifiedSolutionsCount: 1,
    generationSteps: 1,
  };

  const centerCoord = N === 7 ? 3 : 2;
  const centerHubEqs = equations.filter(
    (eq) => eq.resultCell.row === centerCoord && eq.resultCell.col === centerCoord
  );
  const outerEqs = equations.filter(
    (eq) => !(eq.resultCell.row === centerCoord && eq.resultCell.col === centerCoord)
  );

  if (singleMasterAnswer && centerHubEqs.length >= 2) {
    // 1. Carve the center Master Hub cell blank so the player must deduce the Master Answer
    const centerCell = puzzle.cells[centerCoord]?.[centerCoord];
    if (centerCell && !centerCell.isVoid) {
      centerCell.isClue = false;
      centerCell.userValue = '';
    }

    // 2. Keep 1 starter arm's operands visible so the center Hub can be calculated first,
    //    and carve 1 operand blank in each of the other center arms!
    const shuffledCenterEqs = shuffle(centerHubEqs);
    const starterEq = shuffledCenterEqs[0];
    const starterOperandSet = new Set(
      (starterEq?.operandCells ?? []).map((p) => `${p.row},${p.col}`)
    );

    for (let i = 1; i < shuffledCenterEqs.length; i++) {
      const eq = shuffledCenterEqs[i];
      const candidates = shuffle(eq.operandCells).filter(
        (p) => !starterOperandSet.has(`${p.row},${p.col}`) && puzzle.cells[p.row][p.col].isClue
      );
      for (const pos of candidates) {
        const cell = puzzle.cells[pos.row][pos.col];
        cell.isClue = false;
        cell.userValue = '';
        if (isEquationPuzzleUniquelySolvable(puzzle)) {
          break;
        } else {
          cell.isClue = true;
          cell.userValue = String(cell.solution);
        }
      }
    }

    // 3. For every outer equation (which now has its OWN distinct target answer!),
    //    carve either its resultCell or one of its operands blank so every equation requires solving!
    for (const eq of shuffle(outerEqs)) {
      const allPts = shuffle([eq.resultCell, ...eq.operandCells]);
      for (const pos of allPts) {
        if (starterOperandSet.has(`${pos.row},${pos.col}`)) continue;
        const cell = puzzle.cells[pos.row][pos.col];
        if (!cell.isClue) continue;
        cell.isClue = false;
        cell.userValue = '';
        if (isEquationPuzzleUniquelySolvable(puzzle)) {
          break;
        } else {
          cell.isClue = true;
          cell.userValue = String(cell.solution);
        }
      }
    }

    return puzzle;
  }

  // Standard unique domino carving for Window Grid & Non-Hardcore Bonus Topologies
  const activeCoords: { r: number; c: number }[] = [];
  for (let r = 0; r < N; r++) {
    for (let c = 0; c < N; c++) {
      if (!cells[r][c].isVoid) activeCoords.push({ r, c });
    }
  }
  const shuffledCoords = shuffle(activeCoords).sort(
    (a, b) => (cells[b.r][b.c].isHub ? 1 : 0) - (cells[a.r][a.c].isHub ? 1 : 0)
  );
  const targetBlanks = Math.max(
    4,
    Math.min(shuffledCoords.length - 4, Math.round(shuffledCoords.length * 0.5))
  );
  let carved = 0;

  for (const { r, c } of shuffledCoords) {
    if (carved >= targetBlanks) break;
    const cell = puzzle.cells[r][c];
    cell.isClue = false;
    cell.userValue = '';
    if (isEquationPuzzleUniquelySolvable(puzzle)) {
      carved++;
    } else {
      cell.isClue = true;
      cell.userValue = String(cell.solution);
    }
  }

  return puzzle;
}

/**
 * Builds 5x5 topologies where:
 * - In Hardcore mode (`singleMasterAnswer === true`), the 4 center arms converge on `(2,2)` = `masterVal`,
 *   while every separate outer result cell (`(0,4)`, `(4,0)`, `(0,0)`, `(4,4)`) gets its OWN distinct target answer!
 * - In Non-Hardcore mode (`singleMasterAnswer === false`), all 4 arms and all outer bridges get distinct result cells & unique answers!
 */
function build5x5HubTopology(
  profile: DifficultyProfile,
  level: number,
  rating: number,
  topology:
    | 'cross_plus'
    | 'crown_h_bridge'
    | 'pillar_h_frame'
    | 'chakravyuh_ring'
    | 'pinwheel_star'
    | 'hourglass_vault',
  singleMasterAnswer: boolean
): MathCrosswordPuzzle {
  const N = 5;
  const maxOp = Math.min(24, Math.max(10, profile.maxOperand + Math.floor(level / 3)));
  const minTarget = Math.max(6, Math.min(18, 5 + Math.floor(level / 2)));
  const maxTarget = Math.max(minTarget + 28, Math.min(92, maxOp * 3));
  const usedTargets = new Set<number>();

  const masterVal = pickFreshTargetAnswer(minTarget, maxTarget, usedTargets, true);
  // Every separate result box on the board gets a 100% distinct target answer!
  const nextDistinctTarget = () =>
    pickFreshTargetAnswer(minTarget, maxTarget, usedTargets, false);

  const allowedOps = profile.allowedOperators;
  const solutions: (number | null)[][] = Array.from({ length: N }, () => Array(N).fill(null));
  const isVoidMap: boolean[][] = Array.from({ length: N }, () => Array(N).fill(true));
  const isHubMap: boolean[][] = Array.from({ length: N }, () => Array(N).fill(false));
  const equations: PuzzleEquation[] = [];

  solutions[2][2] = masterVal;
  isVoidMap[2][2] = false;
  isHubMap[2][2] = singleMasterAnswer;

  const usedCenterOperands = new Set<number>([masterVal]);
  const buildDistinctArm = () => {
    for (let t = 0; t < 16; t++) {
      const candidate = buildChainForTarget(masterVal, 2, [null, null], allowedOps, maxOp);
      if (
        !usedCenterOperands.has(candidate.operands[0]) ||
        !usedCenterOperands.has(candidate.operands[1])
      ) {
        usedCenterOperands.add(candidate.operands[0]);
        usedCenterOperands.add(candidate.operands[1]);
        return candidate;
      }
    }
    return buildChainForTarget(masterVal, 2, [null, null], allowedOps, maxOp);
  };

  const leftArm = buildDistinctArm();
  solutions[2][0] = leftArm.operands[0];
  solutions[2][1] = leftArm.operands[1];
  isVoidMap[2][0] = isVoidMap[2][1] = false;
  equations.push({
    id: 'hub-left',
    axis: 'row',
    operandCells: [{ row: 2, col: 0 }, { row: 2, col: 1 }],
    ops: leftArm.ops,
    resultCell: { row: 2, col: 2 },
    equalsConnector: { type: 'h', row: 2, col: 1 },
    label: singleMasterAnswer ? 'R3 Left = Hub' : 'R3 Left',
  });

  if (singleMasterAnswer) {
    const rightArm = buildDistinctArm();
    solutions[2][3] = rightArm.operands[0];
    solutions[2][4] = rightArm.operands[1];
    isVoidMap[2][3] = isVoidMap[2][4] = false;
    equations.push({
      id: 'hub-right',
      axis: 'row',
      operandCells: [{ row: 2, col: 3 }, { row: 2, col: 4 }],
      ops: rightArm.ops,
      resultCell: { row: 2, col: 2 },
      equalsConnector: { type: 'h', row: 2, col: 2 },
      label: 'Hub = R3 Right',
    });

    const topArm = buildDistinctArm();
    solutions[0][2] = topArm.operands[0];
    solutions[1][2] = topArm.operands[1];
    isVoidMap[0][2] = isVoidMap[1][2] = false;
    equations.push({
      id: 'hub-top',
      axis: 'col',
      operandCells: [{ row: 0, col: 2 }, { row: 1, col: 2 }],
      ops: topArm.ops,
      resultCell: { row: 2, col: 2 },
      equalsConnector: { type: 'v', row: 1, col: 2 },
      label: 'C3 Top = Hub',
    });

    const bottomArm = buildDistinctArm();
    solutions[3][2] = bottomArm.operands[0];
    solutions[4][2] = bottomArm.operands[1];
    isVoidMap[3][2] = isVoidMap[4][2] = false;
    equations.push({
      id: 'hub-bottom',
      axis: 'col',
      operandCells: [{ row: 3, col: 2 }, { row: 4, col: 2 }],
      ops: bottomArm.ops,
      resultCell: { row: 2, col: 2 },
      equalsConnector: { type: 'v', row: 2, col: 2 },
      label: 'Hub = C3 Bottom',
    });
  } else {
    const targetR = nextDistinctTarget();
    const rightArm = buildChainForTarget(targetR, 2, [solutions[2][2], null], allowedOps, maxOp);
    solutions[2][3] = rightArm.operands[1];
    solutions[2][4] = targetR;
    isVoidMap[2][3] = isVoidMap[2][4] = false;
    equations.push({
      id: 'hub-right',
      axis: 'row',
      operandCells: [{ row: 2, col: 2 }, { row: 2, col: 3 }],
      ops: rightArm.ops,
      resultCell: { row: 2, col: 4 },
      equalsConnector: { type: 'h', row: 2, col: 3 },
      label: 'R3 Right',
    });

    const targetT = nextDistinctTarget();
    const topArm = buildChainForTarget(targetT, 2, [null, solutions[2][2]], allowedOps, maxOp);
    solutions[1][2] = topArm.operands[0];
    solutions[0][2] = targetT;
    isVoidMap[0][2] = isVoidMap[1][2] = false;
    equations.push({
      id: 'hub-top',
      axis: 'col',
      operandCells: [{ row: 1, col: 2 }, { row: 2, col: 2 }],
      ops: topArm.ops,
      resultCell: { row: 0, col: 2 },
      equalsConnector: { type: 'v', row: 0, col: 2 },
      label: 'C3 Top',
    });

    const targetB = nextDistinctTarget();
    const bottomArm = buildChainForTarget(targetB, 2, [solutions[2][2], null], allowedOps, maxOp);
    solutions[3][2] = bottomArm.operands[1];
    solutions[4][2] = targetB;
    isVoidMap[3][2] = isVoidMap[4][2] = false;
    equations.push({
      id: 'hub-bottom',
      axis: 'col',
      operandCells: [{ row: 2, col: 2 }, { row: 3, col: 2 }],
      ops: bottomArm.ops,
      resultCell: { row: 4, col: 2 },
      equalsConnector: { type: 'v', row: 3, col: 2 },
      label: 'C3 Bottom',
    });
  }

  if (topology === 'crown_h_bridge' || topology === 'chakravyuh_ring' || topology === 'hourglass_vault') {
    const topTarget = nextDistinctTarget();
    const topBridge = buildChainForTarget(topTarget, 3, [null, solutions[0][2], null], allowedOps, maxOp);
    solutions[0][1] = topBridge.operands[0];
    solutions[0][2] = topBridge.operands[1];
    solutions[0][3] = topBridge.operands[2];
    solutions[0][4] = topTarget;
    isVoidMap[0][1] = isVoidMap[0][3] = isVoidMap[0][4] = false;
    isHubMap[0][4] = true;
    equations.push({
      id: 'top-bridge',
      axis: 'row',
      operandCells: [{ row: 0, col: 1 }, { row: 0, col: 2 }, { row: 0, col: 3 }],
      ops: topBridge.ops,
      resultCell: { row: 0, col: 4 },
      equalsConnector: { type: 'h', row: 0, col: 3 },
      label: 'R1',
    });

    const botTarget = nextDistinctTarget();
    const botBridge = buildChainForTarget(botTarget, 3, [null, solutions[4][2], null], allowedOps, maxOp);
    solutions[4][1] = botBridge.operands[0];
    solutions[4][2] = botBridge.operands[1];
    solutions[4][3] = botBridge.operands[2];
    solutions[4][0] = botTarget;
    isVoidMap[4][0] = isVoidMap[4][1] = isVoidMap[4][3] = false;
    isHubMap[4][0] = true;
    equations.push({
      id: 'bot-bridge',
      axis: 'row',
      operandCells: [{ row: 4, col: 1 }, { row: 4, col: 2 }, { row: 4, col: 3 }],
      ops: botBridge.ops,
      resultCell: { row: 4, col: 0 },
      equalsConnector: { type: 'h', row: 4, col: 0 },
      label: 'R5',
    });
  }

  if (topology === 'pillar_h_frame' || topology === 'chakravyuh_ring') {
    const leftTarget = nextDistinctTarget();
    const leftPillar = buildChainForTarget(leftTarget, 3, [null, solutions[2][0], null], allowedOps, maxOp);
    solutions[1][0] = leftPillar.operands[0];
    solutions[2][0] = leftPillar.operands[1];
    solutions[3][0] = leftPillar.operands[2];
    solutions[0][0] = leftTarget;
    isVoidMap[0][0] = isVoidMap[1][0] = isVoidMap[3][0] = false;
    isHubMap[0][0] = true;
    equations.push({
      id: 'left-pillar',
      axis: 'col',
      operandCells: [{ row: 1, col: 0 }, { row: 2, col: 0 }, { row: 3, col: 0 }],
      ops: leftPillar.ops,
      resultCell: { row: 0, col: 0 },
      equalsConnector: { type: 'v', row: 0, col: 0 },
      label: 'C1',
    });

    const rightTarget = nextDistinctTarget();
    const rightPillar = buildChainForTarget(rightTarget, 3, [null, solutions[2][4], null], allowedOps, maxOp);
    solutions[1][4] = rightPillar.operands[0];
    solutions[2][4] = rightPillar.operands[1];
    solutions[3][4] = rightPillar.operands[2];
    solutions[4][4] = rightTarget;
    isVoidMap[1][4] = isVoidMap[3][4] = isVoidMap[4][4] = false;
    isHubMap[4][4] = true;
    equations.push({
      id: 'right-pillar',
      axis: 'col',
      operandCells: [{ row: 1, col: 4 }, { row: 2, col: 4 }, { row: 3, col: 4 }],
      ops: rightPillar.ops,
      resultCell: { row: 4, col: 4 },
      equalsConnector: { type: 'v', row: 3, col: 4 },
      label: 'C5',
    });
  }

  if (topology === 'pinwheel_star') {
    const tlTarget = nextDistinctTarget();
    const topLeftWing = buildChainForTarget(tlTarget, 2, [null, solutions[0][2]], allowedOps, maxOp);
    solutions[0][1] = topLeftWing.operands[0];
    solutions[0][2] = topLeftWing.operands[1];
    solutions[0][0] = tlTarget;
    isVoidMap[0][0] = isVoidMap[0][1] = false;
    isHubMap[0][0] = true;
    equations.push({
      id: 'pinwheel-top',
      axis: 'row',
      operandCells: [{ row: 0, col: 1 }, { row: 0, col: 2 }],
      ops: topLeftWing.ops,
      resultCell: { row: 0, col: 0 },
      equalsConnector: { type: 'h', row: 0, col: 0 },
      label: 'R1',
    });

    const brTarget = nextDistinctTarget();
    const botRightWing = buildChainForTarget(brTarget, 2, [solutions[4][2], null], allowedOps, maxOp);
    solutions[4][2] = botRightWing.operands[0];
    solutions[4][3] = botRightWing.operands[1];
    solutions[4][4] = brTarget;
    isVoidMap[4][3] = isVoidMap[4][4] = false;
    isHubMap[4][4] = true;
    equations.push({
      id: 'pinwheel-bot',
      axis: 'row',
      operandCells: [{ row: 4, col: 2 }, { row: 4, col: 3 }],
      ops: botRightWing.ops,
      resultCell: { row: 4, col: 4 },
      equalsConnector: { type: 'h', row: 4, col: 3 },
      label: 'R5',
    });
  }

  return finalizePuzzleFromEquations(
    N,
    solutions,
    isVoidMap,
    isHubMap,
    equations,
    profile,
    level,
    rating,
    singleMasterAnswer
  );
}

/**
 * Window Grid Topology (5x5):
 * 4 interlocking 3-operand equations (R1, R3, C1, C3) where each of the 4 result boxes
 * has its own unique, distinct answer!
 */
function build5x5WindowTopology(
  profile: DifficultyProfile,
  level: number,
  rating: number,
  singleMasterAnswer: boolean
): MathCrosswordPuzzle {
  const N = 5;
  const maxOp = Math.min(24, Math.max(10, profile.maxOperand + Math.floor(level / 3)));
  const minTarget = Math.max(7, Math.min(18, 6 + Math.floor(level / 2)));
  const maxTarget = Math.max(minTarget + 28, Math.min(92, maxOp * 3));
  const usedTargets = new Set<number>();

  const t1 = pickFreshTargetAnswer(minTarget, maxTarget, usedTargets, true);
  const nextDistinctTarget = () =>
    pickFreshTargetAnswer(minTarget, maxTarget, usedTargets, false);

  const allowedOps = profile.allowedOperators;
  const solutions: (number | null)[][] = Array.from({ length: N }, () => Array(N).fill(null));
  const isVoidMap: boolean[][] = Array.from({ length: N }, () => Array(N).fill(true));
  const isHubMap: boolean[][] = Array.from({ length: N }, () => Array(N).fill(false));
  const equations: PuzzleEquation[] = [];

  const topEq = buildChainForTarget(t1, 3, [null, null, null], allowedOps, maxOp);
  solutions[0][0] = topEq.operands[0];
  solutions[0][1] = topEq.operands[1];
  solutions[0][2] = topEq.operands[2];
  solutions[0][3] = t1;
  isVoidMap[0][0] = isVoidMap[0][1] = isVoidMap[0][2] = isVoidMap[0][3] = false;
  isHubMap[0][3] = true;
  equations.push({
    id: 'win-top',
    axis: 'row',
    operandCells: [{ row: 0, col: 0 }, { row: 0, col: 1 }, { row: 0, col: 2 }],
    ops: topEq.ops,
    resultCell: { row: 0, col: 3 },
    equalsConnector: { type: 'h', row: 0, col: 2 },
    label: 'R1',
  });

  const t2 = nextDistinctTarget();
  const leftEq = buildChainForTarget(t2, 3, [solutions[0][0], null, null], allowedOps, maxOp);
  solutions[1][0] = leftEq.operands[1];
  solutions[2][0] = leftEq.operands[2];
  solutions[3][0] = t2;
  isVoidMap[1][0] = isVoidMap[2][0] = isVoidMap[3][0] = false;
  isHubMap[3][0] = true;
  equations.push({
    id: 'win-left',
    axis: 'col',
    operandCells: [{ row: 0, col: 0 }, { row: 1, col: 0 }, { row: 2, col: 0 }],
    ops: leftEq.ops,
    resultCell: { row: 3, col: 0 },
    equalsConnector: { type: 'v', row: 2, col: 0 },
    label: 'C1',
  });

  const t3 = nextDistinctTarget();
  const midColEq = buildChainForTarget(t3, 3, [solutions[0][2], null, null], allowedOps, maxOp);
  solutions[1][2] = midColEq.operands[1];
  solutions[2][2] = midColEq.operands[2];
  solutions[3][2] = t3;
  isVoidMap[1][2] = isVoidMap[2][2] = isVoidMap[3][2] = false;
  isHubMap[3][2] = true;
  equations.push({
    id: 'win-mid-col',
    axis: 'col',
    operandCells: [{ row: 0, col: 2 }, { row: 1, col: 2 }, { row: 2, col: 2 }],
    ops: midColEq.ops,
    resultCell: { row: 3, col: 2 },
    equalsConnector: { type: 'v', row: 2, col: 2 },
    label: 'C3',
  });

  const t4 = nextDistinctTarget();
  const midRowEq = buildChainForTarget(t4, 3, [solutions[2][0], null, solutions[2][2]], allowedOps, maxOp);
  solutions[2][1] = midRowEq.operands[1];
  solutions[2][3] = t4;
  isVoidMap[2][1] = isVoidMap[2][3] = false;
  isHubMap[2][3] = true;
  equations.push({
    id: 'win-mid-row',
    axis: 'row',
    operandCells: [{ row: 2, col: 0 }, { row: 2, col: 1 }, { row: 2, col: 2 }],
    ops: midRowEq.ops,
    resultCell: { row: 2, col: 3 },
    equalsConnector: { type: 'h', row: 2, col: 2 },
    label: 'R3',
  });

  return finalizePuzzleFromEquations(
    N,
    solutions,
    isVoidMap,
    isHubMap,
    equations,
    profile,
    level,
    rating,
    singleMasterAnswer
  );
}

/**
 * Twin Island Bridge Topology (5x5):
 * Center 4-way Hub at `(2,2)` = `masterVal`, while the top-left island hub `(0,0)` and
 * bottom-right island hub `(4,4)` each get their OWN distinct target answers!
 */
function build5x5TwinIslandTopology(
  profile: DifficultyProfile,
  level: number,
  rating: number,
  singleMasterAnswer: boolean
): MathCrosswordPuzzle {
  const N = 5;
  const maxOp = Math.min(22, Math.max(9, profile.maxOperand + Math.floor(level / 3)));
  const minTarget = Math.max(6, Math.min(16, 5 + Math.floor(level / 2)));
  const maxTarget = Math.max(minTarget + 26, Math.min(88, maxOp * 3));
  const usedTargets = new Set<number>();

  const masterVal = pickFreshTargetAnswer(minTarget, maxTarget, usedTargets, true);
  const nextDistinctTarget = () =>
    pickFreshTargetAnswer(minTarget, maxTarget, usedTargets, false);

  const allowedOps = profile.allowedOperators;
  const solutions: (number | null)[][] = Array.from({ length: N }, () => Array(N).fill(null));
  const isVoidMap: boolean[][] = Array.from({ length: N }, () => Array(N).fill(true));
  const isHubMap: boolean[][] = Array.from({ length: N }, () => Array(N).fill(false));
  const equations: PuzzleEquation[] = [];

  solutions[2][2] = masterVal;
  isVoidMap[2][2] = false;
  isHubMap[2][2] = singleMasterAnswer;

  const topArm = buildChainForTarget(masterVal, 2, [null, null], allowedOps, maxOp);
  solutions[0][2] = topArm.operands[0];
  solutions[1][2] = topArm.operands[1];
  isVoidMap[0][2] = isVoidMap[1][2] = false;
  equations.push({
    id: 'twin-c3-top',
    axis: 'col',
    operandCells: [{ row: 0, col: 2 }, { row: 1, col: 2 }],
    ops: topArm.ops,
    resultCell: { row: 2, col: 2 },
    equalsConnector: { type: 'v', row: 1, col: 2 },
    label: singleMasterAnswer ? 'C3 Top = Hub' : 'C3 Top',
  });

  const leftArm = buildChainForTarget(masterVal, 2, [null, null], allowedOps, maxOp);
  solutions[2][0] = leftArm.operands[0];
  solutions[2][1] = leftArm.operands[1];
  isVoidMap[2][0] = isVoidMap[2][1] = false;
  equations.push({
    id: 'twin-r3-left',
    axis: 'row',
    operandCells: [{ row: 2, col: 0 }, { row: 2, col: 1 }],
    ops: leftArm.ops,
    resultCell: { row: 2, col: 2 },
    equalsConnector: { type: 'h', row: 2, col: 1 },
    label: singleMasterAnswer ? 'R3 Left = Hub' : 'R3 Left',
  });

  // Top-Left Island Hub `(0,0)` gets its own distinct answer `tlTarget`
  const tlTarget = nextDistinctTarget();
  solutions[0][0] = tlTarget;
  isVoidMap[0][0] = false;
  isHubMap[0][0] = true;

  const tlRow = buildChainForTarget(tlTarget, 2, [null, solutions[0][2]], allowedOps, maxOp);
  solutions[0][1] = tlRow.operands[0];
  isVoidMap[0][1] = false;
  equations.push({
    id: 'twin-r1',
    axis: 'row',
    operandCells: [{ row: 0, col: 1 }, { row: 0, col: 2 }],
    ops: tlRow.ops,
    resultCell: { row: 0, col: 0 },
    equalsConnector: { type: 'h', row: 0, col: 0 },
    label: 'R1',
  });

  const tlCol = buildChainForTarget(tlTarget, 2, [null, solutions[2][0]], allowedOps, maxOp);
  solutions[1][0] = tlCol.operands[0];
  isVoidMap[1][0] = false;
  equations.push({
    id: 'twin-c1',
    axis: 'col',
    operandCells: [{ row: 1, col: 0 }, { row: 2, col: 0 }],
    ops: tlCol.ops,
    resultCell: { row: 0, col: 0 },
    equalsConnector: { type: 'v', row: 0, col: 0 },
    label: 'C1',
  });

  if (singleMasterAnswer) {
    const rightArm = buildChainForTarget(masterVal, 2, [null, null], allowedOps, maxOp);
    solutions[2][3] = rightArm.operands[0];
    solutions[2][4] = rightArm.operands[1];
    isVoidMap[2][3] = isVoidMap[2][4] = false;
    equations.push({
      id: 'twin-r3-right',
      axis: 'row',
      operandCells: [{ row: 2, col: 3 }, { row: 2, col: 4 }],
      ops: rightArm.ops,
      resultCell: { row: 2, col: 2 },
      equalsConnector: { type: 'h', row: 2, col: 2 },
      label: 'Hub = R3 Right',
    });

    const botArm = buildChainForTarget(masterVal, 2, [null, null], allowedOps, maxOp);
    solutions[3][2] = botArm.operands[0];
    solutions[4][2] = botArm.operands[1];
    isVoidMap[3][2] = isVoidMap[4][2] = false;
    equations.push({
      id: 'twin-c3-bot',
      axis: 'col',
      operandCells: [{ row: 3, col: 2 }, { row: 4, col: 2 }],
      ops: botArm.ops,
      resultCell: { row: 2, col: 2 },
      equalsConnector: { type: 'v', row: 2, col: 2 },
      label: 'Hub = C3 Bottom',
    });
  } else {
    const rRightTarget = nextDistinctTarget();
    const rightArm = buildChainForTarget(rRightTarget, 2, [solutions[2][2], null], allowedOps, maxOp);
    solutions[2][3] = rightArm.operands[1];
    solutions[2][4] = rRightTarget;
    isVoidMap[2][3] = isVoidMap[2][4] = false;
    equations.push({
      id: 'twin-r3-right',
      axis: 'row',
      operandCells: [{ row: 2, col: 2 }, { row: 2, col: 3 }],
      ops: rightArm.ops,
      resultCell: { row: 2, col: 4 },
      equalsConnector: { type: 'h', row: 2, col: 3 },
      label: 'R3 Right',
    });

    const cBotTarget = nextDistinctTarget();
    const botArm = buildChainForTarget(cBotTarget, 2, [solutions[2][2], null], allowedOps, maxOp);
    solutions[3][2] = botArm.operands[1];
    solutions[4][2] = cBotTarget;
    isVoidMap[3][2] = isVoidMap[4][2] = false;
    equations.push({
      id: 'twin-c3-bot',
      axis: 'col',
      operandCells: [{ row: 2, col: 2 }, { row: 3, col: 2 }],
      ops: botArm.ops,
      resultCell: { row: 4, col: 2 },
      equalsConnector: { type: 'v', row: 3, col: 2 },
      label: 'C3 Bottom',
    });
  }

  // Bottom-Right Island Hub `(4,4)` gets its own distinct answer `brTarget`
  const brTarget = nextDistinctTarget();
  solutions[4][4] = brTarget;
  isVoidMap[4][4] = false;
  isHubMap[4][4] = true;

  const brRow = buildChainForTarget(brTarget, 2, [solutions[4][2], null], allowedOps, maxOp);
  solutions[4][3] = brRow.operands[1];
  isVoidMap[4][3] = false;
  equations.push({
    id: 'twin-r5',
    axis: 'row',
    operandCells: [{ row: 4, col: 2 }, { row: 4, col: 3 }],
    ops: brRow.ops,
    resultCell: { row: 4, col: 4 },
    equalsConnector: { type: 'h', row: 4, col: 3 },
    label: 'R5',
  });

  const brCol = buildChainForTarget(brTarget, 2, [solutions[2][4], null], allowedOps, maxOp);
  solutions[3][4] = brCol.operands[1];
  isVoidMap[3][4] = false;
  equations.push({
    id: 'twin-c5',
    axis: 'col',
    operandCells: [{ row: 2, col: 4 }, { row: 3, col: 4 }],
    ops: brCol.ops,
    resultCell: { row: 4, col: 4 },
    equalsConnector: { type: 'v', row: 3, col: 4 },
    label: 'C5',
  });

  return finalizePuzzleFromEquations(
    N,
    solutions,
    isVoidMap,
    isHubMap,
    equations,
    profile,
    level,
    rating,
    singleMasterAnswer
  );
}

/**
 * 7x7 Grand Master Hub & Ring Topologies (`grand_7x7_hub` and `grand_7x7_ring`)
 */
function build7x7HubTopology(
  profile: DifficultyProfile,
  level: number,
  rating: number,
  topology: 'grand_7x7_hub' | 'grand_7x7_ring',
  singleMasterAnswer: boolean
): MathCrosswordPuzzle {
  const N = 7;
  const maxOp = Math.min(24, Math.max(10, profile.maxOperand + Math.floor(level / 3)));
  const minTarget = Math.max(8, Math.min(20, 7 + Math.floor(level / 2)));
  const maxTarget = Math.max(minTarget + 32, Math.min(96, maxOp * 3));
  const usedTargets = new Set<number>();

  const masterVal = pickFreshTargetAnswer(minTarget, maxTarget, usedTargets, true);
  const nextDistinctTarget = () =>
    pickFreshTargetAnswer(minTarget, maxTarget, usedTargets, false);

  const allowedOps = profile.allowedOperators;
  const solutions: (number | null)[][] = Array.from({ length: N }, () => Array(N).fill(null));
  const isVoidMap: boolean[][] = Array.from({ length: N }, () => Array(N).fill(true));
  const isHubMap: boolean[][] = Array.from({ length: N }, () => Array(N).fill(false));
  const equations: PuzzleEquation[] = [];

  solutions[3][3] = masterVal;
  isVoidMap[3][3] = false;
  isHubMap[3][3] = singleMasterAnswer;

  const left = buildChainForTarget(masterVal, 3, [null, null, null], allowedOps, maxOp);
  for (let i = 0; i < 3; i++) {
    solutions[3][i] = left.operands[i];
    isVoidMap[3][i] = false;
  }
  equations.push({
    id: 'g7-left',
    axis: 'row',
    operandCells: [{ row: 3, col: 0 }, { row: 3, col: 1 }, { row: 3, col: 2 }],
    ops: left.ops,
    resultCell: { row: 3, col: 3 },
    equalsConnector: { type: 'h', row: 3, col: 2 },
    label: singleMasterAnswer ? 'R4 Left = Hub' : 'R4 Left',
  });

  if (singleMasterAnswer) {
    const right = buildChainForTarget(masterVal, 3, [null, null, null], allowedOps, maxOp);
    for (let i = 0; i < 3; i++) {
      solutions[3][4 + i] = right.operands[i];
      isVoidMap[3][4 + i] = false;
    }
    equations.push({
      id: 'g7-right',
      axis: 'row',
      operandCells: [{ row: 3, col: 4 }, { row: 3, col: 5 }, { row: 3, col: 6 }],
      ops: right.ops,
      resultCell: { row: 3, col: 3 },
      equalsConnector: { type: 'h', row: 3, col: 3 },
      label: 'Hub = R4 Right',
    });

    const top = buildChainForTarget(masterVal, 3, [null, null, null], allowedOps, maxOp);
    for (let i = 0; i < 3; i++) {
      solutions[i][3] = top.operands[i];
      isVoidMap[i][3] = false;
    }
    equations.push({
      id: 'g7-top',
      axis: 'col',
      operandCells: [{ row: 0, col: 3 }, { row: 1, col: 3 }, { row: 2, col: 3 }],
      ops: top.ops,
      resultCell: { row: 3, col: 3 },
      equalsConnector: { type: 'v', row: 2, col: 3 },
      label: 'C4 Top = Hub',
    });

    const bot = buildChainForTarget(masterVal, 3, [null, null, null], allowedOps, maxOp);
    for (let i = 0; i < 3; i++) {
      solutions[4 + i][3] = bot.operands[i];
      isVoidMap[4 + i][3] = false;
    }
    equations.push({
      id: 'g7-bot',
      axis: 'col',
      operandCells: [{ row: 4, col: 3 }, { row: 5, col: 3 }, { row: 6, col: 3 }],
      ops: bot.ops,
      resultCell: { row: 3, col: 3 },
      equalsConnector: { type: 'v', row: 3, col: 3 },
      label: 'Hub = C4 Bottom',
    });
  } else {
    const rTarget = nextDistinctTarget();
    const right = buildChainForTarget(rTarget, 3, [solutions[3][3], null, null], allowedOps, maxOp);
    solutions[3][4] = right.operands[1];
    solutions[3][5] = right.operands[2];
    solutions[3][6] = rTarget;
    isVoidMap[3][4] = isVoidMap[3][5] = isVoidMap[3][6] = false;
    equations.push({
      id: 'g7-right',
      axis: 'row',
      operandCells: [{ row: 3, col: 3 }, { row: 3, col: 4 }, { row: 3, col: 5 }],
      ops: right.ops,
      resultCell: { row: 3, col: 6 },
      equalsConnector: { type: 'h', row: 3, col: 5 },
      label: 'R4 Right',
    });

    const tTarget = nextDistinctTarget();
    const top = buildChainForTarget(tTarget, 3, [null, null, solutions[3][3]], allowedOps, maxOp);
    solutions[0][3] = tTarget;
    solutions[1][3] = top.operands[0];
    solutions[2][3] = top.operands[1];
    isVoidMap[0][3] = isVoidMap[1][3] = isVoidMap[2][3] = false;
    equations.push({
      id: 'g7-top',
      axis: 'col',
      operandCells: [{ row: 1, col: 3 }, { row: 2, col: 3 }, { row: 3, col: 3 }],
      ops: top.ops,
      resultCell: { row: 0, col: 3 },
      equalsConnector: { type: 'v', row: 0, col: 3 },
      label: 'C4 Top',
    });

    const bTarget = nextDistinctTarget();
    const bot = buildChainForTarget(bTarget, 3, [solutions[3][3], null, null], allowedOps, maxOp);
    solutions[4][3] = bot.operands[1];
    solutions[5][3] = bot.operands[2];
    solutions[6][3] = bTarget;
    isVoidMap[4][3] = isVoidMap[5][3] = isVoidMap[6][3] = false;
    equations.push({
      id: 'g7-bot',
      axis: 'col',
      operandCells: [{ row: 3, col: 3 }, { row: 4, col: 3 }, { row: 5, col: 3 }],
      ops: bot.ops,
      resultCell: { row: 6, col: 3 },
      equalsConnector: { type: 'v', row: 5, col: 3 },
      label: 'C4 Bottom',
    });
  }

  const topCrownTarget = nextDistinctTarget();
  const topCrown = buildChainForTarget(topCrownTarget, 3, [null, solutions[1][3], null], allowedOps, maxOp);
  solutions[1][2] = topCrown.operands[0];
  solutions[1][4] = topCrown.operands[2];
  solutions[1][5] = topCrownTarget;
  isVoidMap[1][2] = isVoidMap[1][4] = isVoidMap[1][5] = false;
  isHubMap[1][5] = true;
  equations.push({
    id: 'g7-crown-top',
    axis: 'row',
    operandCells: [{ row: 1, col: 2 }, { row: 1, col: 3 }, { row: 1, col: 4 }],
    ops: topCrown.ops,
    resultCell: { row: 1, col: 5 },
    equalsConnector: { type: 'h', row: 1, col: 4 },
    label: 'R2',
  });

  const botCrownTarget = nextDistinctTarget();
  const botCrown = buildChainForTarget(botCrownTarget, 3, [null, solutions[5][3], null], allowedOps, maxOp);
  solutions[5][2] = botCrown.operands[0];
  solutions[5][4] = botCrown.operands[2];
  solutions[5][1] = botCrownTarget;
  isVoidMap[5][1] = isVoidMap[5][2] = isVoidMap[5][4] = false;
  isHubMap[5][1] = true;
  equations.push({
    id: 'g7-crown-bot',
    axis: 'row',
    operandCells: [{ row: 5, col: 2 }, { row: 5, col: 3 }, { row: 5, col: 4 }],
    ops: botCrown.ops,
    resultCell: { row: 5, col: 1 },
    equalsConnector: { type: 'h', row: 5, col: 1 },
    label: 'R6',
  });

  if (topology === 'grand_7x7_ring') {
    const leftWingTarget = nextDistinctTarget();
    const leftWing = buildChainForTarget(leftWingTarget, 3, [null, solutions[3][1], null], allowedOps, maxOp);
    solutions[2][1] = leftWing.operands[0];
    solutions[4][1] = leftWing.operands[2];
    solutions[1][1] = leftWingTarget;
    isVoidMap[1][1] = isVoidMap[2][1] = isVoidMap[4][1] = false;
    isHubMap[1][1] = true;
    equations.push({
      id: 'g7-wing-left',
      axis: 'col',
      operandCells: [{ row: 2, col: 1 }, { row: 3, col: 1 }, { row: 4, col: 1 }],
      ops: leftWing.ops,
      resultCell: { row: 1, col: 1 },
      equalsConnector: { type: 'v', row: 1, col: 1 },
      label: 'C2',
    });

    const rightWingTarget = nextDistinctTarget();
    const rightWing = buildChainForTarget(rightWingTarget, 3, [null, solutions[3][5], null], allowedOps, maxOp);
    solutions[2][5] = rightWing.operands[0];
    solutions[4][5] = rightWing.operands[2];
    solutions[5][5] = rightWingTarget;
    isVoidMap[2][5] = isVoidMap[4][5] = isVoidMap[5][5] = false;
    isHubMap[5][5] = true;
    equations.push({
      id: 'g7-wing-right',
      axis: 'col',
      operandCells: [{ row: 2, col: 5 }, { row: 3, col: 5 }, { row: 4, col: 5 }],
      ops: rightWing.ops,
      resultCell: { row: 5, col: 5 },
      equalsConnector: { type: 'v', row: 4, col: 5 },
      label: 'C6',
    });
  }

  return finalizePuzzleFromEquations(
    N,
    solutions,
    isVoidMap,
    isHubMap,
    equations,
    profile,
    level,
    rating,
    singleMasterAnswer
  );
}

/**
 * Picks a topology for the given level and optional grid size override,
 * rotating across multiple structures and never repeating the immediately preceding topology.
 */
export function pickTopologyForLevel(
  level: number,
  overrideSize?: number | null
): HardcoreTopology {
  let pool: HardcoreTopology[];
  if (overrideSize === 3) {
    pool = ['cross_plus', 'pinwheel_star', 'window_grid'];
  } else if (overrideSize === 4) {
    pool = ['window_grid', 'twin_island', 'cross_plus', 'pinwheel_star'];
  } else if (overrideSize === 5) {
    pool = ['crown_h_bridge', 'pillar_h_frame', 'hourglass_vault', 'twin_island', 'window_grid'];
  } else if (overrideSize === 6) {
    pool = ['chakravyuh_ring', 'pinwheel_star', 'crown_h_bridge', 'pillar_h_frame', 'hourglass_vault'];
  } else if (overrideSize === 7) {
    pool = ['grand_7x7_hub', 'grand_7x7_ring'];
  } else {
    pool = [
      'cross_plus',
      'crown_h_bridge',
      'pillar_h_frame',
      'chakravyuh_ring',
      'window_grid',
      'twin_island',
      'pinwheel_star',
      'hourglass_vault',
      'grand_7x7_hub',
      'grand_7x7_ring',
    ];
  }

  const recent = loadRecentTopologies();
  const lastOne = recent[recent.length - 1];
  const lastTwo = new Set(recent.slice(-2));

  let freshPool = pool.filter((t) => !lastTwo.has(t));
  if (freshPool.length === 0) {
    freshPool = pool.filter((t) => t !== lastOne);
  }
  if (freshPool.length === 0) {
    freshPool = pool;
  }

  const chosen = freshPool[(level - 1 + Math.floor(Math.random() * freshPool.length)) % freshPool.length];
  recordTopology(chosen);
  return chosen;
}

export function generateHardcorePuzzle(
  rating: number,
  level: number,
  overrideSize?: number | null,
  options?: HardcoreGenOptions
): MathCrosswordPuzzle {
  const singleMasterAnswer =
    options?.singleMasterAnswer !== undefined
      ? options.singleMasterAnswer
      : (options?.mode ?? 'hardcore') === 'hardcore';

  const topology = pickTopologyForLevel(level, overrideSize);
  const actualGridSize = topology === 'grand_7x7_hub' || topology === 'grand_7x7_ring' ? 7 : 5;
  const baseProfile = getDifficultyProfile(rating, level, actualGridSize);

  const topologyLabels: Record<HardcoreTopology, string> = {
    cross_plus: singleMasterAnswer ? '4-Way Cross (=)' : '4-Way Cross',
    window_grid: singleMasterAnswer ? 'Window Frame (=)' : 'Window Frame',
    twin_island: singleMasterAnswer ? 'Twin Islands (=)' : 'Twin Islands',
    crown_h_bridge: singleMasterAnswer ? 'Crown Bridge (=)' : 'Crown Bridge',
    pillar_h_frame: singleMasterAnswer ? 'Pillar H-Frame (=)' : 'Pillar H-Frame',
    chakravyuh_ring: singleMasterAnswer ? 'Chakravyuh Ring (=)' : 'Chakravyuh Ring',
    pinwheel_star: singleMasterAnswer ? 'Pinwheel Star (=)' : 'Pinwheel Star',
    hourglass_vault: singleMasterAnswer ? 'Hourglass Vault (=)' : 'Hourglass Vault',
    grand_7x7_hub: singleMasterAnswer ? 'Grand 7×7 Hub (=)' : 'Grand 7×7 Hub',
    grand_7x7_ring: singleMasterAnswer ? 'Grand 7×7 Ring (=)' : 'Grand 7×7 Ring',
  };

  const profile: DifficultyProfile = {
    ...baseProfile,
    gridSize: actualGridSize,
    tierName: topologyLabels[topology],
  };

  switch (topology) {
    case 'grand_7x7_hub':
    case 'grand_7x7_ring':
      return build7x7HubTopology(profile, level, rating, topology, singleMasterAnswer);
    case 'window_grid':
      return build5x5WindowTopology(profile, level, rating, singleMasterAnswer);
    case 'twin_island':
      return build5x5TwinIslandTopology(profile, level, rating, singleMasterAnswer);
    case 'cross_plus':
    case 'crown_h_bridge':
    case 'pillar_h_frame':
    case 'chakravyuh_ring':
    case 'pinwheel_star':
    case 'hourglass_vault':
    default:
      return build5x5HubTopology(profile, level, rating, topology, singleMasterAnswer);
  }
}
