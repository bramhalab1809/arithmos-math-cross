import {
  CellData,
  DifficultyProfile,
  MathCrosswordPuzzle,
  MathOperator,
  PuzzleEquation,
} from './types';
import { getDifficultyProfile } from './difficulty';
import { evaluateLinearChain } from './ops';
import { solveSingleUnknownInLine } from './lineSolver';

export type HardcoreTopology =
  | 'cross_plus'
  | 'crown_h_bridge'
  | 'pillar_h_frame'
  | 'chakravyuh_ring'
  | 'window_grid'
  | 'twin_island'
  | 'pinwheel_star'
  | 'grand_7x7_hub';

function randInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

/**
 * O(1) Direct Algebraic Construction of an n-operand chain (n in {2, 3})
 * that evaluates to `target` using BODMAS, optionally respecting fixed operand values.
 */
function buildChainForTarget(
  target: number,
  numOperands: 2 | 3,
  fixedOperands: (number | null)[],
  allowedOps: MathOperator[],
  maxOperand: number
): { operands: number[]; ops: MathOperator[] } {
  const canSub = allowedOps.includes('-');
  const canMul = allowedOps.includes('*');
  const canDiv = allowedOps.includes('/');

  if (numOperands === 2) {
    const f0 = fixedOperands[0];
    const f1 = fixedOperands[1];

    if (f0 !== null && f1 !== null) {
      for (const op of allowedOps) {
        if (evaluateLinearChain([f0, f1], [op]) === target) {
          return { operands: [f0, f1], ops: [op] };
        }
      }
    }

    if (f0 !== null) {
      const candidates: { operands: number[]; ops: MathOperator[] }[] = [];
      if (target - f0 >= 1) candidates.push({ operands: [f0, target - f0], ops: ['+'] });
      if (canSub && f0 - target >= 1) candidates.push({ operands: [f0, f0 - target], ops: ['-'] });
      if (canMul && target % f0 === 0 && target / f0 >= 1 && target / f0 <= maxOperand) {
        candidates.push({ operands: [f0, target / f0], ops: ['*'] });
      }
      if (canDiv && f0 % target === 0 && f0 / target >= 1 && f0 / target <= maxOperand) {
        candidates.push({ operands: [f0, f0 / target], ops: ['/'] });
      }
      if (candidates.length > 0) return pickRandom(candidates);
    }

    if (f1 !== null) {
      const candidates: { operands: number[]; ops: MathOperator[] }[] = [];
      if (target - f1 >= 1) candidates.push({ operands: [target - f1, f1], ops: ['+'] });
      if (canSub && target + f1 <= maxOperand * 2) {
        candidates.push({ operands: [target + f1, f1], ops: ['-'] });
      }
      if (canMul && target % f1 === 0 && target / f1 >= 1) {
        candidates.push({ operands: [target / f1, f1], ops: ['*'] });
      }
      if (canDiv && target * f1 <= maxOperand * 2) {
        candidates.push({ operands: [target * f1, f1], ops: ['/'] });
      }
      if (candidates.length > 0) return pickRandom(candidates);
    }

    // Both free: O(1) direct construction
    const candidates: { operands: number[]; ops: MathOperator[] }[] = [];
    if (target >= 2) {
      const a = randInt(1, Math.min(maxOperand, target - 1));
      candidates.push({ operands: [a, target - a], ops: ['+'] });
    }
    if (canSub) {
      const b = randInt(1, Math.min(12, maxOperand));
      candidates.push({ operands: [target + b, b], ops: ['-'] });
    }
    if (canMul) {
      for (let d = 2; d <= Math.min(12, maxOperand); d++) {
        if (target % d === 0 && target / d >= 1 && target / d <= maxOperand) {
          candidates.push({ operands: [d, target / d], ops: ['*'] });
        }
      }
    }
    if (canDiv) {
      const b = randInt(2, 5);
      if (target * b <= maxOperand * 2) {
        candidates.push({ operands: [target * b, b], ops: ['/'] });
      }
    }
    if (candidates.length > 0) return pickRandom(candidates);
    return { operands: [Math.max(1, target - 1), 1], ops: ['+'] };
  }

  // numOperands === 3: [a, b, c] with [op1, op2]
  const f0 = fixedOperands[0];
  const f1 = fixedOperands[1];
  const f2 = fixedOperands[2];

  for (let attempt = 0; attempt < 25; attempt++) {
    const op1 = pickRandom(allowedOps);
    const op2 = pickRandom(allowedOps);
    const a = f0 ?? randInt(1, maxOperand);
    const b = f1 ?? randInt(1, maxOperand);

    if (f2 !== null) {
      if (evaluateLinearChain([a, b, f2], [op1, op2]) === target) {
        return { operands: [a, b, f2], ops: [op1, op2] };
      }
      continue;
    }

    const ab = evaluateLinearChain([a, b], [op1]);
    if (ab !== null && ab >= 1) {
      if (target - ab >= 1 && target - ab <= maxOperand * 2) {
        if (evaluateLinearChain([a, b, target - ab], [op1, '+']) === target) {
          return { operands: [a, b, target - ab], ops: [op1, '+'] };
        }
      }
      if (canSub && ab - target >= 1 && ab - target <= maxOperand * 2) {
        if (evaluateLinearChain([a, b, ab - target], [op1, '-']) === target) {
          return { operands: [a, b, ab - target], ops: [op1, '-'] };
        }
      }
    }
  }

  const a = f0 ?? randInt(1, Math.max(1, Math.min(maxOperand, target - 2)));
  const b = f1 ?? randInt(1, Math.max(1, Math.min(maxOperand, Math.abs(target - a) - 1)));
  if (f2 !== null) {
    const rem = target - f2;
    if (rem >= 2) {
      const x = f0 ?? randInt(1, rem - 1);
      const y = f1 ?? Math.max(1, rem - x);
      if (x + y + f2 === target) return { operands: [x, y, f2], ops: ['+', '+'] };
    }
    const need = f2 + target;
    const x = f0 ?? randInt(1, Math.max(1, need - 1));
    const y = f1 ?? Math.max(1, need - x);
    if (x + y - f2 === target) return { operands: [x, y, f2], ops: ['+', '-'] };
  }

  const sumAB = a + b;
  if (sumAB < target) {
    return { operands: [a, b, target - sumAB], ops: ['+', '+'] };
  } else if (sumAB > target) {
    return { operands: [a, b, sumAB - target], ops: ['+', '-'] };
  }
  return { operands: [a, b, 1], ops: ['+', '*'] };
}

/**
 * Verifies in O(E) time that all blank cells in an equation-based puzzle can be
 * uniquely deduced step-by-step via single-unknown equation elimination.
 */
function isEquationPuzzleUniquelySolvable(puzzle: MathCrosswordPuzzle): boolean {
  const N = puzzle.size;
  const eqs = puzzle.equations ?? [];
  const known: (number | null)[][] = Array.from({ length: N }, (_, r) =>
    Array.from({ length: N }, (__, c) => {
      const cell = puzzle.cells[r][c];
      if (cell.isVoid) return 0;
      return cell.isClue ? cell.solution : null;
    })
  );

  let remainingBlanks = 0;
  for (let r = 0; r < N; r++) {
    for (let c = 0; c < N; c++) {
      if (!puzzle.cells[r][c].isVoid && known[r][c] === null) {
        remainingBlanks++;
      }
    }
  }
  if (remainingBlanks === 0) return true;

  let progress = true;
  while (progress && remainingBlanks > 0) {
    progress = false;
    for (const eq of eqs) {
      const allPos = [...eq.operandCells, eq.resultCell];
      let nullIdx = -1;
      let nullCount = 0;
      const lineVals: (number | null)[] = allPos.map((p, idx) => {
        const v = known[p.row][p.col];
        if (v === null) {
          nullCount++;
          nullIdx = idx;
        }
        return v;
      });

      if (nullCount === 1 && nullIdx !== -1) {
        const deduced = solveSingleUnknownInLine(lineVals, eq.ops);
        const targetPos = allPos[nullIdx];
        const expectedSol = puzzle.cells[targetPos.row][targetPos.col].solution;
        if (deduced !== null && deduced === expectedSol) {
          known[targetPos.row][targetPos.col] = deduced;
          remainingBlanks--;
          progress = true;
          if (remainingBlanks === 0) return true;
        }
      }
    }
  }

  return remainingBlanks === 0;
}

function finalizePuzzleFromEquations(
  N: number,
  solutions: (number | null)[][],
  isVoidMap: boolean[][],
  isHubMap: boolean[][],
  equations: PuzzleEquation[],
  profile: DifficultyProfile,
  level: number,
  rating: number
): MathCrosswordPuzzle {
  const hConnectors: (MathOperator | '=' | '')[][] = Array.from({ length: N }, () =>
    Array(Math.max(1, N - 1)).fill('')
  );
  const vConnectors: (MathOperator | '=' | '')[][] = Array.from({ length: Math.max(1, N - 1) }, () =>
    Array(N).fill('')
  );
  const rowOps: MathOperator[][] = Array.from({ length: N }, () =>
    Array(Math.max(1, N - 2)).fill('+')
  );
  const colOps: MathOperator[][] = Array.from({ length: Math.max(1, N - 2) }, () =>
    Array(N).fill('+')
  );

  for (const eq of equations) {
    if (eq.axis === 'row') {
      const r = eq.resultCell.row;
      for (let i = 0; i < eq.ops.length; i++) {
        const leftCol = Math.min(eq.operandCells[i].col, eq.operandCells[i + 1].col);
        hConnectors[r][leftCol] = eq.ops[i];
        if (leftCol < N - 2) rowOps[r][leftCol] = eq.ops[i];
      }
      hConnectors[eq.equalsConnector.row][eq.equalsConnector.col] = '=';
    } else {
      const c = eq.resultCell.col;
      for (let i = 0; i < eq.ops.length; i++) {
        const topRow = Math.min(eq.operandCells[i].row, eq.operandCells[i + 1].row);
        vConnectors[topRow][c] = eq.ops[i];
        if (topRow < N - 2) colOps[topRow][c] = eq.ops[i];
      }
      vConnectors[eq.equalsConnector.row][eq.equalsConnector.col] = '=';
    }
  }

  const cells: CellData[][] = Array.from({ length: N }, (_, r) =>
    Array.from({ length: N }, (__, c) => {
      const isVoid = isVoidMap[r][c] || solutions[r][c] === null;
      const sol = solutions[r][c] ?? 1;
      return {
        row: r,
        col: c,
        solution: sol,
        userValue: String(sol),
        isClue: !isVoid,
        isError: false,
        isHinted: false,
        isVoid,
        isWall: false,
        isHub: isHubMap[r][c],
      };
    })
  );

  const puzzle: MathCrosswordPuzzle = {
    id: `hc-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    size: N,
    cells,
    rowOps,
    colOps,
    hConnectors,
    vConnectors,
    equations,
    level,
    ratingAtGeneration: rating,
    profile,
    verifiedSolutionsCount: 1,
    generationSteps: 1,
  };

  // Carve blanks while preserving a unique domino solution
  const activeCoords: { r: number; c: number }[] = [];
  for (let r = 0; r < N; r++) {
    for (let c = 0; c < N; c++) {
      if (!cells[r][c].isVoid) activeCoords.push({ r, c });
    }
  }

  for (let i = activeCoords.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [activeCoords[i], activeCoords[j]] = [activeCoords[j], activeCoords[i]];
  }

  // Prefer carving at least one hub cell if possible so player gets to enter the Master Answer
  activeCoords.sort((a, b) => (cells[b.r][b.c].isHub ? 1 : 0) - (cells[a.r][a.c].isHub ? 1 : 0));

  const targetBlanks = Math.max(
    4,
    Math.min(activeCoords.length - 4, Math.round(activeCoords.length * 0.48))
  );
  let carved = 0;

  for (const { r, c } of activeCoords) {
    if (carved >= targetBlanks) break;
    const cell = puzzle.cells[r][c];
    cell.isClue = false;
    cell.userValue = '';

    if (isEquationPuzzleUniquelySolvable(puzzle)) {
      carved++;
    } else {
      cell.isClue = true;
      cell.userValue = String(cell.solution);
    }
  }

  return puzzle;
}

/**
 * Builds a 5x5 Single-Master-Answer puzzle across 5 distinct topologies:
 * - 'cross_plus': Central '+' cross where all 4 arms converge on (2,2) = hubVal
 * - 'crown_h_bridge': Central '+' cross PLUS top & bottom horizontal equations that ALSO equal hubVal
 * - 'pillar_h_frame': Central '+' cross PLUS left & right vertical equations that ALSO equal hubVal
 * - 'chakravyuh_ring': Full 5x5 outer perimeter ring + inner 4-way hub where ALL 8 equations equal hubVal
 * - 'pinwheel_star': 4-way center hub + 2 diagonal corner L-arms all equaling hubVal
 */
function build5x5ConvergingHub(
  profile: DifficultyProfile,
  level: number,
  rating: number,
  topology: 'cross_plus' | 'crown_h_bridge' | 'pillar_h_frame' | 'chakravyuh_ring' | 'pinwheel_star'
): MathCrosswordPuzzle {
  const N = 5;
  const maxOp = Math.min(18, Math.max(9, profile.maxOperand));
  const hubVal = randInt(8, Math.min(28, maxOp * 2));
  const allowedOps = profile.allowedOperators;

  const solutions: (number | null)[][] = Array.from({ length: N }, () => Array(N).fill(null));
  const isVoidMap: boolean[][] = Array.from({ length: N }, () => Array(N).fill(true));
  const isHubMap: boolean[][] = Array.from({ length: N }, () => Array(N).fill(false));
  const equations: PuzzleEquation[] = [];

  // Center Master Answer Hub at (2,2)
  solutions[2][2] = hubVal;
  isVoidMap[2][2] = false;
  isHubMap[2][2] = true;

  // 4 Center Arms converging on (2,2):
  const leftArm = buildChainForTarget(hubVal, 2, [null, null], allowedOps, maxOp);
  solutions[2][0] = leftArm.operands[0];
  solutions[2][1] = leftArm.operands[1];
  isVoidMap[2][0] = false;
  isVoidMap[2][1] = false;
  equations.push({
    id: 'hub-left',
    axis: 'row',
    operandCells: [{ row: 2, col: 0 }, { row: 2, col: 1 }],
    ops: leftArm.ops,
    resultCell: { row: 2, col: 2 },
    equalsConnector: { type: 'h', row: 2, col: 1 },
    label: 'R3 Left = Hub',
  });

  const rightArm = buildChainForTarget(hubVal, 2, [null, null], allowedOps, maxOp);
  solutions[2][3] = rightArm.operands[0];
  solutions[2][4] = rightArm.operands[1];
  isVoidMap[2][3] = false;
  isVoidMap[2][4] = false;
  equations.push({
    id: 'hub-right',
    axis: 'row',
    operandCells: [{ row: 2, col: 3 }, { row: 2, col: 4 }],
    ops: rightArm.ops,
    resultCell: { row: 2, col: 2 },
    equalsConnector: { type: 'h', row: 2, col: 2 },
    label: 'Hub = R3 Right',
  });

  const topArm = buildChainForTarget(hubVal, 2, [null, null], allowedOps, maxOp);
  solutions[0][2] = topArm.operands[0];
  solutions[1][2] = topArm.operands[1];
  isVoidMap[0][2] = false;
  isVoidMap[1][2] = false;
  equations.push({
    id: 'hub-top',
    axis: 'col',
    operandCells: [{ row: 0, col: 2 }, { row: 1, col: 2 }],
    ops: topArm.ops,
    resultCell: { row: 2, col: 2 },
    equalsConnector: { type: 'v', row: 1, col: 2 },
    label: 'C3 Top = Hub',
  });

  const bottomArm = buildChainForTarget(hubVal, 2, [null, null], allowedOps, maxOp);
  solutions[3][2] = bottomArm.operands[0];
  solutions[4][2] = bottomArm.operands[1];
  isVoidMap[3][2] = false;
  isVoidMap[4][2] = false;
  equations.push({
    id: 'hub-bottom',
    axis: 'col',
    operandCells: [{ row: 3, col: 2 }, { row: 4, col: 2 }],
    ops: bottomArm.ops,
    resultCell: { row: 2, col: 2 },
    equalsConnector: { type: 'v', row: 2, col: 2 },
    label: 'Hub = C3 Bottom',
  });

  if (topology === 'crown_h_bridge' || topology === 'chakravyuh_ring') {
    const topBridge = buildChainForTarget(hubVal, 3, [null, solutions[0][2], null], allowedOps, maxOp);
    solutions[0][1] = topBridge.operands[0];
    solutions[0][2] = topBridge.operands[1];
    solutions[0][3] = topBridge.operands[2];
    solutions[0][4] = hubVal;
    isVoidMap[0][1] = false;
    isVoidMap[0][3] = false;
    isVoidMap[0][4] = false;
    isHubMap[0][4] = true;
    equations.push({
      id: 'top-bridge',
      axis: 'row',
      operandCells: [{ row: 0, col: 1 }, { row: 0, col: 2 }, { row: 0, col: 3 }],
      ops: topBridge.ops,
      resultCell: { row: 0, col: 4 },
      equalsConnector: { type: 'h', row: 0, col: 3 },
      label: 'R1 = Hub',
    });

    const botBridge = buildChainForTarget(hubVal, 3, [null, solutions[4][2], null], allowedOps, maxOp);
    solutions[4][1] = botBridge.operands[0];
    solutions[4][2] = botBridge.operands[1];
    solutions[4][3] = botBridge.operands[2];
    solutions[4][0] = hubVal;
    isVoidMap[4][0] = false;
    isVoidMap[4][1] = false;
    isVoidMap[4][3] = false;
    isHubMap[4][0] = true;
    equations.push({
      id: 'bot-bridge',
      axis: 'row',
      operandCells: [{ row: 4, col: 1 }, { row: 4, col: 2 }, { row: 4, col: 3 }],
      ops: botBridge.ops,
      resultCell: { row: 4, col: 0 },
      equalsConnector: { type: 'h', row: 4, col: 0 },
      label: 'Hub = R5',
    });
  }

  if (topology === 'pillar_h_frame' || topology === 'chakravyuh_ring') {
    const leftPillar = buildChainForTarget(hubVal, 3, [null, solutions[2][0], null], allowedOps, maxOp);
    solutions[1][0] = leftPillar.operands[0];
    solutions[2][0] = leftPillar.operands[1];
    solutions[3][0] = leftPillar.operands[2];
    solutions[0][0] = hubVal;
    isVoidMap[0][0] = false;
    isVoidMap[1][0] = false;
    isVoidMap[3][0] = false;
    isHubMap[0][0] = true;
    equations.push({
      id: 'left-pillar',
      axis: 'col',
      operandCells: [{ row: 1, col: 0 }, { row: 2, col: 0 }, { row: 3, col: 0 }],
      ops: leftPillar.ops,
      resultCell: { row: 0, col: 0 },
      equalsConnector: { type: 'v', row: 0, col: 0 },
      label: 'Hub = C1',
    });

    const rightPillar = buildChainForTarget(hubVal, 3, [null, solutions[2][4], null], allowedOps, maxOp);
    solutions[1][4] = rightPillar.operands[0];
    solutions[2][4] = rightPillar.operands[1];
    solutions[3][4] = rightPillar.operands[2];
    solutions[4][4] = hubVal;
    isVoidMap[1][4] = false;
    isVoidMap[3][4] = false;
    isVoidMap[4][4] = false;
    isHubMap[4][4] = true;
    equations.push({
      id: 'right-pillar',
      axis: 'col',
      operandCells: [{ row: 1, col: 4 }, { row: 2, col: 4 }, { row: 3, col: 4 }],
      ops: rightPillar.ops,
      resultCell: { row: 4, col: 4 },
      equalsConnector: { type: 'v', row: 3, col: 4 },
      label: 'C5 = Hub',
    });
  }

  if (topology === 'pinwheel_star') {
    const topLeftWing = buildChainForTarget(hubVal, 2, [null, solutions[0][2]], allowedOps, maxOp);
    solutions[0][1] = topLeftWing.operands[0];
    solutions[0][2] = topLeftWing.operands[1];
    solutions[0][0] = hubVal;
    isVoidMap[0][0] = false;
    isVoidMap[0][1] = false;
    isHubMap[0][0] = true;
    equations.push({
      id: 'pinwheel-top',
      axis: 'row',
      operandCells: [{ row: 0, col: 1 }, { row: 0, col: 2 }],
      ops: topLeftWing.ops,
      resultCell: { row: 0, col: 0 },
      equalsConnector: { type: 'h', row: 0, col: 0 },
      label: 'Hub = R1',
    });

    const botRightWing = buildChainForTarget(hubVal, 2, [solutions[4][2], null], allowedOps, maxOp);
    solutions[4][2] = botRightWing.operands[0];
    solutions[4][3] = botRightWing.operands[1];
    solutions[4][4] = hubVal;
    isVoidMap[4][3] = false;
    isVoidMap[4][4] = false;
    isHubMap[4][4] = true;
    equations.push({
      id: 'pinwheel-bot',
      axis: 'row',
      operandCells: [{ row: 4, col: 2 }, { row: 4, col: 3 }],
      ops: botRightWing.ops,
      resultCell: { row: 4, col: 4 },
      equalsConnector: { type: 'h', row: 4, col: 3 },
      label: 'R5 = Hub',
    });
  }

  return finalizePuzzleFromEquations(N, solutions, isVoidMap, isHubMap, equations, profile, level, rating);
}

/**
 * Window Grid Topology (5x5):
 * Outer frame of 4 interlocking 3-operand equations (R1, R3, C1, C3) that ALL evaluate
 * to the exact same Master Answer (`hubVal`) in the 4 hubs, with clean void windows inside!
 */
function build5x5WindowSingleAnswer(
  profile: DifficultyProfile,
  level: number,
  rating: number
): MathCrosswordPuzzle {
  const N = 5;
  const maxOp = Math.min(18, Math.max(9, profile.maxOperand));
  const hubVal = randInt(9, Math.min(28, maxOp * 2));
  const allowedOps = profile.allowedOperators;

  const solutions: (number | null)[][] = Array.from({ length: N }, () => Array(N).fill(null));
  const isVoidMap: boolean[][] = Array.from({ length: N }, () => Array(N).fill(true));
  const isHubMap: boolean[][] = Array.from({ length: N }, () => Array(N).fill(false));
  const equations: PuzzleEquation[] = [];

  // Top Row: (0,0) op (0,1) op (0,2) = (0,3) [hubVal]
  const topEq = buildChainForTarget(hubVal, 3, [null, null, null], allowedOps, maxOp);
  solutions[0][0] = topEq.operands[0];
  solutions[0][1] = topEq.operands[1];
  solutions[0][2] = topEq.operands[2];
  solutions[0][3] = hubVal;
  isVoidMap[0][0] = isVoidMap[0][1] = isVoidMap[0][2] = isVoidMap[0][3] = false;
  isHubMap[0][3] = true;
  equations.push({
    id: 'win-top',
    axis: 'row',
    operandCells: [{ row: 0, col: 0 }, { row: 0, col: 1 }, { row: 0, col: 2 }],
    ops: topEq.ops,
    resultCell: { row: 0, col: 3 },
    equalsConnector: { type: 'h', row: 0, col: 2 },
    label: 'R1 = Hub',
  });

  // Left Col: (0,0) op (1,0) op (2,0) = (3,0) [hubVal]
  const leftEq = buildChainForTarget(hubVal, 3, [solutions[0][0], null, null], allowedOps, maxOp);
  solutions[1][0] = leftEq.operands[1];
  solutions[2][0] = leftEq.operands[2];
  solutions[3][0] = hubVal;
  isVoidMap[1][0] = isVoidMap[2][0] = isVoidMap[3][0] = false;
  isHubMap[3][0] = true;
  equations.push({
    id: 'win-left',
    axis: 'col',
    operandCells: [{ row: 0, col: 0 }, { row: 1, col: 0 }, { row: 2, col: 0 }],
    ops: leftEq.ops,
    resultCell: { row: 3, col: 0 },
    equalsConnector: { type: 'v', row: 2, col: 0 },
    label: 'C1 = Hub',
  });

  // Mid Col C3: (0,2) op (1,2) op (2,2) = (3,2) [hubVal]
  const midColEq = buildChainForTarget(hubVal, 3, [solutions[0][2], null, null], allowedOps, maxOp);
  solutions[1][2] = midColEq.operands[1];
  solutions[2][2] = midColEq.operands[2];
  solutions[3][2] = hubVal;
  isVoidMap[1][2] = isVoidMap[2][2] = isVoidMap[3][2] = false;
  isHubMap[3][2] = true;
  equations.push({
    id: 'win-mid-col',
    axis: 'col',
    operandCells: [{ row: 0, col: 2 }, { row: 1, col: 2 }, { row: 2, col: 2 }],
    ops: midColEq.ops,
    resultCell: { row: 3, col: 2 },
    equalsConnector: { type: 'v', row: 2, col: 2 },
    label: 'C3 = Hub',
  });

  // Mid Row R3: (2,0) op (2,1) op (2,2) = (2,3) [hubVal]
  const midRowEq = buildChainForTarget(hubVal, 3, [solutions[2][0], null, solutions[2][2]], allowedOps, maxOp);
  solutions[2][1] = midRowEq.operands[1];
  solutions[2][3] = hubVal;
  isVoidMap[2][1] = isVoidMap[2][3] = false;
  isHubMap[2][3] = true;
  equations.push({
    id: 'win-mid-row',
    axis: 'row',
    operandCells: [{ row: 2, col: 0 }, { row: 2, col: 1 }, { row: 2, col: 2 }],
    ops: midRowEq.ops,
    resultCell: { row: 2, col: 3 },
    equalsConnector: { type: 'h', row: 2, col: 2 },
    label: 'R3 = Hub',
  });

  return finalizePuzzleFromEquations(N, solutions, isVoidMap, isHubMap, equations, profile, level, rating);
}

/**
 * Twin Island Bridge Topology (5x5):
 * Two diagonal Crossmath islands linked through the center, where EVERY equation
 * evaluates to the exact same Master Answer (`hubVal`).
 */
function build5x5TwinIslandSingleAnswer(
  profile: DifficultyProfile,
  level: number,
  rating: number
): MathCrosswordPuzzle {
  const N = 5;
  const maxOp = Math.min(16, Math.max(8, profile.maxOperand));
  const hubVal = randInt(8, Math.min(24, maxOp * 2));
  const allowedOps = profile.allowedOperators;

  const solutions: (number | null)[][] = Array.from({ length: N }, () => Array(N).fill(null));
  const isVoidMap: boolean[][] = Array.from({ length: N }, () => Array(N).fill(true));
  const isHubMap: boolean[][] = Array.from({ length: N }, () => Array(N).fill(false));
  const equations: PuzzleEquation[] = [];

  // Shared center hub at (2,2) = hubVal
  solutions[2][2] = hubVal;
  isVoidMap[2][2] = false;
  isHubMap[2][2] = true;

  // Island 1 (Top-Left): C3 top arm (0,2),(1,2)->(2,2) and R3 left arm (2,0),(2,1)->(2,2)
  const topArm = buildChainForTarget(hubVal, 2, [null, null], allowedOps, maxOp);
  solutions[0][2] = topArm.operands[0];
  solutions[1][2] = topArm.operands[1];
  isVoidMap[0][2] = isVoidMap[1][2] = false;
  equations.push({
    id: 'twin-c3-top',
    axis: 'col',
    operandCells: [{ row: 0, col: 2 }, { row: 1, col: 2 }],
    ops: topArm.ops,
    resultCell: { row: 2, col: 2 },
    equalsConnector: { type: 'v', row: 1, col: 2 },
    label: 'C3 Top = Hub',
  });

  const leftArm = buildChainForTarget(hubVal, 2, [null, null], allowedOps, maxOp);
  solutions[2][0] = leftArm.operands[0];
  solutions[2][1] = leftArm.operands[1];
  isVoidMap[2][0] = isVoidMap[2][1] = false;
  equations.push({
    id: 'twin-r3-left',
    axis: 'row',
    operandCells: [{ row: 2, col: 0 }, { row: 2, col: 1 }],
    ops: leftArm.ops,
    resultCell: { row: 2, col: 2 },
    equalsConnector: { type: 'h', row: 2, col: 1 },
    label: 'R3 Left = Hub',
  });

  // Top-left hub at (0,0) = hubVal
  solutions[0][0] = hubVal;
  isVoidMap[0][0] = false;
  isHubMap[0][0] = true;

  const tlRow = buildChainForTarget(hubVal, 2, [null, solutions[0][2]], allowedOps, maxOp);
  solutions[0][1] = tlRow.operands[0];
  isVoidMap[0][1] = false;
  equations.push({
    id: 'twin-r1',
    axis: 'row',
    operandCells: [{ row: 0, col: 1 }, { row: 0, col: 2 }],
    ops: tlRow.ops,
    resultCell: { row: 0, col: 0 },
    equalsConnector: { type: 'h', row: 0, col: 0 },
    label: 'Hub = R1',
  });

  const tlCol = buildChainForTarget(hubVal, 2, [null, solutions[2][0]], allowedOps, maxOp);
  solutions[1][0] = tlCol.operands[0];
  isVoidMap[1][0] = false;
  equations.push({
    id: 'twin-c1',
    axis: 'col',
    operandCells: [{ row: 1, col: 0 }, { row: 2, col: 0 }],
    ops: tlCol.ops,
    resultCell: { row: 0, col: 0 },
    equalsConnector: { type: 'v', row: 0, col: 0 },
    label: 'Hub = C1',
  });

  // Island 2 (Bottom-Right): (2,2) = (2,3) op (2,4) and (2,2) = (3,2) op (4,2)
  const rightArm = buildChainForTarget(hubVal, 2, [null, null], allowedOps, maxOp);
  solutions[2][3] = rightArm.operands[0];
  solutions[2][4] = rightArm.operands[1];
  isVoidMap[2][3] = isVoidMap[2][4] = false;
  equations.push({
    id: 'twin-r3-right',
    axis: 'row',
    operandCells: [{ row: 2, col: 3 }, { row: 2, col: 4 }],
    ops: rightArm.ops,
    resultCell: { row: 2, col: 2 },
    equalsConnector: { type: 'h', row: 2, col: 2 },
    label: 'Hub = R3 Right',
  });

  const botArm = buildChainForTarget(hubVal, 2, [null, null], allowedOps, maxOp);
  solutions[3][2] = botArm.operands[0];
  solutions[4][2] = botArm.operands[1];
  isVoidMap[3][2] = isVoidMap[4][2] = false;
  equations.push({
    id: 'twin-c3-bot',
    axis: 'col',
    operandCells: [{ row: 3, col: 2 }, { row: 4, col: 2 }],
    ops: botArm.ops,
    resultCell: { row: 2, col: 2 },
    equalsConnector: { type: 'v', row: 2, col: 2 },
    label: 'Hub = C3 Bottom',
  });

  // Bottom-Right Hub at (4,4) = hubVal
  solutions[4][4] = hubVal;
  isVoidMap[4][4] = false;
  isHubMap[4][4] = true;

  const brRow = buildChainForTarget(hubVal, 2, [solutions[4][2], null], allowedOps, maxOp);
  solutions[4][3] = brRow.operands[1];
  isVoidMap[4][3] = false;
  equations.push({
    id: 'twin-r5',
    axis: 'row',
    operandCells: [{ row: 4, col: 2 }, { row: 4, col: 3 }],
    ops: brRow.ops,
    resultCell: { row: 4, col: 4 },
    equalsConnector: { type: 'h', row: 4, col: 3 },
    label: 'R5 = Hub',
  });

  const brCol = buildChainForTarget(hubVal, 2, [solutions[2][4], null], allowedOps, maxOp);
  solutions[3][4] = brCol.operands[1];
  isVoidMap[3][4] = false;
  equations.push({
    id: 'twin-c5',
    axis: 'col',
    operandCells: [{ row: 2, col: 4 }, { row: 3, col: 4 }],
    ops: brCol.ops,
    resultCell: { row: 4, col: 4 },
    equalsConnector: { type: 'v', row: 3, col: 4 },
    label: 'C5 = Hub',
  });

  return finalizePuzzleFromEquations(N, solutions, isVoidMap, isHubMap, equations, profile, level, rating);
}

/**
 * 7x7 Grand Master Hub:
 * Center (3,3) is a 4-way `=` Hub with 3-operand chains from all 4 directions,
 * plus 2 outer horizontal bridge equations — all 6 equations evaluate to `hubVal`!
 */
function build7x7SingleAnswerHub(
  profile: DifficultyProfile,
  level: number,
  rating: number
): MathCrosswordPuzzle {
  const N = 7;
  const maxOp = Math.min(18, Math.max(9, profile.maxOperand));
  const hubVal = randInt(10, Math.min(32, maxOp * 2));
  const allowedOps = profile.allowedOperators;

  const solutions: (number | null)[][] = Array.from({ length: N }, () => Array(N).fill(null));
  const isVoidMap: boolean[][] = Array.from({ length: N }, () => Array(N).fill(true));
  const isHubMap: boolean[][] = Array.from({ length: N }, () => Array(N).fill(false));
  const equations: PuzzleEquation[] = [];

  solutions[3][3] = hubVal;
  isVoidMap[3][3] = false;
  isHubMap[3][3] = true;

  // 4 Center 3-operand arms into (3,3)
  const left = buildChainForTarget(hubVal, 3, [null, null, null], allowedOps, maxOp);
  for (let i = 0; i < 3; i++) {
    solutions[3][i] = left.operands[i];
    isVoidMap[3][i] = false;
  }
  equations.push({
    id: 'g7-left',
    axis: 'row',
    operandCells: [{ row: 3, col: 0 }, { row: 3, col: 1 }, { row: 3, col: 2 }],
    ops: left.ops,
    resultCell: { row: 3, col: 3 },
    equalsConnector: { type: 'h', row: 3, col: 2 },
    label: 'R4 Left = Hub',
  });

  const right = buildChainForTarget(hubVal, 3, [null, null, null], allowedOps, maxOp);
  for (let i = 0; i < 3; i++) {
    solutions[3][4 + i] = right.operands[i];
    isVoidMap[3][4 + i] = false;
  }
  equations.push({
    id: 'g7-right',
    axis: 'row',
    operandCells: [{ row: 3, col: 4 }, { row: 3, col: 5 }, { row: 3, col: 6 }],
    ops: right.ops,
    resultCell: { row: 3, col: 3 },
    equalsConnector: { type: 'h', row: 3, col: 3 },
    label: 'Hub = R4 Right',
  });

  const top = buildChainForTarget(hubVal, 3, [null, null, null], allowedOps, maxOp);
  for (let i = 0; i < 3; i++) {
    solutions[i][3] = top.operands[i];
    isVoidMap[i][3] = false;
  }
  equations.push({
    id: 'g7-top',
    axis: 'col',
    operandCells: [{ row: 0, col: 3 }, { row: 1, col: 3 }, { row: 2, col: 3 }],
    ops: top.ops,
    resultCell: { row: 3, col: 3 },
    equalsConnector: { type: 'v', row: 2, col: 3 },
    label: 'C4 Top = Hub',
  });

  const bot = buildChainForTarget(hubVal, 3, [null, null, null], allowedOps, maxOp);
  for (let i = 0; i < 3; i++) {
    solutions[4 + i][3] = bot.operands[i];
    isVoidMap[4 + i][3] = false;
  }
  equations.push({
    id: 'g7-bot',
    axis: 'col',
    operandCells: [{ row: 4, col: 3 }, { row: 5, col: 3 }, { row: 6, col: 3 }],
    ops: bot.ops,
    resultCell: { row: 3, col: 3 },
    equalsConnector: { type: 'v', row: 3, col: 3 },
    label: 'Hub = C4 Bottom',
  });

  // Add Top & Bottom horizontal crowns through (1,3) and (5,3)
  const topCrown = buildChainForTarget(hubVal, 3, [null, solutions[1][3], null], allowedOps, maxOp);
  solutions[1][2] = topCrown.operands[0];
  solutions[1][4] = topCrown.operands[2];
  solutions[1][5] = hubVal;
  isVoidMap[1][2] = isVoidMap[1][4] = isVoidMap[1][5] = false;
  isHubMap[1][5] = true;
  equations.push({
    id: 'g7-crown-top',
    axis: 'row',
    operandCells: [{ row: 1, col: 2 }, { row: 1, col: 3 }, { row: 1, col: 4 }],
    ops: topCrown.ops,
    resultCell: { row: 1, col: 5 },
    equalsConnector: { type: 'h', row: 1, col: 4 },
    label: 'R2 = Hub',
  });

  const botCrown = buildChainForTarget(hubVal, 3, [null, solutions[5][3], null], allowedOps, maxOp);
  solutions[5][2] = botCrown.operands[0];
  solutions[5][4] = botCrown.operands[2];
  solutions[5][1] = hubVal;
  isVoidMap[5][1] = isVoidMap[5][2] = isVoidMap[5][4] = false;
  isHubMap[5][1] = true;
  equations.push({
    id: 'g7-crown-bot',
    axis: 'row',
    operandCells: [{ row: 5, col: 2 }, { row: 5, col: 3 }, { row: 5, col: 4 }],
    ops: botCrown.ops,
    resultCell: { row: 5, col: 1 },
    equalsConnector: { type: 'h', row: 5, col: 1 },
    label: 'Hub = R6',
  });

  return finalizePuzzleFromEquations(N, solutions, isVoidMap, isHubMap, equations, profile, level, rating);
}

export function pickTopologyForLevel(
  level: number,
  overrideSize?: number | null
): HardcoreTopology {
  if (overrideSize === 3) return 'cross_plus';
  if (overrideSize === 4) {
    return level % 2 === 1 ? 'window_grid' : 'twin_island';
  }
  if (overrideSize === 5) {
    return level % 2 === 1 ? 'crown_h_bridge' : 'pillar_h_frame';
  }
  if (overrideSize === 6) {
    return level % 2 === 1 ? 'chakravyuh_ring' : 'pinwheel_star';
  }
  if (overrideSize === 7) return 'grand_7x7_hub';

  const pool: HardcoreTopology[] = [
    'cross_plus',
    'crown_h_bridge',
    'pillar_h_frame',
    'chakravyuh_ring',
    'window_grid',
    'twin_island',
    'pinwheel_star',
    'grand_7x7_hub',
  ];
  const idx = (level - 1 + Math.floor(Math.random() * pool.length)) % pool.length;
  return pool[idx];
}

export function generateHardcorePuzzle(
  rating: number,
  level: number,
  overrideSize?: number | null
): MathCrosswordPuzzle {
  const topology = pickTopologyForLevel(level, overrideSize);
  const actualGridSize = topology === 'grand_7x7_hub' ? 7 : 5;
  const baseProfile = getDifficultyProfile(rating, level, actualGridSize);

  const topologyLabels: Record<HardcoreTopology, string> = {
    cross_plus: '4-Way Cross (=)',
    window_grid: 'Window Frame (=)',
    twin_island: 'Twin Islands (=)',
    crown_h_bridge: 'Crown Bridge (=)',
    pillar_h_frame: 'Pillar H-Frame (=)',
    chakravyuh_ring: 'Chakravyuh Ring (=)',
    pinwheel_star: 'Pinwheel Star (=)',
    grand_7x7_hub: 'Grand 7×7 Hub (=)',
  };

  const profile: DifficultyProfile = {
    ...baseProfile,
    gridSize: actualGridSize,
    tierName: topologyLabels[topology],
  };

  switch (topology) {
    case 'grand_7x7_hub':
      return build7x7SingleAnswerHub(profile, level, rating);
    case 'window_grid':
      return build5x5WindowSingleAnswer(profile, level, rating);
    case 'twin_island':
      return build5x5TwinIslandSingleAnswer(profile, level, rating);
    case 'cross_plus':
    case 'crown_h_bridge':
    case 'pillar_h_frame':
    case 'chakravyuh_ring':
    case 'pinwheel_star':
    default:
      return build5x5ConvergingHub(profile, level, rating, topology);
  }
}
