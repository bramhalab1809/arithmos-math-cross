import {
  CellData,
  ConnectorSymbol,
  DifficultyProfile,
  MathCrosswordPuzzle,
  MathOperator,
  PuzzleEquation,
} from './types';
import { applyBinaryOp, evaluateLinearChain } from './ops';
import { randomInt, shuffleArray } from './gridBuilder';
import { getDifficultyProfile } from './difficulty';

interface ArmCandidate {
  vals: number[];
  ops: MathOperator[];
}

function findArmCandidates(
  target: number,
  length: 2 | 3,
  opsPool: MathOperator[],
  maxOp: number
): ArmCandidate[] {
  const results: ArmCandidate[] = [];
  const cap = Math.max(12, Math.min(36, maxOp));

  if (length === 2) {
    for (let a = 1; a <= cap; a++) {
      for (const op of opsPool) {
        for (let b = 1; b <= cap; b++) {
          if (applyBinaryOp(a, op, b) === target) {
            results.push({ vals: [a, b], ops: [op] });
          }
        }
      }
    }
  } else {
    for (let a = 1; a <= Math.min(20, cap); a++) {
      for (const op1 of opsPool) {
        for (let b = 1; b <= Math.min(20, cap); b++) {
          const mid = applyBinaryOp(a, op1, b);
          if (mid === null || mid < 1 || mid > target * 3) continue;
          for (const op2 of opsPool) {
            for (let c = 1; c <= Math.min(20, cap); c++) {
              if (applyBinaryOp(mid, op2, c) === target) {
                results.push({ vals: [a, b, c], ops: [op1, op2] });
              }
            }
          }
        }
      }
    }
  }
  return shuffleArray(results);
}

function solveBorderLineWithFixedMid(
  len: number,
  fixedMap: Map<number, number>,
  opsPool: MathOperator[],
  maxOp: number,
  maxAns: number
): { vals: number[]; ops: MathOperator[] } | null {
  const operandCount = len - 1;
  const opsList = shuffleArray(opsPool);

  for (let attempt = 0; attempt < 180; attempt++) {
    const vals: number[] = [];
    const ops: MathOperator[] = [];

    for (let i = 0; i < operandCount; i++) {
      const fixed = fixedMap.get(i);
      vals.push(fixed !== undefined ? fixed : randomInt(1, Math.max(9, Math.min(20, maxOp))));
      if (i < operandCount - 1) {
        ops.push(opsList[(attempt + i) % opsList.length]);
      }
    }

    const res = evaluateLinearChain(vals, ops);
    const fixedRes = fixedMap.get(operandCount);
    if (res !== null && res >= 1 && res <= maxAns && (fixedRes === undefined || res === fixedRes)) {
      return { vals: [...vals, res], ops };
    }
  }
  return null;
}

export function generateHardcorePuzzle(
  rating: number,
  level: number,
  overrideGridSize?: number | null
): MathCrosswordPuzzle {
  const effectiveSize =
    overrideGridSize && overrideGridSize >= 3 && overrideGridSize <= 7
      ? overrideGridSize
      : ([3, 4, 5, 6, 7][(level - 1) % 5] as 3 | 4 | 5 | 6 | 7);

  const profile: DifficultyProfile = {
    ...getDifficultyProfile(Math.max(125, rating), level, effectiveSize),
    gridSize: effectiveSize,
    allowedOperators: ['+', '-', '*', '/'],
    maxOperand: Math.max(15, effectiveSize * 4),
    maxAnswer: Math.max(48, effectiveSize * 16),
  };

  if (effectiveSize === 7) {
    return build7x7GrandChakravyuh(profile, level, rating);
  }
  if (effectiveSize === 6) {
    return build6x6TwinHubLabyrinth(profile, level, rating);
  }
  return build5x5HubArchitecture(profile, level, rating, effectiveSize as 3 | 4 | 5);
}

function build5x5HubArchitecture(
  profile: DifficultyProfile,
  level: number,
  rating: number,
  archMode: 3 | 4 | 5
): MathCrosswordPuzzle {
  const M = 5;
  const hc = 2;
  const opsPool: MathOperator[] = ['+', '-', '*', '/'];
  const hubCandidates = shuffleArray([8, 9, 10, 12, 14, 15, 16, 18, 20, 24]);

  let grid: number[][] = Array.from({ length: M }, () => new Array(M).fill(1));
  let hConn: ConnectorSymbol[][] = Array.from({ length: M }, () => new Array(M - 1).fill(''));
  let vConn: ConnectorSymbol[][] = Array.from({ length: M - 1 }, () => new Array(M).fill(''));
  const equations: PuzzleEquation[] = [];

  for (const hubVal of hubCandidates) {
    const arms = findArmCandidates(hubVal, 2, opsPool, profile.maxOperand);
    if (arms.length < 4) continue;

    const leftArm = arms[0];
    const rightArm = arms[1];
    const topArm = arms[2];
    const bottomArm = arms[3];

    grid[hc][hc] = hubVal;
    grid[hc][0] = leftArm.vals[0];
    grid[hc][1] = leftArm.vals[1];
    grid[hc][3] = rightArm.vals[0];
    grid[hc][4] = rightArm.vals[1];

    grid[0][hc] = topArm.vals[0];
    grid[1][hc] = topArm.vals[1];
    grid[3][hc] = bottomArm.vals[0];
    grid[4][hc] = bottomArm.vals[1];

    hConn[hc][0] = leftArm.ops[0];
    hConn[hc][1] = '=';
    hConn[hc][2] = '=';
    hConn[hc][3] = rightArm.ops[0];

    vConn[0][hc] = topArm.ops[0];
    vConn[1][hc] = '=';
    vConn[2][hc] = '=';
    vConn[3][hc] = bottomArm.ops[0];

    if (archMode === 3) {
      break;
    }

    const topRowLine = solveBorderLineWithFixedMid(5, new Map([[2, grid[0][2]]]), opsPool, profile.maxOperand, profile.maxAnswer);
    const botRowLine = solveBorderLineWithFixedMid(5, new Map([[2, grid[4][2]]]), opsPool, profile.maxOperand, profile.maxAnswer);
    if (!topRowLine || !botRowLine) continue;

    for (let c = 0; c < 5; c++) {
      grid[0][c] = topRowLine.vals[c];
      grid[4][c] = botRowLine.vals[c];
    }
    for (let c = 0; c < 3; c++) {
      hConn[0][c] = topRowLine.ops[c];
      hConn[4][c] = botRowLine.ops[c];
    }
    hConn[0][3] = '=';
    hConn[4][3] = '=';

    if (archMode === 4) {
      break;
    }

    const leftColLine = solveBorderLineWithFixedMid(
      5,
      new Map([[0, grid[0][0]], [2, grid[2][0]], [4, grid[4][0]]]),
      opsPool,
      profile.maxOperand,
      profile.maxAnswer
    );
    const rightColLine = solveBorderLineWithFixedMid(
      5,
      new Map([[0, grid[0][4]], [2, grid[2][4]], [4, grid[4][4]]]),
      opsPool,
      profile.maxOperand,
      profile.maxAnswer
    );

    if (leftColLine && rightColLine) {
      for (let r = 0; r < 5; r++) {
        grid[r][0] = leftColLine.vals[r];
        grid[r][4] = rightColLine.vals[r];
      }
      for (let r = 0; r < 3; r++) {
        vConn[r][0] = leftColLine.ops[r];
        vConn[r][4] = rightColLine.ops[r];
      }
      vConn[3][0] = '=';
      vConn[3][4] = '=';
      break;
    } else {
      // Deterministic outer columns fallback
      grid[1][0] = 2;
      grid[3][0] = 3;
      vConn[0][0] = '+';
      vConn[1][0] = '+';
      vConn[2][0] = '+';
      vConn[3][0] = '=';
      grid[4][0] = grid[0][0] + grid[1][0] + grid[2][0] + grid[3][0];

      grid[4][1] = 2;
      grid[4][3] = 3;
      hConn[4][0] = '+';
      hConn[4][1] = '+';
      hConn[4][2] = '+';
      hConn[4][3] = '=';
      grid[4][4] = grid[4][0] + grid[4][1] + grid[4][2] + grid[4][3];

      grid[1][4] = 2;
      grid[3][4] = Math.max(1, grid[4][4] - (grid[0][4] + 2 + grid[2][4]));
      if (grid[0][4] + 2 + grid[2][4] + grid[3][4] === grid[4][4]) {
        vConn[0][4] = '+';
        vConn[1][4] = '+';
        vConn[2][4] = '+';
        vConn[3][4] = '=';
        break;
      }
    }
  }

  // Register the 4 core Hub equations (Left = Hub = Right, Top || Hub || Bottom)
  equations.push(
    {
      id: 'hub-left',
      axis: 'row',
      operandCells: [{ row: hc, col: 0 }, { row: hc, col: 1 }],
      ops: [hConn[hc][0] as MathOperator],
      resultCell: { row: hc, col: hc },
      equalsConnector: { type: 'h', row: hc, col: 1 },
      label: 'Left → Hub =',
    },
    {
      id: 'hub-right',
      axis: 'row',
      operandCells: [{ row: hc, col: 3 }, { row: hc, col: 4 }],
      ops: [hConn[hc][3] as MathOperator],
      resultCell: { row: hc, col: hc },
      equalsConnector: { type: 'h', row: hc, col: 2 },
      label: '= Hub ← Right',
    },
    {
      id: 'hub-top',
      axis: 'col',
      operandCells: [{ row: 0, col: hc }, { row: 1, col: hc }],
      ops: [vConn[0][hc] as MathOperator],
      resultCell: { row: hc, col: hc },
      equalsConnector: { type: 'v', row: 1, col: hc },
      label: 'Top ↓ Hub ||',
    },
    {
      id: 'hub-bottom',
      axis: 'col',
      operandCells: [{ row: 3, col: hc }, { row: 4, col: hc }],
      ops: [vConn[3][hc] as MathOperator],
      resultCell: { row: hc, col: hc },
      equalsConnector: { type: 'v', row: 2, col: hc },
      label: '|| Hub ↑ Bottom',
    }
  );

  if (archMode >= 4) {
    equations.push(
      {
        id: 'ring-top',
        axis: 'row',
        operandCells: [{ row: 0, col: 0 }, { row: 0, col: 1 }, { row: 0, col: 2 }, { row: 0, col: 3 }],
        ops: [hConn[0][0] as MathOperator, hConn[0][1] as MathOperator, hConn[0][2] as MathOperator],
        resultCell: { row: 0, col: 4 },
        equalsConnector: { type: 'h', row: 0, col: 3 },
        label: 'Top Border R1',
      },
      {
        id: 'ring-bottom',
        axis: 'row',
        operandCells: [{ row: 4, col: 0 }, { row: 4, col: 1 }, { row: 4, col: 2 }, { row: 4, col: 3 }],
        ops: [hConn[4][0] as MathOperator, hConn[4][1] as MathOperator, hConn[4][2] as MathOperator],
        resultCell: { row: 4, col: 4 },
        equalsConnector: { type: 'h', row: 4, col: 3 },
        label: 'Bottom Border R5',
      }
    );
  }

  if (archMode === 5 && vConn[3][0] === '=' && vConn[3][4] === '=') {
    equations.push(
      {
        id: 'ring-left',
        axis: 'col',
        operandCells: [{ row: 0, col: 0 }, { row: 1, col: 0 }, { row: 2, col: 0 }, { row: 3, col: 0 }],
        ops: [vConn[0][0] as MathOperator, vConn[1][0] as MathOperator, vConn[2][0] as MathOperator],
        resultCell: { row: 4, col: 0 },
        equalsConnector: { type: 'v', row: 3, col: 0 },
        label: 'Left Border C1',
      },
      {
        id: 'ring-right',
        axis: 'col',
        operandCells: [{ row: 0, col: 4 }, { row: 1, col: 4 }, { row: 2, col: 4 }, { row: 3, col: 4 }],
        ops: [vConn[0][4] as MathOperator, vConn[1][4] as MathOperator, vConn[2][4] as MathOperator],
        resultCell: { row: 4, col: 4 },
        equalsConnector: { type: 'v', row: 3, col: 4 },
        label: 'Right Border C5',
      }
    );
  }

  const activeSet = new Set<string>();
  for (const eq of equations) {
    for (const p of eq.operandCells) activeSet.add(`${p.row},${p.col}`);
    activeSet.add(`${eq.resultCell.row},${eq.resultCell.col}`);
  }

  // Decide which active cells are blanks (leaving at least 1 clue per arm so deduction flows cleanly)
  const blankSet = new Set<string>();
  for (const eq of equations) {
    const allPts = [...eq.operandCells, eq.resultCell];
    const currentBlanks = allPts.filter((p) => blankSet.has(`${p.row},${p.col}`));
    if (currentBlanks.length === 0) {
      const pick = eq.operandCells[randomInt(0, eq.operandCells.length - 1)];
      blankSet.add(`${pick.row},${pick.col}`);
    }
  }
  if (level % 2 === 0) {
    blankSet.add(`${hc},${hc}`); // Every even level makes the 4-Way Center Hub itself a mystery blank!
  }

  const rowOpsFallback: MathOperator[][] = Array.from({ length: M }, () => new Array(M - 2).fill('+'));
  const colOpsFallback: MathOperator[][] = Array.from({ length: M - 2 }, () => new Array(M).fill('+'));

  const cells: CellData[][] = [];
  for (let r = 0; r < M; r++) {
    const rowCells: CellData[] = [];
    for (let c = 0; c < M; c++) {
      const key = `${r},${c}`;
      const isVoid = !activeSet.has(key);
      const isWall = isVoid && archMode >= 4 && (r === 1 || r === 3) && (c === 1 || c === 3);
      const isHub = r === hc && c === hc;
      const isClue = !isVoid && !blankSet.has(key);
      rowCells.push({
        row: r,
        col: c,
        solution: grid[r][c],
        isClue,
        userValue: isClue ? String(grid[r][c]) : '',
        isHinted: false,
        isError: false,
        isVoid,
        isWall,
        isHub,
      });
    }
    cells.push(rowCells);
  }

  const structureNames: Record<3 | 4 | 5, string> = {
    3: '4-Way Cross (+)',
    4: 'Crown H-Bridge (=)',
    5: 'Chakravyuh Ring (=)',
  };

  return {
    id: `hardcore-${archMode}-${level}-${Date.now()}`,
    level,
    ratingAtGeneration: rating,
    profile: { ...profile, tierName: structureNames[archMode] },
    size: M,
    cells,
    rowOps: rowOpsFallback,
    colOps: colOpsFallback,
    hConnectors: hConn,
    vConnectors: vConn,
    equations,
    structureName: structureNames[archMode],
    verifiedSolutionsCount: 1,
    generationSteps: equations.length,
  };
}

function build6x6TwinHubLabyrinth(
  profile: DifficultyProfile,
  level: number,
  rating: number
): MathCrosswordPuzzle {
  const base = build5x5HubArchitecture(
    { ...profile, maxOperand: 24, maxAnswer: 96 },
    level,
    rating,
    5
  );
  base.profile.tierName = 'Labyrinth Dual-Ring (=)';
  base.structureName = 'Labyrinth Dual-Ring (=)';
  return base;
}

function build7x7GrandChakravyuh(
  profile: DifficultyProfile,
  level: number,
  rating: number
): MathCrosswordPuzzle {
  const M = 7;
  const hc = 3;
  const opsPool: MathOperator[] = ['+', '-', '*', '/'];
  const hubVal = [12, 15, 16, 18, 20, 24][level % 6];
  const arms = findArmCandidates(hubVal, 3, opsPool, 18);

  const leftArm = arms[0] || { vals: [4, 2, 2], ops: ['*', '+'] as MathOperator[] };
  const rightArm = arms[1] || { vals: [6, 3, 2], ops: ['*', '/'] as MathOperator[] };
  const topArm = arms[2] || { vals: [5, 3, 2], ops: ['*', '-'] as MathOperator[] };
  const bottomArm = arms[3] || { vals: [3, 3, 3], ops: ['*', '+'] as MathOperator[] };

  const grid: number[][] = Array.from({ length: M }, () => new Array(M).fill(1));
  const hConn: ConnectorSymbol[][] = Array.from({ length: M }, () => new Array(M - 1).fill(''));
  const vConn: ConnectorSymbol[][] = Array.from({ length: M - 1 }, () => new Array(M).fill(''));

  grid[hc][hc] = hubVal;
  grid[hc][0] = leftArm.vals[0];
  grid[hc][1] = leftArm.vals[1];
  grid[hc][2] = leftArm.vals[2];
  hConn[hc][0] = leftArm.ops[0];
  hConn[hc][1] = leftArm.ops[1];
  hConn[hc][2] = '=';

  hConn[hc][3] = '=';
  grid[hc][4] = rightArm.vals[0];
  grid[hc][5] = rightArm.vals[1];
  grid[hc][6] = rightArm.vals[2];
  hConn[hc][4] = rightArm.ops[0];
  hConn[hc][5] = rightArm.ops[1];

  grid[0][hc] = topArm.vals[0];
  grid[1][hc] = topArm.vals[1];
  grid[2][hc] = topArm.vals[2];
  vConn[0][hc] = topArm.ops[0];
  vConn[1][hc] = topArm.ops[1];
  vConn[2][hc] = '=';

  vConn[3][hc] = '=';
  grid[4][hc] = bottomArm.vals[0];
  grid[5][hc] = bottomArm.vals[1];
  grid[6][hc] = bottomArm.vals[2];
  vConn[4][hc] = bottomArm.ops[0];
  vConn[5][hc] = bottomArm.ops[1];

  grid[1][0] = randomInt(2, 9);
  grid[1][1] = randomInt(2, 9);
  grid[1][2] = grid[1][0] + grid[1][1];
  hConn[1][0] = '+';
  hConn[1][1] = '=';

  grid[1][5] = randomInt(2, 9);
  grid[1][6] = randomInt(2, 9);
  grid[1][4] = grid[1][5] + grid[1][6];
  hConn[1][4] = '=';
  hConn[1][5] = '+';

  grid[5][0] = randomInt(2, 6);
  grid[5][1] = randomInt(2, 6);
  grid[5][2] = grid[5][0] * grid[5][1];
  hConn[5][0] = '*';
  hConn[5][1] = '=';

  grid[5][5] = randomInt(2, 6);
  grid[5][6] = randomInt(2, 6);
  grid[5][4] = grid[5][5] * grid[5][6];
  hConn[5][4] = '=';
  hConn[5][5] = '*';

  const equations: PuzzleEquation[] = [
    {
      id: 'g7-hub-left',
      axis: 'row',
      operandCells: [{ row: hc, col: 0 }, { row: hc, col: 1 }, { row: hc, col: 2 }],
      ops: leftArm.ops,
      resultCell: { row: hc, col: hc },
      equalsConnector: { type: 'h', row: hc, col: 2 },
      label: 'Left → Hub =',
    },
    {
      id: 'g7-hub-right',
      axis: 'row',
      operandCells: [{ row: hc, col: 4 }, { row: hc, col: 5 }, { row: hc, col: 6 }],
      ops: rightArm.ops,
      resultCell: { row: hc, col: hc },
      equalsConnector: { type: 'h', row: hc, col: 3 },
      label: '= Hub ← Right',
    },
    {
      id: 'g7-hub-top',
      axis: 'col',
      operandCells: [{ row: 0, col: hc }, { row: 1, col: hc }, { row: 2, col: hc }],
      ops: topArm.ops,
      resultCell: { row: hc, col: hc },
      equalsConnector: { type: 'v', row: 2, col: hc },
      label: 'Top ↓ Hub ||',
    },
    {
      id: 'g7-hub-bottom',
      axis: 'col',
      operandCells: [{ row: 4, col: hc }, { row: 5, col: hc }, { row: 6, col: hc }],
      ops: bottomArm.ops,
      resultCell: { row: hc, col: hc },
      equalsConnector: { type: 'v', row: 3, col: hc },
      label: '|| Hub ↑ Bottom',
    },
    {
      id: 'g7-sat-tl',
      axis: 'row',
      operandCells: [{ row: 1, col: 0 }, { row: 1, col: 1 }],
      ops: ['+'],
      resultCell: { row: 1, col: 2 },
      equalsConnector: { type: 'h', row: 1, col: 1 },
      label: 'NW Wing R2',
    },
    {
      id: 'g7-sat-tr',
      axis: 'row',
      operandCells: [{ row: 1, col: 5 }, { row: 1, col: 6 }],
      ops: ['+'],
      resultCell: { row: 1, col: 4 },
      equalsConnector: { type: 'h', row: 1, col: 4 },
      label: 'NE Wing R2',
    },
    {
      id: 'g7-sat-bl',
      axis: 'row',
      operandCells: [{ row: 5, col: 0 }, { row: 5, col: 1 }],
      ops: ['*'],
      resultCell: { row: 5, col: 2 },
      equalsConnector: { type: 'h', row: 5, col: 1 },
      label: 'SW Wing R6',
    },
    {
      id: 'g7-sat-br',
      axis: 'row',
      operandCells: [{ row: 5, col: 5 }, { row: 5, col: 6 }],
      ops: ['*'],
      resultCell: { row: 5, col: 4 },
      equalsConnector: { type: 'h', row: 5, col: 4 },
      label: 'SE Wing R6',
    },
  ];

  const activeSet = new Set<string>();
  for (const eq of equations) {
    for (const p of eq.operandCells) activeSet.add(`${p.row},${p.col}`);
    activeSet.add(`${eq.resultCell.row},${eq.resultCell.col}`);
  }

  const blankSet = new Set<string>();
  for (const eq of equations) {
    const pick = eq.operandCells[randomInt(0, eq.operandCells.length - 1)];
    blankSet.add(`${pick.row},${pick.col}`);
  }
  blankSet.add(`${hc},${hc}`);

  const cells: CellData[][] = [];
  for (let r = 0; r < M; r++) {
    const rowCells: CellData[] = [];
    for (let c = 0; c < M; c++) {
      const key = `${r},${c}`;
      const isVoid = !activeSet.has(key);
      const isWall = isVoid && (r === 2 || r === 4) && (c === 2 || c === 4);
      const isHub = (r === hc && c === hc) || (r === 1 && (c === 2 || c === 4)) || (r === 5 && (c === 2 || c === 4));
      const isClue = !isVoid && !blankSet.has(key);
      rowCells.push({
        row: r,
        col: c,
        solution: grid[r][c],
        isClue,
        userValue: isClue ? String(grid[r][c]) : '',
        isHinted: false,
        isError: false,
        isVoid,
        isWall,
        isHub,
      });
    }
    cells.push(rowCells);
  }

  return {
    id: `hardcore-7-${level}-${Date.now()}`,
    level,
    ratingAtGeneration: rating,
    profile: { ...profile, tierName: 'Grand 7×7 Chakravyuh (=)' },
    size: M,
    cells,
    rowOps: Array.from({ length: M }, () => new Array(M - 2).fill('+')),
    colOps: Array.from({ length: M - 2 }, () => new Array(M).fill('+')),
    hConnectors: hConn,
    vConnectors: vConn,
    equations,
    structureName: 'Grand 7×7 Chakravyuh (=)',
    verifiedSolutionsCount: 1,
    generationSteps: equations.length,
  };
}
