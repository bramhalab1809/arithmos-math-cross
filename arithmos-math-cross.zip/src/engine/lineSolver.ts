import { MathOperator } from './types';
import { evaluateLinearChain } from './ops';

/**
 * Given an equation of length N (N-1 operands + 1 result at index N-1)
 * where EXACTLY ONE position `unknownIdx` is null and all other N-1 positions are positive integers,
 * algebraically computes the unique positive integer value for `unknownIdx` under strict linear left-to-right rules.
 * Returns null if no positive integer can satisfy the equation.
 */
export function solveSingleUnknownInLine(
  lineValues: (number | null)[],
  ops: MathOperator[]
): number | null {
  const n = lineValues.length;
  let unknownIdx = -1;
  let unknownCount = 0;

  for (let i = 0; i < n; i++) {
    if (lineValues[i] === null) {
      unknownIdx = i;
      unknownCount++;
      if (unknownCount > 1) return null;
    }
  }

  if (unknownCount !== 1) return null;

  // Case 1: The unknown is the result cell at n - 1
  if (unknownIdx === n - 1) {
    const operands = lineValues.slice(0, n - 1) as number[];
    return evaluateLinearChain(operands, ops);
  }

  // Case 2: The unknown is an operand at index u in 0 .. n - 2
  const targetResult = lineValues[n - 1];
  if (targetResult === null || targetResult < 1) return null;

  // Peel known operands from the right (from index n - 2 down to unknownIdx + 1)
  let requiredPrefix = targetResult;
  for (let i = n - 2; i > unknownIdx; i--) {
    const rightVal = lineValues[i]!;
    const op = ops[i - 1];
    // We have: (prevPrefix) op rightVal = requiredPrefix
    switch (op) {
      case '+':
        requiredPrefix = requiredPrefix - rightVal;
        break;
      case '-':
        requiredPrefix = requiredPrefix + rightVal;
        break;
      case '*':
        if (rightVal <= 0 || requiredPrefix % rightVal !== 0) return null;
        requiredPrefix = requiredPrefix / rightVal;
        break;
      case '/':
        requiredPrefix = requiredPrefix * rightVal;
        break;
    }
    if (!Number.isInteger(requiredPrefix) || requiredPrefix < 1) return null;
  }

  // Now the prefix chain [0 .. unknownIdx] must evaluate to `requiredPrefix`
  let candidate: number | null = null;
  if (unknownIdx === 0) {
    candidate = requiredPrefix;
  } else {
    const knownPrefixOperands = lineValues.slice(0, unknownIdx) as number[];
    const knownPrefixOps = ops.slice(0, unknownIdx - 1);
    const leftAcc = evaluateLinearChain(knownPrefixOperands, knownPrefixOps);
    if (leftAcc === null) return null;

    const op = ops[unknownIdx - 1];
    // We have: leftAcc op candidate = requiredPrefix
    switch (op) {
      case '+':
        candidate = requiredPrefix - leftAcc;
        break;
      case '-':
        candidate = leftAcc - requiredPrefix;
        break;
      case '*':
        if (leftAcc <= 0 || requiredPrefix % leftAcc !== 0) return null;
        candidate = requiredPrefix / leftAcc;
        break;
      case '/':
        if (requiredPrefix <= 0 || leftAcc % requiredPrefix !== 0) return null;
        candidate = leftAcc / requiredPrefix;
        break;
    }
  }

  if (candidate === null || !Number.isInteger(candidate) || candidate < 1) {
    return null;
  }

  // Final forward check to verify exactness
  const verifyOperands: number[] = [];
  for (let i = 0; i < n - 1; i++) {
    verifyOperands.push(i === unknownIdx ? candidate : (lineValues[i] as number));
  }
  const actualResult = evaluateLinearChain(verifyOperands, ops);
  if (actualResult !== targetResult) return null;

  return candidate;
}

/**
 * Checks whether a complete line of numbers satisfies its equation.
 */
export function isCompleteLineValid(values: number[], ops: MathOperator[]): boolean {
  if (!values || !ops || !Array.isArray(ops) || values.length < 3) return false;
  const operands = values.slice(0, values.length - 1);
  const expectedResult = values[values.length - 1];
  const actual = evaluateLinearChain(operands, ops);
  return actual !== null && actual === expectedResult;
}
