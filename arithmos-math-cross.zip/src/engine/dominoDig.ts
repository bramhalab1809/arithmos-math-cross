import { CellData, DifficultyProfile, MathCrosswordPuzzle, MathOperator } from './types';
import { generateValidGridSolution, randomInt, shuffleArray } from './gridBuilder';
import { generateDeterministicFallbackGrid } from './generator';
import { countFirstMoves, isDominoSolvableGrid } from './flow';

export interface DominoPuzzleOptions {
  blanksScale?: number;
  level?: number;
  rating?: number;
  easeApplied?: boolean;
  relief?: boolean;
}

/**
 * Generates a puzzle whose solution is provably reachable through single-unknown line eliminations alone.
 * Capped at 2N - 1 blanks.
 */
export function generateDominoPuzzle(
  profile: DifficultyProfile,
  options?: DominoPuzzleOptions
): MathCrosswordPuzzle {
  const N = profile.gridSize;
  const level = options?.level ?? 1;
  const rating = options?.rating ?? 100;
  const requested = Math.max(3, Math.round(profile.targetBlanks * (options?.blanksScale ?? 1)));
  const targetBlanks = level === 1 && N === 3 ? 4 : Math.min(requested, 2 * N - 1);

  let bestGrid: number[][] = [];
  let bestRowOps: MathOperator[][] = [];
  let bestColOps: MathOperator[][] = [];
  let bestBoardState: (number | null)[][] = [];
  let bestBlanks = 0;

  for (let attempt = 0; attempt < 5; attempt++) {
    let solved: { grid: number[][]; rowOps: MathOperator[][]; colOps: MathOperator[][] } | null = null;
    for (let trySolve = 0; trySolve < 50; trySolve++) {
      solved = generateValidGridSolution(profile);
      if (solved) break;
    }
    if (!solved) solved = generateDeterministicFallbackGrid(profile);

    const { grid, rowOps, colOps } = solved;
    const boardState: (number | null)[][] = grid.map((r) => [...r]);

    const coords: [number, number][] = [];
    for (let r = 0; r < N; r++) {
      for (let c = 0; c < N; c++) coords.push([r, c]);
    }
    const shuffledCoords = shuffleArray(coords);

    // Guarantee onboarding cell (0, 1) is tried first on level 1 (3x3)
    if (level === 1 && N === 3) {
      const idx = shuffledCoords.findIndex(([r, c]) => r === 0 && c === 1);
      if (idx > 0) {
        const [item] = shuffledCoords.splice(idx, 1);
        shuffledCoords.unshift(item);
      }
    }

    let blanks = 0;
    for (const [r, c] of shuffledCoords) {
      if (blanks >= targetBlanks) break;
      const backup = boardState[r][c];
      boardState[r][c] = null;
      if (isDominoSolvableGrid(boardState, rowOps, colOps)) {
        blanks++;
      } else {
        boardState[r][c] = backup;
      }
    }

    if (blanks > bestBlanks || attempt === 0) {
      bestGrid = grid;
      bestRowOps = rowOps;
      bestColOps = colOps;
      bestBoardState = boardState;
      bestBlanks = blanks;
    }

    if (bestBlanks >= targetBlanks) break;
  }

  const cells: CellData[][] = [];
  for (let r = 0; r < N; r++) {
    const rowCells: CellData[] = [];
    for (let c = 0; c < N; c++) {
      const isClue = bestBoardState[r][c] !== null;
      rowCells.push({
        row: r,
        col: c,
        solution: bestGrid[r][c],
        isClue,
        userValue: isClue ? String(bestGrid[r][c]) : '',
        isHinted: false,
        isError: false,
      });
    }
    cells.push(rowCells);
  }

  const puzzle: MathCrosswordPuzzle = {
    id: `puzzle-${level}-${Date.now()}-${randomInt(100, 999)}`,
    level,
    ratingAtGeneration: rating,
    profile,
    size: N,
    cells,
    rowOps: bestRowOps,
    colOps: bestColOps,
    verifiedSolutionsCount: 1,
    generationSteps: bestBlanks,
    flow: {
      firstMoves: 0,
      domino: true,
      relief: Boolean(options?.relief),
      easeApplied: Boolean(options?.easeApplied),
      paced: rating,
    },
  };
  puzzle.flow!.firstMoves = countFirstMoves(puzzle);
  return puzzle;
}
