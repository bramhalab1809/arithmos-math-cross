import { lerpRound } from './rampMath';

/**
 * Piecewise-linear rating ceiling for a given level:
 * (1, 100), (6, 140), (15, 200), (30, 270), (50, 350), (70, 450)
 * Above level 70: +5 rating per level.
 */
export function levelCeilingRating(level: number): number {
  if (level <= 1) return 100;
  if (level <= 6) return lerpRound(100, 140, (level - 1) / (6 - 1));
  if (level <= 15) return lerpRound(140, 200, (level - 6) / (15 - 6));
  if (level <= 30) return lerpRound(200, 270, (level - 15) / (30 - 15));
  if (level <= 50) return lerpRound(270, 350, (level - 30) / (50 - 30));
  if (level <= 70) return lerpRound(350, 450, (level - 50) / (70 - 50));
  return 450 + 5 * (level - 70);
}

/**
 * Bounds adaptive difficulty progression to the player's level schedule.
 */
export function getPacedRating(rating: number, level: number): number {
  return Math.min(rating, levelCeilingRating(level));
}

/**
 * Breather/relief levels: level 4 and every multiple of 5 starting from 10.
 */
export function isReliefLevel(level: number): boolean {
  return level === 4 || (level >= 10 && level % 5 === 0);
}

/**
 * Scales positive rating gain deltas by 0.4 (rounded). Zero and negative unchanged.
 */
export function scaleRatingGain(delta: number): number {
  if (delta <= 0) return delta;
  return Math.round(delta * 0.4);
}
