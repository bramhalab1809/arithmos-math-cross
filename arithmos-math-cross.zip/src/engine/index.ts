export type {
  MathOperator,
  ConnectorSymbol,
  DifficultyProfile,
  CellData,
  PuzzleEquation,
  MathCrosswordPuzzle,
  PuzzleFlowMetadata,
  LogicalDeductionHint,
  RatingAdjustmentResult,
} from './types';

export {
  applyBinaryOp,
  evaluateLinearChain,
  formatLinearEquationString,
} from './ops';

export {
  solveSingleUnknownInLine,
  isCompleteLineValid,
} from './lineSolver';

export {
  getPuzzleEquations,
  getCellNumericValue,
  getRequiredValueForCellInEquation,
  isCellAwaitingMoreDigits,
  evaluateEquationStatus,
  formatPuzzleEquationPreview,
} from './equations';

export { generateHardcorePuzzle } from './hardcoreGenerator';

export { countPuzzleSolutions } from './uniqueness';

export { getDifficultyProfile } from './difficulty';

export type { GeneratePuzzleOptions } from './generator';
export {
  randomInt,
  shuffleArray,
  generateValidGridSolution,
  generateDeterministicFallbackGrid,
  generateMathCrossword,
} from './generator';

export { generatePuzzleAsync } from './generateAsync';

export { findLogicalDeductionHint } from './hints';

export {
  calculateRatingAdjustment,
  calculateTimeUpPenalty,
} from './rating';

export { calculatePuzzleTimeLimit } from './timeLimit';

export {
  getCellMaxValue,
  getOperandCap,
  isValueInDomain,
} from './valueDomain';

export type {
  StarCalculationInput,
  StarCalculationResult,
} from './stars';

export { calculateStars, scaleRatingDelta } from './stars';

export {
  levelCeilingRating,
  getPacedRating,
  isReliefLevel,
  scaleRatingGain,
} from './pacing';

export {
  countFirstMoves,
  isDominoSolvable,
  isDominoSolvableGrid,
  findBestStartCell,
} from './flow';

export { generateDominoPuzzle } from './dominoDig';
