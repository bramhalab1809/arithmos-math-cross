export interface StarCalculationInput {
  hintsUsed: number;
  mistakes: number;
  elapsedSeconds: number;
  timeLimitSeconds: number;
  calculatorUses?: number;
}

export interface StarCalculationResult {
  stars: 1 | 2 | 3;
  reason: string;
}

/**
 * Calculates star scoring for Star Mode:
 * - 3 stars: No hints, <= 1 mistake, completed in <= 60% of time limit, 0 calculator uses
 * - 2 stars: <= 1 hint, <= 3 mistakes, completed in <= 85% of time limit, <= 1 calculator use
 * - 1 star: Any other completed solve
 */
export function calculateStars(
  input: StarCalculationInput
): StarCalculationResult {
  const { hintsUsed, mistakes, elapsedSeconds, timeLimitSeconds, calculatorUses = 0 } = input;
  const safeTimeLimit = Math.max(1, timeLimitSeconds);

  const isThreeStarBase = hintsUsed === 0 && mistakes <= 1 && elapsedSeconds <= 0.6 * safeTimeLimit;
  if (isThreeStarBase && calculatorUses === 0) {
    return {
      stars: 3,
      reason: 'Flawless solve: under 60% time, no hints, max 1 mistake',
    };
  }

  const isTwoStarBase = hintsUsed <= 1 && mistakes <= 3 && elapsedSeconds <= 0.85 * safeTimeLimit;
  if ((isThreeStarBase || isTwoStarBase) && calculatorUses <= 1) {
    const calcNote = isThreeStarBase && calculatorUses > 0 ? ' (calculator used)' : '';
    return {
      stars: 2,
      reason: `Strong solve: under 85% time, max 1 hint, max 3 mistakes${calcNote}`,
    };
  }

  const loweredByCalc = (isThreeStarBase || isTwoStarBase) && calculatorUses > 1;
  return {
    stars: 1,
    reason: loweredByCalc
      ? 'Solved within time limit (calculator used)'
      : 'Solved: completed within the time limit',
  };
}

/**
 * Scales the rating adjustment delta based on star performance in Star mode.
 */
export function scaleRatingDelta(delta: number, stars: 1 | 2 | 3): number {
  if (delta <= 0) return delta;
  if (stars === 3) return Math.round(delta * 1.25);
  if (stars === 2) return Math.round(delta * 1.0);
  return Math.round(delta * 0.75);
}
