import { MathCrosswordPuzzle, MathOperator, PuzzleEquation } from './types';
import { evaluateLinearChain, formatLinearEquationString } from './ops';
import { solveSingleUnknownInLine } from './lineSolver';

export function getPuzzleEquations(puzzle: MathCrosswordPuzzle): PuzzleEquation[] {
  if (puzzle.equations && puzzle.equations.length > 0) {
    return puzzle.equations;
  }

  const N = puzzle.size;
  const eqs: PuzzleEquation[] = [];

  for (let r = 0; r < N; r++) {
    const operandCells = Array.from({ length: N - 1 }, (_, c) => ({ row: r, col: c }));
    const ops = puzzle.rowOps[r] || [];
    eqs.push({
      id: `row-${r}`,
      axis: 'row',
      operandCells,
      ops,
      resultCell: { row: r, col: N - 1 },
      equalsConnector: { type: 'h', row: r, col: N - 2 },
      label: `R${r + 1}`,
    });
  }

  for (let c = 0; c < N; c++) {
    const operandCells = Array.from({ length: N - 1 }, (_, r) => ({ row: r, col: c }));
    const ops: MathOperator[] = [];
    for (let r = 0; r < N - 2; r++) {
      ops.push(puzzle.colOps?.[r]?.[c] ?? '+');
    }
    eqs.push({
      id: `col-${c}`,
      axis: 'col',
      operandCells,
      ops,
      resultCell: { row: N - 1, col: c },
      equalsConnector: { type: 'v', row: N - 2, col: c },
      label: `C${c + 1}`,
    });
  }

  return eqs;
}

export function getCellNumericValue(puzzle: MathCrosswordPuzzle, row: number, col: number): number | null {
  const cell = puzzle.cells[row]?.[col];
  if (!cell || cell.isVoid) return null;
  if (cell.isClue) return cell.solution;
  const trimmed = cell.userValue.trim();
  if (trimmed === '') return null;
  const parsed = parseInt(trimmed, 10);
  return Number.isInteger(parsed) && parsed >= 1 ? parsed : null;
}

/**
 * Computes the algebraically required positive integer for (row, col) in a given equation
 * if all other cells in that equation are currently filled.
 */
export function getRequiredValueForCellInEquation(
  puzzle: MathCrosswordPuzzle,
  eq: PuzzleEquation,
  row: number,
  col: number
): number | null {
  const allPositions = [...eq.operandCells, eq.resultCell];
  const idx = allPositions.findIndex((p) => p.row === row && p.col === col);
  if (idx === -1) return null;

  const lineValues: (number | null)[] = allPositions.map((p, i) => {
    if (i === idx) return null;
    return getCellNumericValue(puzzle, p.row, p.col);
  });

  if (lineValues.some((v, i) => i !== idx && v === null)) {
    return null;
  }

  return solveSingleUnknownInLine(lineValues, eq.ops);
}

/**
 * Returns true if the user has typed 1 (or 2) digits into (row, col) and the cell is
 * still awaiting additional digits to reach its multi-digit target (e.g. typing '1' on the way to '12').
 */
export function isCellAwaitingMoreDigits(
  puzzle: MathCrosswordPuzzle,
  row: number,
  col: number
): boolean {
  const cell = puzzle.cells[row]?.[col];
  if (!cell || cell.isVoid || cell.isClue || cell.isHinted) return false;
  const trimmed = cell.userValue.trim();
  if (trimmed === '' || trimmed.length >= 3) return false;

  const solStr = String(cell.solution);
  if (solStr.length > trimmed.length && solStr.startsWith(trimmed)) {
    return true;
  }

  const eqs = getPuzzleEquations(puzzle);
  for (const eq of eqs) {
    const reqVal = getRequiredValueForCellInEquation(puzzle, eq, row, col);
    if (reqVal !== null) {
      const reqStr = String(reqVal);
      if (reqStr.length > trimmed.length && reqStr.startsWith(trimmed)) {
        return true;
      }
    }
  }

  return false;
}

export function evaluateEquationStatus(
  puzzle: MathCrosswordPuzzle,
  eq: PuzzleEquation
): 'incomplete' | 'valid' | 'invalid' {
  const allPositions = [...eq.operandCells, eq.resultCell];
  for (const pos of allPositions) {
    const val = getCellNumericValue(puzzle, pos.row, pos.col);
    if (val === null) return 'incomplete';
    if (isCellAwaitingMoreDigits(puzzle, pos.row, pos.col)) {
      return 'incomplete';
    }
  }

  const operandVals = eq.operandCells.map((p) => getCellNumericValue(puzzle, p.row, p.col)!);
  const resultVal = getCellNumericValue(puzzle, eq.resultCell.row, eq.resultCell.col)!;
  const actual = evaluateLinearChain(operandVals, eq.ops);
  return actual !== null && actual === resultVal ? 'valid' : 'invalid';
}

export function formatPuzzleEquationPreview(
  puzzle: MathCrosswordPuzzle,
  eq: PuzzleEquation
): string {
  const opTokens = eq.operandCells.map((p) => {
    const c = puzzle.cells[p.row]?.[p.col];
    if (!c) return '?';
    return c.isClue ? c.solution : c.userValue.trim() || '?';
  });
  const resCell = puzzle.cells[eq.resultCell.row]?.[eq.resultCell.col];
  const resToken = !resCell ? '?' : resCell.isClue ? resCell.solution : resCell.userValue.trim() || '?';

  const equalsRightOfResult =
    (eq.equalsConnector.type === 'h' && eq.equalsConnector.col === eq.resultCell.col) ||
    (eq.equalsConnector.type === 'v' && eq.equalsConnector.row === eq.resultCell.row);

  if (equalsRightOfResult) {
    const rhsChain = formatLinearEquationString([...opTokens, resToken], eq.ops).split(' = ')[0];
    return `${resToken} = ${rhsChain}`;
  }
  return formatLinearEquationString([...opTokens, resToken], eq.ops);
}
