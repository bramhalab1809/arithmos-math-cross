import { MathOperator } from './types';

/**
 * Applies a single binary operation with strict integer arithmetic validation.
 * Returns null if division is not exact or if result <= 0.
 */
export function applyBinaryOp(a: number, op: MathOperator, b: number): number | null {
  if (!Number.isFinite(a) || !Number.isFinite(b) || b <= 0 || a <= 0) return null;
  switch (op) {
    case '+':
      return a + b;
    case '-': {
      const diff = a - b;
      return diff >= 1 ? diff : null;
    }
    case '*':
      return a * b;
    case '/': {
      if (b === 0 || a % b !== 0) return null;
      const quot = a / b;
      return quot >= 1 ? quot : null;
    }
  }
}

/**
 * Evaluates an operand chain strictly left-to-right (or top-to-bottom):
 * (((operands[0] op[0] operands[1]) op[1] operands[2]) ...)
 * Returns null if any intermediate step produces a non-integer or non-positive number.
 */
export function evaluateLinearChain(operands: number[], ops: MathOperator[]): number | null {
  if (operands.length === 0) return null;
  if (ops.length !== operands.length - 1) return null;

  let acc = operands[0];
  if (!Number.isInteger(acc) || acc < 1) return null;

  for (let i = 0; i < ops.length; i++) {
    const nextVal = operands[i + 1];
    if (!Number.isInteger(nextVal) || nextVal < 1) return null;
    const stepResult = applyBinaryOp(acc, ops[i], nextVal);
    if (stepResult === null || !Number.isInteger(stepResult) || stepResult < 1) {
      return null;
    }
    acc = stepResult;
  }

  return acc;
}

/**
 * Formats an equation with explicit left-to-right parenthetical grouping
 * so players can visually inspect the strict linear order of operations.
 */
export function formatLinearEquationString(
  values: (number | string)[],
  ops: MathOperator[]
): string {
  if (values.length < 2) return '';
  const operands = values.slice(0, values.length - 1);
  const result = values[values.length - 1];

  const displayOp = (op: MathOperator) =>
    op === '*' ? '×' : op === '/' ? '÷' : op === '-' ? '−' : '+';

  let expr = `${operands[0]}`;
  for (let i = 0; i < ops.length; i++) {
    const wrapped = i > 0 && ops.length > 1 ? `(${expr})` : expr;
    expr = `${wrapped} ${displayOp(ops[i])} ${operands[i + 1]}`;
  }
  return `${expr} = ${result}`;
}
