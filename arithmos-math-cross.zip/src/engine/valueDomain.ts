import { DifficultyProfile, MathCrosswordPuzzle } from './types';

/**
 * Returns the maximum allowed operand value according to the verified difficulty domain.
 * Exactly 15 for profiles with maxOperand <= 12 and maxAnswer >= 15.
 */
export function getOperandCap(profile: DifficultyProfile): number {
  return Math.min(profile.maxAnswer, Math.max(15, profile.maxOperand));
}

/**
 * Returns the maximum allowed integer value for a crossword cell.
 * Result cells (bottom row and rightmost column) allow up to profile.maxAnswer.
 * Interior operand cells allow up to getOperandCap(profile).
 */
export function getCellMaxValue(
  puzzle: MathCrosswordPuzzle,
  row: number,
  col: number
): number {
  if (row === puzzle.size - 1 || col === puzzle.size - 1) {
    return puzzle.profile.maxAnswer;
  }
  return puzzle.profile.operandCap ?? getOperandCap(puzzle.profile);
}

/**
 * Checks whether an integer value falls within the verified domain for this cell.
 */
export function isValueInDomain(
  puzzle: MathCrosswordPuzzle,
  row: number,
  col: number,
  value: number
): boolean {
  if (!Number.isInteger(value) || value < 1) return false;
  return value <= getCellMaxValue(puzzle, row, col);
}
