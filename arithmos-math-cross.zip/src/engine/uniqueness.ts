import { MathOperator } from './types';
import { isCompleteLineValid, solveSingleUnknownInLine } from './lineSolver';

/**
 * Backtracking solver with constraint propagation (unit-unknown elimination)
 * and bounded step budget to guarantee zero infinite loops.
 * Counts up to `maxSolutions` (default 2) to verify uniqueness (solutions === 1).
 */
export function countPuzzleSolutions(
  initialBoard: (number | null)[][],
  rowOps: MathOperator[][],
  colOps: MathOperator[][],
  maxDomainValue: number,
  maxSolutions = 2,
  maxSteps = 8000,
  operandCap = 15
): { solutions: number; steps: number; timedOut: boolean } {
  const size = initialBoard.length;
  let steps = 0;
  let timedOut = false;

  function cloneBoard(b: (number | null)[][]): (number | null)[][] {
    return b.map((row) => [...row]);
  }

  function getColValues(b: (number | null)[][], c: number): (number | null)[] {
    const arr: (number | null)[] = [];
    for (let r = 0; r < size; r++) arr.push(b[r][c]);
    return arr;
  }

  function getColOpsForCol(c: number): MathOperator[] {
    const arr: MathOperator[] = [];
    for (let r = 0; r < size - 2; r++) arr.push(colOps[r][c]);
    return arr;
  }

  /**
   * Propagates all rows and columns that have 0 or 1 unknowns.
   * Returns false if a contradiction is discovered.
   */
  function propagate(board: (number | null)[][]): boolean {
    let changed = true;
    while (changed) {
      changed = false;
      steps++;
      if (steps > maxSteps) {
        timedOut = true;
        return false;
      }

      // Check rows
      for (let r = 0; r < size; r++) {
        let nulls = 0;
        let nullCol = -1;
        for (let c = 0; c < size; c++) {
          if (board[r][c] === null) {
            nulls++;
            nullCol = c;
          }
        }

        if (nulls === 0) {
          if (!isCompleteLineValid(board[r] as number[], rowOps[r])) {
            return false;
          }
        } else if (nulls === 1) {
          const deduced = solveSingleUnknownInLine(board[r], rowOps[r]);
          if (deduced === null || deduced < 1 || deduced > maxDomainValue) {
            return false;
          }
          board[r][nullCol] = deduced;
          changed = true;
        }
      }

      // Check columns
      for (let c = 0; c < size; c++) {
        let nulls = 0;
        let nullRow = -1;
        for (let r = 0; r < size; r++) {
          if (board[r][c] === null) {
            nulls++;
            nullRow = r;
          }
        }

        const colValues = getColValues(board, c);
        const cOps = getColOpsForCol(c);

        if (nulls === 0) {
          if (!isCompleteLineValid(colValues as number[], cOps)) {
            return false;
          }
        } else if (nulls === 1) {
          const deduced = solveSingleUnknownInLine(colValues, cOps);
          if (deduced === null || deduced < 1 || deduced > maxDomainValue) {
            return false;
          }
          board[nullRow][c] = deduced;
          changed = true;
        }
      }
    }
    return true;
  }

  let solutionsFound = 0;

  function search(board: (number | null)[][]): void {
    if (solutionsFound >= maxSolutions || timedOut) return;

    if (!propagate(board)) return;

    // Find the remaining unknown cell with Minimum Remaining Values (most constrained row+col)
    let bestR = -1;
    let bestC = -1;
    let bestScore = 999;

    const rowUnknowns = new Array(size).fill(0);
    const colUnknowns = new Array(size).fill(0);

    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        if (board[r][c] === null) {
          rowUnknowns[r]++;
          colUnknowns[c]++;
        }
      }
    }

    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        if (board[r][c] === null) {
          const score = Math.min(rowUnknowns[r], colUnknowns[c]) * 10 + (rowUnknowns[r] + colUnknowns[c]);
          if (score < bestScore) {
            bestScore = score;
            bestR = r;
            bestC = c;
          }
        }
      }
    }

    // No unknowns left -> valid complete solution found!
    if (bestR === -1) {
      solutionsFound++;
      return;
    }

    // Branch over candidate integers for (bestR, bestC)
    // Prefer smaller operand range if not in result row/col
    const isResultSlot = bestR === size - 1 || bestC === size - 1;
    const upperBound = isResultSlot ? maxDomainValue : Math.min(maxDomainValue, operandCap);

    for (let val = 1; val <= upperBound; val++) {
      if (solutionsFound >= maxSolutions || timedOut) return;
      steps++;
      if (steps > maxSteps) {
        timedOut = true;
        return;
      }

      const nextBoard = cloneBoard(board);
      nextBoard[bestR][bestC] = val;
      search(nextBoard);
    }
  }

  search(cloneBoard(initialBoard));
  return { solutions: solutionsFound, steps, timedOut };
}
