import { DifficultyProfile, MathOperator } from './types';
import { applyBinaryOp, evaluateLinearChain } from './ops';

export function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function shuffleArray<T>(arr: T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

export function generateValidGridSolution(profile: DifficultyProfile): {
  grid: number[][];
  rowOps: MathOperator[][];
  colOps: MathOperator[][];
} | null {
  const N = profile.gridSize;
  const opsPool = profile.allowedOperators;
  const maxOp = profile.maxOperand;
  const maxAns = profile.maxAnswer;

  const grid: number[][] = Array.from({ length: N }, () => new Array(N).fill(1));
  const rowOps: MathOperator[][] = Array.from({ length: N }, () => new Array(N - 2).fill('+'));
  const colOps: MathOperator[][] = Array.from({ length: N - 2 }, () => new Array(N).fill('+'));

  // Track vertical running accumulators for columns 0 .. N-2
  const colAcc: number[] = new Array(N - 1).fill(0);

  // Fill rows 0 .. N-2 and cols 0 .. N-2
  for (let r = 0; r < N - 1; r++) {
    let rowAcc = 0;
    for (let c = 0; c < N - 1; c++) {
      // Leave (N-2, N-2) for intersection matching below
      if (r === N - 2 && c === N - 2) continue;

      const candidates = shuffleArray(
        Array.from({ length: maxOp }, (_, idx) => idx + 1)
      );

      let placed = false;

      if (r === 0 && c === 0) {
        const val = candidates[0];
        grid[0][0] = val;
        rowAcc = val;
        colAcc[0] = val;
        placed = true;
      } else if (r === 0 && c > 0) {
        const shuffledRowOps = shuffleArray(opsPool);
        for (const rOp of shuffledRowOps) {
          for (const val of candidates) {
            const nextRowAcc = applyBinaryOp(rowAcc, rOp, val);
            // Keep intermediate values reasonable so future operations have headroom
            const maxInter = c === N - 2 ? maxAns : Math.max(maxAns, maxOp * 2);
            if (nextRowAcc !== null && nextRowAcc >= 1 && nextRowAcc <= maxInter) {
              grid[0][c] = val;
              rowOps[0][c - 1] = rOp;
              rowAcc = nextRowAcc;
              colAcc[c] = val;
              placed = true;
              break;
            }
          }
          if (placed) break;
        }
      } else if (r > 0 && c === 0) {
        const shuffledColOps = shuffleArray(opsPool);
        for (const cOp of shuffledColOps) {
          for (const val of candidates) {
            const nextColAcc = applyBinaryOp(colAcc[0], cOp, val);
            const maxInter = r === N - 2 ? maxAns : Math.max(maxAns, maxOp * 2);
            if (nextColAcc !== null && nextColAcc >= 1 && nextColAcc <= maxInter) {
              grid[r][0] = val;
              colOps[r - 1][0] = cOp;
              rowAcc = val;
              colAcc[0] = nextColAcc;
              placed = true;
              break;
            }
          }
          if (placed) break;
        }
      } else {
        // Both r > 0 and c > 0
        const shuffledRowOps = shuffleArray(opsPool);
        const shuffledColOps = shuffleArray(opsPool);
        for (const rOp of shuffledRowOps) {
          for (const cOp of shuffledColOps) {
            for (const val of candidates) {
              const nextRowAcc = applyBinaryOp(rowAcc, rOp, val);
              const nextColAcc = applyBinaryOp(colAcc[c], cOp, val);
              const maxRowInter = c === N - 2 ? maxAns : Math.max(maxAns, maxOp * 2);
              const maxColInter = r === N - 2 ? maxAns : Math.max(maxAns, maxOp * 2);
              if (
                nextRowAcc !== null &&
                nextRowAcc >= 1 &&
                nextRowAcc <= maxRowInter &&
                nextColAcc !== null &&
                nextColAcc >= 1 &&
                nextColAcc <= maxColInter
              ) {
                grid[r][c] = val;
                rowOps[r][c - 1] = rOp;
                colOps[r - 1][c] = cOp;
                rowAcc = nextRowAcc;
                colAcc[c] = nextColAcc;
                placed = true;
                break;
              }
            }
            if (placed) break;
          }
          if (placed) break;
        }
      }

      if (!placed) return null;
    }

    if (r < N - 2) {
      grid[r][N - 1] = rowAcc;
    }
  }

  // Finalize column results for cols 0 .. N-3
  for (let c = 0; c < N - 2; c++) {
    grid[N - 1][c] = colAcc[c];
  }

  // Now compute running prefix of bottom row (row N-1) for cols 0 .. N-3
  // and running prefix of rightmost column (col N-1) for rows 0 .. N-3
  // Then pick grid[N-2][N-2] and the remaining operators so they meet at grid[N-1][N-1]!
  const bottomPrefixOpsTries = 12;
  for (let t = 0; t < bottomPrefixOpsTries; t++) {
    // Pick operators for bottom row up to col N-3 and right col up to row N-3
    let bottomAcc = grid[N - 1][0];
    let bottomOk = true;
    for (let c = 1; c < N - 2; c++) {
      const shuffled = shuffleArray(opsPool);
      let stepFound = false;
      for (const op of shuffled) {
        const res = applyBinaryOp(bottomAcc, op, grid[N - 1][c]);
        if (res !== null && res >= 1 && res <= maxAns * 2) {
          rowOps[N - 1][c - 1] = op;
          bottomAcc = res;
          stepFound = true;
          break;
        }
      }
      if (!stepFound) {
        bottomOk = false;
        break;
      }
    }
    if (!bottomOk) continue;

    let rightAcc = grid[0][N - 1];
    let rightOk = true;
    for (let r = 1; r < N - 2; r++) {
      const shuffled = shuffleArray(opsPool);
      let stepFound = false;
      for (const op of shuffled) {
        const res = applyBinaryOp(rightAcc, op, grid[r][N - 1]);
        if (res !== null && res >= 1 && res <= maxAns * 2) {
          colOps[r - 1][N - 1] = op;
          rightAcc = res;
          stepFound = true;
          break;
        }
      }
      if (!stepFound) {
        rightOk = false;
        break;
      }
    }
    if (!rightOk) continue;

    // Prefix of row N-2 up to col N-3:
    const rowN2PrefixOperands = grid[N - 2].slice(0, N - 2);
    const rowN2PrefixOps = rowOps[N - 2].slice(0, N - 3);
    const rowN2Acc = evaluateLinearChain(rowN2PrefixOperands, rowN2PrefixOps);
    const colN2Acc = colAcc[N - 2];

    if (rowN2Acc === null) continue;

    // Now test candidate values for grid[N-2][N-2] and operators so that
    // bottom row result === rightmost column result === grid[N-1][N-1] <= maxAns
    const valCandidates = shuffleArray(Array.from({ length: maxOp }, (_, i) => i + 1));
    const shuffledOps1 = shuffleArray(opsPool);
    const shuffledOps2 = shuffleArray(opsPool);

    for (const val of valCandidates) {
      for (const opR of shuffledOps1) {
        const rN2Result = applyBinaryOp(rowN2Acc, opR, val);
        if (rN2Result === null || rN2Result < 1 || rN2Result > maxAns) continue;

        for (const opC of shuffledOps2) {
          const cN2Result = applyBinaryOp(colN2Acc, opC, val);
          if (cN2Result === null || cN2Result < 1 || cN2Result > maxAns) continue;

          // Now check if (bottomAcc [opBottomLast] cN2Result) === (rightAcc [opRightLast] rN2Result)
          for (const opBottomLast of shuffledOps1) {
            const cornerFromRow = applyBinaryOp(bottomAcc, opBottomLast, cN2Result);
            if (cornerFromRow === null || cornerFromRow < 1 || cornerFromRow > maxAns) continue;

            for (const opRightLast of shuffledOps2) {
              const cornerFromCol = applyBinaryOp(rightAcc, opRightLast, rN2Result);
              if (cornerFromCol === cornerFromRow) {
                grid[N - 2][N - 2] = val;
                rowOps[N - 2][N - 3] = opR;
                colOps[N - 3][N - 2] = opC;
                grid[N - 2][N - 1] = rN2Result;
                grid[N - 1][N - 2] = cN2Result;
                rowOps[N - 1][N - 3] = opBottomLast;
                colOps[N - 3][N - 1] = opRightLast;
                grid[N - 1][N - 1] = cornerFromRow;
                return { grid, rowOps, colOps };
              }
            }
          }
        }
      }
    }
  }

  return null;
}
