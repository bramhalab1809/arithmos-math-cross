import { DifficultyProfile, MathOperator } from './types';
import { evaluateLinearChain } from './ops';

const RECENT_CLASSIC_CORNERS_KEY = 'arithmos_recent_classic_corners_v1';
let recentCornersMemory: number[] = [];

function getRecentCorners(): Set<number> {
  if (typeof window !== 'undefined') {
    try {
      const raw = window.localStorage.getItem(RECENT_CLASSIC_CORNERS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) recentCornersMemory = parsed;
      }
    } catch {
      // ignore
    }
  }
  return new Set(recentCornersMemory);
}

export function recordClassicCornerAnswer(val: number): void {
  const list = recentCornersMemory.filter((x) => x !== val);
  list.push(val);
  while (list.length > 24) list.shift();
  recentCornersMemory = list;
  if (typeof window !== 'undefined') {
    try {
      window.localStorage.setItem(RECENT_CLASSIC_CORNERS_KEY, JSON.stringify(list));
    } catch {
      // ignore
    }
  }
}

export function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function shuffleArray<T>(arr: T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

/**
 * Generates a 100% BODMAS-valid N×N Math Crossword grid solution where:
 * - Every row r (0..N-1) satisfies evaluateLinearChain(grid[r][0..N-2], rowOps[r]) === grid[r][N-1]
 * - Every col c (0..N-1) satisfies evaluateLinearChain(grid[0..N-2][c], colOps[0..N-3][c]) === grid[N-1][c]
 * - The bottom-right Master Corner Answer grid[N-1][N-1] does not repeat recent classic puzzles!
 */
export function generateValidGridSolution(profile: DifficultyProfile): {
  grid: number[][];
  rowOps: MathOperator[][];
  colOps: MathOperator[][];
} | null {
  const N = profile.gridSize;
  const opsPool = profile.allowedOperators;
  const maxOp = profile.maxOperand;
  const maxAns = profile.maxAnswer;
  const recentCorners = getRecentCorners();

  const grid: number[][] = Array.from({ length: N }, () => new Array(N).fill(1));
  const rowOps: MathOperator[][] = Array.from({ length: N }, () => new Array(N - 2).fill('+'));
  const colOps: MathOperator[][] = Array.from({ length: N - 2 }, () => new Array(N).fill('+'));

  const evalRowPrefix = (r: number, upToCol: number): number | null => {
    const operands = grid[r].slice(0, upToCol + 1);
    const ops = rowOps[r].slice(0, upToCol);
    return evaluateLinearChain(operands, ops);
  };

  const evalColPrefix = (c: number, upToRow: number): number | null => {
    const operands: number[] = [];
    const ops: MathOperator[] = [];
    for (let rr = 0; rr <= upToRow; rr++) {
      operands.push(grid[rr][c]);
      if (rr < upToRow) ops.push(colOps[rr][c]);
    }
    return evaluateLinearChain(operands, ops);
  };

  const usedLineResults = new Set<number>();

  for (let r = 0; r < N - 1; r++) {
    for (let c = 0; c < N - 1; c++) {
      if (r === N - 2 && c === N - 2) continue;

      const candidates = shuffleArray(Array.from({ length: maxOp }, (_, idx) => idx + 1));
      let placed = false;

      if (r === 0 && c === 0) {
        grid[0][0] = candidates[0];
        placed = true;
      } else if (r === 0 && c > 0) {
        const shuffledRowOps = shuffleArray(opsPool);
        for (const rOp of shuffledRowOps) {
          for (const val of candidates) {
            grid[0][c] = val;
            rowOps[0][c - 1] = rOp;
            const res = evalRowPrefix(0, c);
            const maxInter = c === N - 2 ? maxAns : Math.max(maxAns, maxOp * 2);
            if (
              res !== null &&
              res >= 1 &&
              res <= maxInter &&
              (c < N - 2 || !usedLineResults.has(res))
            ) {
              placed = true;
              break;
            }
          }
          if (placed) break;
        }
      } else if (r > 0 && c === 0) {
        const shuffledColOps = shuffleArray(opsPool);
        for (const cOp of shuffledColOps) {
          for (const val of candidates) {
            grid[r][0] = val;
            colOps[r - 1][0] = cOp;
            const res = evalColPrefix(0, r);
            const maxInter = r === N - 2 ? maxAns : Math.max(maxAns, maxOp * 2);
            if (
              res !== null &&
              res >= 1 &&
              res <= maxInter &&
              (r < N - 2 || !usedLineResults.has(res))
            ) {
              placed = true;
              break;
            }
          }
          if (placed) break;
        }
      } else {
        const shuffledRowOps = shuffleArray(opsPool);
        const shuffledColOps = shuffleArray(opsPool);
        for (const rOp of shuffledRowOps) {
          for (const cOp of shuffledColOps) {
            for (const val of candidates) {
              grid[r][c] = val;
              rowOps[r][c - 1] = rOp;
              colOps[r - 1][c] = cOp;
              const rowRes = evalRowPrefix(r, c);
              const colRes = evalColPrefix(c, r);
              const maxRowInter = c === N - 2 ? maxAns : Math.max(maxAns, maxOp * 2);
              const maxColInter = r === N - 2 ? maxAns : Math.max(maxAns, maxOp * 2);
              if (
                rowRes !== null &&
                rowRes >= 1 &&
                rowRes <= maxRowInter &&
                colRes !== null &&
                colRes >= 1 &&
                colRes <= maxColInter
              ) {
                placed = true;
                break;
              }
            }
            if (placed) break;
          }
          if (placed) break;
        }
      }

      if (!placed) return null;
    }

    if (r < N - 2) {
      const finalRowVal = evalRowPrefix(r, N - 2);
      if (finalRowVal === null || finalRowVal < 1 || finalRowVal > maxAns) return null;
      grid[r][N - 1] = finalRowVal;
      usedLineResults.add(finalRowVal);
    }
  }

  for (let c = 0; c < N - 2; c++) {
    const finalColVal = evalColPrefix(c, N - 2);
    if (finalColVal === null || finalColVal < 1 || finalColVal > maxAns) return null;
    grid[N - 1][c] = finalColVal;
    usedLineResults.add(finalColVal);
  }

  // Pick operators for bottom row (0..N-4) and right col (0..N-4), then solve intersection at (N-2, N-2) and corner (N-1, N-1)
  for (let t = 0; t < 18; t++) {
    let prefixesOk = true;
    for (let c = 1; c < N - 2; c++) {
      rowOps[N - 1][c - 1] = shuffleArray(opsPool)[0];
    }
    if (N > 3) {
      const botPref = evalRowPrefix(N - 1, N - 3);
      if (botPref === null || botPref < 1 || botPref > maxAns * 2) prefixesOk = false;
    }

    for (let r = 1; r < N - 2; r++) {
      colOps[r - 1][N - 1] = shuffleArray(opsPool)[0];
    }
    if (N > 3) {
      const rightPref = evalColPrefix(N - 1, N - 3);
      if (rightPref === null || rightPref < 1 || rightPref > maxAns * 2) prefixesOk = false;
    }
    if (!prefixesOk) continue;

    const valCandidates = shuffleArray(Array.from({ length: maxOp }, (_, i) => i + 1));
    const shuffledOps1 = shuffleArray(opsPool);
    const shuffledOps2 = shuffleArray(opsPool);

    for (const val of valCandidates) {
      grid[N - 2][N - 2] = val;
      for (const opR of shuffledOps1) {
        rowOps[N - 2][N - 3] = opR;
        const rN2Result = evalRowPrefix(N - 2, N - 2);
        if (rN2Result === null || rN2Result < 1 || rN2Result > maxAns) continue;
        grid[N - 2][N - 1] = rN2Result;

        for (const opC of shuffledOps2) {
          colOps[N - 3][N - 2] = opC;
          const cN2Result = evalColPrefix(N - 2, N - 2);
          if (cN2Result === null || cN2Result < 1 || cN2Result > maxAns) continue;
          grid[N - 1][N - 2] = cN2Result;

          for (const opBottomLast of shuffledOps1) {
            rowOps[N - 1][N - 3] = opBottomLast;
            const cornerFromRow = evalRowPrefix(N - 1, N - 2);
            if (cornerFromRow === null || cornerFromRow < 1 || cornerFromRow > maxAns) continue;
            if (recentCorners.has(cornerFromRow) && t < 12) continue;

            for (const opRightLast of shuffledOps2) {
              colOps[N - 3][N - 1] = opRightLast;
              const cornerFromCol = evalColPrefix(N - 1, N - 2);
              if (cornerFromCol === cornerFromRow) {
                grid[N - 1][N - 1] = cornerFromRow;
                recordClassicCornerAnswer(cornerFromRow);
                return { grid, rowOps, colOps };
              }
            }
          }
        }
      }
    }
  }

  return null;
}
