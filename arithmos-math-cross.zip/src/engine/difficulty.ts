import { DifficultyProfile, MathOperator } from './types';
import { clamp01, lerpRound, progressInRange } from './rampMath';
import { getOperandCap } from './valueDomain';
import { getPacedRating } from './pacing';

export function applyPostCapGrowth(profile: DifficultyProfile, ratingAboveCap: number): void {
  if (ratingAboveCap <= 0) return;
  const steps = Math.floor(ratingAboveCap / 20);
  profile.maxOperand = Math.min(20, profile.maxOperand + Math.min(8, steps));
  profile.maxAnswer = Math.min(199, profile.maxAnswer + steps * 10);
}

export function getDifficultyProfile(
  rating: number,
  level: number,
  overrideGridSize?: number | null
): DifficultyProfile {
  const isAdaptiveLevel1 = level === 1 && !overrideGridSize;
  const isExplicitGrid = Boolean(overrideGridSize && overrideGridSize >= 3 && overrideGridSize <= 7);
  const effectiveRating = isAdaptiveLevel1
    ? 100
    : isExplicitGrid
    ? Math.max(100, rating)
    : Math.max(100, getPacedRating(rating, level));

  let gridSize = 3;
  let tierName = 'Initiate';
  let allowedOperators: MathOperator[] = ['+', '-'];
  let maxOperand = 6;
  let maxAnswer = 9;
  let targetBlanks = 4;
  let parTimeSeconds = 45;

  if (overrideGridSize && overrideGridSize >= 3 && overrideGridSize <= 7) {
    gridSize = overrideGridSize;
    const t = clamp01((effectiveRating - 100) / 250);

    if (gridSize === 3) {
      tierName = 'Initiate (3×3)';
      allowedOperators = t >= 0.8 ? ['+', '-', '*', '/'] : t >= 0.4 ? ['+', '-', '*'] : ['+', '-'];
      maxOperand = lerpRound(5, 9, t);
      maxAnswer = lerpRound(9, 18, t);
      targetBlanks = lerpRound(3, 5, t);
      parTimeSeconds = lerpRound(0.85 * 45, 45, t);
    } else if (gridSize === 4) {
      tierName = 'Adept (4×4)';
      allowedOperators = t >= 0.5 ? ['+', '-', '*', '/'] : ['+', '-', '*'];
      maxOperand = lerpRound(6, 10, t);
      maxAnswer = lerpRound(18, 36, t);
      targetBlanks = lerpRound(5, 9, t);
      parTimeSeconds = lerpRound(0.85 * 80, 80, t);
    } else if (gridSize === 5) {
      tierName = 'Tactician (5×5)';
      allowedOperators = t >= 0.25 ? ['+', '-', '*', '/'] : ['+', '-', '*'];
      maxOperand = lerpRound(7, 11, t);
      maxAnswer = lerpRound(30, 60, t);
      targetBlanks = lerpRound(8, 13, t);
      parTimeSeconds = lerpRound(0.85 * 130, 130, t);
    } else if (gridSize === 6) {
      tierName = 'Architect (6×6)';
      allowedOperators = t >= 0.25 ? ['+', '-', '*', '/'] : ['+', '-', '*'];
      maxOperand = lerpRound(8, 12, t);
      maxAnswer = lerpRound(45, 90, t);
      targetBlanks = lerpRound(11, 17, t);
      parTimeSeconds = lerpRound(0.85 * 190, 190, t);
    } else {
      tierName = 'Grandmaster (7×7)';
      allowedOperators = t >= 0.25 ? ['+', '-', '*', '/'] : ['+', '-', '*'];
      maxOperand = lerpRound(9, 12, t);
      maxAnswer = lerpRound(60, 120, t);
      targetBlanks = lerpRound(14, 19, t);
      parTimeSeconds = lerpRound(0.85 * 260, 260, t);
    }

    const profile: DifficultyProfile = {
      tierName,
      gridSize,
      allowedOperators,
      minValue: 1,
      maxOperand,
      maxAnswer,
      targetBlanks,
      parTimeSeconds,
      operandCap: 15,
    };

    if (effectiveRating > 350) {
      applyPostCapGrowth(profile, effectiveRating - 350);
    }

    profile.operandCap = getOperandCap(profile);
    return profile;
  }

  // Endless & Star adaptive progression
  if (effectiveRating < 140) {
    const p = progressInRange(effectiveRating, 100, 140);
    gridSize = 3;
    tierName = 'Initiate';
    allowedOperators = ['+', '-'];
    maxOperand = 6;
    maxAnswer = 9;
    targetBlanks = isAdaptiveLevel1 ? 4 : lerpRound(3, 5, p);
    parTimeSeconds = isAdaptiveLevel1 ? 45 : lerpRound(0.85 * 45, 45, p);
  } else if (effectiveRating < 200) {
    const p = progressInRange(effectiveRating, 140, 200);
    gridSize = 4;
    tierName = 'Adept';
    allowedOperators = ['+', '-', '*'];
    maxOperand = lerpRound(6, 8, p);
    maxAnswer = lerpRound(12, 24, p);
    targetBlanks = lerpRound(6, 9, p);
    parTimeSeconds = lerpRound(0.85 * 80, 80, p);
  } else if (effectiveRating < 270) {
    const p = progressInRange(effectiveRating, 200, 270);
    gridSize = 5;
    tierName = 'Tactician';
    allowedOperators = p >= 0.35 ? ['+', '-', '*', '/'] : ['+', '-', '*'];
    maxOperand = lerpRound(8, 9, p);
    maxAnswer = lerpRound(24, 45, p);
    targetBlanks = lerpRound(9, 13, p);
    parTimeSeconds = lerpRound(0.85 * 130, 130, p);
  } else if (effectiveRating < 350) {
    const p = progressInRange(effectiveRating, 270, 350);
    gridSize = 6;
    tierName = 'Architect';
    allowedOperators = ['+', '-', '*', '/'];
    maxOperand = lerpRound(9, 12, p);
    maxAnswer = lerpRound(45, 72, p);
    targetBlanks = lerpRound(12, 17, p);
    parTimeSeconds = lerpRound(0.85 * 190, 190, p);
  } else {
    const p = progressInRange(effectiveRating, 350, 450);
    gridSize = 7;
    tierName = 'Grandmaster';
    allowedOperators = ['+', '-', '*', '/'];
    maxOperand = 12;
    maxAnswer = lerpRound(72, 99, p);
    targetBlanks = lerpRound(15, 19, p);
    parTimeSeconds = lerpRound(0.85 * 260, 260, p);

    if (effectiveRating > 450) {
      targetBlanks = Math.min(21, targetBlanks + Math.floor((effectiveRating - 450) / 30));
    }
  }

  const profile: DifficultyProfile = {
    tierName,
    gridSize,
    allowedOperators,
    minValue: 1,
    maxOperand,
    maxAnswer,
    targetBlanks,
    parTimeSeconds,
    operandCap: 15,
  };

  if (!overrideGridSize && effectiveRating > 450) {
    applyPostCapGrowth(profile, effectiveRating - 450);
  }

  profile.operandCap = getOperandCap(profile);
  return profile;
}
