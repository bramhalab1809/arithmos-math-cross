export type MathOperator = '+' | '-' | '*' | '/';
export type ConnectorSymbol = MathOperator | '=' | '';

export interface DifficultyProfile {
  tierName: string;
  gridSize: number; // 3 to 7
  allowedOperators: MathOperator[];
  minValue: number;
  maxOperand: number;
  maxAnswer: number;
  targetBlanks: number;
  parTimeSeconds: number;
  operandCap: number;
}

export interface CellData {
  row: number;
  col: number;
  solution: number;
  isClue: boolean;
  userValue: string;
  isHinted: boolean;
  isError: boolean;
  hasStar?: boolean;
  /** True if this grid coordinate is an architectural cutout or wall rather than a number cell */
  isVoid?: boolean;
  /** True if this void cell should render as a crossed-out [X] labyrinth block; false for open cross cutout */
  isWall?: boolean;
  /** True if this cell is a multi-directional '=' convergence Hub (e.g. 4-Way '=' Center Hub) */
  isHub?: boolean;
}

export interface PuzzleEquation {
  id: string;
  axis: 'row' | 'col';
  /** Ordered operand coordinates evaluated left-to-right / top-to-bottom via evaluateLinearChain */
  operandCells: { row: number; col: number }[];
  /** Operators between consecutive operandCells (length = operandCells.length - 1) */
  ops: MathOperator[];
  /** Target answer cell coordinate on the other side of '=' */
  resultCell: { row: number; col: number };
  /** Location of the '=' connector for board status coloring */
  equalsConnector: { type: 'h' | 'v'; row: number; col: number };
  /** Short UI label for EquationBar (e.g. "R1", "Left → Hub", "Hub ← Right", "Top ↓ Hub", "Hub ↑ Bottom") */
  label: string;
}

export interface MathCrosswordPuzzle {
  id: string;
  level: number;
  ratingAtGeneration: number;
  profile: DifficultyProfile;
  size: number; // Logical grid dimension
  cells: CellData[][];
  rowOps: MathOperator[][];
  colOps: MathOperator[][];
  /** Optional explicit horizontal connector symbols [r][c] between (r,c) and (r,c+1) */
  hConnectors?: ConnectorSymbol[][];
  /** Optional explicit vertical connector symbols [r][c] between (r,c) and (r+1,c) */
  vConnectors?: ConnectorSymbol[][];
  /** Optional explicit equations list for Hardcore 4-Way '=' Hub & Labyrinth topologies */
  equations?: PuzzleEquation[];
  /** Optional architecture name badge (e.g. "4-Way Cross (+)", "Chakravyuh Ring", "Grand Labyrinth") */
  structureName?: string;
  verifiedSolutionsCount: number;
  generationSteps: number;
  flow?: PuzzleFlowMetadata;
}

export interface PuzzleFlowMetadata {
  firstMoves: number;
  domino: boolean;
  relief: boolean;
  easeApplied: boolean;
  paced?: number;
}

export interface LogicalDeductionHint {
  row: number;
  col: number;
  axis: 'row' | 'col';
  lineIndex: number;
  value: number;
  explanation: string;
}

export interface RatingAdjustmentResult {
  previousRating: number;
  newRating: number;
  delta: number;
  performanceLabel: string;
  timeRatio: number;
}
