export type MathOperator = '+' | '-' | '*' | '/';

export interface DifficultyProfile {
  tierName: string;
  gridSize: number; // 3 to 7
  allowedOperators: MathOperator[];
  minValue: number;
  maxOperand: number;
  maxAnswer: number;
  targetBlanks: number;
  parTimeSeconds: number;
  operandCap: number;
}

export interface CellData {
  row: number;
  col: number;
  solution: number;
  isClue: boolean;
  userValue: string;
  isHinted: boolean;
  isError: boolean;
  hasStar?: boolean;
}

export interface MathCrosswordPuzzle {
  id: string;
  level: number;
  ratingAtGeneration: number;
  profile: DifficultyProfile;
  size: number; // N (3 to 7)
  cells: CellData[][];
  /**
   * rowOps[r][c] is the operator between cells[r][c] and cells[r][c+1] for c in 0..size-3.
   * Between cells[r][size-2] and cells[r][size-1] is always '='.
   */
  rowOps: MathOperator[][];
  /**
   * colOps[r][c] is the operator between cells[r][c] and cells[r+1][c] for r in 0..size-3.
   * Between cells[size-2][c] and cells[size-1][c] is always '='.
   */
  colOps: MathOperator[][];
  verifiedSolutionsCount: number;
  generationSteps: number;
  flow?: PuzzleFlowMetadata;
}

export interface PuzzleFlowMetadata {
  firstMoves: number;
  domino: boolean;
  relief: boolean;
  easeApplied: boolean;
  paced?: number;
}

export interface LogicalDeductionHint {
  row: number;
  col: number;
  axis: 'row' | 'col';
  lineIndex: number;
  value: number;
  explanation: string;
}

export interface RatingAdjustmentResult {
  previousRating: number;
  newRating: number;
  delta: number;
  performanceLabel: string;
  timeRatio: number;
}
