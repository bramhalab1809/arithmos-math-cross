import { CellData, DifficultyProfile, MathCrosswordPuzzle, MathOperator } from './types';
import { getDifficultyProfile } from './difficulty';
import { countPuzzleSolutions } from './uniqueness';
import { getOperandCap } from './valueDomain';
import { randomInt, shuffleArray, generateValidGridSolution } from './gridBuilder';
import { getPacedRating, isReliefLevel } from './pacing';
import { countFirstMoves } from './flow';
import { generateDominoPuzzle } from './dominoDig';

export { randomInt, shuffleArray, generateValidGridSolution };

export interface GeneratePuzzleOptions {
  blanksScale?: number;
  dominoOnly?: boolean;
  minFirstMoves?: number;
  easeApplied?: boolean;
  profileOverride?: Partial<DifficultyProfile>;
}

export function generateDeterministicFallbackGrid(profile: DifficultyProfile): {
  grid: number[][];
  rowOps: MathOperator[][];
  colOps: MathOperator[][];
} {
  const N = profile.gridSize;
  const maxOp = Math.max(4, Math.min(12, profile.maxOperand));
  const grid: number[][] = Array.from({ length: N }, () => new Array(N).fill(1));
  const rowOps: MathOperator[][] = Array.from({ length: N }, () => new Array(N - 2).fill('+'));
  const colOps: MathOperator[][] = Array.from({ length: N - 2 }, () => new Array(N).fill('+'));

  for (let r = 0; r < N - 1; r++) {
    let rSum = 0;
    for (let c = 0; c < N - 1; c++) {
      const val = randomInt(1, maxOp);
      grid[r][c] = val;
      rSum += val;
    }
    grid[r][N - 1] = rSum;
  }
  for (let c = 0; c < N; c++) {
    let cSum = 0;
    for (let r = 0; r < N - 1; r++) cSum += grid[r][c];
    grid[N - 1][c] = cSum;
  }
  return { grid, rowOps, colOps };
}

export function generateMathCrossword(
  rating: number,
  level: number,
  overrideGridSize?: number | null,
  options?: GeneratePuzzleOptions
): MathCrosswordPuzzle {
  const isAdaptive = !overrideGridSize || overrideGridSize < 3 || overrideGridSize > 7;
  const relief = isReliefLevel(level);
  const isDomino = Boolean(
    options?.dominoOnly ||
    (isAdaptive && level <= 10) ||
    relief ||
    (!isAdaptive && level <= 3)
  );
  const effectivePacedRating = isAdaptive ? getPacedRating(rating, level) : rating;
  const baseProfile = getDifficultyProfile(rating, level, overrideGridSize);
  const profile: DifficultyProfile = options?.profileOverride ? { ...baseProfile, ...options.profileOverride } : baseProfile;
  const N = profile.gridSize;

  if (isDomino) {
    return generateDominoPuzzle(profile, {
      blanksScale: options?.blanksScale,
      level,
      rating: effectivePacedRating,
      easeApplied: options?.easeApplied,
      relief,
    });
  }

  const operandCap = profile.operandCap ?? getOperandCap(profile);
  const requested = Math.max(3, Math.round(profile.targetBlanks * (options?.blanksScale ?? 1)));
  const targetBlanks = level === 1 && N === 3 ? 4 : requested;
  const minFirstMoves = options?.minFirstMoves ?? (level < 30 ? 2 : 1);

  let bestPuzzle: MathCrosswordPuzzle | null = null;
  let bestFirstMoves = -1;

  for (let attempt = 0; attempt < 6; attempt++) {
    let generated: { grid: number[][]; rowOps: MathOperator[][]; colOps: MathOperator[][] } | null = null;
    for (let trySolve = 0; trySolve < 50; trySolve++) {
      generated = generateValidGridSolution(profile);
      if (generated) break;
    }
    if (!generated) generated = generateDeterministicFallbackGrid(profile);

    const { grid, rowOps, colOps } = generated;
    const boardState: (number | null)[][] = grid.map((row) => [...row]);

    const allCoords: [number, number][] = [];
    for (let r = 0; r < N; r++) {
      for (let c = 0; c < N; c++) allCoords.push([r, c]);
    }
    const shuffledCoords = shuffleArray(allCoords);

    let blanks = 0;
    let solverSteps = 0;
    for (const [r, c] of shuffledCoords) {
      if (blanks >= targetBlanks) break;
      const rowClues = boardState[r].filter((v) => v !== null).length;
      let colClues = 0;
      for (let rr = 0; rr < N; rr++) {
        if (boardState[rr][c] !== null) colClues++;
      }
      if (rowClues <= 1 || colClues <= 1) continue;

      const backup = boardState[r][c];
      boardState[r][c] = null;
      const validation = countPuzzleSolutions(boardState, rowOps, colOps, profile.maxAnswer, 2, 5000, operandCap);
      solverSteps += validation.steps;

      if (validation.solutions === 1 && !validation.timedOut) {
        blanks++;
      } else {
        boardState[r][c] = backup;
      }
    }

    const cells: CellData[][] = [];
    for (let r = 0; r < N; r++) {
      const rowCells: CellData[] = [];
      for (let c = 0; c < N; c++) {
        const isClue = boardState[r][c] !== null;
        rowCells.push({
          row: r,
          col: c,
          solution: grid[r][c],
          isClue,
          userValue: isClue ? String(grid[r][c]) : '',
          isHinted: false,
          isError: false,
        });
      }
      cells.push(rowCells);
    }

    const candidate: MathCrosswordPuzzle = {
      id: `puzzle-${level}-${Date.now()}-${randomInt(100, 999)}`,
      level,
      ratingAtGeneration: effectivePacedRating,
      profile,
      size: N,
      cells,
      rowOps,
      colOps,
      verifiedSolutionsCount: 1,
      generationSteps: solverSteps,
      flow: {
        firstMoves: 0,
        domino: false,
        relief,
        easeApplied: Boolean(options?.easeApplied),
        paced: effectivePacedRating,
      },
    };
    const fm = countFirstMoves(candidate);
    candidate.flow!.firstMoves = fm;

    if (fm >= minFirstMoves && blanks >= Math.floor(targetBlanks * 0.7)) {
      return candidate;
    }

    if (fm > bestFirstMoves || (fm === bestFirstMoves && (!bestPuzzle || blanks > bestPuzzle.generationSteps))) {
      bestPuzzle = candidate;
      bestFirstMoves = fm;
    }
  }

  if (!bestPuzzle || bestFirstMoves < 1) {
    return generateDominoPuzzle(profile, {
      blanksScale: options?.blanksScale,
      level,
      rating: effectivePacedRating,
      easeApplied: options?.easeApplied,
      relief,
    });
  }

  return bestPuzzle;
}
