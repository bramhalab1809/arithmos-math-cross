import {
  LogicalDeductionHint,
  MathCrosswordPuzzle,
  formatPuzzleEquationPreview,
  getPuzzleEquations,
  getRequiredValueForCellInEquation,
} from './index';

export function findLogicalDeductionHint(
  puzzle: MathCrosswordPuzzle,
  focusedPos: { row: number; col: number } | null
): LogicalDeductionHint | null {
  const equations = getPuzzleEquations(puzzle);

  // Check each equation for exactly 1 empty cell
  for (const eq of equations) {
    const allPts = [...eq.operandCells, eq.resultCell];
    const emptyPts = allPts.filter((p) => {
      const c = puzzle.cells[p.row]?.[p.col];
      return c && !c.isVoid && !c.isClue && c.userValue.trim() === '';
    });

    if (emptyPts.length === 1) {
      const targetPos = emptyPts[0];
      const targetCell = puzzle.cells[targetPos.row][targetPos.col];
      const deducedVal =
        getRequiredValueForCellInEquation(puzzle, eq, targetPos.row, targetPos.col) ?? targetCell.solution;
      const preview = formatPuzzleEquationPreview(puzzle, eq);

      return {
        row: targetPos.row,
        col: targetPos.col,
        axis: eq.axis,
        lineIndex: eq.axis === 'row' ? targetPos.row : targetPos.col,
        value: deducedVal,
        explanation: `${eq.label} has one unknown left: ${preview} → ? = ${deducedVal}`,
      };
    }
  }

  // Fallback: if focused cell is unsolved and not void, reveal it
  if (focusedPos) {
    const fCell = puzzle.cells[focusedPos.row]?.[focusedPos.col];
    if (fCell && !fCell.isVoid && !fCell.isClue && parseInt(fCell.userValue, 10) !== fCell.solution) {
      return {
        row: fCell.row,
        col: fCell.col,
        axis: 'row',
        lineIndex: fCell.row,
        value: fCell.solution,
        explanation: `Cell at Row ${fCell.row + 1}, Col ${fCell.col + 1} resolves to ${fCell.solution}.`,
      };
    }
  }

  // Final fallback: first unsolved non-void cell
  for (let r = 0; r < puzzle.size; r++) {
    for (let c = 0; c < puzzle.size; c++) {
      const cell = puzzle.cells[r][c];
      if (!cell.isVoid && !cell.isClue && parseInt(cell.userValue, 10) !== cell.solution) {
        return {
          row: r,
          col: c,
          axis: 'row',
          lineIndex: r,
          value: cell.solution,
          explanation: `Cell at Row ${r + 1}, Col ${c + 1} resolves to ${cell.solution}.`,
        };
      }
    }
  }

  return null;
}
