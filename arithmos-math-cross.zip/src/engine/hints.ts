import { LogicalDeductionHint, MathCrosswordPuzzle, MathOperator } from './types';
import { formatLinearEquationString } from './ops';

/**
 * Finds the clearest next logical step for the player (a row or column with 1 remaining blank)
 * so hints teach the linear crossword deduction rather than just dumping numbers.
 */
export function findLogicalDeductionHint(
  puzzle: MathCrosswordPuzzle,
  focusedPos: { row: number; col: number } | null
): LogicalDeductionHint | null {
  const N = puzzle.size;

  // Build current effective board using solution values for already-correct cells and clues
  const currentBoard: (number | null)[][] = puzzle.cells.map((row) =>
    row.map((cell) => {
      if (cell.isClue) return cell.solution;
      const parsed = parseInt(cell.userValue, 10);
      if (parsed === cell.solution) return cell.solution;
      return null;
    })
  );

  // First check if any row has exactly 1 unknown
  for (let r = 0; r < N; r++) {
    const unknowns: number[] = [];
    for (let c = 0; c < N; c++) {
      if (currentBoard[r][c] === null) unknowns.push(c);
    }
    if (unknowns.length === 1) {
      const targetCol = unknowns[0];
      const cell = puzzle.cells[r][targetCol];
      const eqPreview = formatLinearEquationString(
        puzzle.cells[r].map((cl, idx) => (idx === targetCol ? '?' : cl.solution)),
        puzzle.rowOps[r]
      );
      return {
        row: r,
        col: targetCol,
        axis: 'row',
        lineIndex: r,
        value: cell.solution,
        explanation: `Row ${r + 1} has one unknown left: ${eqPreview} → ? = ${cell.solution}`,
      };
    }
  }

  // Next check if any column has exactly 1 unknown
  for (let c = 0; c < N; c++) {
    const unknowns: number[] = [];
    for (let r = 0; r < N; r++) {
      if (currentBoard[r][c] === null) unknowns.push(r);
    }
    if (unknowns.length === 1) {
      const targetRow = unknowns[0];
      const cell = puzzle.cells[targetRow][c];
      const colOpsArr: MathOperator[] = [];
      for (let rr = 0; rr < N - 2; rr++) colOpsArr.push(puzzle.colOps[rr][c]);
      const eqPreview = formatLinearEquationString(
        puzzle.cells.map((rowArr, idx) => (idx === targetRow ? '?' : rowArr[c].solution)),
        colOpsArr
      );
      return {
        row: targetRow,
        col: c,
        axis: 'col',
        lineIndex: c,
        value: cell.solution,
        explanation: `Column ${c + 1} has one unknown left: ${eqPreview} → ? = ${cell.solution}`,
      };
    }
  }

  // Fallback: if focused cell is unsolved, reveal it; otherwise reveal first unsolved cell
  if (focusedPos) {
    const fCell = puzzle.cells[focusedPos.row]?.[focusedPos.col];
    if (fCell && !fCell.isClue && parseInt(fCell.userValue, 10) !== fCell.solution) {
      return {
        row: fCell.row,
        col: fCell.col,
        axis: 'row',
        lineIndex: fCell.row,
        value: fCell.solution,
        explanation: `Intersection at Row ${fCell.row + 1}, Col ${fCell.col + 1} resolves to ${fCell.solution}.`,
      };
    }
  }

  for (let r = 0; r < N; r++) {
    for (let c = 0; c < N; c++) {
      const cell = puzzle.cells[r][c];
      if (!cell.isClue && parseInt(cell.userValue, 10) !== cell.solution) {
        return {
          row: r,
          col: c,
          axis: 'row',
          lineIndex: r,
          value: cell.solution,
          explanation: `Intersection at Row ${r + 1}, Col ${c + 1} resolves to ${cell.solution}.`,
        };
      }
    }
  }

  return null;
}
