/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { loadUiState, saveUiScreen, UiScreen } from './storage/uiState';
import { loadHistory } from './storage/history';
import { getActiveLabContext, loadLabPacks } from './storage/packs';
import { MistakeRecord, setActiveMistakeId } from './storage/mistakes';
import { useSettings } from './features/settings/useSettings';
import { HomeSettingsSheet, GameSettingsSheet } from './features/settings/SettingsSheet';
import { useGameSession } from './features/game/hooks/useGameSession';
import { HomePage } from './pages/HomePage';
import { GamePage } from './pages/GamePage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { LabPage } from './pages/LabPage';
import { LevelMapPage } from './pages/LevelMapPage';
import { MistakeHubPage } from './pages/MistakeHubPage';
import { LivingBirdsOverlay } from './features/birds/LivingBirdsOverlay';
import { Loader2 } from './icons';

export default function App() {
  const settings = useSettings();
  const [screen, setScreen] = useState<UiScreen>(() => loadUiState().screen);
  const [mapMode, setMapMode] = useState<'endless' | 'star' | 'practice' | 'hardcore'>('endless');
  const [mapPracticeGrid, setMapPracticeGrid] = useState<'auto' | 3 | 4 | 5 | 6 | 7>('auto');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [analyticsEntryId, setAnalyticsEntryId] = useState<string | undefined>(undefined);
  const [storageRevision, setStorageRevision] = useState(0);

  const {
    state, dispatch, inputRefs, startPuzzleLevel, startLabLevel,
    handleRetryPuzzle, handleSwapPuzzle, cancelGeneration,
    handleCellInputChange, handleTriggerHint, handleValidateBoard,
    handleUndo, handleRedo, handleCellKeyDown, handleNumpadPress,
    resetCellAppendWindow,
  } = useGameSession({
    controls: settings.controls,
    darkMode: settings.resolvedDarkMode,
    muted: settings.muted,
    isSettingsOpen,
  });

  const navigate = (nextScreen: UiScreen, pushHistory = true) => {
    setScreen(nextScreen);
    saveUiScreen(nextScreen);
    if (pushHistory && typeof window !== 'undefined') {
      try {
        window.history.pushState({ arithmosScreen: nextScreen }, '');
      } catch { /* ignore */ }
    }
  };

  const handleOpenSettings = () => {
    cancelGeneration();
    if (state.gameState === 'PLAYING') dispatch({ type: 'PAUSE' });
    setIsSettingsOpen(true);
  };

  const handleResetProgress = () => {
    cancelGeneration();
    dispatch({ type: 'GO_TO_TITLE' });
    setStorageRevision((r) => r + 1);
  };

  const handleOpenAnalytics = (entryId?: string) => {
    const targetId =
      entryId ??
      (state.gameState === 'ROUND_SUMMARY' || state.gameState === 'TIME_UP' ? loadHistory()[0]?.id : undefined);
    setAnalyticsEntryId(targetId);
    navigate('analytics');
  };

  const handleCloseAnalytics = () => {
    if (state.gameState === 'ROUND_SUMMARY' || state.gameState === 'TIME_UP') dispatch({ type: 'GO_TO_TITLE' });
    setAnalyticsEntryId(undefined);
    navigate('home');
  };

  const handleStartMistakeRepair = (entry: MistakeRecord) => {
    setActiveMistakeId(entry.id);
    navigate('game');
    startPuzzleLevel('repair', 220, entry.level, entry.gridSize, true);
  };

  const handleExitGameToHub = () => {
    dispatch({ type: 'GO_TO_TITLE' });
    if (state.mode === 'lab') navigate('lab');
    else if (state.mode === 'repair') navigate('mistakes');
    else if (state.mode === 'endless' || state.mode === 'star' || state.mode === 'practice' || state.mode === 'hardcore') {
      setMapMode(state.mode);
      if (state.mode === 'practice' || state.mode === 'hardcore') setMapPracticeGrid((state.overrideSize as 3 | 4 | 5 | 6 | 7) || 'auto');
      navigate('levelMap');
    } else navigate('home');
  };

  useEffect(() => {
    const onPopState = () => {
      if (isSettingsOpen) { setIsSettingsOpen(false); return; }
      if (state.gameState !== 'TITLE_MENU') { handleExitGameToHub(); return; }
      if (screen !== 'home') navigate('home', false);
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  });

  const handleNextCustomAction = (): boolean => {
    if (state.mode === 'lab') {
      const ctx = getActiveLabContext();
      if (ctx) {
        const pack = loadLabPacks().find((p) => p.id === ctx.packId);
        if (pack && ctx.levelIndex + 1 < pack.levels.length) {
          startLabLevel(pack, ctx.levelIndex + 1);
          return true;
        }
      }
      dispatch({ type: 'GO_TO_TITLE' });
      navigate('lab');
      return true;
    }
    if (state.mode === 'repair') {
      dispatch({ type: 'GO_TO_TITLE' });
      navigate('mistakes');
      return true;
    }
    return false;
  };

  return (
    <div className={settings.resolvedDarkMode ? 'dark' : ''}>
      <LivingBirdsOverlay />

      {screen === 'analytics' ? (
        <AnalyticsPage
          darkMode={settings.resolvedDarkMode} initialMode={state.mode} initialEntryId={analyticsEntryId}
          onBack={handleCloseAnalytics}
          onPlayMode={(m) => {
            if (m === 'endless' || m === 'star' || m === 'practice' || m === 'hardcore') { setMapMode(m); navigate('levelMap'); }
            else if (m === 'repair') navigate('mistakes');
            else navigate('lab');
          }}
        />
      ) : screen === 'levelMap' && state.gameState === 'TITLE_MENU' ? (
        <LevelMapPage
          mode={mapMode} darkMode={settings.resolvedDarkMode} initialPracticeGrid={mapPracticeGrid}
          onBack={() => navigate('home')}
          onSelectLevel={(lvl, sizeOverride, rating) => {
            if (mapMode === 'practice' || mapMode === 'hardcore') setMapPracticeGrid((sizeOverride as 3 | 4 | 5 | 6 | 7) || 'auto');
            navigate('game');
            startPuzzleLevel(mapMode, rating, lvl, sizeOverride, true);
          }}
        />
      ) : screen === 'lab' && state.gameState === 'TITLE_MENU' ? (
        <LabPage
          darkMode={settings.resolvedDarkMode} onBack={() => navigate('home')}
          onStartLevel={(pack, idx) => { navigate('game'); startLabLevel(pack, idx); }}
        />
      ) : screen === 'mistakes' && state.gameState === 'TITLE_MENU' ? (
        <MistakeHubPage
          darkMode={settings.resolvedDarkMode} onBack={() => navigate('home')}
          onStartRepair={handleStartMistakeRepair}
        />
      ) : state.gameState === 'TITLE_MENU' ? (
        <>
          <HomePage
            key={storageRevision} darkMode={settings.resolvedDarkMode}
            onResumeGame={(session) => { navigate('game'); dispatch({ type: 'RESUME_SAVED_SESSION', session }); }}
            onStartGame={(mode, rating, level, size) => { navigate('game'); startPuzzleLevel(mode, rating, level, size, true); }}
            onOpenLevelMap={(m, pSize) => { setMapMode(m); if (pSize) setMapPracticeGrid(pSize); navigate('levelMap'); }}
            onOpenSettings={handleOpenSettings} onOpenAnalytics={handleOpenAnalytics}
            onOpenLab={() => navigate('lab')} onOpenMistakes={() => navigate('mistakes')}
          />
          {state.isGenerating && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs">
              <div className={`flex items-center gap-3 px-6 py-4 rounded-2xl shadow-xl border ${settings.resolvedDarkMode ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-800'}`}>
                <Loader2 className="w-5 h-5 animate-spin motion-reduce:animate-none text-amber-500" />
                <span className="text-sm font-semibold tracking-wide">Preparing puzzle</span>
              </div>
            </div>
          )}
        </>
      ) : (
        <GamePage
          state={state} dispatch={dispatch} inputRefs={inputRefs}
          controls={settings.controls[state.mode] || settings.controls.endless}
          isSettingsOpen={isSettingsOpen} startPuzzleLevel={startPuzzleLevel}
          handleRetryPuzzle={handleRetryPuzzle} handleSwapPuzzle={handleSwapPuzzle}
          handleCellInputChange={handleCellInputChange} handleTriggerHint={handleTriggerHint}
          handleValidateBoard={handleValidateBoard} handleUndo={handleUndo} handleRedo={handleRedo}
          handleCellKeyDown={handleCellKeyDown} handleNumpadPress={handleNumpadPress}
          resetCellAppendWindow={resetCellAppendWindow}
          onOpenSettings={handleOpenSettings} onNextCustomAction={handleNextCustomAction}
          onExitToHub={handleExitGameToHub}
        />
      )}

      {state.gameState === 'TITLE_MENU' && screen !== 'analytics' ? (
        <HomeSettingsSheet
          isOpen={isSettingsOpen} muted={settings.muted} volume={settings.volume}
          themeMode={settings.themeMode} darkMode={settings.resolvedDarkMode}
          onClose={() => setIsSettingsOpen(false)} onToggleMute={settings.toggleMute}
          onChangeVolume={settings.setVolume} onSelectThemeMode={settings.setThemeMode}
          onResetAllProgress={handleResetProgress}
        />
      ) : (
        <GameSettingsSheet
          isOpen={isSettingsOpen && screen !== 'analytics'} mode={state.mode}
          muted={settings.muted} volume={settings.volume} darkMode={settings.resolvedDarkMode}
          controls={settings.controls[state.mode] || settings.controls.endless}
          onClose={() => setIsSettingsOpen(false)} onToggleMute={settings.toggleMute}
          onChangeVolume={settings.setVolume} onToggleControl={(key) => settings.toggleModeControl(state.mode, key)}
        />
      )}
    </div>
  );
}
