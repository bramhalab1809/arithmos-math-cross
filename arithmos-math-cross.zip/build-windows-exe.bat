@echo off
title Arithmos — Windows .EXE Builder
echo ========================================================
echo   Arithmos — Building Windows Desktop (.EXE) Installer
echo ========================================================
echo.
call npm install
call npm install --no-save electron electron-builder
call npm run dist:exe
echo.
echo Build complete! Check the "release-builds" folder for your Arithmos .exe files.
pause
