const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('node:path');
const fs = require('node:fs');

function getSaveFilePath() {
  return path.join(app.getPath('userData'), 'arithmos-storage.json');
}

ipcMain.handle('arithmos:read-save', async () => {
  try {
    const filePath = getSaveFilePath();
    if (!fs.existsSync(filePath)) return null;
    const raw = await fs.promises.readFile(filePath, 'utf-8');
    return JSON.parse(raw);
  } catch {
    return null;
  }
});

ipcMain.handle('arithmos:write-save', async (_event, data) => {
  try {
    if (!data || typeof data !== 'object') return false;
    const filePath = getSaveFilePath();
    await fs.promises.mkdir(path.dirname(filePath), { recursive: true });
    await fs.promises.writeFile(filePath, JSON.stringify(data, null, 2), 'utf-8');
    return true;
  } catch {
    return false;
  }
});

function createMainWindow() {
  const iconPath = path.join(__dirname, '../public/icon-512.png');
  const win = new BrowserWindow({
    title: 'Arithmos',
    icon: fs.existsSync(iconPath) ? iconPath : undefined,
    width: 1280,
    height: 820,
    minWidth: 380,
    minHeight: 640,
    autoHideMenuBar: true,
    backgroundColor: '#0B0F17',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://') || url.startsWith('http://')) {
      shell.openExternal(url);
    }
    return { action: 'deny' };
  });

  const distIndex = path.join(__dirname, '../dist/index.html');
  if (fs.existsSync(distIndex)) {
    win.loadFile(distIndex);
  } else {
    win.loadURL('http://localhost:3000');
  }
}

app.whenReady().then(() => {
  createMainWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
