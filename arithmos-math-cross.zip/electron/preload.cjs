const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('arithmosElectron', {
  readSaveFile: () => ipcRenderer.invoke('arithmos:read-save'),
  writeSaveFile: (data) => ipcRenderer.invoke('arithmos:write-save', data),
});
