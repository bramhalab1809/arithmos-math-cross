# Audio Assets & Synthesis Licenses

## Procedural Sound Effects & Sound Themes
- **Source**: 100% Client-Side Web Audio API Synthesizer (`src/audio/audioBuffers.ts`, `src/audio/themes/`, and `src/audio/customAudioSynth.ts`).
- **Nature**: Synthesized in real-time using mathematical harmonic formulas (sine, triangle, square, sawtooth waves, exponential envelopes, and modal scale tuning across 8 distinct sound themes: Dream Box, Zen Wood, Arcade, Crystal, Lo-Fi, Space, Classic, and Original).
- **Safety**: Evaluated using a sandboxed recursive descent mathematical expression engine (`src/audio/expr/`) with no dynamic code execution (`no eval`, `no new Function`).
- **License**: Public Domain / Apache 2.0 / MIT. Zero third-party audio files, zero network calls, zero tracking.

## Ambient Background Track (`ambient-loop.mp3`)
- **File**: `public/audio/ambient-loop.mp3`
- **Nature**: AI-generated ambient composition loop created specifically for Arithmos.
- **License**: Royalty-free for use within the Arithmos application.
