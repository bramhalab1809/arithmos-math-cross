import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

const CRC_TABLE = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  CRC_TABLE[n] = c >>> 0;
}

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function makeChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
  return Buffer.concat([len, typeBuf, data, crcBuf]);
}

function encodePng(size, rgba) {
  const raw = Buffer.alloc(size * (size * 4 + 1));
  for (let y = 0; y < size; y++) {
    const rowStart = y * (size * 4 + 1);
    raw[rowStart] = 0;
    rgba.copy(raw, rowStart + 1, y * size * 4, (y + 1) * size * 4);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0);
  ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  return Buffer.concat([sig, makeChunk('IHDR', ihdr), makeChunk('IDAT', zlib.deflateSync(raw)), makeChunk('IEND', Buffer.alloc(0))]);
}

const GLYPHS = {
  '3': ['11111', '00001', '01111', '00001', '11111'],
  '4': ['10010', '10010', '11111', '00010', '00010'],
  '2': ['11111', '00001', '11111', '10000', '11111'],
  '7': ['11111', '00001', '00010', '00100', '00100'],
};

function renderArithmosIcon(size) {
  const buf = Buffer.alloc(size * size * 4);
  const s = size / 512;
  const setPx = (x, y, r, g, b, a = 255) => {
    if (x < 0 || y < 0 || x >= size || y >= size) return;
    const idx = (y * size + x) * 4;
    buf[idx] = r; buf[idx + 1] = g; buf[idx + 2] = b; buf[idx + 3] = a;
  };
  const inRoundRect = (x, y, rx, ry, rw, rh, rad) => {
    if (x < rx || x >= rx + rw || y < ry || y >= ry + rh) return false;
    const cx = x < rx + rad ? rx + rad : x > rx + rw - rad ? rx + rw - rad : x;
    const cy = y < ry + rad ? ry + rad : y > ry + rh - rad ? ry + rh - rad : y;
    return Math.hypot(x - cx, y - cy) <= rad;
  };
  const fillRoundRect = (rx, ry, rw, rh, rad, fill, stroke, sw = 0) => {
    for (let y = Math.floor(ry * s); y < Math.ceil((ry + rh) * s); y++) {
      for (let x = Math.floor(rx * s); x < Math.ceil((rx + rw) * s); x++) {
        const ux = x / s, uy = y / s;
        if (!inRoundRect(ux, uy, rx, ry, rw, rh, rad)) continue;
        const inner = sw > 0 && inRoundRect(ux, uy, rx + sw, ry + sw, rw - sw * 2, rh - sw * 2, Math.max(2, rad - sw));
        const col = stroke && !inner ? stroke : fill;
        setPx(x, y, col[0], col[1], col[2], 255);
      }
    }
  };
  const drawGlyph = (ch, cx, cy, col) => {
    const grid = GLYPHS[ch];
    const cellW = 14, cellH = 16;
    const ox = cx - (5 * cellW) / 2, oy = cy - (5 * cellH) / 2;
    for (let r = 0; r < 5; r++) {
      for (let c = 0; c < 5; c++) {
        if (grid[r][c] === '1') fillRoundRect(ox + c * cellW, oy + r * cellH, cellW, cellH, 2, col, null, 0);
      }
    }
  };

  fillRoundRect(0, 0, 512, 512, 108, [11, 15, 23], null, 0);
  fillRoundRect(16, 16, 480, 480, 96, [15, 23, 42], [30, 41, 59], 8);
  fillRoundRect(64, 64, 152, 152, 34, [48, 38, 24], [251, 191, 36], 12);
  fillRoundRect(296, 64, 152, 152, 34, [30, 41, 59], [71, 85, 105], 10);
  fillRoundRect(64, 296, 152, 152, 34, [30, 41, 59], [71, 85, 105], 10);
  fillRoundRect(296, 296, 152, 152, 34, [16, 52, 49], [52, 211, 153], 12);

  drawGlyph('3', 140, 140, [253, 230, 138]);
  drawGlyph('4', 372, 140, [241, 245, 249]);
  drawGlyph('2', 140, 372, [241, 245, 249]);
  drawGlyph('7', 372, 372, [110, 231, 183]);

  fillRoundRect(234, 133, 44, 14, 6, [251, 191, 36], null, 0);
  fillRoundRect(249, 118, 14, 44, 6, [251, 191, 36], null, 0);
  fillRoundRect(118, 249, 44, 14, 6, [148, 163, 184], null, 0);
  fillRoundRect(350, 237, 44, 12, 5, [52, 211, 153], null, 0);
  fillRoundRect(350, 261, 44, 12, 5, [52, 211, 153], null, 0);
  fillRoundRect(234, 353, 44, 12, 5, [52, 211, 153], null, 0);
  fillRoundRect(234, 377, 44, 12, 5, [52, 211, 153], null, 0);

  return encodePng(size, buf);
}

const pubDir = path.resolve('public');
fs.mkdirSync(pubDir, { recursive: true });
const png512 = renderArithmosIcon(512);
const png192 = renderArithmosIcon(192);
fs.writeFileSync(path.join(pubDir, 'icon-512.png'), png512);
fs.writeFileSync(path.join(pubDir, 'icon-192.png'), png192);

const androidRes = path.resolve('android/app/src/main/res');
if (fs.existsSync(androidRes)) {
  const dirs = ['mipmap-mdpi', 'mipmap-hdpi', 'mipmap-xhdpi', 'mipmap-xxhdpi', 'mipmap-xxxhdpi'];
  for (const d of dirs) {
    const targetDir = path.join(androidRes, d);
    if (fs.existsSync(targetDir)) {
      fs.writeFileSync(path.join(targetDir, 'ic_launcher.png'), png512);
      fs.writeFileSync(path.join(targetDir, 'ic_launcher_round.png'), png512);
      fs.writeFileSync(path.join(targetDir, 'ic_launcher_foreground.png'), png512);
    }
  }
}
console.log('Generated Arithmos icons: public/icon-512.png & public/icon-192.png');
